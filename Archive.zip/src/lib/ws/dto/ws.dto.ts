import { WS_CODE } from '@/lib/ws/dto/ws.enum.dto';


export interface WsResponseDTO {
	code: WS_CODE;  // 响应码
	msg: string;  // 消息文本
}

export type WsResponseDataDTO<D> = WsResponseDTO & {
	data: D;  // 数据
}
