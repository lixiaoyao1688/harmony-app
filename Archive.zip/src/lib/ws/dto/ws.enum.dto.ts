export enum WS_CODE {
	SUCCESS = 0,
	TOKEN_LACK = 101,  // 缺少参数 token
	OTHER_LOGIN = 105,  // 用户在其他地方登录
	TOKEN_INVALID = 106,  // token无效
}


