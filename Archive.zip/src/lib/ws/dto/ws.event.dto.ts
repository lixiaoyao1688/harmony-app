import { Socket } from 'socket.io-client';
import type { WarnDTO } from '@/modules/warn/dto/warn.dto';
import type { WsResponseDTO } from '@/lib/ws/dto/ws.dto';
import type { CardDTO } from '@/modules/admission/dto/card.dto';
import type { WarnNotifyDeleteDTO } from '@/modules/warn/dto/warn.dto';
import type { AdmissionConfigDTO, WsNoticeSetDTO } from '@/modules/admission/dto/admission.dto';
import type { FingerAddDTO } from '@/modules/glucose/dto/finger.dto';


// ws 事件
export enum WS_EVENT {
	CONNECT = 'connect',
	DISCONNECT = 'disconnect',
	CONNECT_ERROR = 'connect_error',
	
	REPORT_OFFLINE = 'offline',  // 离线通知
	SUBSCRIBE_AND_REPORT_LOGIN = 'login',  // 登录（停用）
	SUBSCRIBE_AND_REPORT_UPDATE_ALL = 'update_all',  // 病人 全量更新
	SUBSCRIBE_AND_REPORT_BOARD = 'board',  // 医院 看板
	SUBSCRIBE_AND_REPORT_WARN = 'update_warn',  // 报警列表
	SUBSCRIBE_AND_REPORT_WARN_ONE = 'warn_one',  // 报警弹窗
	SUBSCRIBE_AND_REPORT_ADMISSION_FINGER = 'admission_finger',  // 指血记录 添加 (已废弃)
	
	SET_ADMISSION_FIND = 'admission_find',  // 病人筛选
	
	// 2024-10-08: 删除病人管理相关的 ws 操作
	SET_DELETE_WARN_POPUP = 'delete_warn_popup',  // 报警弹窗删除
	SET_ADMISSION_ADD = 'admission_add',  // 病人增加
	SET_ADMISSION_DELETE = 'admission_del',  // 病人删除
	SET_ADMISSION_UPDATE = 'admission_update',  // 病人修改
	SET_ADMISSION_CONFIG = 'admission_set',  // 病人设置 (低药量报警/换床)
	
	
	REPORT_ADMISSION_UPDATE_ONE = 'update_one',  // 病人 更新单人
	NOTICE_SET = 'notice_set',  // update_all/update_one 订阅/退订
	
	ADVICE_ADD = 'advice_add',  // 医嘱 上传
	ADVICE_UPDATE = 'advice_update',  // 医嘱 接收（护士）
}

// 报告
export interface ServerToClientEvents {
	offline: (data: WsResponseDTO) => void;  // 离线通知
	login: (e) => void;  // 登录
	update_all: (records: CardDTO[]) => void;  // 全量更新
	update_one: (e: CardDTO) => void;  // 病人 更新单人
	update_warn: (e: WarnDTO[]) => void;  // 报警列表
	warn_one: (e: WarnDTO[]) => void;  // 报警弹窗
	admission_add: (e: WsResponseDTO) => void;  // 病人 增加
	admission_set: (e: WsResponseDTO) => void;  // 病人 设置 (报警/换床)
	board: (e: WsResponseDTO) => void;  // 医院看板
	admission_finger: (e: WsResponseDTO) => void;  // 指血记录 添加
}

// 订阅/设置
export interface ClientToServerEvents {
	login: () => void;  // 登录
	update_all: () => void;  // 全量更新
	update_warn: () => void;  // 报警列表
	warn_one: () => void;  // 报警弹窗
	delete_warn_popup: (data: WarnNotifyDeleteDTO) => void;  // 报警弹窗删除
	admission_add: () => void;  // 病人 增加
	admission_update: () => void;  // 病人 修改
	admission_find: () => void;  // 病人 筛选
	admission_del: () => void;  // 病人 删除
	admission_set: (p: AdmissionConfigDTO) => void;  // 病人 设置
	board: (p: AdmissionConfigDTO) => void;  // 医院看板
	notice_set: (data: WsNoticeSetDTO) => void;
	admission_finger: (p: FingerAddDTO) => void;  // 指血记录 添加
}

// socket 实例
export type TSocket = Socket<ServerToClientEvents, ClientToServerEvents>;
