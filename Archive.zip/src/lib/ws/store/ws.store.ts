import { defineStore } from 'pinia';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { TSocket, WS_EVENT } from '@/lib/ws/dto/ws.event.dto';
import { doWorkAfterLogout } from '@/utils/global.tool';
import { doWorkAfterWsConnected, getSocketInstance, wsGetURI, wsLogger, wsSubscribeFirst } from '@/lib/ws/util/ws.utils';
import { WS_STATUS } from '@/lib/ws/config/ws.config';
import { WS_CODE } from '@/lib/ws/dto/ws.enum.dto';
import { notifyError } from '@/lib/aaruy-design/notify/notify';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useStorageStore } from '@/lib/storage/store/storage.store';
import { printError, printSingle, sendErrorToServer } from '@/lib/log/util/log.util';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import {requestLogout} from '@/modules/user/requests/login.http';
import type { WsResponseDTO } from '@/lib/ws/dto/ws.dto';


interface State {
	socket: TSocket | null;
  isConnecting: boolean;  // 是否首次连接中
  isConnected: boolean;  // 是否连接完成
  isReconnecting: boolean;  // 是否重连中
  isTimeout: boolean;  // 连接是否超时
}

interface Action {
  init: () => Promise<void>;
	connect: (isReconnect?: boolean) => Promise<void>;
	disconnect: () => void;
  listenError: (s: TSocket) => void;
  resolveError: () => void;
	off: (event?: WS_EVENT) => void;  // 移除全部监听器
	on: (event: WS_EVENT, listener: (data: any) => void) => void;
	send: (event: WS_EVENT, payload: unknown, isMobile?: boolean) => void;
}

type Getter = {}

export const useWsStore = defineStore<string, State, Getter, Action>('ws-store', {
	
  state: () => ({
    socket: null,
    isConnecting: false,
    isConnected: false,
    isReconnecting: false,
    isTimeout: false,
  }),
	
  actions: {
    init() {
      return new Promise<void>(resolve => {
        this
          .connect()
          .then(() => {
            doWorkAfterWsConnected();
            resolve();
          })
          .catch(reason => {
            printError('[ERROR][WS]', reason);
          });
      });
    },
    
    listenError(s: TSocket) {
      const screenStore = useScreenStore();
      // 连接建立后断开
      s.on(WS_EVENT.DISCONNECT, (reason: string) => {
        // https://socket.io/zh-CN/docs/v4/client-api/#event-disconnect
        if (reason && reason.includes && reason.includes('timeout')) {
          this.isTimeout = true;
        }
        wsLogger(WS_STATUS.DISCONNECT, '', reason, screenStore.isMobile);
        this.resolveError();
      });
      // 连接建立过程中出错
      s.on(WS_EVENT.CONNECT_ERROR, (e) => {
        if (e && e.message && e.message.includes && e.message.includes('timeout')) {
          this.isTimeout = true;
        }
        if (e && e.message && e.message.includes && e.message.includes('websocket error')) {
          // 检测到断网立即显示超时。见《GBT25000.51-2016符合性声明》 5.3.2 产品质量-性能效率-注。
          this.isTimeout = true;
        }
        wsLogger(WS_STATUS.CONNECT_ERROR, '', e, screenStore.isMobile);
        this.resolveError();
      });
    },
    
    resolveError() {
      const storageStore = useStorageStore();
      this.isConnected = false;
      
      // 重连
      const reconnect = () => {
        if (this.isReconnecting) {
          printSingle('System is reconnecting. Do not reconnect again.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
          return;  // 如果正在重连，不要重复连接。
        }
        setTimeout(() => {
          this.isReconnecting = true;
          printSingle('[WS] Reconnect Trying...', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
          this.connect(true)
            .then(() => {
              printSingle('[WS] Reconnected.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
              doWorkAfterWsConnected();
              console.log('subscribe after reconnected.');
              wsSubscribeFirst();
            })
            .catch(reason => printError('[ERROR][WS]', reason))
            .finally(() => {
              printSingle('[WS] Reconnect Finished.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
              this.isReconnecting = false;
            });
        }, 0);
      };
      
      // 如果本地有 token_hospital, 则认为不是用户主动退出, 重连;
      // 如果本地没有 token_hospital, 说明是正常断开，关闭 socket 实例, 不再接收消息。
      const doWorkByToken = (hasToken: boolean) => {
        if (hasToken) {
          reconnect();
        }
        else {
          if (this.socket) {
            this.socket.close();
          }
        }
      };
      
      if (useScreenStore().isPC) {
        doWorkByToken(storageStore.hasToken());
      }
      else {
        storageStore.hasMobileToken().then(hasToken => {
          doWorkByToken(hasToken);
        });
      }
    },
    
	  connect(isReconnect) {
      return new Promise<void>((resolve, reject) => {

        const screenStore = useScreenStore();
        const storageStore = useStorageStore();
        
        if (isWebHttpUsing()) {
          const WS_TOKEN = storageStore.getToken();
          this.isConnecting = true;
          this.isTimeout = false;
          this.isConnected = false;
          
          if (!WS_TOKEN) {
            sendErrorToServer('TOKEN ERROR', WS_TOKEN, '', 'ws.store.ts');
            doWorkAfterLogout();
            return reject();
          }
          
          // 连接 WS
          const WS_URI = wsGetURI();
          printSingle(`[WS]URL: ${WS_URI}`, LOG_COLOR.NORMAL, screenStore.isMobile);
          printSingle(`[WS]TOKEN: ${WS_TOKEN}`, LOG_COLOR.NORMAL, screenStore.isMobile);
          
          this.socket = getSocketInstance(WS_URI, WS_TOKEN);
          if (this.socket) {
            // 连接建立
            this.socket.on(WS_EVENT.CONNECT, () => {
              this.isConnecting = false;
              this.isTimeout = false;
              this.isConnected = true;
              resolve();
            });
            
            // 离线通知
            this.socket.on(WS_EVENT.REPORT_OFFLINE, (data: WsResponseDTO) => {
              wsLogger(WS_STATUS.RECEIVED, WS_EVENT.REPORT_OFFLINE, data, screenStore.isMobile);
              
              const handler = (data: WsResponseDTO, message: string) => {
                notifyError(message, '请重新登录');
                doWorkAfterLogout();
              };
              
              if (data.code === WS_CODE.TOKEN_LACK) {
                handler(data, '身份验证失败');
              }
              else if (data.code === WS_CODE.OTHER_LOGIN) {
                handler(data, '用户在其他地方登录');
              }
              else if (data.code === WS_CODE.TOKEN_INVALID) {
                // 2025-08-05: 弹窗后直接退出，不调用任何接口。
                handler(data, '登录已过期');
                // requestLogout()
                //   .then(() => {
                //     doWorkAfterLogout();
                //   });
              }
            });
            // 2024-01-15: 移除WS登录操作，不需要监听登录结果了
            // socket.on(WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, (data: WsResponseDTO) => {
            // 	wsLogger(WS_STATUS.RECEIVED, WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, data);
            // 	if (data.code !== WS_CODE.SUCCESS) {
            // 		doWorkAfterLogout();
            // 		return;
            // 	}
            // })
            
            // 处理报错
            this.listenError(this.socket as TSocket);
          }
        }
        else {
          storageStore.getMobileToken().then(token => {
            const WS_TOKEN = token;
            
            if (!isReconnect) {
              this.isConnecting = true;
            }
            
            this.isTimeout = false;
            this.isConnected = false;
            
            if (!WS_TOKEN) {
              sendErrorToServer('TOKEN ERROR', WS_TOKEN, '', 'ws.store.ts');
              doWorkAfterLogout();
              return reject();
            }
            
            // 连接 WS
            const WS_URI = wsGetURI();
            printSingle(`[WS]URL: ${WS_URI}`, LOG_COLOR.NORMAL, screenStore.isMobile);
            printSingle(`[WS]TOKEN: ${WS_TOKEN}`, LOG_COLOR.NORMAL, screenStore.isMobile);
            
            this.socket = getSocketInstance(WS_URI, WS_TOKEN);
            if (this.socket) {
              // 连接建立
              this.socket.on(WS_EVENT.CONNECT, () => {
                this.isConnecting = false;
                this.isTimeout = false;
                this.isConnected = true;
                resolve();
              });
              
              // 离线通知
              this.socket.on(WS_EVENT.REPORT_OFFLINE, (data: WsResponseDTO) => {
                wsLogger(WS_STATUS.RECEIVED, WS_EVENT.REPORT_OFFLINE, data, screenStore.isMobile);
                
                const handler = (data: WsResponseDTO, message: string) => {
                  notifyError(message, '请重新登录');
                  doWorkAfterLogout();
                };
                
                if (data.code === WS_CODE.TOKEN_LACK) {
                  handler(data, '身份验证失败');
                }
                else if (data.code === WS_CODE.OTHER_LOGIN) {
                  handler(data, '用户在其他地方登录');
                }
                else if (data.code === WS_CODE.TOKEN_INVALID) {
                  // 2025-08-05: 弹窗后直接退出，不调用任何接口。
                  handler(data, '登录已过期');
                  // requestLogout()
                  //   .then(() => {
                  //     doWorkAfterLogout();
                  //   });
                }
              });
              
              // 2024-01-15: 移除WS登录操作，不需要监听登录结果了
              // socket.on(WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, (data: WsResponseDTO) => {
              // 	wsLogger(WS_STATUS.RECEIVED, WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, data);
              // 	if (data.code !== WS_CODE.SUCCESS) {
              // 		doWorkAfterLogout();
              // 		return;
              // 	}
              // })
              
              // 报错处理
              this.listenError(this.socket as TSocket);
            }
          });
        }
        
      });
	   
    },
    
	  send(event, payload, isMobile) {
		  if (!this.socket) {
			  printError('[ERROR][WS]', 'Socket Not Found');
			  return;
		  }
      const storageStore = useStorageStore();
      if (isWebHttpUsing()) {
        // WEB
        const token = storageStore.getToken();
        const realPayload = !!payload && typeof payload === 'object' ? { ...payload, token: token } : { token: token };
        wsLogger(WS_STATUS.SEND, event, realPayload, isMobile);
        this.socket.emit(event as any, realPayload);
      }
      else {
        // APP
        storageStore.getMobileToken().then(token => {
          const realPayload = !!payload && typeof payload === 'object' ? { ...payload, token: token } : { token: token };
          wsLogger(WS_STATUS.SEND, event, realPayload, isMobile);
          this.socket ? this.socket.emit(event as any, realPayload) : null;
        });
      }
	  },
   
	  on(event, listener) {
      if (!this.socket) {
        return;
      }
      this.socket.on(event as any, listener);
	  },
   
	  off(event) {
      if (!this.socket) {
        return;
      }
      this.socket.off(event as any);
	  },
   
	  disconnect() {
		  // if (this.socket) {
      //   this.socket.disconnect();
		  // }
      this.isConnecting = false;
      this.isTimeout = false;
      this.isConnected = false;
	  }
   
  }
	
});
