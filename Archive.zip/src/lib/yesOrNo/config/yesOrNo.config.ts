import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export enum YES_OR_NO {
  YES = 1,
  NO = 0,
}

export const YES_OR_NO_ITEM_NO = new SelectItemVO<undefined>({ id: YES_OR_NO.NO, text: '否' });
export const YES_OR_NO_ITEM_YES = new SelectItemVO<undefined>({ id: YES_OR_NO.YES, text: '是' });
export const YES_OR_NO_ITEMS = [
  YES_OR_NO_ITEM_NO,
  YES_OR_NO_ITEM_YES,
];
export const YES_OR_NO_MAP = SelectItemVO.getMap(YES_OR_NO_ITEMS);
