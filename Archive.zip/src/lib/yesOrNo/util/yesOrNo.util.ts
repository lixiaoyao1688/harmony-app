import {YES_OR_NO, YES_OR_NO_MAP} from '@/lib/yesOrNo/config/yesOrNo.config';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import type {ItemType, ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


export function getYesOrNoText2ColorFromEnum(data?: YES_OR_NO): string {
  if (data === undefined) {
    return 'rgb(189,205,219)';
  }
  return data === YES_OR_NO.YES ? 'rgb(0,255,93)' : 'rgb(189,205,219)';
}

export function getYesOrNoText2FromEnum(e: YES_OR_NO): string {
  return e === YES_OR_NO.YES ? '开启' : '关闭';
}

export function getYesOrNoTextFromEnum(e: YES_OR_NO): string {
  return e === YES_OR_NO.YES ? '是' : '否';
}

export function getYesOrNoItemFromBoolean(b: boolean): ItemType2 {
  return SelectItemVO.getItem(YES_OR_NO_MAP, getYesOrNoEnumFromBoolean(b));
}

export function getYesOrNoBooleanFromItem(d: ItemType2): boolean {
  return getYesOrNoBooleanFromEnum(d.id);
}

export function getYesOrNoBooleanFromEnum(e: YES_OR_NO): boolean {
  return e === YES_OR_NO.YES;
}

export function getYesOrNoEnumFromBoolean(b: boolean): YES_OR_NO {
  return b ? YES_OR_NO.YES : YES_OR_NO.NO;
}

export function getItemPayload(t1: string, t2: string): { list: Array<ItemType>, map: Map<number, ItemType> } {
  const list = [
    new SelectItemVO<undefined>({ id: YES_OR_NO.YES, text: t1 }),
    new SelectItemVO<undefined>({ id: YES_OR_NO.NO, text: t2 }),
  ];
  const map = SelectItemVO.getMap<undefined>(list);
  return { list, map };
}
