import Vant from 'vant';
import App from '@/App.vue';
import Antd from 'ant-design-vue';
import router from '@/routers/global.router';
import { createApp } from 'vue';
import { createPinia } from 'pinia';
import { notifyConfig } from '@/lib/aaruy-design/notify/pc/notify.pc';
import { setupDisableWheelDirective } from '@/directives/disable.wheel';
import type { Component } from '@vue/runtime-core';

import '@/styles/global.style.css';
import '@/styles/atom.style.css';
import '@/styles/atom.component.style.css';
import '@/styles/fix.vant.style.css';
import '@/modules/warn/style/warn.style.css';
import 'ant-design-vue/dist/antd.css';
import 'vant/lib/index.css';
import '@/lib/aaruy-design/aaruy.design.variable.css';
import '@/modules/report/styles/print.common.style.css';
import '@/modules/report/styles/printer.style.css';


export const app = createApp(App as unknown as Component);
const pinia = createPinia();
notifyConfig();

// 注册全局自定义指令
// 参考: https://cn.vuejs.org/guide/reusability/custom-directives
setupDisableWheelDirective(app);

app.use(router).use(Antd).use(pinia).use(Vant).mount('#app');
