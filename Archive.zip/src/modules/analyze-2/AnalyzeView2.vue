<script setup lang="ts">
import {useAnalyze2Store} from '@/modules/analyze-2/store/analyze2.store';
import AnalyzeTool2 from '@/modules/analyze-2/components/AnalyzeTool2.vue';
import AnalyzeChart from '@/modules/analyze-2/components/AnalyzeChart.vue';
import AnalyzeTIR2 from '@/modules/analyze-2/components/AnalyzeTIR2.vue';
import AnalyzeCompare from '@/modules/analyze-2/components/AnalyzeCompare.vue';
import AnalyzeBasic from '@/modules/analyze-2/components/AnalyzeBasic.vue';
import AnalyzeGluKind from '@/modules/analyze-2/components/AnalyzeGluKind.vue';
import AnalyzeIns from '@/modules/analyze-2/components/AnalyzeIns.vue';
import AnalyzePart from '@/modules/analyze-2/components/AnalyzePart.vue';


const store = useAnalyze2Store();
</script>

<template>
  <AnalyzeTool2 />
  <div v-if="store.isComparing" class="overflow-x-hidden overflow-y-auto px-16" style="height: calc(100vh - var(--header-height) - 64px);">
    <AnalyzeCompare :index="1" :vo="store.compareVO1" :title="store.compareVO1.objectName" class="pb-8" />
    <AnalyzeCompare :index="2" :vo="store.compareVO2" :title="store.compareVO2.objectName" class="pb-8"  />
  </div>
  <div v-else class="overflow-x-hidden overflow-y-auto px-16 pb-16" style="height: calc(100vh - var(--header-height) - 64px);">
    <div class="flex" style="height: 440px;">
      <div style="width: 800px" class="h-full">
        <AnalyzeBasic :vo="store.indexVO" />
        <div style="height: calc(100% - 140px)" class="pt-8 flex justify-between">
          <template v-if="!store.isIndexLoading && store.filter.isTotalPartSelected">
            <AnalyzeGluKind width="calc(50% - 4px)" height="100%" id="analyze-glu-kind-index" :vo="store.indexVO" />
            <AnalyzePart />
          </template>
          <template v-else>
            <AnalyzeGluKind width="100%" height="100%" id="analyze-glu-kind-index" :vo="store.indexVO" />
          </template>
        </div>
      </div>
      <AnalyzeTIR2 class="flex-1 mr-8 ml-8" :vo="store.indexVO" />
      <AnalyzeIns id="analyze-ins" :vo="store.indexVO" />
    </div>
    <div style="height: calc(100% - 448px); margin-top: 8px; min-height: 448px;">
      <AnalyzeChart id="gluLow" width="100%" height="50%" :disabled="store.indexVO.hasNotData" disabled-text="低血糖发生次数" :c="store.indexVO.gluLowCountConfig" />
      <AnalyzeChart id="gluHigh" width="100%" height="50%" :disabled="store.indexVO.hasNotData" disabled-text="高血糖发生次数" :c="store.indexVO.gluHighCountConfig" class="mt-8" />
    </div>
  </div>
</template>
