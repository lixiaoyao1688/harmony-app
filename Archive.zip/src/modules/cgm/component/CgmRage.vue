<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {COLOR_WHITE_0} from '@/lib/style/color';
import {getDigitCount} from '@/lib/math/util/math.util';
import {getCgmChangeIcon} from '@/modules/cgm/util/cgm.util';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {CGM_CHANGE, CGM_CHANGE_DIRECTION} from '@/modules/cgm/config/cgm.change';
import {
  CGM_RAGE,
  CGM_RAGE_CUSTOM_MAX,
  CGM_RAGE_CUSTOM_MAX_DIGIT,
  CGM_RAGE_CUSTOM_MIN,
  CGM_RAGE_MAP, CGM_RAGES
} from '@/modules/cgm/config/cgm.rage';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import SelectorPage from '@/lib/aaruy-design/selector/page/SelectorPage.vue';
import type {SelectorPageExpose} from '@/lib/aaruy-design/selector/page/type/selector.page.type';


/**
 * 上升警示 组件
 *
 * 归属功能
 * CGM警示设置
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  propRage: CGM_RAGE;
  propValue?: string;  // 自定义值
  width?: string;
}

interface Emit {
	(e: 'change', data: CGM_RAGE): void;
	(e: 'custom-value-change', data: string): void;
}

defineExpose({
  checkError
});

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const rageRef = ref<SelectorPageExpose | null>(null);
const rage = ref<CGM_RAGE>(CGM_RAGE.CLOSE);  // 上升警示项
const rageValue = ref<string>('');  // 上升警示自定义值
const rageValueTips = ref<string>('');  // 上升警示自定义值 错误提示
const isOpened = ref<boolean>(false);
const rageIcon1 = getCgmChangeIcon(CGM_CHANGE.SLOW, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP);
const rageIcon2 = getCgmChangeIcon(CGM_CHANGE.FAST, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP);
const rageIcon3 = getCgmChangeIcon(CGM_CHANGE.VERY_FAST, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP);

const rageConfirmHead = ref<string>('');  // 已保存的上升警示标题
const rageConfirmBody = ref<string>('');  // 已保存的上升警示内容

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.propRage, (data) => {
  rage.value = data;
  rageConfirmHead.value = getConfirmHead(data);
  rageConfirmBody.value = getConfirmBody(data, prop.propValue);
}, { immediate: true });

watch(() => prop.propValue, (data) => {
  const valueText = data || '';
  rageValue.value = valueText;
  if (prop.propRage === CGM_RAGE.CUSTOM) {
    rageConfirmBody.value = getConfirmBody(CGM_RAGE.CUSTOM, data);
  }
  if (valueText !== '') {
    updateTips(getTips(valueText));
  }
}, { immediate: true });

function getConfirmHead(data: CGM_RAGE): string {
  if (data === CGM_RAGE.CLOSE) {
    return '';
  }
  else if (data === CGM_RAGE.UP_1) {
    return rageIcon1;
  }
  else if (data === CGM_RAGE.UP_2) {
    return rageIcon2;
  }
  else if (data === CGM_RAGE.UP_3) {
    return rageIcon3;
  }
  else {
    return '(自定义)';
  }
}

function getConfirmBody(data: CGM_RAGE, customValueText?: string): string {
  if (data === CGM_RAGE.CUSTOM) {
    return `${customValueText || rageValue.value}mmol/L/min`;
  } else {
    return SelectItemVO.getText(CGM_RAGE_MAP, data);
  }
}

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function changeRageApp(data: CGM_RAGE): void {
  rage.value = data;
}

function onChange(e): void {
  if (e && e.target) {
    const data = e.target.value;
    rage.value = data;
    if (data !== CGM_RAGE.CUSTOM) {
      if (rageValue.value !== '') {
        checkError();
      }
      rageValue.value = '';
    }
  }
}

function onConfirm(): void {
  if (rage.value === CGM_RAGE.CUSTOM && rageValueTips.value !== '') {
    return;
  }
  const data = rage.value;
  rageConfirmHead.value = getConfirmHead(data);
  
  if (data === CGM_RAGE.CUSTOM) {
    const value = rageValue.value;
    emit('custom-value-change', value);
    rageConfirmBody.value = `${value}mmol/L/min`;
  }
  else {
    rageConfirmBody.value = SelectItemVO.getText(CGM_RAGE_MAP, data);
  }
  emit('change', data);
  
  if (screenStore.isPC) {
    onClose();
  } else {
    if (rageRef.value) {
      rageRef.value.onClose();
    }
  }
  
}

function onValueChange(e): void {
  if (e && e.target) {
    const data = e.target.value;
    rageValue.value = data;
    updateTips(getTips(data));
  }
}

function checkError(): boolean {
  const tips = getTips(rageValue.value);
  updateTips(tips);
  return tips !== '';
}

function updateTips(data: string): void {
  rageValueTips.value = data;
}

function getTips(data: string): string {
  if (!data) {
    return '请输入有效数字';
  }
  if (+data < CGM_RAGE_CUSTOM_MIN) {
    return `不得小于 ${CGM_RAGE_CUSTOM_MIN}mmol/L/min`;
  }
  if (+data > CGM_RAGE_CUSTOM_MAX) {
    return `不得大于 ${CGM_RAGE_CUSTOM_MAX}mmol/L/min`;
  }
  if (getDigitCount(data) > CGM_RAGE_CUSTOM_MAX_DIGIT) {
    return `小数位数不得超过${CGM_RAGE_CUSTOM_MAX_DIGIT}位`;
  }
  return '';
}
</script>

<template>
  <template v-if="pc">
    <ModalView title="上升警示" :visible="isOpened" @close="onClose">
      <div class="px-16">
        <a-radio-group :value="rage" class="radio-group-new-vertical add-px-16 no-hover" @change="onChange">
          <a-radio :value="CGM_RAGE.CLOSE">关闭</a-radio>
          <a-radio :value="CGM_RAGE.UP_1">
            <div class="inline-flex items-center">
              <span v-html="rageIcon1" class="inline-flex items-center" style="width: 32px;"></span>
              <span class="text-white text-s">≥0.06mmol/L/min</span>
            </div>
          </a-radio>
          <a-radio :value="CGM_RAGE.UP_2">
            <div class="inline-flex items-center">
              <span v-html="rageIcon2" class="inline-flex items-center" style="width: 32px;"></span>
              <span class="text-white text-s">≥0.11mmol/L/min</span>
            </div>
          </a-radio>
          <a-radio :value="CGM_RAGE.UP_3">
            <div class="inline-flex items-center">
              <span v-html="rageIcon3" class="inline-flex items-center" style="width: 32px;"></span>
              <span class="text-white text-s">≥0.17mmol/L/min</span>
            </div>
          </a-radio>
          <a-radio :value="CGM_RAGE.CUSTOM" class="custom">
            <div class="mb-4">自定义(0.06-0.28)</div>
            <template v-if="rage === CGM_RAGE.CUSTOM">
              <input :value="rageValue"
                     v-disable-wheel
                     type="number"
                     :class="{ 'border-error': rageValueTips }"
                     class="input-placeholder input-arrow-hidden bg-2 border-bg-2 text-s text-white px-8 rounded-4"
                     style="width: 160px; height: 32px; line-height: 32px;"
                     placeholder="请输入"
                     @input="onValueChange"
                     @keyup.enter="onConfirm"
              />
              <ErrorView :tips="rageValueTips" is-text-left />
            </template>
          </a-radio>
        </a-radio-group>
      </div>
      <div class="flex items-center justify-end p-16">
        <ButtonView type="default" text="取消" style="width: 80px; height: 32px; margin-right: 8px;"
                    @click="onClose" />
        <ButtonView type="primary" text="确定" style="width: 80px; height: 32px;"
                    @click="onConfirm" />
      </div>
    </ModalView>
    <div :style="{ width: width }">
      <div class="flex items-center">
        <span class="text-xs">上升警示</span>
        <template v-if="rageConfirmHead">
          <span class="ml-4" v-html="rageConfirmHead"></span>
        </template>
      </div>
      <div class="cursor-pointer text-primary text-color-hover-primary-2"
           style="height: 24px; line-height: 24px;"
           @click="onOpen">{{ rageConfirmBody }}</div>
    </div>
  </template>
  <SelectorPage v-else title="上升警示"
                ref="rageRef"
                :id="rage" :custom-id="CGM_RAGE.CUSTOM" custom-tips="(0.06-0.28)" :items="CGM_RAGES"
                @id-change="changeRageApp" @confirm="onConfirm">
    <template #head>
      <FieldView2 type="other-complex" padding="12px 12px 8px" show-border-top-black is-end>
        <div class="flex justify-between">
          <div class="flex-1 text-xs">
            <div class="inline-flex items-center">
              <span>上升警示</span>
              <span class="ml-8 inline-flex" v-html="rageConfirmHead"></span>
            </div>
            <div class="text-primary">{{ rageConfirmBody }}</div>
          </div>
          <IconPickerField />
        </div>
      </FieldView2>
    </template>
    <template #custom>
      <div v-if="rage === CGM_RAGE.CUSTOM" class="pt-4 pb-16 px-12 relative">
        <input v-disable-wheel
               :value="rageValue"
               type="number"
               name="rage-value"
               :class="{ 'border-error': rageValueTips }"
               class="input-placeholder input-arrow-hidden focus-border-primary-1 w-full bg-16 border-bg-16 text-s text-white px-8 rounded-4"
               style="height: 32px; line-height: 32px; padding-right: 120px;"
               placeholder="请输入"
               @input="onValueChange"
        />
        <span class="absolute" style="right: 20px; top: 6px;">mmol/L/min</span>
        <ErrorView v-if="rageValueTips" :tips="rageValueTips" is-text-left />
      </div>
    </template>
  </SelectorPage>
</template>
