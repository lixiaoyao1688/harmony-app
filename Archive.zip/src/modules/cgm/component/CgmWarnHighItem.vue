<script setup lang="ts">
import {ref, watch, computed} from 'vue';
import {Dayjs} from 'dayjs';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {CGM_RAGE} from '@/modules/cgm/config/cgm.rage';
import {CgmWarnHighItemVO} from '@/modules/cgm/vo/CgmWarnHighItem.vo';
import {DEFAULT_TIME_RANGE} from '@/lib/aaruy-design/time-picker/config/time.range.config';
import {CGM_WARN_HIGH_PRES, DEFAULT_CGM_WARN_HIGH_PRE} from '@/modules/cgm/config/cgm.warn.high.pre';
import {getMinuteIndexFromDayjs, getMinuteIndexFromDayjs2, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {
  CGM_WARN_HIGH, CGM_WARN_HIGH_MAP,
  CGM_WARN_HIGH_VALUE_DIGIT, CGM_WARN_HIGH_VALUE_MAX,
  CGM_WARN_HIGH_VALUE_MIN,
  DEFAULT_CGM_WARN_HIGH
} from '@/modules/cgm/config/cgm.warn.high';
import CgmRage from '@/modules/cgm/component/CgmRage.vue';
import IconCgmWarnClose from '@/modules/cgm/icons/IconCgmWarnClose.vue';
import CgmWarnHighRange from '@/modules/cgm/component/CgmWarnHighRange.vue';
import CgmWarnHighValue from '@/modules/cgm/component/CgmWarnHighValue.vue';
import CgmWarnHighValuePre from '@/modules/cgm/component/CgmWarnHighValuePre.vue';
import CgmWarnValueInput from '@/modules/cgm/component/CgmWarnValueInput.vue';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import PickerDoubleMobile from '@/lib/aaruy-design/picker/PickerDoubleMobile.vue';
import PickerSingleMobile from '@/lib/aaruy-design/picker/PickerSingleMobile.vue';
import { CGM_WARN_TIME_MAP, CGM_WARN_TIMES } from '@/modules/cgm/config/cgm.warn.time';
import { CGM_WARN_HIGH_VALUE_MAP, CGM_WARN_HIGH_VALUES } from '@/modules/cgm/config/cgm.warn.high.value';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import PickerField from '@/lib/aaruy-design/picker/PickerField.vue';
import SwitchField from '@/lib/aaruy-design/switch/field/SwitchField.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import IconCgmWarnRemove from '@/modules/cgm/icons/IconCgmWarnRemove.vue';
import type {ErrorExposedType} from '@/lib/aaruy-design/error/type/error.type';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 高CGM警示项 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  vo: CgmWarnHighItemVO;
  isHead?: boolean;  // head 或 body
  isCloseShowed?: boolean;  // 是否展示关闭图标
  isDisabled?: boolean;  // 是否禁用 仅APP
  margin?: string;  // 仅APP
}

interface Emit {
	(e: 'change', data: CgmWarnHighItemVO): void;
	(e: 'remove', data: CgmWarnHighItemVO): void;  // 仅 isHead
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>('');  // CGM值
const valueRef = ref<ErrorExposedType | null>(null);

const range = ref<[Dayjs, Dayjs]>(DEFAULT_TIME_RANGE);  // 时间范围
const valuePreItem = ref<ItemType2>(DEFAULT_CGM_WARN_HIGH_PRE);  // 高CGM值前警示
const valueEnableItem = ref<ItemType2>(DEFAULT_CGM_WARN_HIGH);  // 高CGM值警示
const isValueEnable = computed<boolean>(() => valueEnableItem.value.id === CGM_WARN_HIGH.OPEN);  // 高CGM值警示(APP)
const rage = ref<CGM_RAGE>(CGM_RAGE.CLOSE);  // 上升警示项
const rageValue = ref<string>('');  // 上升警示自定义值

// CGM值(APP)
const valueItem = computed<ItemType2>(() => SelectItemVO.getItem(CGM_WARN_HIGH_VALUE_MAP, +value.value * 10));
// 时间范围(APP)
const rangeItem = computed<[ItemType2, ItemType2]>(() => {
  const list = range.value;
  return [
    SelectItemVO.getItem(CGM_WARN_TIME_MAP, getMinuteIndexFromDayjs2(list[0])),
    SelectItemVO.getItem(CGM_WARN_TIME_MAP, getMinuteIndexFromDayjs2(list[1])),
  ];
});

const isAppOpened = ref<boolean>(false);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const pad = computed<boolean>(() => screenStore.isPad);
const phone = computed<boolean>(() => screenStore.isNewPhone);


defineExpose({
  hasError
});

watch(() => prop.vo, (data) => {
  value.value = data.value;
  range.value = data.range;
  valuePreItem.value = data.valuePreItem;
  valueEnableItem.value = data.valueEnableItem;
  rage.value = data.rage;
  rageValue.value = data.rageValue;
}, { immediate: true });

function hasError(): boolean {
  if (valueRef.value) {
    return valueRef.value.hasError();
  }
  return false;
}

function onReset(): void {
  const data = prop.vo;
  value.value = data.value;
  range.value = data.range;
  valuePreItem.value = data.valuePreItem;
  valueEnableItem.value = data.valueEnableItem;
  rage.value = data.rage;
  rageValue.value = data.rageValue;
}

function onValueChangeApp(data: ItemType2): void {
  onValueChange(data.text, true);
}

function onRangeChangeApp(data: [ItemType2, ItemType2]): void {
  const today = getTodayDayjs();
  const [s,e] = data;
  const day1 = today.hour(+s.text.slice(0,2)).minute(+s.text.slice(3));
  const day2 = today.hour(+e.text.slice(0,2)).minute(+e.text.slice(3));
  onRangeChange([day1, day2], true);
}

function onValueEnableChangeApp(data: boolean): void {
  onValueEnableItemChange(SelectItemVO.getItem(CGM_WARN_HIGH_MAP, data ? CGM_WARN_HIGH.OPEN : CGM_WARN_HIGH.CLOSE), true);
}

function onRangeChange(data: [Dayjs, Dayjs], isApp?: boolean): void {
  range.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValueChange(data: string, isApp?: boolean): void {
  value.value = data;
  if (!isApp) {
    emitData();
  }
}

function onRageValueChange(data: string, isApp?: boolean): void {
  rageValue.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValuePreItemChange(data: ItemType2, isApp?: boolean): void {
  valuePreItem.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValueEnableItemChange(data: ItemType2, isApp?: boolean): void {
  valueEnableItem.value = data;
  if (!isApp) {
    emitData();
  }
}

function onRageChange(data: CGM_RAGE, isApp?: boolean): void {
  rage.value = data;
  if (!isApp) {
    emitData();
  }
}

function onRemove(): void {
  if (prop.isDisabled) {
    return;
  }
  emit('remove', prop.vo);
}

function onAppOpen(): void {
  if (prop.isDisabled) {
    return;
  }
  isAppOpened.value = true;
}

function onAppClose(): void {
  isAppOpened.value = false;
}

function onAppCancel(): void {
  onAppClose();
  onReset();
}

function onAppConfirm(): void {
  emitData();
  onAppClose();
}

function emitData(): void {
  const [s, e] = range.value;
  emit('change', new CgmWarnHighItemVO({
    value_start: getMinuteIndexFromDayjs(s),
    value_end: e.hour() === 0 && e.minute() === 0 ? 1440 : getMinuteIndexFromDayjs(e),
    value: +value.value,
    notice_minute_before: valuePreItem.value.id,
    if_notice_value: valueEnableItem.value.id,
    rage_index: rage.value,
    rage_start: +rageValue.value
  }, prop.vo.id));
}
</script>

<template>
  <template v-if="pc">
    <div v-if="isHead" class="flex justify-between flex-1 text-white font-bold pr-12">
      <div class="inline-flex">
        <CgmWarnHighRange :data="range" @change="onRangeChange" />
        <CgmWarnValueInput ref="valueRef"
                           :data="value"
                           :min="CGM_WARN_HIGH_VALUE_MIN"
                           :max="CGM_WARN_HIGH_VALUE_MAX"
                           :digit="CGM_WARN_HIGH_VALUE_DIGIT"
                           @change="onValueChange" />
      </div>
      <IconCgmWarnClose v-if="isCloseShowed" @click="onRemove" />
    </div>
    <div v-else class="flex items-center justify-between text-white pt-8 border-t-bg-9-dashed">
      <CgmWarnHighValuePre :data="valuePreItem" @change="onValuePreItemChange" />
      <CgmWarnHighValue :data="valueEnableItem" @change="onValueEnableItemChange" />
      <CgmRage :prop-rage="rage"
               :prop-value="rageValue"
               width="36%"
               @change="onRageChange"
               @custom-value-change="onRageValueChange" />
    </div>
  </template>
  <template v-else>
    <PageMobile :visible="isAppOpened" @goBack="onAppClose">
      <template #title>警示设置</template>
      <template #content>
        <div class="flex justify-center pt-16">
          <div class="flex" style="width: 100%; min-width: 300px; max-width: 400px;">
            <PickerDoubleMobile title="时间范围" width="60%" :items1="CGM_WARN_TIMES" :items2="CGM_WARN_TIMES" :selected-items="rangeItem"
                                @change="onRangeChangeApp" />
            <PickerSingleMobile title="高CGM值" width="40%" :items="CGM_WARN_HIGH_VALUES" :item="valueItem"
                                @change="onValueChangeApp" />
          </div>
        </div>
        <div class="text-xs font-bold text-weak-8 pt-16 pb-8 px-16">警示内容</div>
        <div class="px-16">
          <FieldView2 type="other" is-start>
            <PickerField title="高CGM值前警示"
                         :items="CGM_WARN_HIGH_PRES" :item="valuePreItem"
                         @change="onValuePreItemChange($event, true)" />
          </FieldView2>
          <FieldView2 type="other">
            <SwitchField title="高CGM值警示"
                         :value="isValueEnable"
                         width="100%"
                         height="48px"
                         font-size="14px"
                         @change="onValueEnableChangeApp" />
          </FieldView2>
          <CgmRage :prop-rage="rage"
                   :prop-value="rageValue"
                   @change="onRageChange"
                   @custom-value-change="onRageValueChange($event, true)" />
        </div>
        <div class="flex items-center justify-between px-16 pt-16">
          <ButtonView type="default" text="取消" style="width: 49%; height: 36px; line-height: 36px;"
                      @click="onAppCancel" />
          <ButtonView type="primary" text="确定" style="width: 49%; height: 36px; line-height: 36px;"
                      @click="onAppConfirm" />
        </div>
      </template>
    </PageMobile>
    <div class="flex items-center justify-between" :style="{ margin: margin }">
      <div class="flex-1" @click="onAppOpen">
        <div :class="{ 'text-primary': !isDisabled, 'text-weak-2': isDisabled, 'text-s': pad,  'text-xs': phone }" class="font-bold">{{ vo.title }}</div>
        <div :class="{ 'text-weak-8': !isDisabled,  'text-weak-2': isDisabled, 'text-xs': pad, 'text-xxs': phone }">{{ vo.content }}</div>
      </div>
      <IconCgmWarnRemove size="14px" :is-disabled="isDisabled" @click="onRemove" />
    </div>
  </template>
</template>
