<script setup lang="ts">
import {Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import {getTimeRangeText} from '@/lib/aaruy-design/time-picker/util/time.range.util';
import {DEFAULT_TIME_RANGE} from '@/lib/aaruy-design/time-picker/config/time.range.config';
import TimeRangePicker from '@/lib/aaruy-design/time-picker/TimeRangePicker.vue';


type ValueType = [Dayjs, Dayjs];

/**
 * 高CGM时间 组件
 *
 * 适用项目
 * 请替换为项目名称
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  data: ValueType;
}

interface Emit {
	(e: 'change', data: ValueType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<ValueType>(DEFAULT_TIME_RANGE);
const valueText = computed<string>(() => getTimeRangeText(value.value));

watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: ValueType): void {
  value.value = data;
  emit('change', data);
}
</script>

<template>
  <TimeRangePicker :range="value" is-theme-tips :tips-text="valueText"
                   @change="onChange" />
</template>
