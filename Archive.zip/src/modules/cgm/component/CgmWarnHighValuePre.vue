<script setup lang="ts">
import {ref, watch} from 'vue';
import IconCgmUp from '@/modules/cgm/icons/IconCgmUp.vue';
import IconCgmDown from '@/modules/cgm/icons/IconCgmDown.vue';
import DropdownTip from '@/lib/aaruy-design/dropdown/tip/DropdownTip.vue';
import {CGM_WARN_HIGH_PRES, DEFAULT_CGM_WARN_HIGH_PRE} from '@/modules/cgm/config/cgm.warn.high.pre';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 高CGM值前警示 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  data: ItemType2;
}

interface Emit {
  (e: 'change', data: ItemType2): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const item = ref<ItemType2>(DEFAULT_CGM_WARN_HIGH_PRE);

watch(() => prop.data, (data) => {
  item.value = data;
}, { immediate: true });

function onOpenChange(data: boolean): void {
  isOpened.value = data;
}

function onItemChange(data: ItemType2): void {
  item.value = data;
  emit('change', data);
  onOpenChange(false);
}
</script>

<template>
  <div>
    <div class="text-xs">高CGM值前警示</div>
    <DropdownTip :visible="isOpened" @openChange="onOpenChange">
      <template #content>
        <div class="inline-flex items-center cursor-pointer">
          <span class="text-primary text-hover-primary-2 mr-16">{{ item.text }}</span>
          <IconCgmUp v-if="isOpened" /><IconCgmDown v-else />
        </div>
      </template>
      <template #menu>
        <div class="bg-1 p-8">
          <div v-for="(it,i) in CGM_WARN_HIGH_PRES"
               :key="it.id"
               :class="{ 'bg-default-1': it.id === item.id, 'mt-8': i > 0 }"
               class="bg-default-1-hover text-s py-4 px-16 cursor-pointer rounded-4"
               @click="onItemChange(it)">{{ it.text }}</div>
        </div>
      </template>
    </DropdownTip>
  </div>
</template>
