<script setup lang="ts">
import {Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import {getMinuteIndexFromDayjs, getMinuteIndexFromDayjs2, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {CgmWarnLowItemVO} from '@/modules/cgm/vo/CgmWarnLowItem.vo';
import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';
import {DEFAULT_TIME_RANGE} from '@/lib/aaruy-design/time-picker/config/time.range.config';
import {CGM_WARN_LOW_VALUE_DEFAULT, CGM_WARN_LOW_VALUE_DIGIT, CGM_WARN_LOW_VALUE_MAX, CGM_WARN_LOW_VALUE_MIN} from '@/modules/cgm/config/cgm.warn.low';
import CheckView from '@/lib/aaruy-design/check/CheckView.vue';
import IconCgmWarnClose from '@/modules/cgm/icons/IconCgmWarnClose.vue';
import CgmWarnHighRange from '@/modules/cgm/component/CgmWarnHighRange.vue';
import CgmWarnValueInput from '@/modules/cgm/component/CgmWarnValueInput.vue';
import IconCgmWarnRemove from '@/modules/cgm/icons/IconCgmWarnRemove.vue';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import {CGM_WARN_TIME_MAP, CGM_WARN_TIMES} from '@/modules/cgm/config/cgm.warn.time';
import {CGM_WARN_HIGH_VALUE_MAP, CGM_WARN_HIGH_VALUES} from '@/modules/cgm/config/cgm.warn.high.value';
import PickerDoubleMobile from '@/lib/aaruy-design/picker/PickerDoubleMobile.vue';
import PickerSingleMobile from '@/lib/aaruy-design/picker/PickerSingleMobile.vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import SwitchField from '@/lib/aaruy-design/switch/field/SwitchField.vue';
import type {ErrorExposedType} from '@/lib/aaruy-design/error/type/error.type';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 低CGM警示项 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 *
 * 注意
 * 操作逻辑见: @src\modules\cgm\dto\cgm.warn.dto.ts: CgmWarnTipLowDTO
 */
interface Prop {
  vo: CgmWarnLowItemVO;
  isHead?: boolean;  // head 或 body
  isCloseShowed?: boolean;  // 是否展示关闭图标
  isDisabled?: boolean;  // 是否禁用 仅APP
  margin?: string;  // 仅APP
}

interface Emit {
  (e: 'change', data: CgmWarnLowItemVO): void;
  (e: 'remove', data: CgmWarnLowItemVO): void;  // 仅 isHead
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const range = ref<[Dayjs, Dayjs]>(DEFAULT_TIME_RANGE);  // 时间范围
const value = ref<string>(CGM_WARN_LOW_VALUE_DEFAULT.toString());  // CGM值
const valueRef = ref<ErrorExposedType | null>(null);
const isValuePreOpened = ref<boolean>(false);  // 低CGM值前警示
const isValueOpened = ref<boolean>(false);  // 低CGM值警示
const isValuePreStopOpened = ref<boolean>(false);  // 低CGM值前暂停输注
const isValueStopOpened = ref<boolean>(false);  // 低CGM值暂停输注
const isRecoverBaseOpened = ref<boolean>(false);  // 恢复基础率警示
const isRecoverBaseDisabled = computed<boolean>(() => !isValuePreStopOpened.value && !isValueStopOpened.value);

// CGM值(APP)
const valueItem = computed<ItemType2>(() => SelectItemVO.getItem(CGM_WARN_HIGH_VALUE_MAP, +value.value * 10));
// 时间范围(APP)
const rangeItem = computed<[ItemType2, ItemType2]>(() => {
  const list = range.value;
  return [
    SelectItemVO.getItem(CGM_WARN_TIME_MAP, getMinuteIndexFromDayjs2(list[0])),
    SelectItemVO.getItem(CGM_WARN_TIME_MAP, getMinuteIndexFromDayjs2(list[1])),
  ];
});

const isAppOpened = ref<boolean>(false);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const pad = computed<boolean>(() => screenStore.isPad);
const phone = computed<boolean>(() => screenStore.isNewPhone);


defineExpose({
  hasError
});

watch(() => prop.vo, (data) => {
  range.value = data.range;
  value.value = data.value;
  isValuePreOpened.value = data.isValuePreOpened;
  isValueOpened.value = data.isValueOpened;
  isValuePreStopOpened.value = data.isValuePreStopOpened;
  isValueStopOpened.value = data.isValueStopOpened;
  isRecoverBaseOpened.value = data.isRecoverBaseOpened;
}, { immediate: true });

function hasError(): boolean {
  if (valueRef.value) {
    return valueRef.value.hasError();
  }
  return false;
}

function onReset(): void {
  const data = prop.vo;
  range.value = data.range;
  value.value = data.value;
  isValuePreOpened.value = data.isValuePreOpened;
  isValueOpened.value = data.isValueOpened;
  isValuePreStopOpened.value = data.isValuePreStopOpened;
  isValueStopOpened.value = data.isValueStopOpened;
  isRecoverBaseOpened.value = data.isRecoverBaseOpened;
}

function onValueChangeApp(data: ItemType2): void {
  onValueChange(data.text, true);
}

function onRangeChangeApp(data: [ItemType2, ItemType2]): void {
  const today = getTodayDayjs();
  const [s,e] = data;
  const day1 = today.hour(+s.text.slice(0,2)).minute(+s.text.slice(3));
  const day2 = today.hour(+e.text.slice(0,2)).minute(+e.text.slice(3));
  onRangeChange([day1, day2], true);
}


function onRangeChange(data: [Dayjs, Dayjs], isApp?: boolean): void {
  range.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValueChange(data: string, isApp?: boolean): void {
  value.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValuePreOpenedChange(data: boolean, isApp?: boolean): void {
  isValuePreOpened.value = data;
  if (!isApp) {
    emitData();
  }
}

function onValueOpenedChange(data: boolean, isApp?: boolean): void {
  isValueOpened.value = data;
  if (!isApp) {
    emitData();
  }
}

// 低CGM值前暂停输注
function onValuePreStopOpenedChange(data: boolean, isApp?: boolean): void {
  isValuePreStopOpened.value = data;
  if (data) {
    // 关闭->开启时
    // 1.使"低CGM值暂停输注"关闭。
    isValueStopOpened.value = false;
    // 2.使"恢复基础率警示"开启。
    isRecoverBaseOpened.value = true;
  }
  else {
    // 开启->关闭时
    if (!isValuePreStopOpened.value) {
      // "低CGM值前暂停输注"和"低CGM值暂停输注"同时关闭时，使"恢复基础率警示"关闭。
      isRecoverBaseOpened.value = false;
    }
  }
  if (!isApp) {
    emitData();
  }
}

// 低CGM值暂停输注
function onValueStopOpenedChange(data: boolean, isApp?: boolean): void {
  isValueStopOpened.value = data;
  if (data) {
    // 关闭->开启时
    // 1.使"低CGM值前暂停输注"关闭。
    isValuePreStopOpened.value = false;
    // 2.使"恢复基础率警示"开启。
    isRecoverBaseOpened.value = true;
  }
  else {
    // 开启->关闭时
    if (!isValuePreStopOpened.value) {
      // "低CGM值前暂停输注"和"低CGM值暂停输注"同时关闭时，使"恢复基础率警示"关闭。
      isRecoverBaseOpened.value = false;
    }
  }
  if (!isApp) {
    emitData();
  }
}

function onRecoverBaseOpenedChange(data: boolean, isApp?: boolean): void {
  isRecoverBaseOpened.value = data;
  if (!isApp) {
    emitData();
  }
}

function onRemove(): void {
  emit('remove', prop.vo);
}

function onAppOpen(): void {
  if (prop.isDisabled) {
    return;
  }
  isAppOpened.value = true;
}

function onAppClose(): void {
  isAppOpened.value = false;
}

function onAppCancel(): void {
  onAppClose();
  onReset();
}

function onAppConfirm(): void {
  emitData();
  onAppClose();
}

function emitData(): void {
  const [s, e] = range.value;
  emit('change', new CgmWarnLowItemVO({
    value_start: getMinuteIndexFromDayjs(s),
    value_end: e.hour() === 0 && e.minute() === 0 ? 1440 : getMinuteIndexFromDayjs(e),
    value: +value.value,
    if_notice_value_before: isValuePreOpened.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
    if_notice_value: isValueOpened.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
    if_stop_value_before: isValuePreStopOpened.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
    if_stop_value: isValueStopOpened.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
    if_recover_base: isRecoverBaseOpened.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
  }, prop.vo.id));
}
</script>

<template>
  <template v-if="pc">
    <div v-if="isHead" class="flex justify-between flex-1 text-white font-bold pr-12">
      <div class="inline-flex">
        <CgmWarnHighRange :data="range" @change="onRangeChange" />
        <CgmWarnValueInput ref="valueRef"
                           :data="value"
                           :min="CGM_WARN_LOW_VALUE_MIN"
                           :max="CGM_WARN_LOW_VALUE_MAX"
                           :digit="CGM_WARN_LOW_VALUE_DIGIT"
                           @change="onValueChange" />
      </div>
      <IconCgmWarnClose v-if="isCloseShowed" @click="onRemove" />
    </div>
    <div v-else class="flex text-white pt-8 border-t-bg-9-dashed">
      <div style="width: 50%;">
        <CheckView :checked="isValuePreOpened" @change="onValuePreOpenedChange">低CGM值前警示</CheckView>
        <CheckView :checked="isValueOpened" @change="onValueOpenedChange">低CGM值警示</CheckView>
        <CheckView :checked="isRecoverBaseOpened" :disabled="isRecoverBaseDisabled" @change="onRecoverBaseOpenedChange">恢复基础率警示</CheckView>
      </div>
      <div style="width: 50%;">
        <CheckView :checked="isValuePreStopOpened" @change="onValuePreStopOpenedChange">低CGM值前暂停输注</CheckView>
        <CheckView :checked="isValueStopOpened" @change="onValueStopOpenedChange">低CGM值暂停输注</CheckView>
      </div>
    </div>
  </template>
  <template v-else>
    <PageMobile :visible="isAppOpened" @goBack="onAppClose">
      <template #title>警示设置</template>
      <template #content>
        <div class="flex justify-center pt-16">
          <div class="flex" style="width: 100%; min-width: 300px; max-width: 400px;">
            <PickerDoubleMobile title="时间范围" width="60%" :items1="CGM_WARN_TIMES" :items2="CGM_WARN_TIMES" :selected-items="rangeItem"
                                @change="onRangeChangeApp" />
            <PickerSingleMobile title="低CGM值" width="40%" :items="CGM_WARN_HIGH_VALUES" :item="valueItem"
                                @change="onValueChangeApp" />
          </div>
        </div>
        <div class="text-xs font-bold text-weak-8 pt-16 pb-8 px-16">警示内容</div>
        <div class="px-16">
          <FieldView2 type="other" is-start>
            <SwitchField title="低CGM值前警示" :value="isValuePreOpened"
                         width="100%" height="48px" font-size="14px"
                         @change="onValuePreOpenedChange($event, true)" />
          </FieldView2>
          <FieldView2 type="other">
            <SwitchField title="低CGM值警示" :value="isValueOpened"
                         width="100%" height="48px" font-size="14px"
                         @change="onValueOpenedChange($event, true)" />
          </FieldView2>
          <FieldView2 type="other">
            <SwitchField title="低CGM值前暂停输注" :value="isValuePreStopOpened"
                         width="100%" height="48px" font-size="14px"
                         @change="onValuePreStopOpenedChange($event, true)" />
          </FieldView2>
          <FieldView2 type="other">
            <SwitchField title="低CGM值暂停输注" :value="isValueStopOpened"
                         width="100%" height="48px" font-size="14px"
                         @change="onValueStopOpenedChange($event, true)" />
          </FieldView2>
          <FieldView2 type="other" is-end>
            <SwitchField title="恢复基础率警示" :value="isRecoverBaseOpened"
                         :is-disabled="isRecoverBaseDisabled"
                         width="100%" height="48px" font-size="14px"
                         @change="onRecoverBaseOpenedChange($event, true)" />
          </FieldView2>
        </div>
        <div class="flex items-center justify-between px-16 pt-16">
          <ButtonView type="default" text="取消" style="width: 49%; height: 36px; line-height: 36px;"
                      @click="onAppCancel" />
          <ButtonView type="primary" text="确定" style="width: 49%; height: 36px; line-height: 36px;"
                      @click="onAppConfirm" />
        </div>
      </template>
    </PageMobile>
    <div class="flex items-center justify-between" :style="{ margin: margin }">
      <div class="flex-1" @click="onAppOpen">
        <div :class="{ 'text-primary': !isDisabled, 'text-weak-2': isDisabled, 'text-s': pad,  'text-xs': phone }" class="font-bold">{{ vo.title }}</div>
        <div :class="{ 'text-weak-8': !isDisabled,  'text-weak-2': isDisabled, 'text-xs': pad, 'text-xxs': phone }">{{ vo.content }}</div>
      </div>
      <IconCgmWarnRemove size="14px" :is-disabled="isDisabled" @click="onRemove" />
    </div>
  </template>
</template>
