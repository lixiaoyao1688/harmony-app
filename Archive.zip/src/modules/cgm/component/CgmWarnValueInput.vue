<script setup lang="ts">
import {ref, watch} from 'vue';
import {getDigitCount} from '@/lib/math/util/math.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';


/**
 * 高CGM值 输入框 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  data: string;
  min: number;
  max: number;
  digit: number;
}

interface Emit {
	(e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>('');
const errorTips = ref<string>('');


defineExpose({
  hasError
});

watch(() => prop.data, (data) => {
  if (data && data !== '0') {
    value.value = data;
  }
}, { immediate: true });

function hasError(): boolean {
  checkError();
  return errorTips.value !== '';
}

function checkError(): void {
  errorTips.value = getErrorTips(value.value);
}

function onChange(data: string): void {
  value.value = data;
  emit('change', data);
  checkError();
}

function getErrorTips(data: string): string {
  if (!data && data !== '0') {
    return '请输入有效数字';
  }
  if (+data < prop.min) {
    return `不得小于${prop.min}mmol/L`;
  }
  if (+data > prop.max) {
    return `不得大于${prop.max}mmol/L`;
  }
  if (getDigitCount(data) > prop.digit) {
    return `小数位数不得超过${prop.digit}位`;
  }
  return '';
}
</script>

<template>
  <div style="width: 146px;" class="text-right">
    <div class="inline-flex items-center mb-4" style="height: 24px; line-height: 24px;">
      <input v-disable-wheel
             :value="value"
             type="number"
             placeholder="请输入"
             style="width: 64px;"
             class="input-placeholder input-arrow-hidden border-b-bg-7 border-b-action-primary-2 text-center no-select px-8"
             :class="{ 'border-error': errorTips }"
             @click.stop
             @input="event => onChange(event.target.value)"
      />
      <span class="no-select">mmol/L</span>
    </div>
    <ErrorView :tips="errorTips" />
  </div>
</template>
