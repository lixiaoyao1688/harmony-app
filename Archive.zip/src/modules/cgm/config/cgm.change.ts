export enum CGM_CHANGE {
  VERY_SLOW,
  SLOW,
  FAST,
  VERY_FAST
}

export enum CGM_CHANGE_DIRECTION {
  UP,
  DOWN
}

export enum CGM_DIFF {
  LEVEL_1 = 1.1,
  LEVEL_2 = 2.2,
  LEVEL_3 = 3.3
}

export enum CGM_RATE {
  LEVEL_1 = 0.05,
  LEVEL_2 = 0.1,
  LEVEL_3 = 0.17
}
