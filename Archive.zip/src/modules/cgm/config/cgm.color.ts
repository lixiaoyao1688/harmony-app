export enum CGM_COLOR {
  NORMAL = 'rgb(22,201,165)',
  LOW = 'rgb(247,58,63)',
  HIGH = 'rgb(248,168,30)'
}

// 用于报告的CGM曲线颜色
export const CGM_LINE_REPORT_COLOR = 'rgb(29,110,249)';
