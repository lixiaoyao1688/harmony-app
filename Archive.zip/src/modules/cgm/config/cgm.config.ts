/**
 * 血糖仪状态
 */
export enum CGM_STATUS {
  UNBIND = 0,  // 未绑定
  BIND_BUT_DISCONNECTED,  // 绑定成功但未连接
  CONNECTED,  // 绑定成功并已连接
}
