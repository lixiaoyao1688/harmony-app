import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * CGM连接状态 配置
 */
export enum CGM_CONNECT_STATUS {
  SUCCESS = 1,
  DISCONNECTED,
  BIND_CGM,
  UNBIND,
  BIND_FAILED,
  // OUT
}

const CGM_CONNECT_STATUS_0 = new SelectItemVO({ id: CGM_CONNECT_STATUS.SUCCESS, text: 'CGM连接恢复' });
const CGM_CONNECT_STATUS_1 = new SelectItemVO({ id: CGM_CONNECT_STATUS.DISCONNECTED, text: 'CGM连接断开' });
const CGM_CONNECT_STATUS_2 = new SelectItemVO({ id: CGM_CONNECT_STATUS.BIND_CGM, text: 'CGM连接成功' });
const CGM_CONNECT_STATUS_3 = new SelectItemVO({ id: CGM_CONNECT_STATUS.UNBIND, text: 'CGM解绑' });
const CGM_CONNECT_STATUS_4 = new SelectItemVO({ id: CGM_CONNECT_STATUS.BIND_FAILED, text: 'CGM绑定失败' });
// const CGM_CONNECT_STATUS_4 = new SelectItemVO({ id: CGM_CONNECT_STATUS.OUT, text: 'CGM已过期' });

export const CGM_CONNECT_STATUS_ITEMS = [
  CGM_CONNECT_STATUS_0,
  CGM_CONNECT_STATUS_1,
  CGM_CONNECT_STATUS_2,
  CGM_CONNECT_STATUS_3,
  CGM_CONNECT_STATUS_4,
];
export const CGM_CONNECT_STATUS_MAP_1 = SelectItemVO.getMap(CGM_CONNECT_STATUS_ITEMS);

export const CGM_CONNECT_STATUS_MAP = new Map([
  [CGM_CONNECT_STATUS.SUCCESS, '连接成功'],
  [CGM_CONNECT_STATUS.DISCONNECTED, '断开连接'],
  [CGM_CONNECT_STATUS.BIND_CGM, '绑定CGM'],
  [CGM_CONNECT_STATUS.UNBIND, '解绑'],
]);
