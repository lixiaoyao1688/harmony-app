// https://192.168.1.249:85/project/40/interface/api/3228 extra_status 盾牌状态
export enum CGM_EXTRA {
  
  CLOSED_UP = 10,  // 闭环
  CLOSED_SLEEP = 12,  // 闭环睡眠
  CLOSED_SPORT,  // 闭环运动
  CLOSED_INIT,  // 闭环初始化
  CLOSED_DATA,  // 闭环数据同步
  
  INIT = 21,  // CGM是否初始化中
  
}
