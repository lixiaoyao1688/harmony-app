import {COLOR_WHITE_0} from '@/lib/style/color';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {getCgmChangeIcon} from '@/modules/cgm/util/cgm.util';
import {CGM_CHANGE, CGM_CHANGE_DIRECTION} from '@/modules/cgm/config/cgm.change';
import type {SelectorPageItemPayload} from '@/lib/aaruy-design/selector/page/type/selector.page.type';


/**
 * CGM 上升警示 配置
 */
export enum CGM_RAGE {
  CLOSE = 0,  // 关闭
  UP_1,  // 1箭头
  UP_2,  // 2箭头
  UP_3,  // 3箭头
  CUSTOM // 自定义
}

const CGM_RAGE_0 = new SelectItemVO<SelectorPageItemPayload>({ id: CGM_RAGE.CLOSE, text: '关闭', payload: { icon: '' } });
const CGM_RAGE_1 = new SelectItemVO<SelectorPageItemPayload>({ id: CGM_RAGE.UP_1, text: '≥0.06mmol/L/min', payload: { icon: getCgmChangeIcon(CGM_CHANGE.SLOW, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP) } });
const CGM_RAGE_2 = new SelectItemVO<SelectorPageItemPayload>({ id: CGM_RAGE.UP_2, text: '≥0.11mmol/L/min', payload: { icon: getCgmChangeIcon(CGM_CHANGE.FAST, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP) } });
const CGM_RAGE_3 = new SelectItemVO<SelectorPageItemPayload>({ id: CGM_RAGE.UP_3, text: '≥0.17mmol/L/min', payload: { icon: getCgmChangeIcon(CGM_CHANGE.VERY_FAST, COLOR_WHITE_0, CGM_CHANGE_DIRECTION.UP) } });
const CGM_RAGE_4 = new SelectItemVO<SelectorPageItemPayload>({ id: CGM_RAGE.CUSTOM, text: '自定义', payload: { icon: '' } });

export const CGM_RAGES = [
  CGM_RAGE_0,
  CGM_RAGE_1,
  CGM_RAGE_2,
  CGM_RAGE_3,
  CGM_RAGE_4,
];
export const CGM_RAGE_MAP = SelectItemVO.getMap(CGM_RAGES);

export const CGM_RAGE_CUSTOM_MAX = 0.28;
export const CGM_RAGE_CUSTOM_MIN = 0.06;
export const CGM_RAGE_CUSTOM_MAX_DIGIT = 2;
