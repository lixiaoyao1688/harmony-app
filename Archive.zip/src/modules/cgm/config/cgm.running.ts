export enum CGM_RUNNING_STATUS {
  NOT_BOUND = 0,  // 未绑定
  BOUND,  // 绑定成功但未连接
  CONNECTED  // 绑定成功并已连接
}
