export enum CGM_STATUS {
  UNBIND = 0,  // 未绑定
  DISCONNECTED = 1,  // 绑定成功但未连接
  CONNECTED = 2,  // 绑定成功并已连接
}
