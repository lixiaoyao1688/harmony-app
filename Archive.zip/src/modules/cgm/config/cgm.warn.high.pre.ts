import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 高CGM值前警示 配置
 */
export enum CGM_WARN_HIGH_PRE {
  CLOSE = 0,
  MIN_5 = 5,
  MIN_10 = 10,
  MIN_15 = 15,
  MIN_20 = 20,
  MIN_25 = 25,
  MIN_30 = 30,
}

const CGM_WARN_HIGH_PRE_0 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.CLOSE, text: '关闭' });
const CGM_WARN_HIGH_PRE_5 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_5, text: '5min' });
const CGM_WARN_HIGH_PRE_10 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_10, text: '10min' });
const CGM_WARN_HIGH_PRE_15 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_15, text: '15min' });
const CGM_WARN_HIGH_PRE_20 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_20, text: '20min' });
const CGM_WARN_HIGH_PRE_25 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_25, text: '25min' });
const CGM_WARN_HIGH_PRE_30 = new SelectItemVO({ id: CGM_WARN_HIGH_PRE.MIN_30, text: '30min' });

export const DEFAULT_CGM_WARN_HIGH_PRE = CGM_WARN_HIGH_PRE_0;
export const CGM_WARN_HIGH_PRES = [
  CGM_WARN_HIGH_PRE_0,
  CGM_WARN_HIGH_PRE_5,
  CGM_WARN_HIGH_PRE_10,
  CGM_WARN_HIGH_PRE_15,
  CGM_WARN_HIGH_PRE_20,
  CGM_WARN_HIGH_PRE_25,
  CGM_WARN_HIGH_PRE_30,
];
export const CGM_WARN_HIGH_PRE_MAP = SelectItemVO.getMap(CGM_WARN_HIGH_PRES);
