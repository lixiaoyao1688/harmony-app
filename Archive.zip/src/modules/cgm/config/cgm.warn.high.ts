import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 高CGM值警示 配置
 */
export enum CGM_WARN_HIGH {
  CLOSE,
  OPEN
}

const CGM_WARN_HIGH_CLOSED = new SelectItemVO({ id: CGM_WARN_HIGH.CLOSE, text: '关闭' });
const CGM_WARN_HIGH_OPENED = new SelectItemVO({ id: CGM_WARN_HIGH.OPEN, text: '开启' });

export const DEFAULT_CGM_WARN_HIGH = CGM_WARN_HIGH_CLOSED;
export const CGM_WARN_HIGHS = [
  CGM_WARN_HIGH_CLOSED,
  CGM_WARN_HIGH_OPENED,
];
export const CGM_WARN_HIGH_MAP = SelectItemVO.getMap(CGM_WARN_HIGHS);


/**
 * 高CGM值警示 血糖值 配置
 */
export const CGM_WARN_HIGH_VALUE_MIN = 5.6;
export const CGM_WARN_HIGH_VALUE_MAX = 22.2;
export const CGM_WARN_HIGH_VALUE_DIGIT = 1;
