import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';

/**
 * 高CGM值 配置
 */
export enum CGM_WARN_HIGH_VALUE {
  V_5_6 = 56,
  V_5_7,
  V_5_8,
  V_5_9,
  V_6_0,
  V_6_1,
  V_6_2,
  V_6_3,
  V_6_4,
  V_6_5,
  V_6_6,
  V_6_7,
  V_6_8,
  V_6_9,
  V_7_0,
  V_7_1,
  V_7_2,
  V_7_3,
  V_7_4,
  V_7_5,
  V_7_6,
  V_7_7,
  V_7_8,
  V_7_9,
  V_8_0,
  V_8_1,
  V_8_2,
  V_8_3,
  V_8_4,
  V_8_5,
  V_8_6,
  V_8_7,
  V_8_8,
  V_8_9,
  V_9_0,
  V_9_1,
  V_9_2,
  V_9_3,
  V_9_4,
  V_9_5,
  V_9_6,
  V_9_7,
  V_9_8,
  V_9_9,
  V_10_0,
  V_10_1,
  V_10_2,
  V_10_3,
  V_10_4,
  V_10_5,
  V_10_6,
  V_10_7,
  V_10_8,
  V_10_9,
  V_11_0,
  V_11_1,
  V_11_2,
  V_11_3,
  V_11_4,
  V_11_5,
  V_11_6,
  V_11_7,
  V_11_8,
  V_11_9,
  V_12_0,
  V_12_1,
  V_12_2,
  V_12_3,
  V_12_4,
  V_12_5,
  V_12_6,
  V_12_7,
  V_12_8,
  V_12_9,
  V_13_0,
  V_13_1,
  V_13_2,
  V_13_3,
  V_13_4,
  V_13_5,
  V_13_6,
  V_13_7,
  V_13_8,
  V_13_9,
  V_14_0,
  V_14_1,
  V_14_2,
  V_14_3,
  V_14_4,
  V_14_5,
  V_14_6,
  V_14_7,
  V_14_8,
  V_14_9,
  V_15_0,
  V_15_1,
  V_15_2,
  V_15_3,
  V_15_4,
  V_15_5,
  V_15_6,
  V_15_7,
  V_15_8,
  V_15_9,
  V_16_0,
  V_16_1,
  V_16_2,
  V_16_3,
  V_16_4,
  V_16_5,
  V_16_6,
  V_16_7,
  V_16_8,
  V_16_9,
  V_17_0,
  V_17_1,
  V_17_2,
  V_17_3,
  V_17_4,
  V_17_5,
  V_17_6,
  V_17_7,
  V_17_8,
  V_17_9,
  V_18_0,
  V_18_1,
  V_18_2,
  V_18_3,
  V_18_4,
  V_18_5,
  V_18_6,
  V_18_7,
  V_18_8,
  V_18_9,
  V_19_0,
  V_19_1,
  V_19_2,
  V_19_3,
  V_19_4,
  V_19_5,
  V_19_6,
  V_19_7,
  V_19_8,
  V_19_9,
  V_20_0,
  V_20_1,
  V_20_2,
  V_20_3,
  V_20_4,
  V_20_5,
  V_20_6,
  V_20_7,
  V_20_8,
  V_20_9,
  V_21_0,
  V_21_1,
  V_21_2,
  V_21_3,
  V_21_4,
  V_21_5,
  V_21_6,
  V_21_7,
  V_21_8,
  V_21_9,
  V_22_0,
  V_22_1,
  V_22_2,
}

const CGM_WARN_HIGH_VALUE_5_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_5_6, text: '5.6' });
const CGM_WARN_HIGH_VALUE_5_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_5_7, text: '5.7' });
const CGM_WARN_HIGH_VALUE_5_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_5_8, text: '5.8' });
const CGM_WARN_HIGH_VALUE_5_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_5_9, text: '5.9' });
const CGM_WARN_HIGH_VALUE_6_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_0, text: '6.0' });
const CGM_WARN_HIGH_VALUE_6_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_1, text: '6.1' });
const CGM_WARN_HIGH_VALUE_6_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_2, text: '6.2' });
const CGM_WARN_HIGH_VALUE_6_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_3, text: '6.3' });
const CGM_WARN_HIGH_VALUE_6_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_4, text: '6.4' });
const CGM_WARN_HIGH_VALUE_6_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_5, text: '6.5' });
const CGM_WARN_HIGH_VALUE_6_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_6, text: '6.6' });
const CGM_WARN_HIGH_VALUE_6_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_7, text: '6.7' });
const CGM_WARN_HIGH_VALUE_6_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_8, text: '6.8' });
const CGM_WARN_HIGH_VALUE_6_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_6_9, text: '6.9' });
const CGM_WARN_HIGH_VALUE_7_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_0, text: '7.0' });
const CGM_WARN_HIGH_VALUE_7_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_1, text: '7.1' });
const CGM_WARN_HIGH_VALUE_7_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_2, text: '7.2' });
const CGM_WARN_HIGH_VALUE_7_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_3, text: '7.3' });
const CGM_WARN_HIGH_VALUE_7_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_4, text: '7.4' });
const CGM_WARN_HIGH_VALUE_7_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_5, text: '7.5' });
const CGM_WARN_HIGH_VALUE_7_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_6, text: '7.6' });
const CGM_WARN_HIGH_VALUE_7_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_7, text: '7.7' });
const CGM_WARN_HIGH_VALUE_7_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_8, text: '7.8' });
const CGM_WARN_HIGH_VALUE_7_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_7_9, text: '7.9' });
const CGM_WARN_HIGH_VALUE_8_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_0, text: '8.0' });
const CGM_WARN_HIGH_VALUE_8_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_1, text: '8.1' });
const CGM_WARN_HIGH_VALUE_8_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_2, text: '8.2' });
const CGM_WARN_HIGH_VALUE_8_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_3, text: '8.3' });
const CGM_WARN_HIGH_VALUE_8_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_4, text: '8.4' });
const CGM_WARN_HIGH_VALUE_8_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_5, text: '8.5' });
const CGM_WARN_HIGH_VALUE_8_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_6, text: '8.6' });
const CGM_WARN_HIGH_VALUE_8_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_7, text: '8.7' });
const CGM_WARN_HIGH_VALUE_8_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_8, text: '8.8' });
const CGM_WARN_HIGH_VALUE_8_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_8_9, text: '8.9' });
const CGM_WARN_HIGH_VALUE_9_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_0, text: '9.0' });
const CGM_WARN_HIGH_VALUE_9_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_1, text: '9.1' });
const CGM_WARN_HIGH_VALUE_9_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_2, text: '9.2' });
const CGM_WARN_HIGH_VALUE_9_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_3, text: '9.3' });
const CGM_WARN_HIGH_VALUE_9_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_4, text: '9.4' });
const CGM_WARN_HIGH_VALUE_9_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_5, text: '9.5' });
const CGM_WARN_HIGH_VALUE_9_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_6, text: '9.6' });
const CGM_WARN_HIGH_VALUE_9_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_7, text: '9.7' });
const CGM_WARN_HIGH_VALUE_9_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_8, text: '9.8' });
const CGM_WARN_HIGH_VALUE_9_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_9_9, text: '9.9' });
const CGM_WARN_HIGH_VALUE_10_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_0, text: '10.0' });
const CGM_WARN_HIGH_VALUE_10_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_1, text: '10.1' });
const CGM_WARN_HIGH_VALUE_10_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_2, text: '10.2' });
const CGM_WARN_HIGH_VALUE_10_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_3, text: '10.3' });
const CGM_WARN_HIGH_VALUE_10_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_4, text: '10.4' });
const CGM_WARN_HIGH_VALUE_10_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_5, text: '10.5' });
const CGM_WARN_HIGH_VALUE_10_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_6, text: '10.6' });
const CGM_WARN_HIGH_VALUE_10_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_7, text: '10.7' });
const CGM_WARN_HIGH_VALUE_10_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_8, text: '10.8' });
const CGM_WARN_HIGH_VALUE_10_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_10_9, text: '10.9' });
const CGM_WARN_HIGH_VALUE_11_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_0, text: '11.0' });
const CGM_WARN_HIGH_VALUE_11_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_1, text: '11.1' });
const CGM_WARN_HIGH_VALUE_11_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_2, text: '11.2' });
const CGM_WARN_HIGH_VALUE_11_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_3, text: '11.3' });
const CGM_WARN_HIGH_VALUE_11_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_4, text: '11.4' });
const CGM_WARN_HIGH_VALUE_11_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_5, text: '11.5' });
const CGM_WARN_HIGH_VALUE_11_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_6, text: '11.6' });
const CGM_WARN_HIGH_VALUE_11_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_7, text: '11.7' });
const CGM_WARN_HIGH_VALUE_11_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_8, text: '11.8' });
const CGM_WARN_HIGH_VALUE_11_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_11_9, text: '11.9' });
const CGM_WARN_HIGH_VALUE_12_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_0, text: '12.0' });
const CGM_WARN_HIGH_VALUE_12_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_1, text: '12.1' });
const CGM_WARN_HIGH_VALUE_12_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_2, text: '12.2' });
const CGM_WARN_HIGH_VALUE_12_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_3, text: '12.3' });
const CGM_WARN_HIGH_VALUE_12_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_4, text: '12.4' });
const CGM_WARN_HIGH_VALUE_12_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_5, text: '12.5' });
const CGM_WARN_HIGH_VALUE_12_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_6, text: '12.6' });
const CGM_WARN_HIGH_VALUE_12_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_7, text: '12.7' });
const CGM_WARN_HIGH_VALUE_12_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_8, text: '12.8' });
const CGM_WARN_HIGH_VALUE_12_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_12_9, text: '12.9' });
const CGM_WARN_HIGH_VALUE_13_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_0, text: '13.0' });
const CGM_WARN_HIGH_VALUE_13_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_1, text: '13.1' });
const CGM_WARN_HIGH_VALUE_13_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_2, text: '13.2' });
const CGM_WARN_HIGH_VALUE_13_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_3, text: '13.3' });
const CGM_WARN_HIGH_VALUE_13_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_4, text: '13.4' });
const CGM_WARN_HIGH_VALUE_13_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_5, text: '13.5' });
const CGM_WARN_HIGH_VALUE_13_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_6, text: '13.6' });
const CGM_WARN_HIGH_VALUE_13_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_7, text: '13.7' });
const CGM_WARN_HIGH_VALUE_13_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_8, text: '13.8' });
const CGM_WARN_HIGH_VALUE_13_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_13_9, text: '13.9' });
const CGM_WARN_HIGH_VALUE_14_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_0, text: '14.0' });
const CGM_WARN_HIGH_VALUE_14_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_1, text: '14.1' });
const CGM_WARN_HIGH_VALUE_14_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_2, text: '14.2' });
const CGM_WARN_HIGH_VALUE_14_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_3, text: '14.3' });
const CGM_WARN_HIGH_VALUE_14_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_4, text: '14.4' });
const CGM_WARN_HIGH_VALUE_14_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_5, text: '14.5' });
const CGM_WARN_HIGH_VALUE_14_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_6, text: '14.6' });
const CGM_WARN_HIGH_VALUE_14_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_7, text: '14.7' });
const CGM_WARN_HIGH_VALUE_14_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_8, text: '14.8' });
const CGM_WARN_HIGH_VALUE_14_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_14_9, text: '14.9' });
const CGM_WARN_HIGH_VALUE_15_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_0, text: '15.0' });
const CGM_WARN_HIGH_VALUE_15_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_1, text: '15.1' });
const CGM_WARN_HIGH_VALUE_15_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_2, text: '15.2' });
const CGM_WARN_HIGH_VALUE_15_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_3, text: '15.3' });
const CGM_WARN_HIGH_VALUE_15_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_4, text: '15.4' });
const CGM_WARN_HIGH_VALUE_15_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_5, text: '15.5' });
const CGM_WARN_HIGH_VALUE_15_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_6, text: '15.6' });
const CGM_WARN_HIGH_VALUE_15_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_7, text: '15.7' });
const CGM_WARN_HIGH_VALUE_15_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_8, text: '15.8' });
const CGM_WARN_HIGH_VALUE_15_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_15_9, text: '15.9' });
const CGM_WARN_HIGH_VALUE_16_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_0, text: '16.0' });
const CGM_WARN_HIGH_VALUE_16_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_1, text: '16.1' });
const CGM_WARN_HIGH_VALUE_16_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_2, text: '16.2' });
const CGM_WARN_HIGH_VALUE_16_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_3, text: '16.3' });
const CGM_WARN_HIGH_VALUE_16_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_4, text: '16.4' });
const CGM_WARN_HIGH_VALUE_16_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_5, text: '16.5' });
const CGM_WARN_HIGH_VALUE_16_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_6, text: '16.6' });
const CGM_WARN_HIGH_VALUE_16_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_7, text: '16.7' });
const CGM_WARN_HIGH_VALUE_16_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_8, text: '16.8' });
const CGM_WARN_HIGH_VALUE_16_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_16_9, text: '16.9' });
const CGM_WARN_HIGH_VALUE_17_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_0, text: '17.0' });
const CGM_WARN_HIGH_VALUE_17_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_1, text: '17.1' });
const CGM_WARN_HIGH_VALUE_17_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_2, text: '17.2' });
const CGM_WARN_HIGH_VALUE_17_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_3, text: '17.3' });
const CGM_WARN_HIGH_VALUE_17_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_4, text: '17.4' });
const CGM_WARN_HIGH_VALUE_17_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_5, text: '17.5' });
const CGM_WARN_HIGH_VALUE_17_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_6, text: '17.6' });
const CGM_WARN_HIGH_VALUE_17_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_7, text: '17.7' });
const CGM_WARN_HIGH_VALUE_17_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_8, text: '17.8' });
const CGM_WARN_HIGH_VALUE_17_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_17_9, text: '17.9' });
const CGM_WARN_HIGH_VALUE_18_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_0, text: '18.0' });
const CGM_WARN_HIGH_VALUE_18_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_1, text: '18.1' });
const CGM_WARN_HIGH_VALUE_18_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_2, text: '18.2' });
const CGM_WARN_HIGH_VALUE_18_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_3, text: '18.3' });
const CGM_WARN_HIGH_VALUE_18_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_4, text: '18.4' });
const CGM_WARN_HIGH_VALUE_18_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_5, text: '18.5' });
const CGM_WARN_HIGH_VALUE_18_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_6, text: '18.6' });
const CGM_WARN_HIGH_VALUE_18_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_7, text: '18.7' });
const CGM_WARN_HIGH_VALUE_18_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_8, text: '18.8' });
const CGM_WARN_HIGH_VALUE_18_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_18_9, text: '18.9' });
const CGM_WARN_HIGH_VALUE_19_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_0, text: '19.0' });
const CGM_WARN_HIGH_VALUE_19_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_1, text: '19.1' });
const CGM_WARN_HIGH_VALUE_19_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_2, text: '19.2' });
const CGM_WARN_HIGH_VALUE_19_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_3, text: '19.3' });
const CGM_WARN_HIGH_VALUE_19_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_4, text: '19.4' });
const CGM_WARN_HIGH_VALUE_19_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_5, text: '19.5' });
const CGM_WARN_HIGH_VALUE_19_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_6, text: '19.6' });
const CGM_WARN_HIGH_VALUE_19_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_7, text: '19.7' });
const CGM_WARN_HIGH_VALUE_19_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_8, text: '19.8' });
const CGM_WARN_HIGH_VALUE_19_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_19_9, text: '19.9' });
const CGM_WARN_HIGH_VALUE_20_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_0, text: '20.0' });
const CGM_WARN_HIGH_VALUE_20_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_1, text: '20.1' });
const CGM_WARN_HIGH_VALUE_20_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_2, text: '20.2' });
const CGM_WARN_HIGH_VALUE_20_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_3, text: '20.3' });
const CGM_WARN_HIGH_VALUE_20_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_4, text: '20.4' });
const CGM_WARN_HIGH_VALUE_20_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_5, text: '20.5' });
const CGM_WARN_HIGH_VALUE_20_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_6, text: '20.6' });
const CGM_WARN_HIGH_VALUE_20_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_7, text: '20.7' });
const CGM_WARN_HIGH_VALUE_20_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_8, text: '20.8' });
const CGM_WARN_HIGH_VALUE_20_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_20_9, text: '20.9' });
const CGM_WARN_HIGH_VALUE_21_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_0, text: '21.0' });
const CGM_WARN_HIGH_VALUE_21_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_1, text: '21.1' });
const CGM_WARN_HIGH_VALUE_21_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_2, text: '21.2' });
const CGM_WARN_HIGH_VALUE_21_3 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_3, text: '21.3' });
const CGM_WARN_HIGH_VALUE_21_4 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_4, text: '21.4' });
const CGM_WARN_HIGH_VALUE_21_5 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_5, text: '21.5' });
const CGM_WARN_HIGH_VALUE_21_6 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_6, text: '21.6' });
const CGM_WARN_HIGH_VALUE_21_7 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_7, text: '21.7' });
const CGM_WARN_HIGH_VALUE_21_8 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_8, text: '21.8' });
const CGM_WARN_HIGH_VALUE_21_9 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_21_9, text: '21.9' });
const CGM_WARN_HIGH_VALUE_22_0 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_22_0, text: '22.0' });
const CGM_WARN_HIGH_VALUE_22_1 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_22_1, text: '22.1' });
const CGM_WARN_HIGH_VALUE_22_2 = new SelectItemVO({ id: CGM_WARN_HIGH_VALUE.V_22_2, text: '22.2' });

export const DEFAULT_CGM_WARN_HIGH_VALUE = CGM_WARN_HIGH_VALUE_13_9;
export const CGM_WARN_HIGH_VALUES = [
  CGM_WARN_HIGH_VALUE_5_6,
  CGM_WARN_HIGH_VALUE_5_7,
  CGM_WARN_HIGH_VALUE_5_8,
  CGM_WARN_HIGH_VALUE_5_9,
  CGM_WARN_HIGH_VALUE_6_0,
  CGM_WARN_HIGH_VALUE_6_1,
  CGM_WARN_HIGH_VALUE_6_2,
  CGM_WARN_HIGH_VALUE_6_3,
  CGM_WARN_HIGH_VALUE_6_4,
  CGM_WARN_HIGH_VALUE_6_5,
  CGM_WARN_HIGH_VALUE_6_6,
  CGM_WARN_HIGH_VALUE_6_7,
  CGM_WARN_HIGH_VALUE_6_8,
  CGM_WARN_HIGH_VALUE_6_9,
  CGM_WARN_HIGH_VALUE_7_0,
  CGM_WARN_HIGH_VALUE_7_1,
  CGM_WARN_HIGH_VALUE_7_2,
  CGM_WARN_HIGH_VALUE_7_3,
  CGM_WARN_HIGH_VALUE_7_4,
  CGM_WARN_HIGH_VALUE_7_5,
  CGM_WARN_HIGH_VALUE_7_6,
  CGM_WARN_HIGH_VALUE_7_7,
  CGM_WARN_HIGH_VALUE_7_8,
  CGM_WARN_HIGH_VALUE_7_9,
  CGM_WARN_HIGH_VALUE_8_0,
  CGM_WARN_HIGH_VALUE_8_1,
  CGM_WARN_HIGH_VALUE_8_2,
  CGM_WARN_HIGH_VALUE_8_3,
  CGM_WARN_HIGH_VALUE_8_4,
  CGM_WARN_HIGH_VALUE_8_5,
  CGM_WARN_HIGH_VALUE_8_6,
  CGM_WARN_HIGH_VALUE_8_7,
  CGM_WARN_HIGH_VALUE_8_8,
  CGM_WARN_HIGH_VALUE_8_9,
  CGM_WARN_HIGH_VALUE_9_0,
  CGM_WARN_HIGH_VALUE_9_1,
  CGM_WARN_HIGH_VALUE_9_2,
  CGM_WARN_HIGH_VALUE_9_3,
  CGM_WARN_HIGH_VALUE_9_4,
  CGM_WARN_HIGH_VALUE_9_5,
  CGM_WARN_HIGH_VALUE_9_6,
  CGM_WARN_HIGH_VALUE_9_7,
  CGM_WARN_HIGH_VALUE_9_8,
  CGM_WARN_HIGH_VALUE_9_9,
  CGM_WARN_HIGH_VALUE_10_0,
  CGM_WARN_HIGH_VALUE_10_1,
  CGM_WARN_HIGH_VALUE_10_2,
  CGM_WARN_HIGH_VALUE_10_3,
  CGM_WARN_HIGH_VALUE_10_4,
  CGM_WARN_HIGH_VALUE_10_5,
  CGM_WARN_HIGH_VALUE_10_6,
  CGM_WARN_HIGH_VALUE_10_7,
  CGM_WARN_HIGH_VALUE_10_8,
  CGM_WARN_HIGH_VALUE_10_9,
  CGM_WARN_HIGH_VALUE_11_0,
  CGM_WARN_HIGH_VALUE_11_1,
  CGM_WARN_HIGH_VALUE_11_2,
  CGM_WARN_HIGH_VALUE_11_3,
  CGM_WARN_HIGH_VALUE_11_4,
  CGM_WARN_HIGH_VALUE_11_5,
  CGM_WARN_HIGH_VALUE_11_6,
  CGM_WARN_HIGH_VALUE_11_7,
  CGM_WARN_HIGH_VALUE_11_8,
  CGM_WARN_HIGH_VALUE_11_9,
  CGM_WARN_HIGH_VALUE_12_0,
  CGM_WARN_HIGH_VALUE_12_1,
  CGM_WARN_HIGH_VALUE_12_2,
  CGM_WARN_HIGH_VALUE_12_3,
  CGM_WARN_HIGH_VALUE_12_4,
  CGM_WARN_HIGH_VALUE_12_5,
  CGM_WARN_HIGH_VALUE_12_6,
  CGM_WARN_HIGH_VALUE_12_7,
  CGM_WARN_HIGH_VALUE_12_8,
  CGM_WARN_HIGH_VALUE_12_9,
  CGM_WARN_HIGH_VALUE_13_0,
  CGM_WARN_HIGH_VALUE_13_1,
  CGM_WARN_HIGH_VALUE_13_2,
  CGM_WARN_HIGH_VALUE_13_3,
  CGM_WARN_HIGH_VALUE_13_4,
  CGM_WARN_HIGH_VALUE_13_5,
  CGM_WARN_HIGH_VALUE_13_6,
  CGM_WARN_HIGH_VALUE_13_7,
  CGM_WARN_HIGH_VALUE_13_8,
  CGM_WARN_HIGH_VALUE_13_9,
  CGM_WARN_HIGH_VALUE_14_0,
  CGM_WARN_HIGH_VALUE_14_1,
  CGM_WARN_HIGH_VALUE_14_2,
  CGM_WARN_HIGH_VALUE_14_3,
  CGM_WARN_HIGH_VALUE_14_4,
  CGM_WARN_HIGH_VALUE_14_5,
  CGM_WARN_HIGH_VALUE_14_6,
  CGM_WARN_HIGH_VALUE_14_7,
  CGM_WARN_HIGH_VALUE_14_8,
  CGM_WARN_HIGH_VALUE_14_9,
  CGM_WARN_HIGH_VALUE_15_0,
  CGM_WARN_HIGH_VALUE_15_1,
  CGM_WARN_HIGH_VALUE_15_2,
  CGM_WARN_HIGH_VALUE_15_3,
  CGM_WARN_HIGH_VALUE_15_4,
  CGM_WARN_HIGH_VALUE_15_5,
  CGM_WARN_HIGH_VALUE_15_6,
  CGM_WARN_HIGH_VALUE_15_7,
  CGM_WARN_HIGH_VALUE_15_8,
  CGM_WARN_HIGH_VALUE_15_9,
  CGM_WARN_HIGH_VALUE_16_0,
  CGM_WARN_HIGH_VALUE_16_1,
  CGM_WARN_HIGH_VALUE_16_2,
  CGM_WARN_HIGH_VALUE_16_3,
  CGM_WARN_HIGH_VALUE_16_4,
  CGM_WARN_HIGH_VALUE_16_5,
  CGM_WARN_HIGH_VALUE_16_6,
  CGM_WARN_HIGH_VALUE_16_7,
  CGM_WARN_HIGH_VALUE_16_8,
  CGM_WARN_HIGH_VALUE_16_9,
  CGM_WARN_HIGH_VALUE_17_0,
  CGM_WARN_HIGH_VALUE_17_1,
  CGM_WARN_HIGH_VALUE_17_2,
  CGM_WARN_HIGH_VALUE_17_3,
  CGM_WARN_HIGH_VALUE_17_4,
  CGM_WARN_HIGH_VALUE_17_5,
  CGM_WARN_HIGH_VALUE_17_6,
  CGM_WARN_HIGH_VALUE_17_7,
  CGM_WARN_HIGH_VALUE_17_8,
  CGM_WARN_HIGH_VALUE_17_9,
  CGM_WARN_HIGH_VALUE_18_0,
  CGM_WARN_HIGH_VALUE_18_1,
  CGM_WARN_HIGH_VALUE_18_2,
  CGM_WARN_HIGH_VALUE_18_3,
  CGM_WARN_HIGH_VALUE_18_4,
  CGM_WARN_HIGH_VALUE_18_5,
  CGM_WARN_HIGH_VALUE_18_6,
  CGM_WARN_HIGH_VALUE_18_7,
  CGM_WARN_HIGH_VALUE_18_8,
  CGM_WARN_HIGH_VALUE_18_9,
  CGM_WARN_HIGH_VALUE_19_0,
  CGM_WARN_HIGH_VALUE_19_1,
  CGM_WARN_HIGH_VALUE_19_2,
  CGM_WARN_HIGH_VALUE_19_3,
  CGM_WARN_HIGH_VALUE_19_4,
  CGM_WARN_HIGH_VALUE_19_5,
  CGM_WARN_HIGH_VALUE_19_6,
  CGM_WARN_HIGH_VALUE_19_7,
  CGM_WARN_HIGH_VALUE_19_8,
  CGM_WARN_HIGH_VALUE_19_9,
  CGM_WARN_HIGH_VALUE_20_0,
  CGM_WARN_HIGH_VALUE_20_1,
  CGM_WARN_HIGH_VALUE_20_2,
  CGM_WARN_HIGH_VALUE_20_3,
  CGM_WARN_HIGH_VALUE_20_4,
  CGM_WARN_HIGH_VALUE_20_5,
  CGM_WARN_HIGH_VALUE_20_6,
  CGM_WARN_HIGH_VALUE_20_7,
  CGM_WARN_HIGH_VALUE_20_8,
  CGM_WARN_HIGH_VALUE_20_9,
  CGM_WARN_HIGH_VALUE_21_0,
  CGM_WARN_HIGH_VALUE_21_1,
  CGM_WARN_HIGH_VALUE_21_2,
  CGM_WARN_HIGH_VALUE_21_3,
  CGM_WARN_HIGH_VALUE_21_4,
  CGM_WARN_HIGH_VALUE_21_5,
  CGM_WARN_HIGH_VALUE_21_6,
  CGM_WARN_HIGH_VALUE_21_7,
  CGM_WARN_HIGH_VALUE_21_8,
  CGM_WARN_HIGH_VALUE_21_9,
  CGM_WARN_HIGH_VALUE_22_0,
  CGM_WARN_HIGH_VALUE_22_1,
  CGM_WARN_HIGH_VALUE_22_2,
];
export const CGM_WARN_HIGH_VALUE_MAP = SelectItemVO.getMap(CGM_WARN_HIGH_VALUES);
