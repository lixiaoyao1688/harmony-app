/**
 * 低CGM值警示 血糖值 配置
 */
export const CGM_WARN_LOW_VALUE_MIN = 2.8;
export const CGM_WARN_LOW_VALUE_MAX = 5;
export const CGM_WARN_LOW_VALUE_DEFAULT = 3.6;
export const CGM_WARN_LOW_VALUE_DIGIT = 1;
