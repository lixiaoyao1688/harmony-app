import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * CGM警示 时间范围 配置
 */
export enum CGM_WARN_TIME {
  T_00_00 = 0,
  T_00_30 = 30,
  T_01_00 = 60,
  T_01_30 = 90,
  T_02_00 = 120,
  T_02_30 = 150,
  T_03_00 = 180,
  T_03_30 = 210,
  T_04_00 = 240,
  T_04_30 = 270,
  T_05_00 = 300,
  T_05_30 = 330,
  T_06_00 = 360,
  T_06_30 = 390,
  T_07_00 = 420,
  T_07_30 = 450,
  T_08_00 = 480,
  T_08_30 = 510,
  T_09_00 = 540,
  T_09_30 = 570,
  T_10_00 = 600,
  T_10_30 = 630,
  T_11_00 = 660,
  T_11_30 = 690,
  T_12_00 = 720,
  T_12_30 = 750,
  T_13_00 = 780,
  T_13_30 = 810,
  T_14_00 = 840,
  T_14_30 = 870,
  T_15_00 = 900,
  T_15_30 = 930,
  T_16_00 = 960,
  T_16_30 = 990,
  T_17_00 = 1020,
  T_17_30 = 1050,
  T_18_00 = 1080,
  T_18_30 = 1110,
  T_19_00 = 1140,
  T_19_30 = 1170,
  T_20_00 = 1200,
  T_20_30 = 1230,
  T_21_00 = 1260,
  T_21_30 = 1290,
  T_22_00 = 1320,
  T_22_30 = 1350,
  T_23_00 = 1380,
  T_23_30 = 1410,
  T_24_00 = 1440,
}

const CGM_WARN_TIME_TIME_00_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_00_00, text: '00:00' });
const CGM_WARN_TIME_TIME_00_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_00_30, text: '00:30' });
const CGM_WARN_TIME_TIME_01_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_01_00, text: '01:00' });
const CGM_WARN_TIME_TIME_01_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_01_30, text: '01:30' });
const CGM_WARN_TIME_TIME_02_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_02_00, text: '02:00' });
const CGM_WARN_TIME_TIME_02_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_02_30, text: '02:30' });
const CGM_WARN_TIME_TIME_03_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_03_00, text: '03:00' });
const CGM_WARN_TIME_TIME_03_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_03_30, text: '03:30' });
const CGM_WARN_TIME_TIME_04_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_04_00, text: '04:00' });
const CGM_WARN_TIME_TIME_04_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_04_30, text: '04:30' });
const CGM_WARN_TIME_TIME_05_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_05_00, text: '05:00' });
const CGM_WARN_TIME_TIME_05_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_05_30, text: '05:30' });
const CGM_WARN_TIME_TIME_06_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_06_00, text: '06:00' });
const CGM_WARN_TIME_TIME_06_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_06_30, text: '06:30' });
const CGM_WARN_TIME_TIME_07_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_07_00, text: '07:00' });
const CGM_WARN_TIME_TIME_07_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_07_30, text: '07:30' });
const CGM_WARN_TIME_TIME_08_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_08_00, text: '08:00' });
const CGM_WARN_TIME_TIME_08_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_08_30, text: '08:30' });
const CGM_WARN_TIME_TIME_09_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_09_00, text: '09:00' });
const CGM_WARN_TIME_TIME_09_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_09_30, text: '09:30' });
const CGM_WARN_TIME_TIME_10_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_10_00, text: '10:00' });
const CGM_WARN_TIME_TIME_10_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_10_30, text: '10:30' });
const CGM_WARN_TIME_TIME_11_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_11_00, text: '11:00' });
const CGM_WARN_TIME_TIME_11_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_11_30, text: '11:30' });
const CGM_WARN_TIME_TIME_12_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_12_00, text: '12:00' });
const CGM_WARN_TIME_TIME_12_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_12_30, text: '12:30' });
const CGM_WARN_TIME_TIME_13_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_13_00, text: '13:00' });
const CGM_WARN_TIME_TIME_13_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_13_30, text: '13:30' });
const CGM_WARN_TIME_TIME_14_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_14_00, text: '14:00' });
const CGM_WARN_TIME_TIME_14_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_14_30, text: '14:30' });
const CGM_WARN_TIME_TIME_15_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_15_00, text: '15:00' });
const CGM_WARN_TIME_TIME_15_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_15_30, text: '15:30' });
const CGM_WARN_TIME_TIME_16_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_16_00, text: '16:00' });
const CGM_WARN_TIME_TIME_16_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_16_30, text: '16:30' });
const CGM_WARN_TIME_TIME_17_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_17_00, text: '17:00' });
const CGM_WARN_TIME_TIME_17_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_17_30, text: '17:30' });
const CGM_WARN_TIME_TIME_18_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_18_00, text: '18:00' });
const CGM_WARN_TIME_TIME_18_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_18_30, text: '18:30' });
const CGM_WARN_TIME_TIME_19_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_19_00, text: '19:00' });
const CGM_WARN_TIME_TIME_19_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_19_30, text: '19:30' });
const CGM_WARN_TIME_TIME_20_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_20_00, text: '20:00' });
const CGM_WARN_TIME_TIME_20_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_20_30, text: '20:30' });
const CGM_WARN_TIME_TIME_21_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_21_00, text: '21:00' });
const CGM_WARN_TIME_TIME_21_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_21_30, text: '21:30' });
const CGM_WARN_TIME_TIME_22_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_22_00, text: '22:00' });
const CGM_WARN_TIME_TIME_22_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_22_30, text: '22:30' });
const CGM_WARN_TIME_TIME_23_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_23_00, text: '23:00' });
const CGM_WARN_TIME_TIME_23_30 = new SelectItemVO({ id: CGM_WARN_TIME.T_23_30, text: '23:30' });
const CGM_WARN_TIME_TIME_24_00 = new SelectItemVO({ id: CGM_WARN_TIME.T_24_00, text: '24:00' });

export const DEFAULT_CGM_WARN_TIME_1 = CGM_WARN_TIME_TIME_00_00;
export const DEFAULT_CGM_WARN_TIME_2 = CGM_WARN_TIME_TIME_24_00;
export const CGM_WARN_TIMES = [
  CGM_WARN_TIME_TIME_00_00,
  CGM_WARN_TIME_TIME_00_30,
  CGM_WARN_TIME_TIME_01_00,
  CGM_WARN_TIME_TIME_01_30,
  CGM_WARN_TIME_TIME_02_00,
  CGM_WARN_TIME_TIME_02_30,
  CGM_WARN_TIME_TIME_03_00,
  CGM_WARN_TIME_TIME_03_30,
  CGM_WARN_TIME_TIME_04_00,
  CGM_WARN_TIME_TIME_04_30,
  CGM_WARN_TIME_TIME_05_00,
  CGM_WARN_TIME_TIME_05_30,
  CGM_WARN_TIME_TIME_06_00,
  CGM_WARN_TIME_TIME_06_30,
  CGM_WARN_TIME_TIME_07_00,
  CGM_WARN_TIME_TIME_07_30,
  CGM_WARN_TIME_TIME_08_00,
  CGM_WARN_TIME_TIME_08_30,
  CGM_WARN_TIME_TIME_09_00,
  CGM_WARN_TIME_TIME_09_30,
  CGM_WARN_TIME_TIME_10_00,
  CGM_WARN_TIME_TIME_10_30,
  CGM_WARN_TIME_TIME_11_00,
  CGM_WARN_TIME_TIME_11_30,
  CGM_WARN_TIME_TIME_12_00,
  CGM_WARN_TIME_TIME_12_30,
  CGM_WARN_TIME_TIME_13_00,
  CGM_WARN_TIME_TIME_13_30,
  CGM_WARN_TIME_TIME_14_00,
  CGM_WARN_TIME_TIME_14_30,
  CGM_WARN_TIME_TIME_15_00,
  CGM_WARN_TIME_TIME_15_30,
  CGM_WARN_TIME_TIME_16_00,
  CGM_WARN_TIME_TIME_16_30,
  CGM_WARN_TIME_TIME_17_00,
  CGM_WARN_TIME_TIME_17_30,
  CGM_WARN_TIME_TIME_18_00,
  CGM_WARN_TIME_TIME_18_30,
  CGM_WARN_TIME_TIME_19_00,
  CGM_WARN_TIME_TIME_19_30,
  CGM_WARN_TIME_TIME_20_00,
  CGM_WARN_TIME_TIME_20_30,
  CGM_WARN_TIME_TIME_21_00,
  CGM_WARN_TIME_TIME_21_30,
  CGM_WARN_TIME_TIME_22_00,
  CGM_WARN_TIME_TIME_22_30,
  CGM_WARN_TIME_TIME_23_00,
  CGM_WARN_TIME_TIME_23_30,
  CGM_WARN_TIME_TIME_24_00,
];

export const CGM_WARN_TIME_MAP = SelectItemVO.getMap(CGM_WARN_TIMES);
