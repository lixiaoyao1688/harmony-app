import {CGM_STATUS} from '@/modules/cgm/config/cgm.status';


/**
 * 患者 绑定CGM DTO
 */
export interface CgmBindDTO {
  admission_id: number;  // 患者id
  sn: string;  // CGM序列号
}


/**
 * CGM 实时运行信息 DTO
 */
export interface CgmInfoDTO {
  status: CGM_STATUS;
}
