import {CGM_EXTRA} from '@/modules/cgm/config/cgm.extra';


// https://192.168.1.249:85/project/75/interface/api/5004
// https://192.168.1.249:85/project/40/interface/api/3228
export interface CgmExtraDTO {
  extra_status: CGM_EXTRA;  // CGM状态
  extra_time: number;  // 闭环初始化结束的时间戳
}
