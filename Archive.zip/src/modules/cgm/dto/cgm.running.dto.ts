import {CGM_RUNNING_STATUS} from '@/modules/cgm/config/cgm.running';


/**
 * CGM 运行信息
 */
export interface CgmRunningDTO {
  status:	CGM_RUNNING_STATUS;
  sn:	string;  // 序列号
  product_code:	string;  // 型号
  last_time: number;  // CGM过期时间，时间戳，秒
  value: number;  // 最近血糖值，如 5.5，单位 mmol/L (by 李丹纯 2026-02-28 10:16:05: 后端发过来可能是2位小数(不准确)，四舍五入到1位)
  record_time: number;  // 最近检测时间，时间戳，单位秒
  storard: number;  // 达标率
  index: number;
}
