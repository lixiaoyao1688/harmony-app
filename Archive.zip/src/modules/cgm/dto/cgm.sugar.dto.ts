export interface CgmSugaryDTO {
  url: string;  // 糖仁授权地址，如: "https://test.aaruy.com/open/sugar/index/84b1139db3df11f08b9100163e2c44f1"
}

export interface CgmSugarBodyDTO {
  admission_id: number;
}
