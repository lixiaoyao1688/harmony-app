import {CGM_RAGE} from '@/modules/cgm/config/cgm.rage';
import {CGM_WARN_HIGH} from '@/modules/cgm/config/cgm.warn.high';
import {CGM_WARN_HIGH_PRE} from '@/modules/cgm/config/cgm.warn.high.pre';
import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';


/**
 * CGM警示设置 DTO
 *
 * 参考
 * http://192.168.1.249:8000/project/75/interface/api/7575: warn_item
 */
export interface CgmWarnTipDTO {
  if_high_cgm: OPEN_OR_CLOSE;  // 高CGM值警示（1-开 0关）
  high_cgm_item: Array<CgmWarnTipHighDTO>;  // 高CGM警示配置项列表
  if_low_cgm: OPEN_OR_CLOSE;  // 低CGM值警示（1-开 0关）
  low_cgm_item: Array<CgmWarnTipLowDTO>;  // 低CGM警示配置项列表
}

/**
 * 高CGM警示配置项 DTO
 */
export interface CgmWarnTipHighDTO {
  value_start: number;  // 开始时刻，分钟，范围: [0,1440)且<value_end;
  value_end: number;  // 结束时刻，分钟，范围: (0,1440]且>value_start;
  value: number;  // CGM值，mmol/L
  notice_minute_before: CGM_WARN_HIGH_PRE;  // 高CGM值前警示
  if_notice_value: CGM_WARN_HIGH;  // 高CGM值警示
  rage_index: CGM_RAGE;  // 上升警示
  rage_start: number;  // 上升警示自定义值，范围 [0.06,0.28]，默认 0.06
}

/**
 * 低CGM警示配置项 DTO
 */
export interface CgmWarnTipLowDTO {
  value_start: number;  // 开始时刻，分钟，范围: [0,1440)且<value_end;
  value_end: number;  // 结束时刻，分钟，范围: (0,1440]且>value_start;
  value: number;  // CGM值，mmol/L
  if_notice_value_before: OPEN_OR_CLOSE;  // 低CGM值前警示
  if_notice_value: OPEN_OR_CLOSE;  // 低CGM值警示
  if_stop_value_before: OPEN_OR_CLOSE;  // 低CGM值前暂停输注（关闭->开启时，使"低CGM值暂停输注"关闭。by 黄伦 2025-11-25）
  if_stop_value: OPEN_OR_CLOSE;  // 低CGM值暂停输注（关闭->开启时，使"低CGM值前暂停输注"关闭。by 黄伦 2025-11-25）
  if_recover_base: OPEN_OR_CLOSE;  // 恢复基础率警示（if_stop_value_before 或 if_stop_value 开启时，此字段才可编辑并打开，否则保持不可编辑且关闭。by 黄伦 2025-11-25）
}
