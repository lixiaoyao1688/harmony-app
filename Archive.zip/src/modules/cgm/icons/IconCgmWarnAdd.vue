<script setup lang="ts">
interface Prop {
  size: string;
  isDisabled?: boolean;
}

interface Emit {
  (e: 'click'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClick(): void {
  emit('click');
}
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" :width="size" :height="size" viewBox="0 0 19.969 19.969" @click="onClick">
    <g transform="translate(9.986 1.5) rotate(45)">
      <path d="M0,0V16.969" transform="translate(-0.001 0.001) rotate(-45)" fill="none" stroke-linecap="round" stroke-width="3"
            :stroke="isDisabled ? 'rgb(162,173,184)' : 'rgb(105,158,245)'" />
      <path d="M0,0V16.969" transform="translate(0 12) rotate(-135)" fill="none" stroke-linecap="round" stroke-width="3"
            :stroke="isDisabled ? 'rgb(162,173,184)' : 'rgb(105,158,245)'" />
    </g>
  </svg>
</template>
