<script setup lang="ts">
/**
 * 高CGM警示项 移除图标
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Emit {
	(e: 'click'): void;
}

const emit = defineEmits<Emit>();

function onClick(): void {
  emit('click');
}
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="11.822" height="12" viewBox="0 0 11.822 12"
       class="cursor-pointer"
       style="height: 24px; line-height: 24px;"
       @click.stop="onClick">
    <path d="M171.12,157.96l.039.036,4.793,4.8,4.617-4.619a.706.706,0,0,1,1.033.96l-.035.039-4.618,4.619,4.617,4.619a.706.706,0,0,1-.959,1.034l-.039-.036-4.617-4.619-4.793,4.8a.706.706,0,0,1-1.033-.959l.036-.039,4.794-4.8-4.793-4.8a.706.706,0,0,1,.959-1.034Z"
          transform="translate(-169.955 -157.792)"
          fill="#fff" />
  </svg>
</template>

<style scoped>
svg:hover > path {
  fill: var(--aaruy-primary-color-1);
}
</style>
