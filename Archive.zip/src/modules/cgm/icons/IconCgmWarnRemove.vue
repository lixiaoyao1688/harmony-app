<script setup lang="ts">
interface Prop {
  size: string;
  isDisabled?: boolean;
}

interface Emit {
  (e: 'click'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClick(): void {
  emit('click');
}
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" :width="size" :height="size" viewBox="0 0 20.244 20.245" @click="onClick">
    <g data-name="组 8622" transform="translate(2.122 2.121)">
      <path d="M0,0V22.628" transform="translate(-0.001 0.001) rotate(-45)" fill="none" stroke-linecap="round" stroke-width="3"
            :stroke="isDisabled ? 'rgb(162,173,184)' : 'rgb(247,58,63)'" />
      <path d="M0,0V22.628" transform="translate(0 16.002) rotate(-135)" fill="none" stroke-linecap="round" stroke-width="3"
            :stroke="isDisabled ? 'rgb(162,173,184)' : 'rgb(247,58,63)'" />
    </g>
  </svg>
</template>
