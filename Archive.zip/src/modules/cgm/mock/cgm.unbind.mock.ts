export const CGM_UNBIND_MOCKING = false;

export function MOCK_cgmUnbind(): Promise<null> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(null);
      // reject('模拟服务器错误 cgm');
    }, 1000);
  });
}
