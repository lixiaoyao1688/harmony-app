import {httpUpdate, instance} from '@/lib/http/request/http';
import { AppHttpClient } from '@/lib/http/client/AppHttpClient';
import {isWebHttpUsing} from '@/lib/env/utils/env.domain.util';
import {httpNoResponseCatcher, httpResponseCatcher, isHttpResponseError} from '@/lib/http/util/http.utils';
import {CGM_UNBIND_MOCKING, MOCK_cgmUnbind} from '@/modules/cgm/mock/cgm.unbind.mock';
import type {CgmBindDTO} from '@/modules/cgm/dto/cgm.dto';
import type {HttpResponseDTO} from '@/lib/http/dto/http.dto';
import type {HTTPResponseType} from '@/lib/http/types/http.type';


export const CGM_PATH = {
  BIND: '/hospital/admission/cgm/bind',
  UNBIND: '/hospital/admission/cgm/unbind',
};

enum LOG {
  BIND = '患者 绑定CGM',
  UNBIND = '患者 解绑CGM',
}

export function httpCgmBind(body: CgmBindDTO) {
  return new Promise<null>((resolve, reject) => {
    
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      resolve(null);
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<null>>(CGM_PATH.BIND, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, LOG.BIND, reject));
    }
    else {
      AppHttpClient
        .post<CgmBindDTO>(CGM_PATH.BIND, body, LOG.BIND, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, LOG.BIND, reject));
    }

  });
}

export function httpCgmUnBind(admissionId: number) {
  if (CGM_UNBIND_MOCKING) {
    return MOCK_cgmUnbind();
  }
  return httpUpdate<undefined>(CGM_PATH.UNBIND + `/${admissionId}`, undefined, LOG.UNBIND);
}
