import { instance } from '@/lib/http/request/http';
import {CgmSugarVO} from '@/modules/cgm/vo/CgmSugar.vo';
import { AppHttpClient } from '@/lib/http/client/AppHttpClient';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import { httpNoResponseCatcher, httpResponseCatcher, isHttpResponseError } from '@/lib/http/util/http.utils';
import type {HttpResponseDTO} from '@/lib/http/dto/http.dto';
import type {HTTPResponseType} from '@/lib/http/types/http.type';
import type {CgmSugarBodyDTO, CgmSugaryDTO} from '@/modules/cgm/dto/cgm.sugar.dto';


export const CGM_SUGAR_PATH = {
  AUTH: '/hospital/admission/auth/sugar/url',
};

enum LOG {
  AUTH = '患者 糖仁授权二维码',
}

export function httpCgmSugarAuth(body: CgmSugarBodyDTO) {
  return new Promise<CgmSugarVO>((resolve, reject) => {
    
    const PATH = CGM_SUGAR_PATH.AUTH;
    const AUTH_LOG = LOG.AUTH;
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      resolve(new CgmSugarVO(data.data.data as CgmSugaryDTO));
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<CgmSugaryDTO>>(PATH, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, AUTH_LOG, reject));
    }
    else {
      AppHttpClient
        .post<CgmSugarBodyDTO>(PATH, body, AUTH_LOG, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, AUTH_LOG, reject));
    }
    
  });
}
