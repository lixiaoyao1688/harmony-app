import {CgmWarnHighItemVO} from '@/modules/cgm/vo/CgmWarnHighItem.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';

export type CgmWarnHighItemType = SelectItemVO<CgmWarnHighItemVO>;
