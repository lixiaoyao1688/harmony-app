import {CGM_COLOR} from '@/modules/cgm/config/cgm.color';
import {CGM_CHANGE, CGM_CHANGE_DIRECTION} from '@/modules/cgm/config/cgm.change';


export function getCgmTextColor(value: number, low: number, high: number): CGM_COLOR {
  if (value < low) {
    return CGM_COLOR.LOW;
  }
  if (value > high) {
    return CGM_COLOR.HIGH;
  }
  return CGM_COLOR.NORMAL;
}

// scale: 缩放倍数，默认1，仅PC
export function getCgmChangeIcon(status: CGM_CHANGE, color: string, direction?: CGM_CHANGE_DIRECTION, isApp?: boolean, scale?: number): string {
  if (isApp) {
    if (status === CGM_CHANGE.VERY_SLOW) {
      return `<svg xmlns="http://www.w3.org/2000/svg" width="12.47" height="6.235" viewBox="0 0 12.47 6.235">
        <g transform="translate(12.47) rotate(90)">
          <g transform="translate(0 0)">
            <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
            <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
          </g>
        </g>
      </svg>`;
    }
    else if (status === CGM_CHANGE.SLOW) {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="6.235" height="12.47" viewBox="0 0 6.235 12.47">
          <g transform="translate(0 0)">
            <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
            <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
          </g>
        </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="6.235" height="12.47" viewBox="0 0 6.235 12.47">
          <g transform="translate(6.235 12.47) rotate(180)">
            <g transform="translate(0 0)">
              <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
              <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
            </g>
          </g>
        </svg>`;
      }
    }
    else if (status === CGM_CHANGE.FAST) {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="13.235" height="12.47" viewBox="0 0 13.235 12.47">
          <g transform="translate(-262.55 -713.029)">
            <g transform="translate(262.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(269.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
          </g>
        </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="13.235" height="12.47" viewBox="0 0 13.235 12.47">
          <g transform="translate(275.784 725.499) rotate(180)">
            <g transform="translate(262.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(269.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
          </g>
        </svg>`;
      }
    }
    else {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="20.235" height="12.47" viewBox="0 0 20.235 12.47">
          <g transform="translate(-262.55 -713.029)">
            <g transform="translate(262.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(269.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(276.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
          </g>
        </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="20.235" height="12.47" viewBox="0 0 20.235 12.47">
          <g transform="translate(282.784 725.499) rotate(180)">
            <g transform="translate(262.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(269.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
            <g transform="translate(276.55 713.029)">
              <g transform="translate(0 0)">
                <path d="M500.595,414.689v-8.313h2.078v8.313Z" transform="translate(-498.516 -402.219)" fill="${color}" />
                <path d="M435.086,278.612l3.076-4.157,3.159,4.157h-6.235Z" transform="translate(-435.086 -274.455)" fill="${color}" />
              </g>
            </g>
          </g>
        </svg>`;
      }
    }
  }
  else {
    const s = scale || 1;
    if (status === CGM_CHANGE.VERY_SLOW) {
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${16 * s}" height="${8 * s}" viewBox="0 0 16 8">
        <g transform="translate(-500 -205.999)">
          <g transform="translate(4297.528 2353.011) rotate(90)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
        </g>
      </svg>`;
    }
    else if (status === CGM_CHANGE.SLOW) {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${8 * s}" height="${16 * s}" viewBox="0 0 8 16">
          <g transform="translate(2147.012 -3781.528)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}" />
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}" />
            </g>
          </g>
        </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${8 * s}" height="${16 * s}" viewBox="0 0 8 16">
          <g transform="translate(-2139.012 3797.529) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
        </svg>`;
      }
    }
    else if (status === CGM_CHANGE.FAST) {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${17 * s}" height="${16 * s}" viewBox="0 0 17 16">
        <g transform="translate(512 217.999) rotate(180)">
          <g transform="translate(-1644.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
          <g transform="translate(-1635.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
        </g>
      </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${17 * s}" height="${16 * s}" viewBox="0 0 17 16">
        <g transform="translate(-495 -201.999)">
          <g transform="translate(-1644.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
          <g transform="translate(-1635.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
        </g>
      </svg>`;
      }
    }
    else {
      if (direction === CGM_CHANGE_DIRECTION.UP) {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${26 * s}" height="${16.001 * s}" viewBox="0 0 26 16.001">
        <g transform="translate(512 218) rotate(180)">
          <g transform="translate(503 218) rotate(180)">
            <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
            <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
          </g>
          <g transform="translate(-1635.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
          <g transform="translate(494 218) rotate(180)">
            <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
            <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
          </g>
        </g>
      </svg>`;
      }
      else {
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${26 * s}" height="${16.001 * s}" viewBox="0 0 26 16.001">
        <g transform="translate(-486 -201.999)">
          <g transform="translate(503 218) rotate(180)">
            <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
            <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
          </g>
          <g transform="translate(-1635.012 3999.527) rotate(180)">
            <g transform="translate(-2147.012 3781.528)">
              <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
              <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
            </g>
          </g>
          <g transform="translate(494 218) rotate(180)">
            <path d="M500.595,417.043V406.376h2.667v10.667Z" transform="translate(-497.928 -401.042)" fill="${color}"/>
            <path d="M435.086,279.788l3.947-5.333,4.053,5.333h-8Z" transform="translate(-435.086 -274.455)" fill="${color}"/>
          </g>
        </g>
      </svg>`;
      }
    }
  }
}
