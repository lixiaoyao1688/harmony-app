<script setup lang="ts">
import {computed, ref} from 'vue';
import { CardVO } from '@/modules/admission/vo/Card.vo';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import {useUserStore} from '@/modules/user/store/user.store';
import {httpCgmBind} from '@/modules/cgm/requests/cgm.http';
import {httpAdmissionInfo} from '@/modules/admission/requests/admission.http';
import {
  notifyErrorLackInputer,
  notifyErrorNormal,
  notifyInfo,
  notifySuccessNormal
} from '@/lib/aaruy-design/notify/notify';
import ScanView from '@/lib/aaruy-design/scaner/ScanView.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import IconCgmBinder from '@/modules/cgm/icons/IconCgmBinder.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import FieldDouble from '@/lib/aaruy-design/field/FieldDouble.vue';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import InputField from '@/lib/aaruy-design/input/field/InputField.vue';
import PageBoardContent from '@/lib/aaruy-design/page/component/PageBoardContent.vue';
import {notifyNoAuth} from '@/modules/auth/utils/auth.util';
import {notifyInfoMobile} from '@/lib/aaruy-design/notify/mobile/nofity.mobile';


/**
 * 绑CGM 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  c: CardVO;
  isDisabled?: boolean;
  isNotAuth?: boolean;  // 无权限
  isNotAssigned?: boolean;  // 未分配设备
}

interface Emit {
  (e: 'open'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const FIELD_TITLE = 'CGM序列号';
const userStore = useUserStore();

const code = ref<string>('');
const isOpened = ref<boolean>(false);
const isWaiting = ref<boolean>(false);
const vo = ref<AdmissionVO>(new AdmissionVO());


function onOpen(): void {
  if (prop.isDisabled) {
    if (prop.isNotAuth) {
      notifyNoAuth();
    }
    else if (prop.isNotAssigned) {
      notifyInfoMobile('未分配设备');
    }
    return;
  }
  emit('open');
  isOpened.value = true;
  fetchData();
}

function onBack(): void {
  isOpened.value = false;
}

function onCodeChange(data: string): void {
  code.value = data;
}

function onReset(): void {
  code.value = '';
}

function fetchData(): void {
  vo.value = new AdmissionVO();
  httpAdmissionInfo(prop.c.id)
    .then(data => {
      vo.value = data;
    });
}

function onConfirm(): void {
  if (!code.value) {
    notifyErrorLackInputer(FIELD_TITLE);
    return;
  }
  isWaiting.value = true;
  httpCgmBind({ admission_id: vo.value.id, sn: code.value })
    .then(_ => notifySuccessNormal('绑定完成'))
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => isWaiting.value = false);
}
</script>

<template>
  <PageMobile :visible="isOpened" @goBack="onBack">
    <template #title>绑CGM</template>
    <template #content>
      <PageBoardContent>
        <FieldView2 type="double-text" is-start is-end>
          <FieldDouble t1="姓名" :v1="vo.nameText" t1-width="40px" t2="科室" :v2="vo.partText" />
          <FieldDouble t1="床号" :v1="vo.bedText"  t1-width="40px" t2="登记号" :v2="vo.codeText" is-end />
        </FieldView2>
        <FieldView2 type="other" is-start margin-top="16px">
          <InputField :data="code" type="text" :title="FIELD_TITLE" placeholder="请输入或扫码" is-field @change="onCodeChange" />
          <ScanView margin="0 0 0 12px" @finished="onCodeChange" />
        </FieldView2>
        <FieldView2 type="text" title="操作者" :value="userStore.user.name" is-end></FieldView2>
        <template #bottom>
          <div class="h-full flex items-start justify-between px-16">
            <ButtonView type="default" text="重置" style="width: 49%; height: 80%; font-size: 16px;" @click="onReset" />
            <ButtonView type="primary" text="确认" style="width: 49%; height: 80%; font-size: 16px;" :loading="isWaiting" @click="onConfirm" />
          </div>
        </template>
      </PageBoardContent>
    </template>
  </PageMobile>
  <div class="inline-block text-center w-64-px h-64-px" @click.stop="onOpen">
    <IconCgmBinder :is-disabled="isDisabled" />
    <div :class="{ 'text-weak-real-3': isDisabled, 'text-white': !isDisabled }">绑CGM</div>
  </div>
</template>
