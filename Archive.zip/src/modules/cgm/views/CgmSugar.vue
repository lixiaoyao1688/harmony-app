<script setup lang="ts">
import {ref, watch} from 'vue';
import { toDataURL }  from 'qrcode';
import {useRoute} from 'vue-router';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import {INVALID_ID} from '@/utils/global.vo.help';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useOutPatientStore} from '@/modules/admission/store/out.patient.store';
import {ROUTE_IN_PATIENT, ROUTE_OUT_PATIENT} from '@/routers/global.router';
import {httpCgmSugarAuth} from '@/modules/cgm/requests/cgm.sugar.http';
import {printGroup, printSingle, printSingleError} from '@/lib/log/util/log.util';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import TooltipComplex from '@/lib/aaruy-design/tooltip/complex/TooltipComplex.vue';


/**
 * 理糖宝 授权/只读标识 组件
 *
 * 变更履历
 * 20251114 仅正式服中开放
 * 20251030 暂时隐藏
 * 20251028 V1.0 版本中临时用于正式服（医院试用），不用于注册版
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  isReadOnly?: boolean;  // true:只读标识; false:授权;
}

defineProps<Prop>();
const route = useRoute();
const cardStore = useCardStore();
const admissionStore = useAdmissionStore();
const outPatientStore = useOutPatientStore();
const isLoading = ref<boolean>(false);
const arCodeUrl = ref<string>('');

let admissionId = INVALID_ID;

watch(() => cardStore.selectedCard, (data) => {
  if (route.name === ROUTE_IN_PATIENT) {
    admissionId = data.id;
  }
}, { immediate: true });

watch(() => outPatientStore.selectedAdmission, (data) => {
  if (route.name === ROUTE_OUT_PATIENT) {
    admissionId = data.id;
  }
}, { immediate: true });

function onVisibleChange(isOpened: boolean): void {
  if (isOpened && admissionId !== INVALID_ID) {
    isLoading.value = true;
    httpCgmSugarAuth({ admission_id: admissionId })
      .then(data => {
        const url = data.url;
        printGroup('二维码信息', url, LOG_COLOR.NORMAL);
        toDataURL(url)
          .then(d => {
            arCodeUrl.value = d;
          })
          .catch(reason => printSingle(reason, LOG_COLOR.ERROR))
          .finally(() => {
            isLoading.value = false;
          });
      })
      .catch(e => {
        printSingleError(e);
        isLoading.value = false;
      });
  }
}
</script>

<template>
  <span v-if="isReadOnly" class="text-xs text-weak-2 ml-8">来源: 理糖宝</span>
  <template v-else>
    <div v-if="admissionStore.admission.isInValid"></div>
    <div v-else-if="admissionStore.admission.isCgmSugarAuth" class="text-white text-s font-normal">来源：理糖宝</div>
    <TooltipComplex v-else trigger="click" use-theme1 @change="onVisibleChange">
      <template #title>
        <div class="text-white text-center text-xl-normal font-bold">CGM数据授权</div>
        <div class="pt-8 pb-16 flex items-center justify-center" style="height: 264px;">
          <span v-if="isLoading" class="text-white text-lg">二维码加载中，请稍候...</span>
          <img v-else alt="授权二维码" :src="arCodeUrl" style="width: 240px; height: 240px;" class="text-s" />
        </div>
        <div style="height: 24px; line-height: 24px;" class="text-white text-s text-center font-bold">患者扫描二维码完成CGM数据授权</div>
      </template>
      <div class="text-primary-9 font-bold text-s cursor-pointer text-hover-primary">数据授权</div>
    </TooltipComplex>
  </template>
</template>
