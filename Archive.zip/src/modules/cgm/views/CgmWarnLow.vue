<script setup lang="ts">
import {ref, toRaw, watch, computed, onMounted} from 'vue';
import {CgmWarnLowVO} from '@/modules/cgm/vo/CgmWarnLow.vo';
import {CgmWarnLowItemVO} from '@/modules/cgm/vo/CgmWarnLowItem.vo';
import {getMinuteIndexFromDayjs2} from '@/lib/time/util/dayjs.util';
import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import SwitchView from '@/lib/aaruy-design/switch/SwitchView.vue';
import CollapseView from '@/lib/aaruy-design/collapse/CollapseView.vue';
import AdviceCard from '@/modules/advice-closed-loop/component/AdviceCard.vue';
import CgmWarnLowItem from '@/modules/cgm/component/CgmWarnLowItem.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconCgmWarnAdd from '@/modules/cgm/icons/IconCgmWarnAdd.vue';
import type {CgmWarnTipLowDTO} from '@/modules/cgm/dto/cgm.warn.dto';
import type {ErrorExposedType} from '@/lib/aaruy-design/error/type/error.type';


/**
 * 低CGM警示 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  vo: CgmWarnLowVO;
  isReadOnly?: boolean;
  margin?: string;  // 仅 isReadonly（PC & APP）
}

interface Emit {
  (e: 'change', data: CgmWarnLowVO): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const isEnabled = ref<boolean>(false);
const rangeCoverTips = ref<string>('');

const removingVO = ref<CgmWarnLowItemVO>(CgmWarnLowItemVO.getInvalidVO());
const vos = ref<Array<CgmWarnLowItemVO>>([]);  // 按 startDay 升序排列，且长度一定小于8。
const voRefs = ref<Array<ErrorExposedType | null>>([]);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


defineExpose({
  hasError
});

watch(() => prop.vo, (data) => {
  isEnabled.value = data.isEnabled;
  vos.value = data.items;
}, { immediate: true });

onMounted(() => {
  if (screenStore.isMobile && vos.value.length === 0) {
    // APP端默认有1条数据
    vos.value.push(CgmWarnLowItemVO.getDefaultVO());
  }
});

function hasError(): boolean {
  let res = false;
  checkRangeCoverError();
  // 检查数组是否有误
  if (rangeCoverTips.value !== '') {
    res = true;
  }
  // 检查分段是否有误
  for (let i = 0, len = voRefs.value.length; i < len; i++) {
    const c = voRefs.value[i];
    if (c && c.hasError()) {
      res = true;
    }
  }
  return res;
}

function onOpen(data: CgmWarnLowItemVO): void {
  removingVO.value = data;
  isOpened.value = true;
}

function onClose(): void {
  removingVO.value = CgmWarnLowItemVO.getInvalidVO();
  isOpened.value = false;
}

function onEnableChange(data: boolean): void {
  if (data && vos.value.length === 0) {
    // 关闭->开启，数据为空时，自动插入1条默认数据。
    vos.value.push(CgmWarnLowItemVO.getDefaultVO());
  }
  isEnabled.value = data;
  emitData();
}

function onAdd(): void {
  if (vos.value.length >= 8 || !isEnabled.value) {
    return;
  }
  
  const data = vos.value;
  let index = -1;
  // 从下往上找，找到第1个时间范围超过30分钟的
  for (let i = data.length - 1; i > -1; i--) {
    if (data[i].runningMinutes > 30) {
      index = i;
      break;
    }
  }
  
  if (index !== -1) {
    // index 的范围超过30分钟
    const vo = data[index] as CgmWarnLowItemVO;
    const oldStart = vo.startMinute;
    const newStart = oldStart + vo.halfRunningMinutes;
    const newEnd = vo.endMinute;
    
    const head = data.slice(0, index);
    const tail = data.slice(index + 1);
    const sliceItem1 = CgmWarnLowItemVO.getRangeChangedVO(oldStart, newStart, vo);
    const sliceItem2 = CgmWarnLowItemVO.getAddVO(newStart, newEnd, data[data.length - 1].id + 1);
    
    vos.value = [...head, sliceItem1, sliceItem2, ...tail];
  }
  else {
    // 所有时间范围都是30分钟
    // 如果只有1段
    if (data.length === 1) {
      const vo = data[0];
      if (vo.startMinute === 0) {
        const s = vo.endMinute;
        const e = getMinuteIndexFromDayjs2(vo.endDay.add(30,'m'));
        vos.value.push(CgmWarnLowItemVO.getAddVO(s, e, data[data.length - 1].id + 1));
      }
      else if (vo.endMinute === 1440) {
        const s = getMinuteIndexFromDayjs2(vo.startDay.subtract(30,'m'));
        const e = vo.startMinute;
        vos.value = [CgmWarnLowItemVO.getAddVO(s, e, data[data.length - 1].id + 1), vo];
      }
    }
    else {
      // 有2段及以上。从下往上找第1个空隙。
      for (let i = data.length - 1; i > 0; i--) {
        if (data[i].startMinute !== data[i-1].endMinute) {
          index = i;
          break;
        }
      }
      if (index !== -1) {
        // 找到空隙，新增VO，VO的时间范围为空隙的范围
        vos.value = [
          ...data.slice(0,index),
          CgmWarnLowItemVO.getAddVO(data[index-1].endMinute, data[index].startMinute, data[data.length - 1].id + 1),
          ...data.slice(index)
        ];
      }
      else {
        // 没有找到空隙
        const lastVO = data[data.length - 1];
        if (lastVO.endMinute < 1440) {
          // 最后一个VO的结束时间不是24:00，那么新增的VO时间范围就是 [最后1项的结束时间,24:00]
          vos.value.push(CgmWarnLowItemVO.getAddVO(lastVO.endMinute, 1440, lastVO.id + 1));
        }
        else {
          // 最后一个VO的结束时间是24:00
          // 综合"所有时间范围都是30分钟"、"没有找到空隙"、"有2段及以上且最多8段"，可得: 第1项的开头绝对不是00:00。
          // 那么在数组开头插入1项: [00:00,第1项的开始时间]
          vos.value = [CgmWarnLowItemVO.getAddVO(0, data[0].startMinute, data[data.length - 1].id + 1), ...data];
        }
      }
    }
  }
  emitData();
}

function onRemove(): void {
  const id = removingVO.value.id;
  const index = vos.value.findIndex(it => it.id === id);
  if (index !== -1) {
    vos.value.splice(index, 1);
  }
  onClose();
  emitData();
}

function onChange(vo: CgmWarnLowItemVO): void {
  const index = vos.value.findIndex(it => it.id === vo.id);
  if (index !== -1) {
    vos.value.splice(index, 1, vo);
  }
  checkRangeCoverError();
  emitData();
}

function checkRangeCoverError(): void {
  rangeCoverTips.value = getRangeCoverTips();
}

function getRangeCoverTips(): string {
  const data = vos.value;
  const len = data.length;
  for (let i = len - 1; i > -1; i--) {
    const iVO = data[i];
    for (let j = len - 1; j > -1; j--) {
      if (i === j) {
        break;
      }
      if (iVO.isInRange(data[j] as CgmWarnLowItemVO)) {
        return '时间范围不可重叠';
      }
    }
  }
  return '';
}

function emitData(): void {
  emit('change', new CgmWarnLowVO({
    if_low_cgm: isEnabled.value ? OPEN_OR_CLOSE.OPENED : OPEN_OR_CLOSE.CLOSED,
    low_cgm_item: vos.value.map(it => toRaw(it.dto)).filter(dto => dto !== null) as Array<CgmWarnTipLowDTO>,
    if_high_cgm: OPEN_OR_CLOSE.CLOSED,
    high_cgm_item: []
  }));
}
</script>

<template>
  <template v-if="pc">
    <div v-if="isReadOnly" :style="{ margin: margin }" class="rounded-4 bg-3 p-12">
      <div class="text-s">低CGM警示<span :style="{ color: vo.enabledTextColor }" class="ml-10 font-bold">{{ vo.enabledText }}</span></div>
      <template v-for="(it,i) in vo.items" :key="it.id">
        <div class="text-xs text-primary-0" :class="{ 'mt-12': i > 0 }">{{ it.title }}</div>
        <div class="text-xs text-primary-0">{{ it.content }}</div>
      </template>
    </div>
    <template v-else>
      <ModalView :visible="isOpened" title="移除分段" @close="onClose">
        <div class="text-s text-white pl-24 pt-16">
          确定移除低CGM警示<span class="text-lg font-bold px-8">{{ removingVO.rangeText }}</span>分段？
        </div>
        <div class="flex items-center justify-end py-16 px-16">
          <ButtonView type="default" text="取消" style="width: 80px; height: 32px; margin-right: 16px;" @click="onClose" />
          <ButtonView type="primary" text="确定" style="width: 80px; height: 32px;" @click="onRemove" />
        </div>
      </ModalView>
      <AdviceCard width="33%" padding-in-body="0 12px 4px" :is-error="rangeCoverTips !== ''">
        <template #head>
          <div class="h-full flex items-center justify-between px-12">
            <span class="text-s font-bold text-white">低CGM警示</span>
            <SwitchView :checked="isEnabled" @change="onEnableChange" />
          </div>
          <ErrorView v-if="rangeCoverTips" :tips="rangeCoverTips" is-text-left margin="4px 0 0 0" padding="0 0 0 8px" />
        </template>
        <template #body>
          <div :class="{ 'aaruy-hidden': !isEnabled, 'aaruy-visible': isEnabled }">
            <CollapseView :items="vos" is-style-head accordion>
              <template #col-head="{ item, index }">
                <CgmWarnLowItem :vo="item"
                                is-head
                                :is-close-showed="vos.length > 1"
                                :ref="(el) => voRefs[index] = el"
                                @remove="onOpen"
                                @change="onChange" />
              </template>
              <template #default="{ it }">
                <CgmWarnLowItem :vo="it" @change="onChange" />
              </template>
            </CollapseView>
            <div v-if="vos.length < 8" class="flex justify-center">
              <div class="inline-flex items-center text-primary text-hover-primary-2 cursor-pointer" style="height: 48px;" @click="onAdd">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                  <g transform="translate(-185 -596)">
                    <rect width="24" height="24" transform="translate(185 596)" fill="rgba(255,255,255,0)"/>
                    <g transform="translate(187 598)" fill="none" stroke="#6795ee" stroke-width="1.5">
                      <circle cx="10" cy="10" r="10" stroke="none"/>
                      <circle cx="10" cy="10" r="9.25" fill="none"/>
                    </g>
                    <path d="M-10177.156-3277h8" transform="translate(10370.156 3885)" fill="none" stroke="#6795ee" stroke-linecap="round" stroke-width="1.5"/>
                    <path d="M-10177.156-3277h8" transform="translate(-3080 10781.156) rotate(90)" fill="none" stroke="#6795ee" stroke-linecap="round" stroke-width="1.5"/>
                  </g>
                </svg>
                <span class="text-s no-select pl-8">添加</span>
              </div>
            </div>
          </div>
        </template>
      </AdviceCard>
    </template>
  </template>
  <template v-else>
    <div v-if="isReadOnly" :style="{ margin: margin }" class="bg-16 rounded-4">
      <div style="height: 48px;" class="flex justify-between items-center text-white font-s px-12">
        <span>低CGM值警示</span>
        <span>{{ vo.enabledText }}</span>
      </div>
      <template v-for="(it) in vo.items" :key="it.id">
        <div class="text-s text-primary-6 border-t-bg-17 mx-12 pt-8">{{ it.title }}</div>
        <div class="text-xs text-weak-8 mx-12 pb-8">{{ it.content }}</div>
      </template>
    </div>
    <template v-else>
      <div style="height: 48px;"
           class="flex items-center justify-between mt-16 bg-12 rounded-t-4 text-s px-16 text-white">
        <span>低CGM值警示设置</span>
        <SwitchView :checked="isEnabled" @change="onEnableChange" />
      </div>
      <div class="bg-16 rounded-b-4 py-12 px-12">
        <CgmWarnLowItem v-for="(it,index) in vos"
                         :key="it.id"
                         :vo="it"
                         :ref="(el) => voRefs[index] = el"
                         :is-disabled="!isEnabled"
                         :margin="index > 0 ? '16px 0 0 0' : '0'"
                         @remove="onOpen"
                         @change="onChange" />
        <div v-if="vos.length < 8" class="flex justify-center items-center pt-16" @click="onAdd">
          <IconCgmWarnAdd size="14px" :is-disabled="!isEnabled" />
          <span class="ml-4 text-xs" :class="{ 'text-primary': isEnabled, 'text-weak-2': !isEnabled }">添加</span>
        </div>
      </div>
    </template>
  </template>
</template>

<style scoped>
.text-hover-primary-2:hover > svg > g > g,
.text-hover-primary-2:hover > svg > g > path {
  stroke: var(--aaruy-primary-color-2);
}
</style>
