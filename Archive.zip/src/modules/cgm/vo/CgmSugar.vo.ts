import type { CgmSugaryDTO } from '@/modules/cgm/dto/cgm.sugar.dto';


/**
 * 糖仁 VO
 */
export class CgmSugarVO {
  
  private readonly _entity: CgmSugaryDTO | null;
  
  constructor(e?: CgmSugaryDTO) {
    this._entity = e || null;
  }
  
  // 授权地址
  // 如: "https://test.aaruy.com/open/sugar/index/84b1139db3df11f08b9100163e2c44f1"
  public get url(): string {
    if (!this._entity) {
      return '';
    }
    return this._entity.url;
  }
  
}
