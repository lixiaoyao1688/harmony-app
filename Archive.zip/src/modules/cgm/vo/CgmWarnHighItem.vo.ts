import {Dayjs} from 'dayjs';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {CGM_RAGE, CGM_RAGE_CUSTOM_MIN, CGM_RAGE_MAP} from '@/modules/cgm/config/cgm.rage';
import {getDayjsFromMinuteIndex, getNDayAfterDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {CGM_WARN_HIGH, CGM_WARN_HIGH_MAP, DEFAULT_CGM_WARN_HIGH} from '@/modules/cgm/config/cgm.warn.high';
import {CGM_WARN_HIGH_PRE, CGM_WARN_HIGH_PRE_MAP, DEFAULT_CGM_WARN_HIGH_PRE} from '@/modules/cgm/config/cgm.warn.high.pre';
import {INVALID_ID} from '@/utils/global.vo.help';
import {floorTo30, realRoundTo1Digit} from '@/lib/math/util/math.util';
import type {CgmWarnTipHighDTO} from '@/modules/cgm/dto/cgm.warn.dto';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 高CGM警示项 VO
 */
export class CgmWarnHighItemVO {
  
  private readonly _entity: CgmWarnTipHighDTO | null;
  private readonly _id: number;
  
  constructor(e?: CgmWarnTipHighDTO | null, id?: number) {
    this._entity = e || null;
    this._id = id || INVALID_ID;
  }

  // 默认VO
  public static getDefaultVO(): CgmWarnHighItemVO {
    return new CgmWarnHighItemVO({
      value_start: 0,
      value_end: 1440,
      value: 13.9,
      notice_minute_before: CGM_WARN_HIGH_PRE.CLOSE,
      if_notice_value: CGM_WARN_HIGH.CLOSE,
      rage_index: CGM_RAGE.CLOSE,
      rage_start: CGM_RAGE_CUSTOM_MIN
    }, 1);
  }
  
  // 新增VO（id为数组的最后1个id加1）
  public static getAddVO(s: number, e: number, id: number): CgmWarnHighItemVO {
    return new CgmWarnHighItemVO({
      value_start: s,
      value_end: e,
      value: 13.9,
      notice_minute_before: CGM_WARN_HIGH_PRE.CLOSE,
      if_notice_value: CGM_WARN_HIGH.CLOSE,
      rage_index: CGM_RAGE.CLOSE,
      rage_start: CGM_RAGE_CUSTOM_MIN
    }, id);
  }
  
  // 仅改变时间范围后的VO
  public static getRangeChangedVO(s: number, e: number, vo: CgmWarnHighItemVO): CgmWarnHighItemVO {
    const dto = vo.dto as CgmWarnTipHighDTO;
    return new CgmWarnHighItemVO({
      value_start: s,
      value_end: e,
      value: dto.value,
      notice_minute_before: dto.notice_minute_before,
      if_notice_value: dto.if_notice_value,
      rage_index: dto.rage_index,
      rage_start: dto.rage_start
    }, vo.id);
  }
  
  // 占位VO
  public static getInvalidVO(): CgmWarnHighItemVO {
    return new CgmWarnHighItemVO();
  }
  
  public get id(): number {
    return this._id;
  }
  
  public get dto(): CgmWarnTipHighDTO | null {
    return this._entity;
  }
  
  // 时间范围 + CGM值 文本
  public get title(): string {
    if (!this._entity) {
      return '';
    }
    return `${this.rangeText} | ${this.value}mmol/L`;
  }
  
  // 警示配置内容 文本
  public get content(): string {
    if (!this._entity) {
      return '';
    }
    let valuePreText = '';  // 高CGM值前警示
    let valueText = '';  // 高CGM值警示
    let rageText = '';  // 上升警示
    
    const e = this._entity;
    if (e.notice_minute_before !== CGM_WARN_HIGH_PRE.CLOSE) {
      valuePreText = `高CGM值前${e.notice_minute_before}分钟警示`;
    }
    if (e.if_notice_value === CGM_WARN_HIGH.OPEN) {
      valueText = '高CGM值警示';
    }
    if (e.rage_index !== CGM_RAGE.CLOSE) {
      let tips = SelectItemVO.getText(CGM_RAGE_MAP, e.rage_index);
      if (e.rage_index === CGM_RAGE.CUSTOM) {
        tips += `: ${e.rage_start}mmol/L/min`;
      }
      rageText = `上升警示(${tips})`;
    }
    
    if (valuePreText && valueText && rageText) {
      return `${valuePreText}, ${valueText}, ${rageText}`;
    }
    if (valuePreText && valueText) {
      return `${valuePreText}, ${valueText}`;
    }
    if (valuePreText && rageText) {
      return `${valuePreText}, ${rageText}`;
    }
    if (valueText && rageText) {
      return `${valueText}, ${rageText}`;
    }
    return valuePreText ? valuePreText : (valueText ? valueText : rageText);
  }
  
  // CGM值 文本 mmol/L 保留1位小数
  public get value(): string {
    if (!this._entity) {
      return '';
    }
    return realRoundTo1Digit(this._entity.value).toString();
  }
  
  // 时间范围
  public get range(): [Dayjs, Dayjs] {
    if (!this._entity) {
      return [getTodayDayjs(), getNDayAfterDayjs(1)];
    }
    const e = this._entity;
    return [getDayjsFromMinuteIndex(e.value_start), getDayjsFromMinuteIndex(e.value_end)];
  }
  // 时间范围 文本 如:'08:30'
  public get rangeText(): string {
    if (!this._entity) {
      return '00:00 - 24:00';
    }
    const T = 'HH:mm';
    const e = this._entity;
    return `${getDayjsFromMinuteIndex(e.value_start).format(T)} - ${e.value_end === 1440 ? '24:00' : getDayjsFromMinuteIndex(e.value_end).format(T)}`;
  }
  public get runningMinutes(): number {
    if (!this._entity) {
      return 1440;
    }
    const e = this._entity;
    return Math.floor(e.value_end - e.value_start);
  }
  // 持续时间的半数（向下取整到30的倍数）
  public get halfRunningMinutes(): number {
    if (!this._entity) {
      return 720;
    }
    const e = this._entity;
    return floorTo30((e.value_end - e.value_start) / 2);
  }
  public get startMinute(): number {
    if (!this._entity) {
      return 0;
    }
    return this._entity.value_start;
  }
  public get endMinute(): number {
    if (!this._entity) {
      return 1440;
    }
    return this._entity.value_end;
  }
  public get startDay(): Dayjs {
    if (!this._entity) {
      return getTodayDayjs();
    }
    return getDayjsFromMinuteIndex(this._entity.value_start);
  }
  public get endDay(): Dayjs {
    if (!this._entity) {
      return getNDayAfterDayjs(1);
    }
    return getDayjsFromMinuteIndex(this._entity.value_end);
  }
  
  // 输入VO的时间范围是否和当前VO的时间范围重叠
  public isInRange(data: CgmWarnHighItemVO): boolean {
    if (!this._entity) {
      // 默认范围 [00:00,24:00]
      return true;
    }
    const s = data.startMinute;
    const e = data.endMinute;
    const cs = this.startMinute;
    const ce = this.endMinute;
    if (s === cs && e === ce) {
      return true;
    }
    return (s > cs && s < ce) || (e > cs && e < ce);
  }
  
  // 高CGM值前警示 项
  public get valuePreItem(): ItemType2 {
    if (!this._entity) {
      return DEFAULT_CGM_WARN_HIGH_PRE;
    }
    return SelectItemVO.getItem(CGM_WARN_HIGH_PRE_MAP, this._entity.notice_minute_before);
  }
  
  // 高CGM值警示 项
  public get valueEnableItem(): ItemType2 {
    if (!this._entity) {
      return DEFAULT_CGM_WARN_HIGH;
    }
    return SelectItemVO.getItem(CGM_WARN_HIGH_MAP, this._entity.if_notice_value);
  }
  
  // 上升警示项
  public get rage(): CGM_RAGE {
    if (!this._entity) {
      return CGM_RAGE.CLOSE;
    }
    return this._entity.rage_index;
  }
  
  // 上升警示自定义值
  public get rageValue(): string {
    if (!this._entity) {
      return '';
    }
    return this._entity.rage_start.toString();
  }
  
}
