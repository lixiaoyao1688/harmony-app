import {CgmWarnLowItemVO} from '@/modules/cgm/vo/CgmWarnLowItem.vo';
import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';
import {COLOR_GRAY_1, COLOR_GREEN_4} from '@/lib/style/color';
import type {CgmWarnTipDTO} from '@/modules/cgm/dto/cgm.warn.dto';


/**
 * 低CGM警示 VO
 */
export class CgmWarnLowVO {
  
  private readonly _entity: CgmWarnTipDTO | null;
  
  constructor(e?: CgmWarnTipDTO) {
    this._entity = e || null;
  }
  
  // 是否打开
  public get isEnabled(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_low_cgm === OPEN_OR_CLOSE.OPENED;
  }
  public get enabledText(): string {
    if (!this._entity) {
      return '关闭';
    }
    return this._entity.if_low_cgm === OPEN_OR_CLOSE.OPENED ? '开启' : '关闭';
  }
  public get enabledTextColor(): string {
    if (!this._entity) {
      return COLOR_GRAY_1;
    }
    return this._entity.if_low_cgm === OPEN_OR_CLOSE.OPENED ? COLOR_GREEN_4 : COLOR_GRAY_1;
  }
  
  // 警示项列表
  public get items(): Array<CgmWarnLowItemVO> {
    if (!this._entity || !this._entity.low_cgm_item) {
      return [];
    }
    return this._entity.low_cgm_item.map((dto,i) => new CgmWarnLowItemVO(dto,i+1));
  }
  
  // DTO
  public get dto(): CgmWarnTipDTO | null {
    if (!this._entity) {
      return null;
    }
    return this._entity;
  }
  
}
