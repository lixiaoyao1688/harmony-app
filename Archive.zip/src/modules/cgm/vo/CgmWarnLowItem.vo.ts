import {Dayjs} from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {floorTo30} from '@/lib/math/util/math.util';
import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';
import {CGM_WARN_LOW_VALUE_DEFAULT} from '@/modules/cgm/config/cgm.warn.low';
import {DEFAULT_TIME_RANGE} from '@/lib/aaruy-design/time-picker/config/time.range.config';
import {getDayjsFromMinuteIndex, getNDayAfterDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import type {CgmWarnTipLowDTO} from '@/modules/cgm/dto/cgm.warn.dto';


/**
 * 低CGM警示项 VO
 */
export class CgmWarnLowItemVO {
  
  private readonly _entity: CgmWarnTipLowDTO | null;
  private readonly _id: number;
  
  constructor(e?: CgmWarnTipLowDTO | null, id?: number) {
    this._entity = e || null;
    this._id = id || INVALID_ID;
  }
  
  // 默认VO
  public static getDefaultVO(): CgmWarnLowItemVO {
    return new CgmWarnLowItemVO({
      value_start: 0,
      value_end: 1440,
      value: CGM_WARN_LOW_VALUE_DEFAULT,
      if_notice_value: OPEN_OR_CLOSE.CLOSED,
      if_notice_value_before: OPEN_OR_CLOSE.CLOSED,
      if_stop_value_before: OPEN_OR_CLOSE.CLOSED,
      if_stop_value: OPEN_OR_CLOSE.CLOSED,
      if_recover_base: OPEN_OR_CLOSE.CLOSED,
    }, 1);
  }
  
  // 新增VO（id为数组的最后1个id加1）
  public static getAddVO(s: number, e: number, id: number): CgmWarnLowItemVO {
    return new CgmWarnLowItemVO({
      value_start: s,
      value_end: e,
      value: CGM_WARN_LOW_VALUE_DEFAULT,
      if_notice_value: OPEN_OR_CLOSE.CLOSED,
      if_notice_value_before: OPEN_OR_CLOSE.CLOSED,
      if_stop_value_before: OPEN_OR_CLOSE.CLOSED,
      if_stop_value: OPEN_OR_CLOSE.CLOSED,
      if_recover_base: OPEN_OR_CLOSE.CLOSED,
    }, id);
  }
  
  // 仅改变时间范围后的VO
  public static getRangeChangedVO(s: number, e: number, vo: CgmWarnLowItemVO): CgmWarnLowItemVO {
    const dto = vo.dto as CgmWarnTipLowDTO;
    return new CgmWarnLowItemVO({
      value_start: s,
      value_end: e,
      value: dto.value,
      if_notice_value: dto.if_notice_value,
      if_notice_value_before: dto.if_notice_value_before,
      if_stop_value_before: dto.if_stop_value_before,
      if_stop_value: dto.if_stop_value,
      if_recover_base: dto.if_recover_base,
    }, vo.id);
  }
  
  // 占位VO
  public static getInvalidVO(): CgmWarnLowItemVO {
    return new CgmWarnLowItemVO();
  }
  
  public get id(): number {
    return this._id;
  }
  
  public get dto(): CgmWarnTipLowDTO | null {
    return this._entity;
  }
  
  // 时间范围 + CGM值 文本
  public get title(): string {
    if (!this._entity) {
      return '';
    }
    return `${this.rangeText} | ${this.value}mmol/L`;
  }
  
  // 警示配置内容 文本
  public get content(): string {
    if (!this._entity) {
      return '';
    }
    
    let valuePreText = '';  // 低CGM值前警示
    let valueText = '';  // 低CGM值警示
    let valuePreStopText = '';  // 低CGM值前暂停输注
    let valueStopText = '';  // 低CGM值暂停输注
    let recoverBaseText = '';  // 恢复基础率警示
    
    const e = this._entity;
    if (e.if_notice_value_before === OPEN_OR_CLOSE.OPENED) {
      valuePreText = '低CGM值前警示';
    }
    if (e.if_notice_value === OPEN_OR_CLOSE.OPENED) {
      valueText = '低CGM值警示';
    }
    if (e.if_stop_value_before === OPEN_OR_CLOSE.OPENED) {
      valuePreStopText = '低CGM值前暂停输注';
    }
    if (e.if_stop_value === OPEN_OR_CLOSE.OPENED) {
      valueStopText = '低CGM值暂停输注';
    }
    if (e.if_recover_base === OPEN_OR_CLOSE.OPENED) {
      recoverBaseText = '恢复基础率警示';
    }
    return [valuePreText, valueText, valuePreStopText, valueStopText, recoverBaseText].filter(t => t !== '').join(', ');
  }
  
  // CGM值，mmol/L
  public get value(): string {
    if (!this._entity) {
      return '';
    }
    return this._entity.value.toString();
  }
  
  // 时间范围
  public get range(): [Dayjs, Dayjs] {
    if (!this._entity) {
      return DEFAULT_TIME_RANGE;
    }
    const e = this._entity;
    return [getDayjsFromMinuteIndex(e.value_start), getDayjsFromMinuteIndex(e.value_end)];
  }
  public get rangeText(): string {
    if (!this._entity) {
      return '00:00 - 24:00';
    }
    const T = 'HH:mm';
    const e = this._entity;
    return `${getDayjsFromMinuteIndex(e.value_start).format(T)} - ${e.value_end === 1440 ? '24:00' : getDayjsFromMinuteIndex(e.value_end).format(T)}`;
  }
  public get runningMinutes(): number {
    if (!this._entity) {
      return 1440;
    }
    const e = this._entity;
    return Math.floor(e.value_end - e.value_start);
  }
  // 持续时间的半数（向下取整到30的倍数）
  public get halfRunningMinutes(): number {
    if (!this._entity) {
      return 720;
    }
    const e = this._entity;
    return floorTo30((e.value_end - e.value_start) / 2);
  }
  public get startMinute(): number {
    if (!this._entity) {
      return 0;
    }
    return this._entity.value_start;
  }
  public get endMinute(): number {
    if (!this._entity) {
      return 1440;
    }
    return this._entity.value_end;
  }
  public get startDay(): Dayjs {
    if (!this._entity) {
      return getTodayDayjs();
    }
    return getDayjsFromMinuteIndex(this._entity.value_start);
  }
  public get endDay(): Dayjs {
    if (!this._entity) {
      return getNDayAfterDayjs(1);
    }
    return getDayjsFromMinuteIndex(this._entity.value_end);
  }
  
  // 输入VO的时间范围是否和当前VO的时间范围重叠
  public isInRange(data: CgmWarnLowItemVO): boolean {
    if (!this._entity) {
      // 默认范围 [00:00,24:00]
      return true;
    }
    const s = data.startMinute;
    const e = data.endMinute;
    const cs = this.startMinute;
    const ce = this.endMinute;
    if (s === cs && e === ce) {
      return true;
    }
    return (s > cs && s < ce) || (e > cs && e < ce);
  }
  
  // 低CGM值前警示 是否开启
  public get isValuePreOpened(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_notice_value_before === OPEN_OR_CLOSE.OPENED;
  }
  
  // 低CGM值警示 是否开启
  public get isValueOpened(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_notice_value === OPEN_OR_CLOSE.OPENED;
  }
  
  // 低CGM值前暂停输注 是否开启
  public get isValuePreStopOpened(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_stop_value_before === OPEN_OR_CLOSE.OPENED;
  }
  
  // 低CGM值暂停输注 是否开启
  public get isValueStopOpened(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_stop_value === OPEN_OR_CLOSE.OPENED;
  }
  
  // 恢复基础率警示 是否开启
  public get isRecoverBaseOpened(): boolean {
    if (!this._entity) {
      return false;
    }
    return this._entity.if_recover_base === OPEN_OR_CLOSE.OPENED;
  }
  
}
