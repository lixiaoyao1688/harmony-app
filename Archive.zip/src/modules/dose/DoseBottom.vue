<script setup lang="ts">
import {ref, watch,computed} from 'vue';
import {DOSE} from '@/modules/dose/dose.config';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {useSystemConfigStore} from '@/modules/system-config/store/system.config.store';
import {httpSystemConfigUpdate} from '@/modules/system-config/requests/system.config.http';
import {notifyErrorNormal, notifySuccessNormal} from '@/lib/aaruy-design/notify/notify';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import NewCounter from '@/lib/aaruy-design/counter/NewCounter.vue';
import FormModal from '@/lib/aaruy-design/form/FormModal.vue';
import CounterView from '@/lib/aaruy-design/counter/CounterView.vue';
import type {SystemConfigUpdateDTO} from '@/modules/system-config/dto/system.config.dto';


/**
 * 低药量报警阈值 组件
 * pc && mobile
 */
interface Emit {
  (e: 'change', data: number): void;  // 仅pc
}

const emit = defineEmits<Emit>();
const store = useSystemConfigStore();
const screenStore = useScreenStore();

const isOpened = ref<boolean>(false);
const isWaiting = ref<boolean>(false);
const value = ref<number>(store.systemConfig.drugBottom);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => store.systemConfig.drugBottom, (data) => {
  value.value = data;
}, { immediate: true });


function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onReset(): void {
  value.value = 0;
}

function onChange(data: number): void {
  value.value = data;
  if (pc.value) {
    emit('change', data);
  }
}

function onConfirm(): void {
  const dto: SystemConfigUpdateDTO = {
    dose_threshold: value.value,
  };
  isWaiting.value = true;
  httpSystemConfigUpdate(dto)
    .then(_ => {
      notifySuccessNormal('低药量报警阈值已更新');
      store.systemConfig.drugBottom = value.value;
      onClose();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => isWaiting.value = false);
}
</script>

<template>
  
  <CounterView v-if="pc" title="低药量报警阈值 (0~30U)" unit=""
               :data="value" :step="DOSE.STEP" :digit="DOSE.DIGIT" :min="DOSE.MIN" :max="DOSE.BOTTOM_MAX"
               class="pt-16 mb-24"
               @change="onChange"
  />
  
  <template v-if="mobile">
    <ModalView :visible="isOpened" :is-mobile-dialog="true" title="低药量报警阈值" @close="onClose">
      <FormModal :waiting="isWaiting" cancel-text-mobile="重置" @cancel="onReset" @confirm="onConfirm">
        <NewCounter title="" unit="U"
                    :value="value" :step="DOSE.STEP" :digit="DOSE.DIGIT" :min="DOSE.MIN" :max="DOSE.BOTTOM_MAX"
                    @change="onChange" />
        <div class="text-weak-2 text-xs leading-l mt-8">范围 0~30U，保留1位小数。</div>
      </FormModal>
    </ModalView>
    <div class="flex items-center justify-between h-full w-full leading-l" @click="onOpen">
      <span>低药量报警阈值</span>
      <div class="inline-flex items-center">
        <span class="mr-4">{{ store.systemConfig.drugBottom }}U</span><IconPickerField />
      </div>
    </div>
  </template>
  
</template>
