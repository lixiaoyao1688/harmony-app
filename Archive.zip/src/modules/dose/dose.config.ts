/**
 * 大剂量 配置
 */
export const DOSE = {
  STEP: 0.1,  // 步长
  UNIT: 'U',
  DIGIT: 1,  // 默认保留的小数位数
  DIGIT_FOR_ONCE: 3,  // 单次注射量保留的小数位数
  DIGIT_FOR_ADD: 3,  // 增加量保留的小数位数
  VALUE_DIGIT: 3,  // （新）app 保留的小数位数
  COLOR: 'rgb(0,252,248)',
  COLOR_WEAK: 'rgb(0,204,201)',
  COLOR_WEAK_DELAY: 'rgba(0,204,201,0.2)',
  COLOR_TEXT_WEAK: 'rgb(0,115,114)',
  MAX: 25,
  MIN: 0,
  BOTTOM_MAX: 30,  // 低药量报警阈值 max
  REPORT_VALUE: 4,  // 用于报告的固定高度
  REPORT_VALUE_FOR_INS_DAILY: 3,  // 用于胰岛素用量报告的固定高度
  REPORT_COLOR: 'rgb(20,0,203)',  // 用于报告的颜色
  // 用于报告的标记图形
  REPORT_SYMBOL: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4NCiAgPHJlY3QgaWQ9IuefqeW9ol81MTMxIiBkYXRhLW5hbWU9IuefqeW9oiA1MTMxIiB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIGZpbGw9IiMxNDAwY2IiLz4NCjwvc3ZnPg0K',
  // 用于报告的底部图形
  REPORT_BOTTOM_SYMBOL: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0Ni4wNTYiIGhlaWdodD0iMTguNDIzIiB2aWV3Qm94PSIwIDAgNDYuMDU2IDE4LjQyMyI+DQogIDxlbGxpcHNlIGlkPSLmpK3lnIZfMTU3IiBkYXRhLW5hbWU9IuakreWchiAxNTciIGN4PSIyMy4wMjgiIGN5PSI5LjIxMSIgcng9IjIzLjAyOCIgcnk9IjkuMjExIiBmaWxsPSIjMDBjY2M5Ii8+DQo8L3N2Zz4NCg==',
};
