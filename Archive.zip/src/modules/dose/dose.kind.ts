import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 大剂量类型 配置
 */
export enum DOSE_KIND {
  MEAL = 0,
  TEMP,
  TINY,
  FAST
}

const DOSE_KIND_0 = new SelectItemVO({ id: DOSE_KIND.MEAL, text: '餐时大剂量' });
const DOSE_KIND_1 = new SelectItemVO({ id: DOSE_KIND.TEMP, text: '临时大剂量' });
const DOSE_KIND_2 = new SelectItemVO({ id: DOSE_KIND.TINY, text: '微型大剂量' });
const DOSE_KIND_3 = new SelectItemVO({ id: DOSE_KIND.FAST, text: '声响大剂量' });  // by zmt 2026/03/16 18点 口述

export const DOSE_KINDS = [
  DOSE_KIND_0,
  DOSE_KIND_1,
  DOSE_KIND_2,
  DOSE_KIND_3
];
export const DOSE_KIND_MAP = SelectItemVO.getMap(DOSE_KINDS);


/**
 * 大剂量（包含计算过程）类型
 */
export enum BOLUS_CALC_KIND {
  COMPLEX = 0,
  EASY = 1,
}

const BOLUS_CALC_KIND_0 = new SelectItemVO({ id: BOLUS_CALC_KIND.COMPLEX, text: '精细大剂量' });
const BOLUS_CALC_KIND_1 = new SelectItemVO({ id: BOLUS_CALC_KIND.EASY, text: '简易大剂量' });

export const BOLUS_CALC_KINDS = [
  BOLUS_CALC_KIND_0,
  BOLUS_CALC_KIND_0,
];
export const BOLUS_CALC_KIND_MAP = SelectItemVO.getMap(BOLUS_CALC_KINDS);
