import {DOSE_KIND} from '@/modules/dose/dose.kind';
import {HISTORY_KIND} from '@/modules/record/config/history.config';
import type {InsKindType} from '@/modules/ins/types/ins.type';


// 是否延长大剂量
export function isDelayDose(kind: HISTORY_KIND): boolean {
  return kind === HISTORY_KIND.LARGE_DOSE_DELAY;
}

// 是否微型大剂量 (闭环)
export function isClosedLoopDose(kind: HISTORY_KIND, subKind: InsKindType): boolean {
  return kind === HISTORY_KIND.LARGE_DOSE && subKind === DOSE_KIND.TINY;
  // 2025-08-06 已废弃
  // return isHistoryDose(kind) && subKind === DOSE_KIND.TINY;
}
