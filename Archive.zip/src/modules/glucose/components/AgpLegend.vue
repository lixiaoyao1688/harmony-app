<script setup lang="ts">
import type { LegendChartType } from '@/lib/aaruy-design/legend/types/legend.chart.type';


interface Prop {
  items: Array<LegendChartType>;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="flex items-center justify-between">
    <div v-for="(it,i) in items" :key="it.id">
      <span class="inline-block" style="width: 8px; height: 8px;" :style="{ backgroundColor: it.color }"></span>
      <span class="text-xxs leading-xxs text-white ml-4" :class="{ 'mr-8': i < items.length-1 }">{{ it.text }}</span>
    </div>
  </div>
</template>
