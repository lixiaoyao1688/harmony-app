<script setup lang="ts">
import {GLU} from '@/modules/glucose/config/glu.config';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import StackedBar from '@/lib/aaruy-design/stacked-bar/StackedBar.vue';
import MergeReportItem from '@/modules/ins/components/MergeReportItem.vue';


interface Prop {
  vo: AgpNewVO;
}

defineProps<Prop>();
</script>

<template>
  
  <div style="padding: 16px; border-bottom: 1px solid rgb(204,208,219);">
    <div style="color: rgb(0,0,0); font-size: 14px; font-weight: 700; margin-bottom: 8px;">血糖监测统计</div>
    <div style="display: flex; height: 150px">
      <div style="width: 400px; height: 100%; display: flex; align-items: center; border-radius: 4px; background-color: rgb(242,247,255);">
        <div style="width: 33.3%; height: fit-content;">
          <MergeReportItem title="血糖检测数" is-unit-hidden :value="vo.gluCountText" unit="" />
          <MergeReportItem title="血糖达标率TIR" :value="vo.tirOkText" unit="%" margin-top="16px" />
        </div>
        <div style="width: 33.3%; height: fit-content;">
          <MergeReportItem title="平均血糖" :value="vo.mgText" :unit="GLU.UNIT_1" />
          <MergeReportItem title="变异系数" :value="vo.cvText" unit="%" margin-top="16px" />
        </div>
        <div style="width: 33.3%; height: fit-content;">
          <MergeReportItem title="最低血糖" :value="vo.lowestText" :unit="GLU.UNIT_1" />
          <MergeReportItem title="最高血糖" :value="vo.highestText" :unit="GLU.UNIT_1" margin-top="16px" />
        </div>
      </div>
      <div style="flex: 1; height: 100%; padding-left: 16px; color: rgb(0,0,0);">
        <h5 style="font-size: 14px; line-height: 16px; color: rgb(51,51,51); margin: 0 0 8px 0; font-weight: 400;">血糖分布占比</h5>
        <div style="flex: 1; height: calc(100% - 24px);">
          <p v-if="vo.isTirEmpty" style="font-size: 12px; line-height: 14px; color: rgb(51,51,51,0.8); margin: 0;">暂无数据</p>
          <StackedBar v-else :items="vo.tirItems" height="100%" :is-report="true" />
        </div>
      </div>
    </div>
  </div>
</template>
