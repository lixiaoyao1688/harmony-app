<script setup lang="ts">
interface Prop {
  width: string;
  title: string;
  value: number;
  titleWidth?: string;
  isValid?: boolean;
  unit?: string;
  time?: string;
  useTitleUnit?: boolean;
  useValueUnit?: boolean;
  marginLeft?: string;
  marginBottom?: string;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="bg-1 rounded-4 p-16" :style="{ width: width, marginLeft: marginLeft || 0, marginBottom: marginBottom || 0 }">
    <div class="inline-flex justify-between w-full">
      <div :style="{ width: titleWidth }">
        <div>{{ title }}</div>
        <div class="text-weak-2" v-if="unit && useTitleUnit">{{ unit }}</div>
      </div>
      <div>
        <template v-if="isValid">
          <span class="text-xxl-2 font-bold">{{ value }}</span>
          <span class="text-weak-2 ml-4" v-if="unit && useValueUnit">{{ unit }}</span>
        </template>
        <span v-else class="font-bold text-xxl-2 text-weak-2">--</span>
      </div>
    </div>
    <div class="text-weak-2" v-if="time">{{ time }}</div>
  </div>
</template>
