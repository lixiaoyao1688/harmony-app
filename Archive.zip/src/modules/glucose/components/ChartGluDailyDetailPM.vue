<script setup lang="ts">
import { init } from 'echarts';
import { computed, onMounted, onUpdated } from 'vue';
import { CARD_CHART } from '@/modules/record/config/card.config';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { ChartGluSingleVO } from '@/modules/glucose/vo/GluSingle.vo';
import CardView1 from '@/lib/aaruy-design/card/CardView1.vue';
import StatisticView from '@/lib/aaruy-design/statistic/StatisticView.vue';
import type { ECBasicOption } from 'echarts/types/src/util/types';


interface Prop {
  id: number;
  date: string;
  config: ECBasicOption;
	vo: ChartGluSingleVO;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


onMounted(() => {
  updateChart();
});

onUpdated(() => {
  updateChart();
});

function updateChart(): void {
  const chart = init(document.getElementById(CARD_CHART.GLU_DOM_ID + prop.id));
  if (chart) {
    chart.setOption(prop.config);
  }
}
</script>

<template>
	
	<CardView1 v-if="pc" type="empty" :height="313" class="mb-8">
		<div style="border-radius: 4px 4px 0 0; height: 32px; line-height: 32px; text-align: center; font-size: 16px; background-color: rgb(90,118,165); font-weight: 700;">
			{{ vo.dateText }}
		</div>
		<div class="flex items-center" style="height: calc(100% - 32px);">
			<div style="height: 200px;" class="flex-1" :id="CARD_CHART.GLU_DOM_ID + id"></div>
			<div style="width: 480px;">
				<StatisticView width="25%" :is-valid="vo.isMgValid" title="MG" sub-title="平均葡萄糖" :value="vo.mg" desc="mmol/L" />
				<StatisticView width="25%" :is-valid="vo.isTirValid" title="TIR" sub-title="目标范围内时间" :value="vo.tir" :desc="vo.tirTime" />
				<StatisticView width="25%" :is-valid="vo.isTirValid" title="TAR" sub-title="高于目标范围时间" :value="vo.tar" :desc="vo.tarTime" />
				<StatisticView width="25%" :is-valid="vo.isTirValid" title="TBR" sub-title="低于目标范围时间" :value="vo.tbr" :desc="vo.tbrTime" />
			</div>
		</div>
	</CardView1>
	
	<div v-if="mobile" class="box-border mt-12 w-100">
		<div class="w-100" style="height: 357px;" :id="CARD_CHART.GLU_DOM_ID + id"></div>
	</div>
	
</template>
