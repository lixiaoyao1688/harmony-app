<script setup lang="ts">
import {computed} from 'vue';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import {AGP_ELE_ID} from '@/modules/glucose/config/agp.config';
import {APG_RECORD_KIND_ITEMS} from '@/modules/glucose/config/agp.record.kind';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {AgpRecordVO} from '@/modules/glucose/vo/AgpRecord.vo';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import ApgCard from '@/modules/glucose/components/ApgCard.vue';
import StackedBar from '@/lib/aaruy-design/stacked-bar/StackedBar.vue';
import SelectorTip from '@/lib/aaruy-design/selector/tip/SelectorTip.vue';
import EmptyIcon from '@/lib/aaruy-design/empty/EmptyIcon.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import LegendChart from '@/lib/aaruy-design/legend/LegendChart.vue';
import GluSorter from '@/modules/glucose/components/GluSorter.vue';


/**
 * PC端: 血糖分析-内容
 * APP端: 血糖分析-血糖详情表-列表
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  vo: AgpNewVO;
  kindItem: SelectItemVO<unknown>;
  records: Array<AgpRecordVO>;
  displayRecords: Array<AgpRecordVO>;
  displayCount: number;
  displayTotalCount: number;
  isChartRendering: boolean;
  height: string;
  isNearToFar: boolean;
}

interface Emit {
	(e: 'kindChange', data: SelectItemVO<unknown>): void;
	(e: 'pageAdd'): void;
  (e: 'sort-change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const laptop = computed<boolean>(() => screenStore.isLaptop);


function onKindItemChange(data: SelectItemVO<unknown>): void {
  emit('kindChange', data);
}

function addDisplayPage(): void {
  emit('pageAdd');
}

function onSortWayChange(): void {
  emit('sort-change', !prop.isNearToFar);
}
</script>

<template>
  <div v-if="screenStore.isPC" :style="{ height: height }"
       class="overflow-hidden-auto bg-3 p-16 text-s">
    <div style="height: 305px;" class="flex">
      <div style="width: 420px;" class="flex pr-10">
        <div class="w-half pr-5">
          <ApgCard use-value-unit width="100%" title-width="64px" title="糖化血红蛋白" :is-valid="vo.isHbaValid" :value="vo.hba" unit="%" />
          <div class="bg-1 rounded-4 overflow-hidden-auto py-10 px-16 mt-10" style="height: 200px;">
            <div class="text-weak-10 text-xs leading-xs pt-4">{{ vo.hbaEstimateTimeText }}</div>
            <div class="text-white text-s leading-2 flex justify-between pb-8 border-b-2">
              <span>预估</span>
              <span>{{ vo.hbaEstimateText }}</span>
            </div>
            <div v-if="vo.hbaVOs.length === 0" style="height: calc(100% - 53px);"
                 class="text-weak-10 text-lg pt-8 flex items-center justify-center">暂无检测数据</div>
            <template v-for="it in vo.hbaVOs" :key="it.id">
              <div class="text-weak-10 text-xs leading-xs pt-4">{{ it.dateText }} {{ it.timeText }}</div>
              <div class="text-white text-s leading-2 flex justify-between pb-8 border-b-2">
                <span>检测</span>
                <span>{{ it.valueText }}</span>
              </div>
            </template>
          </div>
        </div>
        <div class="w-half pl-5">
          <ApgCard use-title-unit width="100%" title-width="64px" title="平均血糖" :is-valid="vo.isMgValid" :value="vo.mg" unit="mmol/L" margin-bottom="10px" />
          <ApgCard use-title-unit width="100%" title-width="64px" title="变异系数" :is-valid="vo.isCvValid" :value="vo.cv" unit="%" margin-bottom="10px" />
          <ApgCard use-title-unit width="100%" title-width="80px" title="血糖标准差" :is-valid="vo.isSdValid" :value="vo.sd" unit="mmol/L" />
        </div>
      </div>
      <div class="flex-1 bg-1 rounded-4 px-24 py-16">
        <div class="mb-12">血糖分布占比</div>
        <StackedBar v-if="vo.isTirValid" :items="vo.tirItems" is-pic-vertical />
        <div v-else class="text-weak-2 font-bold text-xxl-2">----</div>
      </div>
    </div>
    <div style="height: calc(100% - 305px); min-height: 500px;" class="pt-10 flex">
      <div style="width: 420px;" class="pr-10 h-full">
        <div style="height: 110px;" class="bg-1 rounded-4 py-16 px-32 flex justify-between">
          <div>
            <div>指血检测</div>
            <div v-if="vo.isFingerCountValid" class="text-xxl-2 font-bold">{{ vo.fingerCount }}</div>
            <div v-else class="text-xxl-2 text-weak-2 font-bold">--</div>
          </div>
          <div>
            <div>静脉血检测</div>
            <div v-if="vo.isVenousCountValid" class="text-xxl-2 font-bold">{{ vo.venousCount }}</div>
            <div v-else class="text-xxl-2 text-weak-2 font-bold">--</div>
          </div>
          <div>
            <div>CGM数值</div>
            <div v-if="vo.isCgmCountValid" class="text-xxl-2 font-bold">{{ vo.cgmCount }}</div>
            <div v-else class="text-xxl-2 text-weak-2 font-bold">--</div>
          </div>
        </div>
        <div style="height: calc(100% - 110px);">
          <div style="height: 50px;" class="flex items-center text-center rounded-t-4 bg-10 px-8">
            <div class="flex-1 flex items-center justify-center cursor-pointer" @click="onSortWayChange">
              <span class="mr-4">时间</span>
              <GluSorter :is-near-to-far="isNearToFar" />
            </div>
            <div style="width: 80px;">
              <div>数值</div>
              <div class="text-weak-2 text-xs leading-xs">mmol/L</div>
            </div>
            <div style="width: 100px;" class="flex justify-center">
              <SelectorTip :item="kindItem" :items="APG_RECORD_KIND_ITEMS" @change="onKindItemChange" />
            </div>
          </div>
          <div style="height: calc(100% - 50px);" class="bg-1 overflow-hidden-auto px-8">
            <EmptyIcon v-if="records.length === 0" tips="暂无数据" height="100%" align-center />
            <template v-else>
              <div v-for="(it,i) in displayRecords"
                   :key="it.id"
                   class="flex items-center text-center "
                   :class="{ 'border-b-default': i === 0 || i < vo.records.length-1 }"
                   style="height: 45px;"
              >
                <div class="flex-1">{{ it.timeText }}</div>
                <div style="width: 80px;">{{ it.valueText2 }}</div>
                <div style="width: 100px;">{{ it.kindText }}</div>
              </div>
              <div v-if="displayRecords.length < records.length" class="pt-8 pb-16">
                <ButtonView type="default-primary" :text="'显示更多' + ' (已显示' + displayCount + '条/共' + displayTotalCount + '条)'" style="width: 100%; height: 32px;"
                            @click="addDisplayPage" />
              </div>
            </template>
          </div>
        </div>
      </div>
      <div class="flex-1 bg-1 h-full">
        <div class="flex items-center justify-between px-16" style="height: 48px;">
          <div class="font-bold text-xl leading-xl">AGP图谱</div>
          <LegendChart :is-agp="true" :items="[
                  { id: 1, text: laptop ? '中位数' : '中位数线', color: 'rgb(159,255,172)' },
                  { id: 2, text: laptop ? '25%-75%' : '25%-75%区间', color: 'rgb(58,131,68)' },
                  { id: 3, text: laptop ? '5%-95%' : '5%-95%区间', color: 'rgb(66,98,70)' },
                  { id: 4, text: laptop ? '95%' : '95%', color: 'rgb(58,68,77)' },
              ]" />
        </div>
        <div class="relative" style="height: calc(100% - 48px);">
          <div v-if="isChartRendering" class="absolute text-weak-2 text-lg" style="left: 16px; top: 16px;">图形渲染中，请稍候...</div>
          <div :id="AGP_ELE_ID" class="h-full"></div>
        </div>
      </div>
    </div>
  </div>
  <template v-else>
    <div v-for="(it,i) in displayRecords"
         :key="it.id"
         class="bg-4 text-white text-xs px-8"
         :class="{
           'rounded-b-4': i === records.length-1,
         }"
         style="height: 64px;">
      <div :class="{ 'border-b-default': i < displayRecords.length-1 }" class="h-full flex">
        <div class="h-full inline-block text-center text-xxs" style="width: 33.3%;">
          <div style="line-height: 40px;">{{ it.dateText }}</div>
          <div style="line-height: 4px;">{{ it.timeText2 }}</div>
        </div>
        <span class="h-full inline-block text-center font-bold" style="width: 33.3%; line-height: 64px;">{{ it.valueText }}</span>
        <span class="h-full inline-block text-center" style="width: 33.3%; line-height: 64px;">{{ it.kindText }}</span>
      </div>
    </div>
    <ButtonView v-if="displayRecords.length < records.length"
                type="primary"
                :text="'显示更多' + ' (已显示' + displayCount + '条/共' + displayTotalCount + '条)'"
                style="width: 100%; height: 32px; background-color: var(--aaruy-bg-color-1);"
                @click="addDisplayPage" />
  </template>
</template>
