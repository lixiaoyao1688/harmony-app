<script setup lang="ts">
import { computed } from 'vue';
import { useGluStore } from '@/modules/glucose/store/glu.store';
import { GluHourVO } from '@/modules/glucose/vo/GluHour.vo';


interface Prop {
	startIndex: number;   // 开始的索引，0~23
}

const store = useGluStore();
const prop = defineProps<Prop>();
const vos = computed<Array<GluHourVO>>(() => store.hourVos.slice(prop.startIndex, prop.startIndex + 8) as Array<GluHourVO>);  // 每个 table 8个小时
const thStyle = {
  lineHeight: '12px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  padding: '0 8px'
};
const tdHeight1 = '40px';
const tdHeight2 = '165px';
const tdHeight3 = '45px';
const tdBorder = '1px solid rgb(34,34,34)';
const tdBorder2 = '1px solid rgb(187,187,187)';
const tdBorder3 = '1px solid rgb(255,255,255)';
</script>

<template>
	
	<div style="display: flex;">
		<!--	一列一个 table	-->
		<table style="width: 24%;">
			<tbody>
			
				<tr :style="{ height: tdHeight1, lineHeight: tdHeight1 }">
					<td style="font-weight: bold; text-align: center; background-color: rgb(29,110,249); color: rgb(255,255,255); font-size: 14px;">时间段（h）</td>
				</tr>
			
				<tr :style="{ height: tdHeight2 }">
					<td :style="{ borderRight: tdBorder, borderBottom: tdBorder }">
						<div style="color: rgb(0,0,0); padding: 10px 8px 14px;">
							<div style="font-weight: 700; color: rgb(34,34,34);">TIR</div>
							<div style="font-size: 12px; line-height: 12px;">葡萄糖目标范围内时间</div>
              <div style="display: flex; align-items: center; margin-top: 8px;">
                <span style="display: inline-block; width: 12px; height: 12px; background-color: rgb(22,201,165);"></span>
                <span style="font-size: 12px; line-height: 12px; margin-left: 4px;">{{ vos[0].okRangeText }}</span>
              </div>
              <div style="display: flex; align-items: center; margin-top: 8px;">
                <span style="display: inline-block; width: 12px; height: 12px; background-color: rgb(211,90,33);"></span>
                <span style="font-size: 12px; line-height: 12px; margin-left: 4px;">{{ vos[0].superHighRangeText }}</span>
              </div>
              <div style="display: flex; align-items: center; margin-top: 8px;">
                <span style="display: inline-block; width: 12px; height: 12px; background-color: rgb(235,166,48);"></span>
                <span style="font-size: 12px; line-height: 12px; margin-left: 4px;">{{ vos[0].highRangeText }}</span>
              </div>
              <div style="display: flex; align-items: center; margin-top: 8px;">
                <span style="display: inline-block; width: 12px; height: 12px; background-color: rgb(255,68,86);"></span>
                <span style="font-size: 12px; line-height: 12px; margin-left: 4px;">{{ vos[0].lowRangeText }}</span>
              </div>
							<div style="display: flex; align-items: center; margin-top: 8px;">
								<span style="display: inline-block; width: 12px; height: 12px; background-color: rgb(149,17,20);"></span>
								<span style="font-size: 12px; line-height: 12px; margin-left: 4px;">{{ vos[0].superLowRangeText }}</span>
							</div>
						</div>
					</td>
				</tr>
				
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">探头数值量</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);"></span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">上限</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder, borderBottom: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">下限</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">达标</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">目标范围内时间</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">很高</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);"></span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">偏高</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">高于目标范围时间</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">很低</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);"></span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder, borderBottom: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">偏低</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">低于目标范围时间</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px;"></div>
						</div>
					</td>
				</tr>
				
				
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">MG</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">平均葡萄糖</div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">SD</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">葡萄糖标准差</div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder, borderBottom: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">CV</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);"></span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">变异系数</div>
						</div>
					</td>
				</tr>
				
				
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">5%-95%</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">区间</div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">50%</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">中位数</div>
						</div>
					</td>
				</tr>
				<tr :style="{ height: tdHeight3 }">
					<td :style="{ borderRight: tdBorder }">
						<div :style="thStyle">
							<div style="display: flex; align-items: flex-end; justify-content: space-between;">
								<span style="font-size: 14px; font-weight: 700; color: rgb(34,34,34);">25%-75%</span>
								<span style="font-size: 12px; margin-left: 8px; color: rgb(0,0,0);">mmol/L</span>
							</div>
							<div style="font-size: 12px; margin-top: 4px; color: rgb(0,0,0);">区间-IQR</div>
						</div>
					</td>
				</tr>
			
			</tbody>
		</table>
		<table v-for="vo in vos" :key="vo.id" style="flex: 1;">
			<tbody style="color: rgb(34,34,34); font-weight: bold; text-align: center;">
			
				<tr :style="{ borderRight: tdBorder3 }" style="font-weight: bold; text-align: center; background-color: rgb(29,110,249); height: 40px; line-height: 40px; color: rgb(255,255,255); font-size: 14px;">
					<td>{{ vo.timeField }}</td>
				</tr>
				
				<tr :style="{ height: tdHeight2 }">
					<td :style="{ borderBottom: tdBorder, borderRight: tdBorder2 }">
						<div style="flex: 1; height: 162px; display: flex; justify-content: center; align-items: center;">
								<div style="width: 50%; height: 80%;">
									<p v-if="vo.isTirEmpty" style="height: 100%; display: flex; align-items: center; justify-content: center;">--</p>
									<template v-else>
										<div v-for="(it, i) in vo.tirItems" :key="it.id"
												 :style="{
											height: it.percent,
											backgroundColor: it.color,
											borderRadius: ( (i === vo.firstDataIndex && i === vo.lastDataIndex) ? '4px' : (i === vo.firstDataIndex ? '4px 4px 0 0' : (i === vo.lastDataIndex ? '0 0 4px 4px' : '0')))
										}"></div>
									</template>
								</div>
						</div>
					</td>
				</tr>
				
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2 }">{{ vo.count }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2 }">{{ vo.top }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder  }">{{ vo.bottom }}</td></tr>
				
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.ok }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.superHigh }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.high }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.superLow }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder   }">{{ vo.low }}</td></tr>
				
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.mg }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.sd }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder   }">{{ vo.cv }}</td></tr>
				
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.agpFiveToNinetyFive }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2, borderBottom: tdBorder2  }">{{ vo.agpFifty }}</td></tr>
				<tr :style="{ height: tdHeight3 }"><td :style="{ borderRight: tdBorder2 }">{{ vo.agpTwentyFiveToSeventyFive }}</td></tr>
				
			</tbody>
		</table>
	</div>
	
</template>
