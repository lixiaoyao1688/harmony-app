<script setup lang="ts">
import { ref, watch, computed, nextTick } from 'vue';
import {GLU, GLU_DEFAULT_RANGE} from '@/modules/glucose/config/glu.config';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {getCenterPoint, getDigitCount, getPercent} from '@/lib/math/util/math.util';
import SliderView from '@/lib/aaruy-design/slider/SliderView.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import StepSingle from '@/lib/aaruy-design/stepper/views/StepSingle.vue';
import IconRightArrow from '@/modules/glucose/icons/IconRightArrow.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import InputField2 from '@/lib/aaruy-design/input/field/InputField2.vue';
import type { GluRangeType } from '@/modules/glucose/types/glu.types';
import type { ErrorExposedType } from '@/lib/aaruy-design/error/type/error.type';
import type { SliderData, SliderRangeType } from '@/lib/aaruy-design/slider/types/slider.type';


/**
 * 血糖目标范围设置 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
	range: SliderRangeType;
  title?: string;
  borderColor?: string;
  padding?: string;  // 默认 padding: 4px 48px;
}

interface Emit {
	(e: 'change', data: SliderData): void;
	(e: 'range-change', data: SliderRangeType): void;
  (e: 'error-change', data: string): void;
}

const screenStore = useScreenStore();

const MIN = GLU.MIN;
const MAX = GLU.MAX;
const STEP = GLU.STEP;
const DIGIT = GLU.RANGE_DIGIT;

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const innerRange = ref<GluRangeType>(GLU_DEFAULT_RANGE);

const superLow = ref<string>(GLU_DEFAULT_RANGE[0].toFixed(1));
const superLowRef = ref<ErrorExposedType | null>(null);

const low = ref<string>(GLU_DEFAULT_RANGE[1].toFixed(1));
const high = ref<string>(GLU_DEFAULT_RANGE[2].toFixed(1));
const rangeErrorTips = ref<string>('');

const superHigh = ref<string>(GLU_DEFAULT_RANGE[3].toFixed(1));
const superHighRef = ref<ErrorExposedType | null>(null);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

const wordX1 = ref<string>('20%');
const wordX2 = ref<string>('40%');
const wordX3 = ref<string>('60%');

// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError
});

watch(() => prop.range, (data) => {
  const x1 = data[0];
  const x2 = data[1];
  const x3 = data[2];
  const x4 = data[3];
  wordX1.value = getLeft(getCenterPoint(x1, x2, DIGIT));
  wordX2.value = getLeft(getCenterPoint(x2, x3, DIGIT));
  wordX3.value = getLeft(getCenterPoint(x3, x4, DIGIT));
  innerRange.value = [...data];
  superLow.value = innerRange.value[0].toString();
  low.value = innerRange.value[1].toFixed(1);
  high.value = innerRange.value[2].toFixed(1);
  superHigh.value = innerRange.value[3].toString();
}, { immediate: true });

function getLeft(x: number): string {
  // "0~x的长度"占"总长度"的百分比
  let p = getPercent(x-MIN, MAX-MIN);
  
  if (p < 10) {
    p = 10;
  }
  else if (p > 90) {
    p = 90;
  }
  return p + '%';
}

function emitChange(data: SliderData): void {
  emit('change', data);
}

function emitRange(data: SliderRangeType): void {
  emit('range-change', data);
}

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function checkValueError(): boolean {
  let hasError = false;
  if (checkRangeError()) {
    hasError = true;
  }
  if (checkSuperLowError()) {
    hasError = true;
  }
  if (checkSuperHighError()) {
    hasError = true;
  }
  return hasError;
}

function checkRangeError(): boolean {
  const tips = getRangeErrorTips(low.value, high.value);
  rangeErrorTips.value = tips;
  emitErrorTips(tips);
  return tips !== '';
}

function checkSuperLowError(): boolean {
  if (!superLowRef.value) {
    return false;
  }
  return superLowRef.value.checkValueError();
}

function checkSuperHighError(): boolean {
  if (!superHighRef.value) {
    return false;
  }
  return superHighRef.value.checkValueError();
}

function getRangeErrorTips(low: string, high: string): string {
  if (!low) {
    return '低血糖阈值不得为空。';
  }
  if (!high) {
    return '高血糖阈值不得为空。';
  }
  if (+high < +low) {
    return '高血糖阈值不得小于低血糖阈值。';
  }
  if (getDigitCount(low) > 1 || getDigitCount(high) > 1) {
    return '小数位数不得超过1位。';
  }
  return '';
}

function emitErrorTips(data: string): void {
  emit('error-change', data);
}

function onSuperLowChange(data: string): void {
  superLow.value = data;
  if (checkSuperLowError()) {
    return;
  }
  innerRange.value[0] = +data;
  emitRange(innerRange.value);
}

function onSuperHighChange(data: string): void {
  superHigh.value = data;
  if (checkSuperHighError()) {
    return;
  }
  innerRange.value[3] = +data;
  emitRange(innerRange.value);
}

function onRangeLowChange(data: string): void {
  low.value = data;
  checkRangeError();
}

function onRangeHighChange(data: string): void {
  high.value = data;
  checkRangeError();
}

async function onRangeChange() {
  if (checkRangeError()) {
    return;
  }
  innerRange.value[1] = +low.value;
  innerRange.value[2] = +high.value;
  emitRange(innerRange.value);
  onClose();
  await nextTick();
  checkSuperLowError();
  checkSuperHighError();
}
</script>

<template>
  <div v-if="pc" class="glu-range">
		<span v-if="title" class="block text-s text-white font-bold mb-8" style="min-height: 6px;">{{ title }}</span>
    <div class="bg-1 rounded-4 border-bg-transparent"
         :style="{ padding: padding || '4px 48px', borderColor: borderColor || 'transparent' }">
      <SliderView :min-range="0" :min="MIN" :max="MAX" :step="STEP" :value="innerRange" @change="emitChange" />
      <div class="bar-word">
        <span class="text" :style="{ left: wordX1 }">{{ pc ? '低血糖' : '低' }}</span>
        <span class="text" :style="{ left: wordX2 }">{{ pc ? '目标范围' : '目标' }}</span>
        <span class="text" :style="{ left: wordX3 }">{{ pc ? '高血糖' : '高' }}</span>
      </div>
    </div>
	</div>
  <template v-else>
    <ModalView :visible="isOpened" title="目标范围" is-mobile-dialog @close="onClose">
      <div class="flex justify-center text-white text-xs text-center leading-xs pt-16">
        <div style="width: 72px;" class="mr-8">
          <div :class="'text-xs'">低血糖阈值</div>
          <div :class="'text-xxs'" class="mb-8">mmol/L</div>
          <StepSingle :data="low" :step="0.1" :digit="1" name="low" @change="onRangeLowChange" />
        </div>
        <div style="width: 72px;">
          <div :class="'text-xs'">高血糖阈值</div>
          <div :class="'text-xxs'" class="mb-8">mmol/L</div>
          <StepSingle :data="high" :step="0.1" :digit="1" name="high" @change="onRangeHighChange" />
        </div>
      </div>
      <ErrorView :tips="rangeErrorTips" :font-weight="700" color="var(--aaruy-error-color)" padding="8px 16px 16px" is-text-center />
      <div class="flex items-center justify-between" style="height: 36px;">
        <ButtonView type="default" text="取消" style="width: 50%; height: 100%; border-radius: 0 0 0 4px;" @click="onClose" />
        <ButtonView type="primary" text="确定" style="width: 50%; height: 100%; border-radius: 0 0 4px 0;" @click="onRangeChange" />
      </div>
    </ModalView>
    <FieldView2 type="other-complex" padding="12px 12px 6px" is-start>
      <div class="flex items-center justify-between pb-4"
           style="border-bottom-width: 1px; border-bottom-style: solid;"
           :style="{
             borderBottomColor: rangeErrorTips ? 'var(--aaruy-error-color-2)' : 'var(--aaruy-bg-color-0)'
           }"
           @click="onOpen">
        <span :class="{ 'text-error-2': rangeErrorTips, 'text-white': !rangeErrorTips }">目标范围</span>
        <div class="inline-flex items-center">
          <span class="mr-8">{{ innerRange[1].toFixed(1) }}-{{ innerRange[2].toFixed(1) }} mmol/L</span>
          <IconRightArrow />
        </div>
      </div>
      <ErrorView v-if="rangeErrorTips" :tips="rangeErrorTips" :font-weight="400" color="var(--aaruy-error-color-2)" />
    </FieldView2>
    <FieldView2 type="other-complex" padding="6px 12px">
      <InputField2 ref="superHighRef" title="紧急高血糖" :data="superHigh"
                   name="superHigh" type="number" unit="mmol/L"
                   :min="+innerRange[2]" :max="100" :digit="1"
                   @change="onSuperHighChange" @error-change="emitErrorTips" />
    </FieldView2>
    <FieldView2 type="other-complex" padding="6px 12px">
      <InputField2 ref="superLowRef" title="紧急低血糖" :data="superLow"
                   name="superLow" type="number" unit="mmol/L"
                   :min="0" :max="+innerRange[1]" :digit="1"
                   @change="onSuperLowChange" @error-change="emitErrorTips" />
    </FieldView2>
  </template>
</template>

<style scoped>
.glu-range {
	--gr-word-width: 70px;
	--gr-word-height: 30px;
	--gr-block-width: 50px;
	--gr-block-height: 40px;
}

.bar-word {
	position: relative;
	height: 30px;
	margin-top: 7px;
}

.text {
	position: absolute;
	top: 0;
	display: inline-block;
	text-align: center;
	width: var(--gr-word-width);
	height: var(--gr-word-height);
	line-height: var(--gr-word-height);
	margin-left: calc(var(--gr-word-width) / -2);
	font-size: 14px;
	color: var(--aaruy-weak-text-color);
}
</style>
