<script setup lang="ts">
import IconSelectorTipUp from '@/lib/aaruy-design/selector/tip/icons/IconSelectorTipUp.vue';
import IconSelectorTipDown from '@/lib/aaruy-design/selector/tip/icons/IconSelectorTipDown.vue';


/**
 * 血糖记录排序器 组件
 */
interface Prop {
  isNearToFar: boolean;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="inline-flex flex-col">
    <IconSelectorTipUp :is-not-yet-enabled="isNearToFar" :scale="0.8" />
    <IconSelectorTipDown :is-not-yet-enabled="!isNearToFar" :scale="0.8" />
  </div>
</template>
