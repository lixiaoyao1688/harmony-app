export const AGP_X_DATA = Array(289).fill(0).map((_,i) => i);
export const AGP_FORMATTER = (v: number) => {
  const value = Math.floor((v * 5) / 60);
  return value == 24 ? '0' : `${value}`;
};
export const AGP_LEGENDS = [
  { id: 1, text: '中位数线', color: 'rgb(159,255,172)' },
  { id: 2, text: '25%-75%', color: 'rgb(58,131,68)' },
  { id: 3, text: '5%-95%', color: 'rgb(66,98,70)' },
  { id: 4, text: '95%', color: 'rgb(58,68,77)' },
];
export const AGP_ELE_ID = 'glu-ana';

// 中位线
export const APG_LINE_CENTER_COLOR = 'rgb(0,49,146)';
// 5%-95%
export const APG_LINE_5_95_COLOR = 'rgb(198,217,255)';
// 25%-75%
export const APG_LINE_25_75_COLOR = 'rgb(110,158,253)';
