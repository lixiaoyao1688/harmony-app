import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {GLU_KIND} from '@/modules/glucose/config/glu.kind';


export enum GLU_RECORD_KIND {
  FINGER = 'finger',
  CGM = 'cgm',
  VEIN = 'vein',
}

// 仅前端使用
export enum APG_RECORD_KIND {
  ALL = 0,
  CGM,
  FINGER,
  VENOUS
}

export const APG_RECORD_KIND_ALL_ITEM = new SelectItemVO({ id: APG_RECORD_KIND.ALL, text: '全部' });

export const APG_RECORD_KIND_ITEMS = [
  APG_RECORD_KIND_ALL_ITEM,
  new SelectItemVO({ id: APG_RECORD_KIND.CGM, text: 'CGM' }),
  new SelectItemVO({ id: APG_RECORD_KIND.FINGER, text: '指血' }),
  new SelectItemVO({ id: APG_RECORD_KIND.VENOUS, text: '静脉血' }),
];

export const APG_RECORD_KIND_MAP = SelectItemVO.getMap(APG_RECORD_KIND_ITEMS);

// GLU_RECORD_KIND => APG_RECORD_KIND 映射表
export const APG_RECORD_KIND_TO_ID_MAP = new Map([
  [GLU_RECORD_KIND.FINGER, APG_RECORD_KIND.FINGER],
  [GLU_RECORD_KIND.CGM, APG_RECORD_KIND.CGM],
  [GLU_RECORD_KIND.VEIN, APG_RECORD_KIND.VENOUS],
]);

// GLU_RECORD_KIND => GLU_KIND 映射表
export const GLU_RECORD_KIND_TO_GLU_KIND_MAP = new Map([
  [GLU_RECORD_KIND.FINGER, GLU_KIND.FINGER],
  [GLU_RECORD_KIND.VEIN, GLU_KIND.VEIN],
]);
