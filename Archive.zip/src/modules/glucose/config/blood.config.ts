import {COLOR_BLACK_0, COLOR_WHITE_0} from '@/lib/style/color';
import {FONT_SIZE_12, FONT_SIZE_16} from '@/lib/chart/config/chart.font';


export const BLOOD_BG_COLOR = 'rgba(103,149,238,0.43)';
export const BLOOD_BG_COLOR_2 = 'rgba(247,58,63,0.43)';
export const BLOOD_COLOR = COLOR_WHITE_0;
export const BLOOD_COLOR_ON_REPORT = COLOR_BLACK_0;
export const BLOOD_SYMBOL_IMAGE = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMS4zNzciIGhlaWdodD0iMTMuNzMzIiB2aWV3Qm94PSIwIDAgMTEuMzc3IDEzLjczMyI+DQogIDxwYXRoIGlkPSJsb2NhdGlvbiIgZD0iTTUsMTIuNDA4Ljg2Nyw2Ljk4MmE0LjExOSw0LjExOSwwLDAsMSwuNi01LjY3Myw1LjQzLDUuNDMsMCwwLDEsNy4wNzEsMCw0LjExOSw0LjExOSwwLDAsMSwuNiw1LjY3M1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwLjY4OSAxMy4yMzMpIHJvdGF0ZSgxODApIiBmaWxsPSIjZjczYTNmIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMSIvPg0KPC9zdmc+DQo=';
export const BLOOD_SYMBOL = `image://${BLOOD_SYMBOL_IMAGE}`;  // 指血（或静脉血）图标
// 指血（或静脉血）打卡图标
export const BLOOD_CHECKIN_SYMBOL = 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMS4zNzciIGhlaWdodD0iMTMuNzMzIiB2aWV3Qm94PSIwIDAgMTEuMzc3IDEzLjczMyI+DQogICAgPHBhdGggZD0iTTUsMTIuNDA4Ljg2Nyw2Ljk4MmE0LjExOSw0LjExOSwwLDAsMSwuNi01LjY3Myw1LjQzLDUuNDMsMCwwLDEsNy4wNzEsMCw0LjExOSw0LjExOSwwLDAsMSwuNiw1LjY3M1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwLjY4OSAxMy4yMzMpIHJvdGF0ZSgxODApIg0KICAgICAgICAgIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSIxIiAvPg0KPC9zdmc+';
export const BLOOD_SYMBOL_SIZE = [11,13];
export const BLOOD_SYMBOL_SIZE_APP = [6.76,8];
export const BLOOD_PADDING = [5,4,2];
export const BLOOD_DISTANCE = 4;
export const BLOOD_DISTANCE_ON_REPORT = 1;
export const BLOOD_FONT_SIZE = FONT_SIZE_16;
export const BLOOD_FONT_SIZE_ON_REPORT = FONT_SIZE_12;
