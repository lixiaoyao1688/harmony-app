/**
 * CGM 断联阈值
 *
 * 单位
 * 分钟
 *
 * 含义
 * 相邻两点测量时间小于等于阈值时，曲线不会断，大于阈值时断掉。
*/

// 雅培
export const CGM_YA_PER_INTERVAL = 15;  // 血糖数据点采集间隔 (分钟)
export const CGM_YA_PEI_THRESHOLD = 15;  // 断联阈值 (分钟)

// 阿瑞
export const CGM_AARUY_INTERVAL = 1;  // 血糖数据点采集间隔 (分钟)
export const CGM_AARUY_THRESHOLD = 5;  // 断联阈值 (分钟)
