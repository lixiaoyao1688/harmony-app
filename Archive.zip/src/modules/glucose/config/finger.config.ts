import {GLOBAL_YES_OR_NO} from '@/dto/global.dto';
import type {FingerTaskType} from '@/modules/glucose/types/finger.type';


/**
 * 指血 配置
 *
 * 单位
 * mmol/L
 */
export const MAX_FINGER_VALUE = 100;
export const MIN_FINGER_VALUE = 0;
export const MAX_FINGER_DIGIT = 1;  // 最多小数位数
export const FINGER_STEP = 0.1;  // 步长

export const FINGER_DEFAULT_TASKS = Array(9).fill(0).map(v => GLOBAL_YES_OR_NO.NO) as FingerTaskType;

export function getDefaultFingerTask(): FingerTaskType {
  return [...FINGER_DEFAULT_TASKS];
}
