import {GLU_ANA_LEVEL} from '@/modules/glucose/dto/agp.dto';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {CHART_CONFIG} from '@/modules/chart/config/chart.config';
import {GluKind, GluLevelItemPayload, GluRangeType} from '@/modules/glucose/types/glu.types';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {COLOR_WHITE_0} from '@/lib/style/color';
import {ADVICE_SMART_AID_TARGET} from '@/modules/advice-closed-loop/config/advice.cl.smart.aid.target';
import {
  BLOOD_BG_COLOR, BLOOD_CHECKIN_SYMBOL, BLOOD_COLOR,
  BLOOD_DISTANCE, BLOOD_FONT_SIZE,
  BLOOD_PADDING,
  BLOOD_SYMBOL,
  BLOOD_SYMBOL_SIZE
} from '@/modules/glucose/config/blood.config';
import type {LegendChartType} from '@/lib/aaruy-design/legend/types/legend.chart.type';


export const GLU = {
	
  INVALID: -1,
  MIN: 0,
  MAX: 23,
  MAX_OVERSIZE: 36.5,  // 异常概率 1% (已废弃)
  
  MARK_VALUE_1: 16.7,
  MARK_VALUE_2: 22.2,
  MARK_VALUE_OVERSIZE: 36.5,
  
  // 高低血糖阈值
  RANGE_MIN: 2,
  RANGE_MAX: 12.5,
  RANGE_MIN_DEFAULT: 3.9,
  RANGE_MAX_DEFAULT: 10,
  STEP: 0.1,
  RANGE_DIGIT: 1,  // 保留的小数位数
  RANGE_DISTANCE: 4,  // 高低血糖阈值至少要有 4 mmol/L 的间距
  RANGE_COUNT: 4,  // 高低血糖阈值点数量，根据 GluRangeType 得到

  CGM: {
    NAME: 'CGM'
  },
  
  DIGITS: 3,  // 保留的小数点位数
  UNIT_1: 'mmol/L',
  UNIT_2: 'mg/dL',
  UNIT_3: 'umol/L',
  
  COLOR: {
    NORMAL: 'rgb(255,255,255)',
    LOW: 'rgb(247,58,63)',
    HIGH: 'rgb(248,168,30)',
  },
  
  NORMAL: {
    COLOR_CGM: 'rgb(159,255,172)',
    COLOR_FINGER: 'rgb(38,111,232)',
  },
  LOW: {
    COLOR: 'rgb(255,36,42)'
  },
  HIGH: {
    COLOR: 'rgb(235,166,48)'
  },
  
  CURRENT_DOM_ID: 'current_glu_chart',
  CURRENT_DOM_ID_OUT: 'current_glu_chart_out',
  
  FINGER: {
    SYMBOL_SIZE: 6,
    SYMBOL_SIZE_FOR_PAD: 6,
    SYMBOL_SIZE_FOR_PHONE: 4,
  },
  
  
  TIR: {
    COLOR: 'rgb(22,201,165)',
  },
  TAR: {
    COLOR: 'rgb(235,166,48)',
  },
  TBR: {
    COLOR: 'rgb(255,68,86)',
  },
  
  // 血糖分布占比
  LEVEL_SUPER_LOW_ITEM: new SelectItemVO<GluLevelItemPayload>({ id: GLU_ANA_LEVEL.SUPER_LOW, text: '很低', payload: { color: 'rgb(149,17,20)' } }),
  LEVEL_LOW_ITEM: new SelectItemVO<GluLevelItemPayload>({ id: GLU_ANA_LEVEL.LOW, text: '偏低', payload: { color: 'rgb(255,68,86)' } }),
  LEVEL_OK_ITEM: new SelectItemVO<GluLevelItemPayload>({ id: GLU_ANA_LEVEL.OK, text: '达标', payload: { color: 'rgb(22,201,165)' } }),
  LEVEL_HIGH_ITEM: new SelectItemVO<GluLevelItemPayload>({ id: GLU_ANA_LEVEL.HIGH, text: '偏高', payload: { color: 'rgb(235,166,48)' } }),
  LEVEL_SUPER_HIGH_ITEM: new SelectItemVO<GluLevelItemPayload>({ id: GLU_ANA_LEVEL.SUPER_HIGH, text: '很高', payload: { color: 'rgb(211,90,33)' } }),
  LEVEL_PERCENT_DIGIT: 1,  // 转换成百分比后，保留的小数位数
  
  LEVEL: {
    ITEMS: [
      // id 代表 dto 的 index
      new SelectorFormItemVO(GLU_ANA_LEVEL.SUPER_LOW, '很低', { color: 'rgb(149,17,20)' }),
      new SelectorFormItemVO(GLU_ANA_LEVEL.LOW, '偏低', { color: 'rgb(255,68,86)' }),
      new SelectorFormItemVO(GLU_ANA_LEVEL.HIGH, '偏高', { color: 'rgb(235,166,48)' }),
      new SelectorFormItemVO(GLU_ANA_LEVEL.SUPER_HIGH, '很高', { color: 'rgb(211,90,33)' }),
      new SelectorFormItemVO(GLU_ANA_LEVEL.OK, '达标', { color: 'rgb(22,201,165)' }),
    ],
    DIGITS: 1,
  },
  
  AGP_POINT_COUNT: 289,
  
};

export const MAX_GLU_VALUE = 22.2; // 最高血糖值 (mmol/L)
export const MIN_GLU_VALUE = 2.6; // 最低血糖值 (mmol/L)
export const GLU_VALUE_DIGIT = 1;  // 血糖值保留的小数位数

export const GLU_REPORT_TARGET_BG_COLOR = 'rgba(105,158,245,0.16)';
export const GLU_HIGH_LINE_COLOR = 'rgb(163,175,188)';


export function gluGetMarkAreaOffset(data: number): [number, number] {
  const y = -2;
  const text = data.toString();
  
  if (text.length === 4) {
    return [-30,y];
  }
  if (text.length === 3) {
    return [-24, y];
  }
  if (text.length === 2) {
    return [-21, y];
  }
  return [-14, y];
}

export function getGluMarkArea(low: number, high: number) {
  return {
    silent: true,
    data: [
      [
        {
          name: high.toString(),
          yAxis: high,
          label: {
            color: CHART_CONFIG.TEXT_COLOR,
            fontSize: CHART_CONFIG.FONT_SIZE_XXS,
            position: gluGetMarkAreaOffset(high),
          },
          itemStyle: {
            // 血糖目标范围背景颜色
            color: 'rgba(159,255,172,0.1)'
          }
        },
        {
          yAxis: low
        },
      ],
      [
        {
          name: low.toString(),
          yAxis: low,
          label: {
            color: CHART_CONFIG.TEXT_COLOR,
            fontSize: CHART_CONFIG.FONT_SIZE_XXS,
            position: gluGetMarkAreaOffset(low),
          },
          itemStyle: {
            // Y轴0到low的背景透明
            color: 'transparent'
          }
        },
        {
          yAxis: GLU.MIN,
        },
      ]
    ]
  };
}

export function getGluSeriesBaseConfig(low: number, high: number, smartAID?: ADVICE_SMART_AID_TARGET, ss?: [number, number], isLabelShowed?: boolean, labelBgColor?: string) {
  const markLineData = [
    {
      yAxis: GLU.MARK_VALUE_1,
      lineStyle: {
        type: [4,4],
        width: 2
      },
      label: {
        show: true,
      }
    },
    {
      yAxis: GLU.MARK_VALUE_2,
      lineStyle: {
        width: 0
      },
      label: {
        show: true,
      }
    }
  ];
  if (smartAID) {
    markLineData.unshift({
      yAxis: smartAID,
      lineStyle: {
        type: [4,4],
        width: 1,
        color: COLOR_WHITE_0
      },
      label: {
        show: false,
      }
    } as any);
  }
  
  return {
    type: 'scatter',
    name: 'finger',
    z: 10,
    markLine: {
      z: 0,
      silent: true,
      animation: false,
      label: {
        position: 'start',
        distance: 6,
        color: CHART_CONFIG.TEXT_COLOR,
        fontSize: CHART_CONFIG.FONT_SIZE_XXS,
      },
      lineStyle: {
        color: CHART_CONFIG.AXIS_LINE_COLOR
      },
      symbol: 'none',
      data: markLineData
    },
    markArea: getGluMarkArea(low, high),
    symbol: (_, p) => {
      return p && p.data && p.data.payload && p.data.payload.isFromCheckin ? BLOOD_CHECKIN_SYMBOL : BLOOD_SYMBOL;
    },
    symbolSize: ss || BLOOD_SYMBOL_SIZE,
    // symbolSize: GLU.FINGER.SYMBOL_SIZE,
    label: {
      show: !!isLabelShowed,
      position: 'bottom',
      distance: BLOOD_DISTANCE,
      backgroundColor: labelBgColor || BLOOD_BG_COLOR,
      color: BLOOD_COLOR,
      padding: BLOOD_PADDING,
      fontSize: BLOOD_FONT_SIZE,
      borderRadius: 4,
    },
    cursor: 'default',
    data: [],
  };
}

export const GLU_LEGENDS: Array<LegendChartType> = [
  { id: 3, text: 'CGM', color: GLU.NORMAL.COLOR_CGM },
];

export const GLU_DEFAULT_RANGE = [3, 3.9, 10, 13.9] as GluRangeType;

// 糖尿病类型
export enum GLU_DIABETE_KIND {
  OTHER,  // 其他糖尿病
  ONE,  // 1型糖尿病
  TWO,  // 2型糖尿病
  ONE_PG,  // 1型糖尿病妊娠
  TWO_PG,  // 2型糖尿病妊娠
  ONE_OLD,  // 老年/高风险1型糖尿病
  TWO_OLD,  // 老年/高风险2型糖尿病
  PG,  // 妊娠型糖尿病
}

// 默认糖尿病类型
export const GLU_DEFAULT_KINDS: Array<GluKind> = [
  { kind_id: GLU_DIABETE_KIND.OTHER, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.ONE, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.TWO, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.ONE_PG, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.TWO_PG, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.ONE_OLD, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.TWO_OLD, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
  { kind_id: GLU_DIABETE_KIND.PG, glucose_range: Array.from(GLU_DEFAULT_RANGE) as GluRangeType },
];

export const GLU_KIND_MAP = new Map<number, string>([
  [GLU_DIABETE_KIND.OTHER, '其他糖尿病'],
  [GLU_DIABETE_KIND.ONE, '1型糖尿病'],
  [GLU_DIABETE_KIND.TWO, '2型糖尿病'],
  [GLU_DIABETE_KIND.ONE_PG, '1型糖尿病妊娠'],
  [GLU_DIABETE_KIND.TWO_PG, '2型糖尿病妊娠'],
  [GLU_DIABETE_KIND.ONE_OLD, '老年/高风险1型糖尿病'],
  [GLU_DIABETE_KIND.TWO_OLD, '老年/高风险2型糖尿病'],
  [GLU_DIABETE_KIND.PG, '妊娠型糖尿病'],
]);
