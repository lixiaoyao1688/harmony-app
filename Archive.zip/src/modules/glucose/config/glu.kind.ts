import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 血糖类型 配置
 */
export enum GLU_KIND {
  FINGER = 0,
  VEIN = 1,
}

const GLU_KIND_FINGER = new SelectItemVO({ id: GLU_KIND.FINGER, text: '血糖 (指血)' });
const GLU_KIND_VEIN = new SelectItemVO({ id: GLU_KIND.VEIN, text: '血糖 (静脉血)' });
export const GLU_KIND_ITEMS = [
  GLU_KIND_FINGER,
  GLU_KIND_VEIN,
];
export const GLU_KIND_ITEM_MAP = SelectItemVO.getMap(GLU_KIND_ITEMS);


const GLU_KIND_FINGER_2 = new SelectItemVO({ id: GLU_KIND.FINGER, text: '指血' });
const GLU_KIND_VEIN_2 = new SelectItemVO({ id: GLU_KIND.VEIN, text: '静脉血' });
export const GLU_KIND_ITEMS_2 = [
  GLU_KIND_FINGER_2,
  GLU_KIND_VEIN_2,
];
export const GLU_KIND_ITEM_MAP_2 = SelectItemVO.getMap(GLU_KIND_ITEMS_2);
