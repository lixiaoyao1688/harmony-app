import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 最近血糖类型 配置
 */
export enum GLU_LAST_KIND {
  FINGER = 0,  // 血糖（指血或静脉血）
  CGM = 1,  // CGM
}

const GLU_LAST_KIND_ITEM_0 = new SelectItemVO({ id: GLU_LAST_KIND.FINGER, text: '血糖' });
const GLU_LAST_KIND_ITEM_1 = new SelectItemVO({ id: GLU_LAST_KIND.CGM, text: 'CGM' });

export const GLU_LAST_KIND_DEFAULT_ITEM = GLU_LAST_KIND_ITEM_0;
export const GLU_LAST_KINDS = [
  GLU_LAST_KIND_ITEM_0,
  GLU_LAST_KIND_ITEM_1,
];
export const GLU_LAST_KIND_MAP = SelectItemVO.getMap(GLU_LAST_KINDS);
