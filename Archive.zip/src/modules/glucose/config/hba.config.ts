/**
 * 糖化血红蛋白 配置
 *
 * 单位
 * %
 */
export const MAX_HBA_VALUE = 100;
export const MIN_HBA_VALUE = 0;
export const MAX_HBA_DIGIT = 1;  // 最多小数位数
export const HBA_STEP = 0.1;  // 步长
