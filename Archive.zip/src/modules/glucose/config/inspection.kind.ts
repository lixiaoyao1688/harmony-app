import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 检测类型 配置
 */
export enum INSPECTION_KIND {
  FINGER = 1,
  VENOUS,
  HBA
}

const INSPECTION_KIND_FINGER = new SelectItemVO({ id: INSPECTION_KIND.FINGER, text: '指血' });
const INSPECTION_KIND_VENOUS = new SelectItemVO({ id: INSPECTION_KIND.VENOUS, text: '静脉血' });
const INSPECTION_KIND_HBA = new SelectItemVO({ id: INSPECTION_KIND.HBA, text: '糖化血红蛋白' });


export const INSPECTION_PC_KINDS = [
  INSPECTION_KIND_FINGER,
  INSPECTION_KIND_VENOUS,
];
export const INSPECTION_KINDS = [
  INSPECTION_KIND_FINGER,
  INSPECTION_KIND_VENOUS,
  INSPECTION_KIND_HBA,
];
export const DEFAULT_INSPECTION_KIND = INSPECTION_KIND_FINGER;
export const INSPECTION_KIND_MAP = SelectItemVO.getMap(INSPECTION_KINDS);
