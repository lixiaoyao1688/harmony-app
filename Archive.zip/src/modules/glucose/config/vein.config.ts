/**
 * 静脉血 配置
 *
 * 单位
 * mmol/L
 */
export const MAX_VEIN_VALUE = 100;
export const MIN_VEIN_VALUE = 0;
export const MAX_VEIN_DIGIT = 1;  // 最多小数位数
export const VEIN_STEP = 0.1;  // 步长
