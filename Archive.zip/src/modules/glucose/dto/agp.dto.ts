import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';
import type { HbaDTO } from '@/modules/glucose/dto/hba.dto';


/**
 * 血糖分析 DTO
 */
export interface AgpDTO {
	value_info: AgpValueDTO;
	agp_info: [AgpLine, AgpLine, AgpLine, AgpLine, AgpLine];  //  AGP图谱: 5%,25%,50%,75%,95%
}

export interface AgpNewDTO {
	glucose_range: [number,number,number,number];  // 血糖分布占比: [很低，偏低，偏高，很高]
	// hba_dt: string;  // hba 检查时间
	// hba_value: number;  // hba 检测值
	glu_records: Array<AgpRecordDTO>;  // 血糖检测列表
	hba_records: Array<HbaDTO>;  // 糖化血紅蛋白的检测列表
}

export interface AgpGetDTO {
	admission_id: number;  //	患者id
	start_date: string;  //	开始日期  2024-11-1
	end_date: string;  //	结束日期  2024-12-1
}

/**
 * 血糖测量记录 DTO
 */
export interface AgpRecordDTO {
	kind: GLU_RECORD_KIND;  // 类型
	record_dt: string;  // 测量时刻, YYYY-MM-DD HH:mm:ss;
	value: number;  // 血糖值
}

/**
 * 指血测量记录 DTO
 */
export type FingerRecordDTO = AgpRecordDTO;


export type AgpLine = Array<number>;  // 1天的数据。每5分钟一个点，共288个。保留 1 位小数。
export type GluTirType = [number, number, number, number, number];  // 血糖分布占比，分别为 [很低, 偏低, 达标, 偏高, 很高]，标准为tir血糖达标率，区间[0,1]，已保留三位小数


export interface AgpValueDTO {
	count_finger:	number | undefined;  // 指血检测次数
	count_mg:	number | undefined;  // 每日平均检测次数 四舍五入
	cv:	number | undefined;  // 变异系数 已保留三位小数
	highest:	number | undefined;  // 最高血糖
	lage:	number | undefined;  // 最大血糖波动 已保留一位小数
	lowest:	number | undefined;  // 	最低血糖
	mg:	number | undefined;  // 血糖平均值 已保留一位小数
	tir_list:	GluTirType | undefined;
	hba: number | undefined;  // 糖化血红蛋白 单位%
}

export enum GLU_ANA_LEVEL {
	SUPER_LOW = 0,
	LOW,
	OK,
	HIGH,
	SUPER_HIGH
}
