export interface CgmInfoDTO {
	admission_id: number;
	create_time: string;
	date_index: number;
	deleted: number;
	device_id: number;
	id: number;
	measure_date: string;
	start_time: number;
	uid: number;
	update_time: string;
	value: number; // 血糖值
}

export interface CGMLine {
	data: Array<Array<number>>;
	date: string;
}
