import {GLU_KIND} from '@/modules/glucose/config/glu.kind';
import {YES_OR_NO} from '@/lib/yesOrNo/config/yesOrNo.config';
import {HISTORY_KIND} from '@/modules/record/config/history.config';


/**
 * 血糖记录 DTO
 */
export interface FingerDTO {
	end_time: number;
	kind: HISTORY_KIND;  // 血糖相关的 kind
	record_time: number;  // 采集时刻，单位秒
	seconds: number;  // 持续时间
	status: number;
	value: number;  // 指血值
	sub_kind?: GLU_KIND;  // 血糖类型
}

/**
 * 增 DTO
 *
 * 指血记录 添加
 */
export interface FingerAddDTO {
	admission_id: number;  // 病人id
	value: number;  // float
}

/**
 * 指血报告
 */
export interface TotalFingerDTO {
	count: number;  // 检测数
	mg:	number;  // 平均血糖
	mg_count:	number;  // 日均检测数
}

/**
 * 指血检测时段 DTO
 *
 * 索引: 时段
 * 0: 检测
 * 1: 不检测
 */
export type FingerTaskDTO = [
	YES_OR_NO,  // 0 凌晨
	YES_OR_NO,  // 1 早餐前
	YES_OR_NO,  // 2 早餐后
	YES_OR_NO,  // 3 午餐前
	YES_OR_NO,  // 4 午餐后
	YES_OR_NO,  // 5 晚餐前
	YES_OR_NO,  // 6 晚餐后
	YES_OR_NO,  // 7 睡前
];
