import type { GluTirType } from '@/modules/glucose/dto/agp.dto';


/**
 * 多日分时段血糖详情表 DTO
 */
export interface GluHourReportDTO {
	time_list: Array<GluHourTimeDTO>;  // 长度24，对应 24 个小时
	apg_info: GluHourApgDTO;  // AGP区间值
}

/**
 * 多日分时段血糖详情表 查 DTO
 */
export interface GluHourReportGetDTO {
	admission_id: number;
	start_time?: number;
	end_time?: number;
}

export interface GluHourTimeDTO {
	count:	number;  //	探头数量
	cv:	number; // 变异系数
	glucose_range: [number, number, number, number]; // [低1, 低2, 高1, 高2]
	mg:	number;  //	平均葡萄糖
	sd:	number;  //	葡萄糖标准差
	tir_list:	GluTirType;
}

// [ [5-95区间的值，长度24], [50的值，长度24], [25-75区间的值 长度24] ]
export type GluHourApgDTO = [Array<string>, Array<string>, Array<string>];


