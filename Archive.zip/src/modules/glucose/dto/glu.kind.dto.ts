/**
 * 糖尿病类型 DTO
 */
export interface GluKindInfoDTO {
  id: number;
  name: string;  // 英文
  text: string;  // 中文
}