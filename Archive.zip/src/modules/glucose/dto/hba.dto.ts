/**
 * 糖化血紅蛋白 DTO
 */
export interface HbaDTO {
	record_dt: string;  //	检测时间, 格式为 YYYY-MM-DD HH:mm:ss
	value: number;  //	检测值
}

export interface HbaAddDTO {
	admission_id: number;
	hba: number;  // 0.062 float 糖化血红蛋白
}
