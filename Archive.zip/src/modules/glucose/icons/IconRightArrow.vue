<script setup lang="ts">
/**
 * 右箭头 图标
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {}

const prop = defineProps<Prop>();
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="6" height="10" viewBox="0 0 6 10">
    <path d="M0,0,5,6l5-6Z" transform="translate(0 10) rotate(-90)" fill="#a2adb8"/>
  </svg>
</template>


