import dayjs from 'dayjs';
import {LOG_COLOR} from '@/lib/log/dto/log.dto';
import {printGroup} from '@/lib/log/util/log.util';
import {randomInEnum, randomInRange, randomInRangeFloat} from '@/lib/math/util/math.util';
import {MOCK_cgmRecords} from '@/modules/glucose/mock/cgm.mock';
import {MINUTES_PER_DAY, MINUTES_PER_HOUR} from '@/lib/time/config/time.config';
import {timeZeroing} from '@/lib/time/util/time.util';
import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';
import type {AgpGetDTO, AgpNewDTO, AgpRecordDTO} from '@/modules/glucose/dto/agp.dto';


export const NEW_AGP_MOCKING = false;

export function MOCK_glu(itemStartTime: number, dayCount: number, pointCount: number, isAGP?: boolean): Array<AgpRecordDTO> {
  const re = randomInEnum;
  const rf = randomInRangeFloat;
  const records: Array<AgpRecordDTO> = [];
  const interval = Math.floor(MINUTES_PER_DAY / pointCount);  // 数据点之间的间隔，分钟;
  const subtractCount = isAGP ? dayCount+1 : dayCount;
  let day = dayjs.unix(itemStartTime).hour(0).minute(0).second(0).millisecond(0).subtract(subtractCount, 'd');
  
  // 是否正在进行 CGM 截断测试（超过阈值的相邻点不能连接）
  const isCgmSplitTesting = false;
  
  if (isCgmSplitTesting) {
    const data: Array<AgpRecordDTO> = MOCK_cgmRecords(itemStartTime, pointCount).map(d => ({
      kind: GLU_RECORD_KIND.CGM,
      record_dt: dayjs.unix(d.start_time).format('YYYY-MM-DD HH:mm:ss'),
      value: d.value,
    }));
    records.push(...data);
  }
  else {
    for (let d = 0; d < dayCount; d++) {
      day = day.add(1, 'd');
      for (let p = 0; p < pointCount; p++) {
        const minutes = p * interval;
        const h = Math.floor(minutes / MINUTES_PER_HOUR);
        const m = Math.floor(minutes % MINUTES_PER_HOUR);
        const isFoodTime = (h === 8 || h === 12 || h === 18);  // 是否饭点
        const isFinger = p % 50 === 0;  // 是否指血
        // 指血: 3~12mmol/L 随机
        // CGM: 三餐波动，其余时间平稳;
        
        let v = rf(2,12,1);
        // let v = isFinger ? rf(2,14,1) : (isFoodTime ? rf(8,9,1) : rf(5,6.2,1));
        if (isAGP) {
          v = rf(2,14,1);
        }
        
        day = day.hour(h).minute(m).second(0).millisecond(0);
        
        records.push({
          // kind: GLU_RECORD_KIND.CGM,
          kind: isFinger ? GLU_RECORD_KIND.FINGER : re(GLU_RECORD_KIND.CGM, GLU_RECORD_KIND.VEIN),
          // kind: re(GLU_RECORD_KIND.FINGER, GLU_RECORD_KIND.VEIN),
          // kind: 'cgm',
          record_dt: day.format('YYYY-MM-DD HH:mm:ss'),
          value: v
        });
      }
    }
  }
  return records;
}

export function MOCK_NEW_AGP(body: AgpGetDTO): AgpNewDTO {
  const dayCount = 15;
  // const pointCount = 576;
  const pointCount = 288;  // 5分钟一个点，共288个点
  // const pointCount = 144;
  // const pointCount = 72;
  const records = MOCK_glu(dayjs().unix(), dayCount, pointCount, true);
  
  const r = randomInRange;
  const startTime = timeZeroing(dayjs(body.start_date)).unix();
  const endTime = timeZeroing(dayjs(body.end_date)).unix();
  
  const dto: AgpNewDTO = {
    glucose_range: [3,3.9,10,13.9] as [number,number,number,number],
    glu_records: records,
    hba_records: Array(8).fill(0).map((_,i) => ({
      id:	i+1,
      record_dt: dayjs.unix(r(startTime,endTime)).format('YYYY-MM-DD HH:mm:ss'),
      value: r(1,90)
    }))
  };
  
  printGroup('[MOCK_merge]', dto, LOG_COLOR.WARN_HARD);
  return dto;
}
