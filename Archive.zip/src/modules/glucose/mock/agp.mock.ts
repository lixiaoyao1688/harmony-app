import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { printGroup } from '@/lib/log/util/log.util';
import { GLU } from '@/modules/glucose/config/glu.config';
import { randomInRange, randomInRangeFloat, roundTo } from '@/lib/math/util/math.util';
import type { AgpDTO, AgpValueDTO, GluTirType } from '@/modules/glucose/dto/agp.dto';


export const AGP_MOCKING = false;

export function MOCK_agp(): AgpDTO {
  const val = (min: number, max: number) => randomInRangeFloat(min, max, 1);
  const dto = {
    value_info: getValueInfo(),
    agp_info: [
      Array(GLU.AGP_POINT_COUNT).fill(0).map(_ => val(1.5,2.6)),
      Array(GLU.AGP_POINT_COUNT).fill(0).map(_ => val(2.6,4.2)),
      Array(GLU.AGP_POINT_COUNT).fill(0).map(_ => val(4.2,10.2)),  // 中位线
      Array(GLU.AGP_POINT_COUNT).fill(0).map(_ => val(10.2,18.2)),
      Array(GLU.AGP_POINT_COUNT).fill(0).map(_ => val(18.2,22.2)),
    ]
  } as AgpDTO;
  
  printGroup('[MOCK_agp]', dto, LOG_COLOR.WARN_HARD);
  return dto;
}

function getValueInfo(): AgpValueDTO {
  return {
    count_finger:	randomInRange(20,200),
    count_mg:	randomInRangeFloat(1,10,3),
    cv:	randomInRangeFloat(1,10,3),
    highest:	randomInRangeFloat(1,10,3),
    lage:	randomInRangeFloat(1,10,3),
    lowest:	randomInRangeFloat(1,10,3),
    mg:	randomInRangeFloat(1,10,3),
    tir_list:	getRandomTirFive(),
    hba: randomInRangeFloat(1,20,1),
  };
}

export function getRandomTir(): [number, number, number] {
  const v1 = randomInRangeFloat(0,1,3);
  const v2 = randomInRangeFloat(0, 1-v1, 3);
  const v3 = roundTo(1 - v1 - v2, 3);
  return [v1, v2, v3];
}

export function getRandomTirFive(): GluTirType {
  const v1 = randomInRangeFloat(0,0.2,3);
  const v2 = randomInRangeFloat(0, 0.2-v1, 3);
  const v3 = roundTo(0.8 - v1 - v2, 3);
  const v4 = randomInRangeFloat(0, 0.2, 3);
  const v5 = roundTo(0.2 - v4, 3);
  return [v1, v2, v3, v4, v5];
}
