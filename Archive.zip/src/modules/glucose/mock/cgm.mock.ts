import dayjs from 'dayjs';
import {randomInRange, randomInRangeFloat} from '@/lib/math/util/math.util';
import {SECONDS_PER_HOUR, SECONDS_PER_MINUTE} from '@/lib/time/config/time.config';
import { gluVal } from '@/modules/glucose/mock/glu.mock';
import type { CgmInfoDTO } from '@/modules/glucose/dto/cgm.dto';
import type { CGMRecordDTO } from '@/modules/admission/dto/card.dto';


export function MOCK_cgmPoints(start: number): Array<CgmInfoDTO> {
  const sec = (h: number) => SECONDS_PER_HOUR * h;
  const count = randomInRange(16, 22);
  const data: Array<CgmInfoDTO> = [];
  
  for (let i = 0; i < count; i++) {
    const time = randomInRange(start+sec(i), start+sec(i+1));
    data.push(getDTO(time, gluVal()));
  }
  return data;
}

export function MOCK_cgmRecords(startTime: number, count: number): Array<CGMRecordDTO> {
  const rf = randomInRangeFloat;
  const MINUTES_PER_INDEX = 3;  // 默认 3 分钟一个点
  
  // 模拟三餐时刻
  const sec = startTime - dayjs.unix(startTime).hour(0).minute(0).second(0).millisecond(0).unix();
  const min = sec / SECONDS_PER_MINUTE;
  const indexes = min / MINUTES_PER_INDEX;

  const step = Math.floor(count / 6);  // 4h
  const step2 = Math.floor(count / 12);  // 2h
  
  const i0 = Math.floor((count / 3 + indexes) % count);  // 8点
  const i1 = Math.floor((i0 + step) % count);  // 12点
  const i2 = Math.floor((i1 + step + step2) % count);  // 18点

  // 默认 3 分钟一个点
  const DEFAULT_INTERVAL_SECONDS = Math.floor(SECONDS_PER_MINUTE * MINUTES_PER_INDEX);
  // 临界情况 5 分钟一个点 （此时线应该断开，临界情况）
  const EDGE_CASE_INTERVAL_SECONDS = Math.floor(SECONDS_PER_MINUTE * 600);
  // 半小时的索引数
  const INDEX_COUNT_HALF_HOUR = Math.floor(Math.floor(SECONDS_PER_HOUR / 2) * DEFAULT_INTERVAL_SECONDS);
  
  
  const isInMealRange = (i: number, mealIndex: number) => Math.abs(mealIndex - i) < 5;
  // 该索引是否餐时
  const isMealTime = (i: number) => isInMealRange(i,i0) || isInMealRange(i,i1) || isInMealRange(i,i2);
  // 该索引是否处于"最近20分钟+-5分钟"的范围中
  const isInRecent20MinRange = (i: number) => {
    const indexPerMin = count / 1440;
    const lastIndex = count - 1;
    const leftIndex = lastIndex - 25 * indexPerMin;
    const rightIndex = lastIndex - 15 * indexPerMin;
    return i >= leftIndex && i <= rightIndex;
  };
  // 该索引是否餐后半小时
  const isAfterMealTime = (i: number) => (i === i0 + INDEX_COUNT_HALF_HOUR) || (i === i1 + INDEX_COUNT_HALF_HOUR) || (i === i2 + INDEX_COUNT_HALF_HOUR);
  
  let start = startTime;
  let intervalSeconds: number;
  
  return Array(count).fill(0).map((_,i) => {
    
    // const value = rf(2.5,11,1);  // 随机血糖值
    // const value = isMealTime(i) ? rf(9,10,1) : rf(5.1, 6, 1);  // 三餐的起伏大一些，其他时间平稳
    const value = isMealTime(i) ? rf(9,10,1) : isInRecent20MinRange(i) ? rf(2,9.5,1) : rf(5.1, 6, 1);  //  三餐的起伏和最近20分钟范围起伏大一些，其他时间平稳
    intervalSeconds = DEFAULT_INTERVAL_SECONDS;  // 默认 3 分钟一个点
    
    const record: CGMRecordDTO = { start_time: start, value: value };
    start = start + intervalSeconds;
    
    return record;
  });
}

function getDTO(s: number, v: number): CgmInfoDTO {
  return {
    admission_id: -1,
    create_time: '',
    date_index: -1,
    deleted: 0,
    device_id: -1,
    id: 1,
    measure_date: '',
    start_time: s,
    uid: 1,
    update_time: '',
    value: v
  };
}
