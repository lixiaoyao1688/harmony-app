import { GLU } from '@/modules/glucose/config/glu.config';
import { SECONDS_PER_HOUR } from '@/lib/time/config/time.config';
import { CARD_STATUS } from '@/modules/record/config/card.config';
import { gluVal } from '@/modules/glucose/mock/glu.mock';
import { randomInRange, randomInRangeFloat } from '@/lib/math/util/math.util';
import type { FingerDTO, TotalFingerDTO } from '@/modules/glucose/dto/finger.dto';


export function MOCK_totalFinger(): TotalFingerDTO {
  return {
    count: randomInRange(30,60),
    mg: randomInRangeFloat(GLU.MIN, GLU.MAX, 1),
    mg_count: randomInRange(1,6),
  };
}

export function MOCK_fingerPoints(start: number): Array<FingerDTO> {
  const sec = (h: number) => SECONDS_PER_HOUR * h;
  const count = randomInRange(20, 24);
  const data: Array<FingerDTO> = [];
  
  for (let i = 0; i < count; i++) {
    const time = randomInRange(start+sec(i), start+sec(i+1));
    data.push(getDTO(time, gluVal()));
  }
  return data;
}

function getDTO(s: number, v: number): FingerDTO {
  return {
    end_time: s,
    kind: 0,
    record_time: s,
    seconds: 1,
    status: CARD_STATUS.GLU,
    value: v
  };
}
