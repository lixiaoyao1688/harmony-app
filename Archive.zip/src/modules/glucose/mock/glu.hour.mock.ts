import {randomInRange, randomInRangeFloat, roundTo} from '@/lib/math/util/math.util';
import type {GluHourReportDTO, GluHourTimeDTO} from '@/modules/glucose/dto/glu.hour.report.dto';


export const GLU_HOUR_MOCKING = false;

export function MOCK_glu_hour(): GluHourReportDTO {
  const r = randomInRange;
  const rf = randomInRangeFloat;
  const timeList: Array<GluHourTimeDTO> = Array(24).fill(0).map((v,i) => {
    const l1 = rf(0.05,0.12,3);
    const l2 = rf(0.05,0.12,3);
    const h1 = rf(0.05,0.12,3);
    const h2 = rf(0.05,0.12,3);
    const ok = roundTo(1 - l1 - l2 - h1 - h2, 3);
    
    return {
      count: r(100,200),
      cv:	rf(10,50,1),
      glucose_range: [
        rf(1,3,1),
        rf(3.1,4.2,1),
        rf(10,12,1),
        rf(12,15,1),
      ],
      mg:	rf(4,6,1),
      sd:	rf(1,4,1),
      tir_list:	[l1, l2, ok, h1, h2],
    };
  });
  
  return {
    time_list: timeList,
    apg_info: [
      Array(24).fill(0).map((_,i) => rf(3.9,10,1).toString()),
      Array(24).fill(0).map((_,i) => rf(3.9,10,1).toString()),
      Array(24).fill(0).map((_,i) => rf(3.9,10,1).toString()),
    ]
  };
  
}
