import { GLU } from '@/modules/glucose/config/glu.config';
import { MOCK_merge } from '@/modules/ins/mock/merge.mock';
import { randomInRangeFloat } from '@/lib/math/util/math.util';
import type { ChartDailyResponseDTO } from '@/modules/record/dto/chart.daily.dto';


export const GLU_MOCKING = false;

export function gluVal(isNormal?: boolean): number {
  if (isNormal) {
    return randomInRangeFloat(3.9, 9,1);
  }
  return randomInRangeFloat(GLU.MIN, GLU.MAX, 1);
}

export function MOCK_glu(): ChartDailyResponseDTO {
  return MOCK_merge();
}
