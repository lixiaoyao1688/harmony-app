<script setup lang="ts">
import { ref, watch } from 'vue';
import { EChartsType } from 'echarts';
import * as echarts from 'echarts';
import { REPORT } from '@/modules/report/configs/report.config';
import { useReportStore } from '@/modules/report/store/report.store';
import { useAgpStore } from '@/modules/glucose/store/agp.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { INVALID_ID } from '@/utils/global.vo.help';
import {printSingleError} from '@/lib/log/util/log.util';
import {httpAgpGet} from '@/modules/glucose/requests/glu.http';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import {ReportConfigVO} from '@/modules/report/vo/ReportConfig.vo';
import ReportView from '@/modules/report/views/ReportView.vue';
import ReportBottom from '@/modules/report/components/ReportBottom.vue';
import AgpReportStat from '@/modules/glucose/components/AgpReportStat.vue';
import ChartReportLegend from '@/modules/chart/component/ChartReportLegend.vue';
import {APG_LINE_25_75_COLOR, APG_LINE_5_95_COLOR, APG_LINE_CENTER_COLOR} from '@/modules/glucose/config/agp.config';
import type {AgpGetDTO} from '@/modules/glucose/dto/agp.dto';
import type { ChartType } from '@/modules/chart/types/chart.type';


/**
 * AGP血糖报告 界面
 */
const store = useAgpStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();

const url = ref<string>('');
const id = ref<string>('agp');
const vo = ref<AgpNewVO>(new AgpNewVO());

const height = 300;
let chart: ChartType = null;

watch(() => reportStore.config.range, (data) => {
  // if (admissionStore.admission.id === INVALID_ID) {
  //   notifyErrorNormal('未选中患者');
  //   return;
  // }
  // const body: ChartDailyGetDTO = {
  //   admission_id: admissionStore.admission.id,
  // };
  // if (newRange && newRange[0] && newRange[1]) {
  //   body.start_time = newRange[0].unix();
  //   body.end_time = newRange[1].unix() + SECONDS_PER_DAY;
  // }
  // store
  //   .fetch(admissionStore.admission as AdmissionVO, body)
  //   .then(() => {
  //     // 等待 loading 结束，画布展示出来，再渲染图形
  //     setTimeout(() => {
  //       if (!chart) {
  //         const el = document.getElementById(id.value);
  //         if (!el) {
  //           return;
  //         }
  //         chart = echarts.init(el);
  //       }
  //       renderChart(chart);
  //       url.value = chart.getDataURL({ type: 'png' });
  //     }, 500);
  //   })
  //   .catch(notifyErrorNormal);
  
  if (admissionStore.admission.id === INVALID_ID || !data || !data[0] || !data[1]) {
    return;
  }
  if (ReportConfigVO.isRangeOnlyOneDay(data)) {
    // 日期范围只有1天时(如: 2026-03-03 至 2026-03-03)，禁用此报告
    // http://192.168.1.236:81/redmine/issues/5646
    return;
  }
  const dto: AgpGetDTO = {
    admission_id: admissionStore.admission.id,
    start_date: data[0].format('YYYY-MM-DD'),
    end_date: data[1].format('YYYY-MM-DD')
  };
  reportStore.isLoading = true;
  httpAgpGet(dto, false)
    .then(data => {
      vo.value = data;
      // 等待 loading 结束，画布展示出来，再渲染图形
      setTimeout(() => {
        if (!chart) {
          const el = document.getElementById(id.value);
          if (!el) {
            return;
          }
          chart = echarts.init(el);
        }
        chart.setOption(vo.value.getReportConfig(admissionStore.admission.gluRange));
        url.value = chart.getDataURL({ type: 'png' });
      }, 500);
    })
    .catch(reason => printSingleError(reason))
    .finally(() => reportStore.isLoading = false);
  
}, { immediate: true });

function renderChart(chart: EChartsType): void {
  const c = { ...store.vo.config };
	
  const textColor = 'rgb(51,51,51)';
  const textColor2 = 'rgb(43,145,0)';
  const fontSize = 12;
  const fontWeight = 400;
  const lineColor = 'rgb(223,223,223)';
	
  const dataColor1 = 'rgb(198,217,255)';
  const dataColor2 = 'rgb(110,158,253)';
  const dataColor3 = 'rgb(0,49,146)';
	
  // @ts-ignore
  c.grid.bottom = 30;
  c.backgroundColor = 'transparent';
  // @ts-ignore
  c.xAxis.axisLabel.color = textColor;
  // @ts-ignore
  c.xAxis.axisLabel.fontWeight = fontWeight;
  // @ts-ignore
  c.xAxis.axisLine.show = false;
  // @ts-ignore
  c.yAxis.nameTextStyle.color = textColor;
  // @ts-ignore
  c.yAxis.nameTextStyle.fontWeight = fontWeight;
  // @ts-ignore
  c.yAxis.axisLabel.color = textColor;
  // @ts-ignore
  c.yAxis.axisLabel.fontWeight = fontWeight;
  // @ts-ignore
  c.yAxis.splitLine.lineStyle.color = lineColor;
  // @ts-ignore
  c.yAxis.splitLine.lineStyle.type = 'dashed';
	
	
  // @ts-ignore
  c.series[1].areaStyle.color = dataColor1;
  // @ts-ignore
  c.series[2].lineStyle.color = dataColor3;
  // @ts-ignore
  c.series[3].areaStyle.color = dataColor2;
  // @ts-ignore
  c.series[4].areaStyle.color = dataColor1;
	
	
  // @ts-ignore
  c.series[4].markArea.data[0][0].itemStyle.color = 'transparent';
	
  // @ts-ignore
  c.series[4].markArea.data[0][0].label.color = textColor2;
  // @ts-ignore
  c.series[4].markArea.data[0][0].label.fontSize = fontSize;
  // @ts-ignore
  c.series[4].markArea.data[0][0].label.fontWeight = fontWeight;
  // @ts-ignore
  c.series[4].markArea.data[0][0].label.position = ['100%', -15];
	
  // @ts-ignore
  c.series[4].markArea.data[1][0].label.color = textColor2;
  // @ts-ignore
  c.series[4].markArea.data[1][0].label.fontSize = fontSize;
  // @ts-ignore
  c.series[4].markArea.data[1][0].label.fontWeight = fontWeight;
  // @ts-ignore
  c.series[4].markArea.data[1][0].label.position = ['100%', 20];

	
  chart.setOption(c);
}
</script>

<template>
	<ReportView :id="REPORT.AGP" :loading="store.loading" :range-text="reportStore.config.rangeText">
    <AgpReportStat :vo="vo" />
		<div style="padding: 14px 12px; color: rgb(0,0,0); border-bottom: 1px solid rgb(153,153,153);">
			<div style="display: flex; justify-content: space-between; align-items: center; height: 24px;">
        <span style="font-size: 14px; font-weight: 700;">AGP图谱</span>
        <div style="display: flex; color: rgb(0,0,0);">
          <ChartReportLegend title="中位线" :color="APG_LINE_CENTER_COLOR" use-rect-theme margin="0 24px 0 0" />
          <ChartReportLegend title="5%-95%" :color="APG_LINE_5_95_COLOR" use-block-theme margin="0 24px 0 0" />
          <ChartReportLegend title="25%-75%" :color="APG_LINE_25_75_COLOR" use-block-theme />
        </div>
      </div>
			<img v-if="url" alt="agp" :src="url" style="width: 100%;" :style="{ height: height + 'px' }" />
			<div v-else :id="id" :style="{ height: height + 'px' }"></div>
		</div>
		<ReportBottom />
	</ReportView>
</template>
