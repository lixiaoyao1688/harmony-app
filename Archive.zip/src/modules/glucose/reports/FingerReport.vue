<script setup lang="ts">
import {ref, watch} from 'vue';
import { REPORT } from '@/modules/report/configs/report.config';
import { INVALID_ID } from '@/utils/global.vo.help';
import { useMergeReportStore } from '@/modules/ins/store/merge.report.store';
import { useReportStore } from '@/modules/report/store/report.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import {printSingleError} from '@/lib/log/util/log.util';
import {httpAgpGet} from '@/modules/glucose/requests/glu.http';
import {FingerReportVO} from '@/modules/glucose/vo/FingerReport.vo';
import ReportView from '@/modules/report/views/ReportView.vue';
import FingerReportStatistic from '@/modules/report/components/FingerReportStatistic.vue';
import type {AgpGetDTO} from '@/modules/glucose/dto/agp.dto';


/**
 * 指血数据表 界面
 */
const store = useMergeReportStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();
const vo = ref<FingerReportVO>(new FingerReportVO());

watch(() => reportStore.config.range, (data) => {
  // if (admissionStore.admission.id === INVALID_ID) {
  //   notifyErrorNormal('未选中患者');
  //   return;
  // }
  // const body: ChartDailyGetDTO = {
  //   admission_id: admissionStore.admission.id,
  // };
  // if (newRange && newRange[0] && newRange[1]) {
  //   body.start_time = newRange[0].unix();
  //   body.end_time = newRange[1].unix() + SECONDS_PER_DAY;
  // }
  // store.fetch(body).catch(notifyErrorNormal);
  
  if (admissionStore.admission.id === INVALID_ID || !data || !data[0] || !data[1]) {
    return;
  }
  const dto: AgpGetDTO = {
    admission_id: admissionStore.admission.id,
    start_date: data[0].format('YYYY-MM-DD'),
    end_date: data[1].format('YYYY-MM-DD')
  };
  reportStore.isLoading = true;
  httpAgpGet(dto, true)
    .then(data => {
      vo.value = data;
    })
    .catch(reason => printSingleError(reason))
    .finally(() => reportStore.isLoading = false);
  
}, { immediate: true });
</script>

<template>
	<ReportView :id="REPORT.FINGER" :loading="store.loading" :range-text="reportStore.config.rangeText">
		<div style="padding: 12px; color: rgb(0,0,0);">
			<div>
				<FingerReportStatistic  title="检测数" :value="vo.count" unit="次" />
				<FingerReportStatistic title="日均检测" :value="vo.mgCount" unit="次" />
			</div>
			<div>
				<FingerReportStatistic title="平均血糖" :value="vo.mg" unit="mmol/L" />
			</div>
		</div>
		<table style="width: 100%; border-collapse: collapse; color: rgb(34,34,34); font-weight: 400; text-align: center;">
			<thead style="background-color: rgb(29,110,249); height: 40px; line-height: 40px;">
				<tr style="color: rgb(255,255,255); line-height: 30px;">
					<th style="border: 1px solid rgb(255,255,255); padding: 0; width: 200px;">日期</th>
					<th style="border: 1px solid rgb(255,255,255); padding: 0;">检测数</th>
				</tr>
			</thead>
			<tbody>
				<tr style="line-height: 40px;" v-for="it in vo.rows" :key="it.id">
					<td style="border: 1px solid rgb(153,153,153); border-left: none;">{{ it.date }}</td>
					<td style="border: 1px solid rgb(153,153,153);">{{ it.count }}</td>
				</tr>
			</tbody>
		</table>
    <div v-if="vo.rows.length === 0" style="color: rgb(105,109,113); padding: 12px; font-size: 16px;">暂无数据</div>
	</ReportView>
</template>
