<script setup lang="ts">
import { ref, watch } from 'vue';
import { useGluStore } from '@/modules/glucose/store/glu.store';
import { useReportStore } from '@/modules/report/store/report.store';
import { REPORT } from '@/modules/report/configs/report.config';
import { INVALID_ID } from '@/utils/global.vo.help';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import {httpGluChartReportGet} from '@/modules/merge/request/merge.http';
import {printSingleError} from '@/lib/log/util/log.util';
import {ChartGluSingleVO} from '@/modules/glucose/vo/GluSingle.vo';
import ReportView from '@/modules/report/views/ReportView.vue';
import GluChartReportItem from '@/modules/glucose/reports/GluChartReportItem.vue';
import ChartReportLegend from '@/modules/chart/component/ChartReportLegend.vue';
import {GLU_REPORT_TARGET_BG_COLOR} from '@/modules/glucose/config/glu.config';
import {CGM_REPORT_LEGEND} from '@/modules/cgm/config/cgm.legend';
import {CGM_LINE_REPORT_COLOR} from '@/modules/cgm/config/cgm.color';
import {BLOOD_SYMBOL_IMAGE} from '@/modules/glucose/config/blood.config';
import type {MergeNewGetDTO} from '@/modules/merge/dto/merge.dto';


/**
 * 血糖趋势图 报告
 */
const store = useGluStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();

const isLoading = ref<boolean>(false);
const chartVOs = ref<Array<ChartGluSingleVO>>([]);

watch(() => reportStore.config.range, (data) => {
  if (admissionStore.admission.id === INVALID_ID || !data || !data[0] || !data[1]) {
    return;
  }
  const dto: MergeNewGetDTO = {
    admission_id: admissionStore.admission.id,
    start_date: data[0].format('YYYY-MM-DD'),
    end_date: data[1].format('YYYY-MM-DD')
  };
  isLoading.value = true;
  reportStore.isLoading = true;
  httpGluChartReportGet(dto)
    .then(data => {
      chartVOs.value = data;
    })
    .catch(reason => printSingleError(reason))
    .finally(() => {
      isLoading.value = false;
      reportStore.isLoading = false;
    });
}, { immediate: true });
</script>

<template>
	<ReportView :id="REPORT.GLU_CHART" :loading="isLoading" :range-text="reportStore.config.rangeText">
    <template #center>
      <div style="display: flex; color: rgb(0,0,0); padding: 12px 0 4px 0;">
        <ChartReportLegend title="目标范围区域" :color="GLU_REPORT_TARGET_BG_COLOR" use-block-theme margin="0 24px 0 0" />
        <ChartReportLegend title="CGM曲线" :base64="CGM_REPORT_LEGEND" base64-width="20px" use-block-theme margin="0 24px 0 0" />
        <ChartReportLegend title="指血或静脉血" :base64="BLOOD_SYMBOL_IMAGE" base64-width="12px" use-block-theme />
        <!--        <ChartReportLegend title="指血或静脉血" :color="CGM_LINE_REPORT_COLOR" use-circle-theme />-->
      </div>
    </template>
    <div style="padding: 16px 0 0;">
      <GluChartReportItem v-for="it in chartVOs" :key="it.id" :vo="it" />
    </div>
	</ReportView>
</template>
