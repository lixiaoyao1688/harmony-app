<script setup lang="ts">
import { onMounted, ref } from 'vue';
import * as echarts from 'echarts';
import { CARD_CHART } from '@/modules/record/config/card.config';
import { ChartGluSingleVO } from '@/modules/glucose/vo/GluSingle.vo';
import {GLU_HIGH_LINE_COLOR, GLU_REPORT_TARGET_BG_COLOR} from '@/modules/glucose/config/glu.config';
import {CGM_LINE_REPORT_COLOR} from '@/modules/cgm/config/cgm.color';
import {BLOOD_BG_COLOR_2, BLOOD_COLOR_ON_REPORT, BLOOD_DISTANCE_ON_REPORT, BLOOD_FONT_SIZE_ON_REPORT} from '@/modules/glucose/config/blood.config';
import type { ChartType } from '@/modules/chart/types/chart.type';


/**
 * 血糖每日趋势图
 *
 * 归属功能
 * 血糖趋势图 报告
 */
interface Prop {
	vo: ChartGluSingleVO;
}

const prop = defineProps<Prop>();
const url = ref<string>('');
let chart: ChartType = null;


onMounted(() => {
  initChart();
});

function initChart(): void {
  renderChart();
  getUrl();
}

function getUrl(): void {
  if (chart) {
    url.value = chart.getDataURL({ type: 'png' });
  }
}

function renderChart(): void {
  const id = CARD_CHART.GLU_DOM_ID_FOR_PRINT;
  const cg = prop.vo.configGlu;
  
  chart = echarts.init(document.getElementById(id + prop.vo.id));
 
  if (chart) {
    const c = { ...cg };
    const TEXT_COLOR = 'rgb(51,51,51)';
    const GLU_VALUE_COLOR = CGM_LINE_REPORT_COLOR;  // 散点和折线统一用此颜色
    
    // @ts-ignore
    c.xAxis.axisLabel.color = TEXT_COLOR;
    // @ts-ignore
    c.yAxis.axisLabel.color = TEXT_COLOR;
    // @ts-ignore
    c.yAxis.nameTextStyle.color = TEXT_COLOR;
    // @ts-ignore
    c.tooltip.show = false;
    // @ts-ignore
    c.series[0].markLine.label.color = TEXT_COLOR;
    // @ts-ignore
    c.series[0].markArea.data[0][0].label.color = TEXT_COLOR;
    // @ts-ignore
    c.series[0].markArea.data[0][0].itemStyle.color = 'rgb(229,236,249)';
    // @ts-ignore
    c.series[0].markArea.data[1][0].label.color = TEXT_COLOR;
    // @ts-ignore
    c.series[0].markLine.lineStyle.color = 'rgb(163,175,188)';
		
    c.grid = {
      top: 40,
      right: 30,
      bottom: 100,
      left: 40,
    };
    c.title = {
      bottom: 24,
      left: 'center',
      text: prop.vo.dateText,
      borderRadius: 4,
      padding: [6, 24],
      backgroundColor: 'rgb(105, 158, 245)',
      textStyle: {
        height: 16,
        fontSize: 14,
        lineHeight: 18,
        color: 'rgb(255,255,255)',
      }
    };
    
    // @ts-ignore
    const seriesScatter = c.series.find(s => s.type === 'scatter');
    if (seriesScatter) {
      const markArea = seriesScatter.markArea;
      // 血糖目标范围 主区域 (low~high)
      const targetRangeMain = markArea.data[0][0];
      targetRangeMain.label.color = TEXT_COLOR;
      targetRangeMain.itemStyle.color = GLU_REPORT_TARGET_BG_COLOR;  // 血糖目标范围 主区域背景颜色
      // 血糖目标范围 底部区域 (0~low)
      const targetRangeLow = markArea.data[1][0];
      targetRangeLow.label.color = TEXT_COLOR;
      // 高位辅助线 (16.7 mmol/L)
      seriesScatter.markLine.lineStyle.color = GLU_HIGH_LINE_COLOR;
      // 报告中由于图例是单一颜色，所以散点血糖的颜色在目标血糖范围外时不变更。
      if (seriesScatter && seriesScatter.data && seriesScatter.data.length > 0) {
        seriesScatter.data.forEach(d => {
          if (d.itemStyle) {
            d.itemStyle.color = GLU_VALUE_COLOR;
          }
        });
      }
      // 修改散点数值样式
      if (seriesScatter.label) {
        const label = seriesScatter.label;
        label.fontSize = BLOOD_FONT_SIZE_ON_REPORT;
        label.backgroundColor = BLOOD_BG_COLOR_2;
        label.color = BLOOD_COLOR_ON_REPORT;
        label.distance = BLOOD_DISTANCE_ON_REPORT;
      }
    }
    // 报告中由于图例是单一颜色，所以CGM颜色在目标血糖范围外时不变更。
    // 视觉映射组件
    // @ts-ignore
    const pieces = c.visualMap.pieces;
    pieces[0].color = GLU_VALUE_COLOR;
    pieces[1].color = GLU_VALUE_COLOR;
    pieces[2].color = GLU_VALUE_COLOR;
		
    chart.setOption(c);
  }
}
</script>

<template>
	<div style="display: flex; justify-content: center; height: 320px;">
		<img v-if="url" style="display: block; width: 700px;" :alt="vo.id" :src="url" />
		<div v-else style="width: 700px;" :id="CARD_CHART.GLU_DOM_ID_FOR_PRINT + vo.id"></div>
	</div>
</template>
