<script setup lang="ts">
import { watch } from 'vue';
import { REPORT } from '@/modules/report/configs/report.config';
import { SECONDS_PER_DAY } from '@/lib/time/config/time.config';
import { INVALID_ID } from '@/utils/global.vo.help';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { useGluStore } from '@/modules/glucose/store/glu.store';
import { useReportStore } from '@/modules/report/store/report.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import { ReportConfigVO } from '@/modules/report/vo/ReportConfig.vo';
import ReportView from '@/modules/report/views/ReportView.vue';
import GluHourTable from '@/modules/glucose/components/GluHourTable.vue';
import type { ChartDailyGetDTO } from '@/modules/record/dto/chart.daily.dto';


/**
 * 多日分时段血糖详情表 报告
 */
const store = useGluStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();

watch(() => reportStore.config.range, (newRange) => {
  if (admissionStore.admission.id === INVALID_ID) {
    notifyErrorNormal('未选中患者');
    return;
  }
  if (!newRange || !newRange[0] || !newRange[1] || ReportConfigVO.isRangeOnlyOneDay(newRange)) {
    // 日期范围只有1天时(如: 2026-03-03 至 2026-03-03)，禁用此报告
    // http://192.168.1.236:81/redmine/issues/5646
    return;
  }
  const body: ChartDailyGetDTO = {
    admission_id: admissionStore.admission.id,
    start_time: newRange[0].unix(),
    end_time: newRange[1].unix() + SECONDS_PER_DAY
  };
  store.fetchHour(admissionStore.admission as AdmissionVO, body).catch(notifyErrorNormal);
}, { immediate: true });
</script>

<template>
	<ReportView :id="REPORT.GLU_HOUR" :loading="store.loading" :range-text="reportStore.config.rangeText">
		<GluHourTable :start-index="0" />
		<GluHourTable :start-index="8" />
		<GluHourTable :start-index="16" />
	</ReportView>
</template>
