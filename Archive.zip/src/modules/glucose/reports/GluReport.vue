<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import * as echarts from 'echarts';
import { fillZero } from '@/lib/time/util/time.util';
import { roundToString } from '@/lib/math/util/math.util';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { useGluStore } from '@/modules/glucose/store/glu.store';
import { useReportStore } from '@/modules/report/store/report.store';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { REPORT } from '@/modules/report/configs/report.config';
import { WatchStopHandle } from '@vue/runtime-core';
import { INVALID_ID } from '@/utils/global.vo.help';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { SECONDS_PER_DAY } from '@/lib/time/config/time.config';
import { ChartGluSingleVO } from '@/modules/glucose/vo/GluSingle.vo';
import GluRow from '@/modules/report/components/GluRow.vue';
import ReportView from '@/modules/report/views/ReportView.vue';
import type { EChartsType } from 'echarts';
import type { ChartType } from '@/modules/chart/types/chart.type';
import type { ChartDailyGetDTO } from '@/modules/record/dto/chart.daily.dto';


const width = 698;
const height = 350;
const url = ref<string>('');
const id = ref<string>('glu');

const gluStore = useGluStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();

const charts = computed<Array<ChartGluSingleVO>>(() => gluStore.vo.charts.slice().reverse() as Array<ChartGluSingleVO>);
const report = computed<SelectorFormItemVO>(() => reportStore.config.items.find(it => it.id === REPORT.GLU) as SelectorFormItemVO);

let unwatch: WatchStopHandle = () => {};
let chart: ChartType = null;


onMounted(() => {
  unwatch = watch(() => reportStore.config.range, (newRange) => {
    if (admissionStore.admission.id === INVALID_ID) {
      notifyErrorNormal('未选中患者');
      return;
    }
    const body: ChartDailyGetDTO = {
      admission_id: admissionStore.admission.id,
    };
    if (newRange && newRange[0] && newRange[1]) {
      body.start_time = newRange[0].unix();
      body.end_time = newRange[1].unix() + SECONDS_PER_DAY;
    }
    gluStore
      .fetch(body)
      .then(() => {
        // 等待 loading 结束，画布展示出来，再渲染图形
        setTimeout(() => {
          if (!chart) {
            const el = document.getElementById(id.value);
            if (!el) {
              return;
            }
            chart = echarts.init(el);
          }
          renderChart(chart);
          url.value = chart.getDataURL({ type: 'png' });
        }, 500);
      })
      .catch(notifyErrorNormal);
  }, { immediate: true });
});

onUnmounted(() => {
  if (unwatch) {
    unwatch();
  }
});

function renderChart(chart: EChartsType): void {
  const textColor = 'rgb(51,51,51)';
  const textColor2 = 'rgb(43,145,0)';
  const fontSize = 12;
  const fontWeight = 400;
  const lineColor = 'rgb(223,223,223)';
  const colorLine = 'rgb(91,103,116)';
	
  const MIN_ARRAY_PER_DAY = Array(1441).fill(0).map((_,i) => i);
	
  const MIN_Y = 0;
  const MAX_Y = 23;
  const MIN_Y_V = admissionStore.admission.gluLow;
  const MAX_Y_V = admissionStore.admission.gluHigh;
	
  const markArea = {
    silent: true,
    data: [
      [
        {
          name: roundToString(MAX_Y_V, 1),
          yAxis: MAX_Y_V,
          label: {
            color: textColor2,
            fontSize: fontSize,
            position: ['100%', -15],
            fontWeight: fontWeight,
          },
          itemStyle: {
            color: 'rgba(184,211,255,0.16)'
          }
        },
        {
          yAxis: MIN_Y_V
        },
      ],
      [
        {
          name: roundToString(MIN_Y_V, 1),
          yAxis: MIN_Y_V,
          label: {
            color: textColor2,
            fontSize: fontSize,
            position: ['100%', 5],
            fontWeight: fontWeight,
          },
          itemStyle: {
            color: 'transparent'
          }
        },
        {
          yAxis: MIN_Y,
        },
      ]
    ]
  };
	
  function getSeries(data: number[][], name: string, showArea?: boolean) {
    return {
      type: 'line',
      name: name,
      smooth: true,
      markArea: showArea ? markArea : null,
      itemStyle: {
        opacity: 0,
      },
      data: data
    };
  }
  const series = charts.value.map((c,i) => getSeries(c.cgmLine.data, c.cgmLine.date, i === 0));
  const option = {
    grid: {
      left: 35,
      top: 40,
      right: 40,
      bottom: 100,
    },
    legend: {
      show: true,
      bottom: 10,
      data: charts.value.map(c => c.cgmLine.date),
    },
    color: [
      'rgb(0,181,173)',
      'rgb(219,98,146)',
      'rgb(188,163,35)',
      'rgb(181,204,24)',
      'rgb(242,113,28)',
      'rgb(194,115,206)',
      'rgb(225,31,64)',
      'rgb(236,182,134)',
      'rgb(116,210,181)',
      'rgb(25,151,11)',
      'rgb(153,120,245 )',
      'rgb(188,163,35)',
      'rgb(75,174,249)',
    ],
    animation: false,
    backgroundColor: 'transparent',
    xAxis: {
      type: 'category',
      axisLabel: {
        show: true,
        color: textColor,
        interval: 239,
        fontSize: fontSize,
        fontWeight: fontWeight,
        formatter: (min: number) => {
          const data = Math.floor(min / 60);
          return data === 24 ? '00:00' : `${fillZero(data)}:00`;
        },
      },
      axisTick: {
        show: false,
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: colorLine
        }
      },
      data: MIN_ARRAY_PER_DAY
    },
    yAxis: {
      name: 'mmol/L',
      nameLocation: 'end',
      nameTextStyle: {
        color: textColor,
        fontSize: fontSize,
        fontWeight: fontWeight,
      },
      type: 'value',
      min: MIN_Y,
      max: MAX_Y,
      interval: 4,
      axisTick: {
        show: false,
      },
      axisLine: {
        show: false,
      },
      axisLabel: {
        show: true,
        color: textColor,
        fontSize: fontSize,
        fontWeight: fontWeight,
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: lineColor,
          type: 'dashed',
        }
      }
    },
    series: series,
  };
	
  chart.setOption(option, true);
}
</script>

<template>
	<!-- todo: 改成按列分配对象的做法	-->
	<ReportView :id="REPORT.GLU" :loading="gluStore.loading" :range-text="reportStore.config.rangeText">
		<img v-if="url" alt="agp" :src="url" :style="{ width: width + 'px', height: height + 'px' }" />
		<div v-else :id="id" :style="{ height: height + 'px' }"></div>
		<table style="width: 100%; border-collapse: collapse;">
			<thead style="background-color: rgb(29,110,249); height: 40px; line-height: 40px;">
				<tr style="color: rgb(255,255,255); height: 30px; line-height: 30px;">
					<th style="border: 1px solid rgb(255,255,255)">日期</th>
					<th style="border: 1px solid rgb(255,255,255)" v-for="it in charts" :key="it.id">{{ it.simpleDateText }}</th>
				</tr>
			</thead>
			<tbody style="color: rgb(34,34,34);">
				<GluRow title="MG" desc="平均葡萄糖" unit="mmol/L" bg-color="rgb(255,255,255)" :charts="charts" field="mg" />
				<GluRow title="TIR" desc="目标范围内时间" bg-color="rgb(233,240,255)" :charts="charts" field="tir" />
				<GluRow title="TAR" desc="高于目标范围时间" bg-color="rgb(255,255,255)" :charts="charts" field="tar" />
				<GluRow title="TBR" desc="低于目标范围时间" bg-color="rgb(233,240,255)" :charts="charts" field="tbr" />
			</tbody>
		</table>
		<div style="color: rgb(34,34,34); height: 40px; line-height: 40px; padding-left: 27px; font-weight: 700; background-color: rgb(152,213,245);">血糖波动</div>
		<table style="width: 100%; border-collapse: collapse; margin-bottom: 8px;">
			<tbody style="color: rgb(34,34,34);">
				<GluRow title="LAGE" unit="mmol/L" bg-color="rgb(255,255,255)" :charts="charts" field="lage" />
				<GluRow title="MAGE" unit="mmol/L" desc="最大血糖波动幅度" bg-color="rgb(233,240,255)" :charts="charts" field="mage" />
				<GluRow title="MODD" unit="mmol/L" desc="平均血糖波动幅度" bg-color="rgb(255,255,255)" :charts="charts" field="modd" />
				<GluRow title="SD" unit="mmol/L" desc="日间血糖平均绝对差" bg-color="rgb(233,240,255)" :charts="charts" field="sd" />
				<GluRow title="CV" desc="变异系数" bg-color="rgb(255,255,255)" :charts="charts" field="cv" />
			</tbody>
		</table>
	</ReportView>
</template>
