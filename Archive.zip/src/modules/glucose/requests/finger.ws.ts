import { useWsStore } from '@/lib/ws/store/ws.store';
import { WS_EVENT } from '@/lib/ws/dto/ws.event.dto';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import type { FingerAddDTO } from '@/modules/glucose/dto/finger.dto';


// [设置] 指血记录 添加
export function wsSetFingerBloodAdd(dto: FingerAddDTO): void {
  const wsStore = useWsStore();
  const screenStore = useScreenStore();
  wsStore.send(WS_EVENT.SUBSCRIBE_AND_REPORT_ADMISSION_FINGER, dto, screenStore.isMobile);
}
