import {
  getHttpCatcherType,
  httpNoResponseCatcher,
  httpResponseCatcher,
  isHttpResponseError, throwFieldLackError
} from '@/lib/http/util/http.utils';
import { instance } from '@/lib/http/request/http';
import { printError } from '@/lib/log/util/log.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import { GluHourReportDTO, GluHourReportGetDTO } from '@/modules/glucose/dto/glu.hour.report.dto';
import { GluHourVO } from '@/modules/glucose/vo/GluHour.vo';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import {MOCK_NEW_AGP, NEW_AGP_MOCKING} from '@/modules/glucose/mock/agp.mock.new';
import {FingerReportVO} from '@/modules/glucose/vo/FingerReport.vo';
import {GLU_HOUR_MOCKING, MOCK_glu_hour} from '@/modules/glucose/mock/glu.hour.mock';
import {AppHttpClient} from '@/lib/http/client/AppHttpClient';
import {isWebHttpUsing} from '@/lib/env/utils/env.domain.util';
import type { HttpResponseDTO } from '@/lib/http/dto/http.dto';
import type { HTTPResponseType } from '@/lib/http/types/http.type';
import type { AgpGetDTO, AgpNewDTO } from '@/modules/glucose/dto/agp.dto';


export const AGP_PATH = {
  // GET_ANA_OLD: '/hospital/record/glucose',
  GET_ANA: '/hospital/record/glu/get',
  REPORT_HOUR: '/hospital/record/glucose/times',
};

enum LOG {
  // GET_ANA_OLD = '血糖分析',
  GET_ANA = '血糖分析（new）',
  REPORT_HOUR = '打印 多日分时段血糖',
}


export function gluCatcher(type: 'getAna' | 'report-hour'): (reason: string) => void {
  let title = '';
  const store = useScreenStore();
	
  if (type === 'getAna') {
    title = getHttpCatcherType(LOG.GET_ANA, AGP_PATH.GET_ANA);
  }
  else if (type === 'report-hour') {
    title = getHttpCatcherType(LOG.REPORT_HOUR, AGP_PATH.REPORT_HOUR);
  }
  return (reason: string) => printError(title, reason, store.isMobile);
}


type ReturnTypeOfHttpAgpGet<T extends boolean> = T extends true ? FingerReportVO : AgpNewVO;
export function httpAgpGet<T extends boolean>(body: AgpGetDTO, isReport: T): Promise<ReturnTypeOfHttpAgpGet<T>> {
  return new Promise((resolve, reject) => {
    
    const log = LOG.GET_ANA;
    const path = AGP_PATH.GET_ANA;
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      if (NEW_AGP_MOCKING) {
        data.data.data = MOCK_NEW_AGP(body);
      }
      
      if (isReport) {
        if (!data.data.data.glu_records) {
          throwFieldLackError('glu_records', AGP_PATH.GET_ANA);
        }
        resolve(new FingerReportVO(data.data.data.glu_records, body.start_date, body.end_date) as ReturnTypeOfHttpAgpGet<T>);
      }
      else {
        resolve(new AgpNewVO(data.data.data) as ReturnTypeOfHttpAgpGet<T>);
      }
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<AgpNewDTO>>(path, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .post<AgpGetDTO>(path, body, log, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    
  });
}

// 返回24个GluHourItemVO，对应 24小时。
export function httpGluReportHour(body: GluHourReportGetDTO, admission: AdmissionVO): Promise<Array<GluHourVO>> {
  return new Promise<Array<GluHourVO>>((resolve, reject) => {
    instance
      .post<HttpResponseDTO<GluHourReportDTO>>(AGP_PATH.REPORT_HOUR, body, undefined)
      .then(data => {
        if (isHttpResponseError(data)) {
          return httpResponseCatcher(data, reject);
        }
        if (GLU_HOUR_MOCKING) {
          data.data.data = MOCK_glu_hour();
        }
        const value: Array<GluHourVO> = [];
        for (let i = 0; i < 24; i++) {
          value.push(new GluHourVO(i, data.data.data, admission));
        }
        resolve(value);
      })
      .catch(err => httpNoResponseCatcher(err, LOG.REPORT_HOUR, reject));
  });
}
