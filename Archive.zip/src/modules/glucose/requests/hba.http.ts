import { httpAdd } from '@/lib/http/request/http';
import { printError } from '@/lib/log/util/log.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getHttpCatcherType } from '@/lib/http/util/http.utils';
import type { HbaAddDTO } from '@/modules/glucose/dto/hba.dto';


const PATH = {
  ADD: '/hospital/admission/record/add',
};

enum LOG {
	ADD = '指血记录 添加',
}


export function hbaCatcher(type: 'add'): (reason: string) => void {
  let title = '';
  const store = useScreenStore();
	
  if (type === 'add') {
    title = getHttpCatcherType(LOG.ADD, PATH.ADD);
  }
  return (reason: string) => printError(title, reason, store.isMobile);
}

export function httpHbaAdd(body: HbaAddDTO) {
  return httpAdd<HbaAddDTO>(PATH.ADD, body, LOG.ADD);
}
