import { defineStore } from 'pinia';
import { AgpVO } from '@/modules/glucose/vo/Agp.vo';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import {gluCatcher, httpAgpGet} from '@/modules/glucose/requests/glu.http';
import {AgpFilterVO} from '@/modules/glucose/vo/AgpFilter.vo';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import type { ChartDailyGetDTO } from '@/modules/record/dto/chart.daily.dto';


interface State {
	filter: AgpFilterVO;
	loading: boolean;
	vo: AgpVO;
	hbaUpdateWaiting: boolean;  // 是否等待刷新糖化血红蛋白值
  newVO: AgpNewVO;
}

interface Action {
	fetch: () => Promise<AgpNewVO>;
	clear: () => void;
}

type Getter = {}


export const useAgpStore = defineStore<string, State, Getter, Action>('agp-store', {
	
  state: () => ({
	  filter: new AgpFilterVO(),
	  loading: false,
    vo: new AgpVO(new AdmissionVO(undefined, false)),
	  hbaUpdateWaiting: false,
    newVO: new AgpNewVO(),
  }),
	
  actions: {
    fetch() {
      return new Promise<AgpNewVO>((resolve, reject) => {
        this.loading = true;
	      httpAgpGet(this.filter.dto, false)
          .then(vo => {
            this.newVO = vo;
            resolve(vo);
          })
          .catch(gluCatcher('getAna'))
          .finally(() => this.loading = false);
      });
    },
	  clear() {
      this.$reset();
	  }
  }
	
});
