import { defineStore } from 'pinia';
import { DailyFilterVO } from '@/modules/ins/vo/DailyFilter.vo';
import { GluDayVO } from '@/modules/glucose/vo/GluDay.vo';
import { httpGluDayGet } from '@/modules/record/requests/record.http';
import { GluHourVO } from '@/modules/glucose/vo/GluHour.vo';
import { gluCatcher, httpGluReportHour } from '@/modules/glucose/requests/glu.http';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import type { ChartDailyGetDTO } from '@/modules/record/dto/chart.daily.dto';


interface State {
	filter: DailyFilterVO;
	loading: boolean;
	vo: GluDayVO;
	hourVos: Array<GluHourVO>;
}

interface Action {
	fetch: (body?: ChartDailyGetDTO) => Promise<void>;
	fetchHour: (admission: AdmissionVO, body?: ChartDailyGetDTO) => Promise<void>;
	clear: () => void;
}

type Getter = {}

const EMPTY_HOUR_VOS = Array(24).fill(0).map((_,i) => new GluHourVO(i, undefined, new AdmissionVO(undefined, true, i+1)));

export const useGluStore = defineStore<string, State, Getter, Action>('glu-store', {
	
  state: () => ({
    filter: new DailyFilterVO(),
    loading: false,
	  vo: new GluDayVO(),
	  hourVos: EMPTY_HOUR_VOS,
  }),
	
  actions: {
    fetch(body) {
      return new Promise<void>((resolve, reject) => {
        this.loading = true;
        this.vo = new GluDayVO();
        httpGluDayGet(body || this.filter.dto)
          .then(vo => {
            this.vo = vo;
            resolve();
          })
          .catch(reason => reject(reason))
          .finally(() => this.loading = false);
      });
    },
	  fetchHour(admission, body) {
		  return new Promise<void>((resolve, reject) => {
			  this.loading = true;
			  this.hourVos = EMPTY_HOUR_VOS;
			  httpGluReportHour(body || this.filter.dto, admission)
				  .then(data => {
					  this.hourVos = data;
					  resolve();
				  })
				  .catch(gluCatcher('report-hour'))
				  .finally(() => this.loading = false);
		  });
	  },
	  clear() {
      this.$reset();
	  }
  }
	
});
