import {GLU_KIND} from '@/modules/glucose/config/glu.kind';

type ChartXValue = number;  // indexOfMinute，当前时间点（分钟）在一天（1440分钟）中的索引
type ChartYValue = number;  // 血糖值
type ChartYDataValueType = [ChartXValue, ChartYValue];


export type ChartYDataType = {
	value: ChartYDataValueType,
	visualMap: boolean,
	itemStyle?: {
		color: string;
	},
	payload?: {
		recordTime: number;   // 记录发生的时刻，时间戳，单位毫秒
		kind?: GLU_KIND;  // 血糖类型，仅 finger 时需要（区分指血/静脉血）
		isFromCheckin?: boolean;  // 是否转化自打卡记录，见: src\modules\device\vo\Cgm.vo.ts: config5
	};
	label?: {
		// 血糖散点图标
		position?: string;  // 图标的位置 https://echarts.apache.org/zh/option.html#series-scatter.data.label.position
	}
}

export type ChartTooltipFormatParamType = {
	data: ChartYDataType;
}
