import {GLOBAL_YES_OR_NO} from '@/dto/global.dto';


export type FingerTaskType = [
  GLOBAL_YES_OR_NO,  // 0 凌晨
  GLOBAL_YES_OR_NO,  // 1 早餐前
  GLOBAL_YES_OR_NO,  // 2 早餐后
  GLOBAL_YES_OR_NO,  // 3 午餐前
  GLOBAL_YES_OR_NO,  // 4 午餐后
  GLOBAL_YES_OR_NO,  // 5 晚餐前
  GLOBAL_YES_OR_NO,  // 6 晚餐后
  GLOBAL_YES_OR_NO,  // 7 睡前
  GLOBAL_YES_OR_NO,  // 8 随机
];  // 表示指血检测的九个时段是否检测;
