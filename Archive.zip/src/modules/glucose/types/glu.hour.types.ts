export interface GluHourAgpType {
	fiveToNinetyFive: string;  // 5%-95%
	fifty: string;  // 50%
	twentyFiveToSeventyFive: string;  // 25%-75%
}

export interface GluHourRowType {
	title: string;
	unit?: string;
	desc?: string;
}
