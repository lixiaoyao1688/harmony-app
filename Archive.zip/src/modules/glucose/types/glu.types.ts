import {GLU_DIABETE_KIND} from '@/modules/glucose/config/glu.config';
import {GLU_KIND} from '@/modules/glucose/config/glu.kind';


export type GluRangeType = [number, number, number, number];  // 血糖阈值点: [极低, 偏低, 偏高, 极高];

export interface GluKind {
  kind_id: GLU_DIABETE_KIND;
  glucose_range: GluRangeType;
}

export type GluKindRange = Array<GluKind>;

export type GluLevelItemPayload = {
  color: string;
}

export interface GluPayload {
  kindText: string;  // 类型文本，如 '血糖(指血)、血糖(静脉血)'
  text: string;  // 值文本，如 6.8 mmol/L
  kind: GLU_KIND;  // 血糖类型
}

