import { GLU } from '@/modules/glucose/config/glu.config';
import {AgpDTO, type AgpRecordDTO, GLU_ANA_LEVEL} from '@/modules/glucose/dto/agp.dto';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {StackedBarItemVO} from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';
import type {GluRangeType} from '@/modules/glucose/types/glu.types';
import {roundTo} from '@/lib/math/util/math.util';


export function getEmptyAgpDTO(): AgpDTO {
  return {
    value_info: {
      count_finger:	undefined,
      count_mg:	undefined,
      cv:	undefined,
      highest:	undefined,
      lage:	undefined,
      lowest:	undefined,
      mg: undefined,
      tir_list: undefined,
      hba: undefined,
    },
    agp_info: [[],[],[],[],[]]
  };
}

export function getGluLevelOK(): SelectorFormItemVO {
  return getGluLevel(GLU_ANA_LEVEL.OK);
}

export function getGluLevel(id: GLU_ANA_LEVEL): SelectorFormItemVO {
  return GLU.LEVEL.ITEMS.find(it => it.id === id) as SelectorFormItemVO;
}

export function getGluLevelIndex(id: GLU_ANA_LEVEL): number {
  const vo = getGluLevel(id);
  return vo ? vo.id : 0;
}

export function getGluLevelReverse(): Array<SelectorFormItemVO> {
  return GLU.LEVEL.ITEMS.slice().reverse();
}

export function getStackedBarItemsFromRangeAndRecord(range: GluRangeType, records: Array<AgpRecordDTO>): Array<StackedBarItemVO> {
  const l2Item = GLU.LEVEL_SUPER_LOW_ITEM;
  const l1Item = GLU.LEVEL_LOW_ITEM;
  const h1Item = GLU.LEVEL_HIGH_ITEM;
  const h2Item = GLU.LEVEL_SUPER_HIGH_ITEM;
  const okItem = GLU.LEVEL_OK_ITEM;
  const digit = GLU.LEVEL_PERCENT_DIGIT;
  
  if (records.length === 0) {
    return [
      new StackedBarItemVO(l2Item.id, l2Item.text, 0, l2Item.payload.color, digit),
      new StackedBarItemVO(l1Item.id, l1Item.text, 0, l1Item.payload.color, digit),
      new StackedBarItemVO(h1Item.id, h1Item.text, 0, h1Item.payload.color, digit),
      new StackedBarItemVO(h2Item.id, h2Item.text, 0, h2Item.payload.color, digit),
      new StackedBarItemVO(okItem.id, okItem.text, 0, okItem.payload.color, digit),
    ];
  }
  
  const data = records;
  const total = data.length;
  const [l2,l1,h1,h2] = range;
  const valueDigit = Math.floor(digit + 2);
  
  const l2c = data.filter(d => d.value < l2).length;
  const l1c = data.filter(d => d.value >= l2 && d.value < l1).length;
  const h1c = data.filter(d => d.value > h1 && d.value <= h2).length;
  const h2c = data.filter(d => d.value > h2).length;
  const okc = Math.floor(total - l2c - l1c - h1c - h2c);
  
  const l2p = roundTo(l2c / total, valueDigit);
  const l1p = roundTo(l1c / total, valueDigit);
  const h1p = roundTo(h1c / total, valueDigit);
  const h2p = roundTo(h2c / total, valueDigit);
  const okp = roundTo(okc / total, valueDigit);
  
  return [
    new StackedBarItemVO(l2Item.id, l2Item.text, l2p, l2Item.payload.color, digit),
    new StackedBarItemVO(l1Item.id, l1Item.text, l1p, l1Item.payload.color, digit),
    new StackedBarItemVO(h1Item.id, h1Item.text, h1p, h1Item.payload.color, digit),
    new StackedBarItemVO(h2Item.id, h2Item.text, h2p, h2Item.payload.color, digit),
    new StackedBarItemVO(okItem.id, okItem.text, okp, okItem.payload.color, digit),
  ];
}
