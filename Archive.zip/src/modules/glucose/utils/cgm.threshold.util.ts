import {SECONDS_PER_MINUTE} from '@/lib/time/config/time.config';
import type {ChartYDataType} from '@/modules/glucose/types/finger.blood.chart.type';


/**
 * 获取本次 CGM 的断联阈值（分钟）
 *
 * 1. 算出所有相邻点的"间隔秒数"及其"出现次数"。
 *     间隔秒数        出现次数
 *      1200            10
 *      1000            20
 *      999             1
 *      900             30
 *      600             30
 *      200             9
 * 2. 选出"出现次数"最多的项，可能有多个，那么就组成一个数组。本例中是 [900秒(出现30次), 600秒(出现30次)] 这两个。
 * 3. 在这个数组中，返回间隔秒数最大的，把秒数转换为分钟后，返回分钟数。本例中是 900秒(出现30次)，那么断联阈值就是 900秒，转换为分钟就是 15分钟。
 *
 * @param data CGM数据，保证按测量时刻从早到晚排列
 * @param minutePerIndex 每个X刻度代表的分钟数
 */
export function getCgmThreshold(data: Array<ChartYDataType>, minutePerIndex: number): number {
  // 间隔秒数->这个"间隔秒数"的出现次数
  const map = new Map<number, number>();
  
  for (let i = 0, len = data.length - 1; i < len; i++) {
    // 存储每1个相邻2点的间隔秒数
    const interval = Math.floor((data[i+1].value[0] - data[i].value[0]) * minutePerIndex * SECONDS_PER_MINUTE);
    const count = map.get(interval);
    if (count) {
      // 这个"间隔秒数"的出现次数+1
      map.set(interval, count + 1);
    }
    else {
      // 这个"间隔秒数"首次出现
      map.set(interval, 1);
    }
  }
  
  // 所有"间隔秒数"中，出现最多的那个，找到它出现的次数
  const maxCount = Math.max(...Array.from(map.values()));
  // 出现最多次的"间隔秒数"可能有多个，在它们中找到最大的"间隔秒数"
  let maxInterval = 0;
  for (const [interval, count] of map) {
    if (count === maxCount) {
      maxInterval = Math.max(interval, maxInterval);
    }
  }
  
  // 把出现最多次的最大的"间隔秒数"转化为分钟，即为这一批 CGM 数据的断联阈值。
  return Math.round(maxInterval / SECONDS_PER_MINUTE);
  
  // 2025-08-15 已废弃
  // let yaPeiCount = 0;  // 雅培数据间隔数
  // let otherCount = 0;  // 其他设备数据间隔数
  //
  // for (let i = 0, len = data.length - 1; i < len; i++) {
  //   // 计算每一个相邻两点的测量间隔时间 (分钟)
  //   const interval = Math.floor((data[i+1].value[0] - data[i].value[0]) * minutePerIndex);
  //   if (interval >= CGM_YA_PER_INTERVAL) {
  //     yaPeiCount++;  // 间隔比较大，认为数据来源于雅培的CGM;
  //   }
  //   else {
  //     otherCount++;  // 间隔比较小，认为数据来源于其他设备;
  //   }
  // }
  // printSingle('CGM间隔在15分钟及以上的数量: ' + yaPeiCount, LOG_COLOR.NORMAL);
  // printSingle('CGM间隔在15分钟以内的数量: ' + otherCount, LOG_COLOR.NORMAL);
  // // 根据设备选取断联阈值
  // return yaPeiCount >= otherCount ? CGM_YA_PEI_THRESHOLD : CGM_AARUY_THRESHOLD;
}
