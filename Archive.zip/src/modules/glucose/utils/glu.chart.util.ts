import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';


/**
 * 是否属于绘制散点图的记录
 *
 * @param kind 记录类型
 */
export function isChartScatter(kind: GLU_RECORD_KIND): boolean {
  return kind === GLU_RECORD_KIND.FINGER || kind === GLU_RECORD_KIND.VEIN;
}

/**
 * 是否属于绘制折线图的记录
 *
 * @param kind 记录类型
 */
export function isGluChartLine(kind: GLU_RECORD_KIND): boolean {
  return kind === GLU_RECORD_KIND.CGM;
}

/**
 * 是否属于血糖散点图系列
 *
 * @param name 记录类型
 */
export function isSeriesGluScatter(name: string): boolean {
  return name === 'finger';
}
