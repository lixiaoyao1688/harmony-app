import {COLOR_GREEN_2} from '@/lib/style/color';
import { GLU } from '@/modules/glucose/config/glu.config';
import { CHART_CONFIG } from '@/modules/chart/config/chart.config';
import { notifyError } from '@/lib/aaruy-design/notify/notify';
import { getDigitCount } from '@/lib/math/util/math.util';
import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';
import type { GluRangeType } from '@/modules/glucose/types/glu.types';
import type { SliderRangeType } from '@/lib/aaruy-design/slider/types/slider.type';


export function getGluColorByValue(v: number, low: number, high: number, isCGM?: boolean, isText?: boolean): string {
  if (v < low) {
    return GLU.LOW.COLOR;
  }
  if (v > high) {
    return GLU.HIGH.COLOR;
  }
  if (isText) {
    return CHART_CONFIG.TEXT_COLOR;
  }
  return isCGM ? GLU.NORMAL.COLOR_CGM : GLU.NORMAL.COLOR_FINGER;
}


export function getGluColor(v: number, low: number, high: number, isApp?: boolean): string {
  const normalColor = isApp ? COLOR_GREEN_2 : GLU.COLOR.NORMAL;
  return v < low ? GLU.COLOR.LOW : (v > high ? GLU.COLOR.HIGH : normalColor);
}


/**
 * @param formatText 以 ',' 分隔的血糖值字符串
 */
export function getGluRange(formatText: string): SliderRangeType {
  if (!formatText || !formatText.includes(',')) {
    return [GLU.MIN, GLU.RANGE_MIN_DEFAULT, GLU.RANGE_MAX_DEFAULT, GLU.MAX];
  }
  return formatText.split(',').map(text => +text) as SliderRangeType;
}


/**
 * 血糖目标范围是否无效
 * @param v 血糖目标范围
 */
export function isGluRangeInvalid(v: GluRangeType): boolean {
  if (Math.round(v[2] - v[1]) < GLU.RANGE_DISTANCE) {
    notifyError('数值有误', `目标范围至少要有 ${GLU.RANGE_DISTANCE} mmol/L`);
    return true;
  }
  if (v[0] > v[1] || v[1] > v[2] || v[2] > v[3]) {
    notifyError('数值有误', '各个血糖阈值需从小到大排列');
    return true;
  }
  if (
    isGluDigitOverflow(v[0]) ||
    isGluDigitOverflow(v[1]) ||
    isGluDigitOverflow(v[2]) ||
    isGluDigitOverflow(v[3])
  ) {
    notifyError('数值有误', '血糖阈值的小数位数不得超过 1 位');
    return true;
  }
  return false;
}


/**
 * 血糖目标范围无效提示
 * @param v 血糖目标范围
 */
export function getTipFromValue(v: GluRangeType): string {
  if (Math.round(v[2] - v[1]) < GLU.RANGE_DISTANCE) {
    return `目标范围至少要有 ${GLU.RANGE_DISTANCE} mmol/L`;
  }
  if (v[0] > v[1] || v[1] > v[2] || v[2] > v[3]) {
    return '各个血糖阈值需从小到大排列';
  }
  if (
    isGluDigitOverflow(v[0]) ||
    isGluDigitOverflow(v[1]) ||
    isGluDigitOverflow(v[2]) ||
    isGluDigitOverflow(v[3])
  ) {
    return '血糖阈值的小数位数不得超过 1 位';
  }
  return '';
}

/**
 * 是否离散的血糖记录
 *
 * @param data 血糖类型
 */
export function isScatterGlu(data: GLU_RECORD_KIND): boolean {
  return data === GLU_RECORD_KIND.FINGER || data === GLU_RECORD_KIND.VEIN;
}

/**
 * 血糖值的小数位数是否超过最大小数位数
 * @param data 血糖值
 */
function isGluDigitOverflow(data: number): boolean {
  return getDigitCount(data.toString()) > 1;
}
