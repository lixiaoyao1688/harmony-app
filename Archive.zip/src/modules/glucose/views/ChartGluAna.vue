<script setup lang="ts">
import * as echarts from 'echarts';
import dayjs, {Dayjs} from 'dayjs';
import { useRoute } from 'vue-router';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useAgpStore } from '@/modules/glucose/store/agp.store';
import {useReportStore} from '@/modules/report/store/report.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import {ROUTE_HISTORY, ROUTE_IN_PATIENT, ROUTE_OUT_PATIENT} from '@/routers/global.router';
import { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';
import { REPORT } from '@/modules/report/configs/report.config';
import { AGP_ELE_ID, AGP_LEGENDS } from '@/modules/glucose/config/agp.config';
import StackedBar from '@/lib/aaruy-design/stacked-bar/StackedBar.vue';
import ChartRangePicker from '@/modules/record/components/ChartRangePicker.vue';
import PrintView from '@/modules/report/views/PrintView.vue';
import CalendarPickerMobile from '@/lib/aaruy-design/calendar/CalendarPickerMobile.vue';
import AgpLegend from '@/modules/glucose/components/AgpLegend.vue';
import CardDetailMobile from '@/modules/ins/components/CardDetailMobile.vue';
import AdviceEmpty from '@/modules/advice-closed-loop/component/AdviceEmpty.vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {APG_RECORD_KIND, APG_RECORD_KIND_ALL_ITEM, APG_RECORD_KIND_ITEMS} from '@/modules/glucose/config/agp.record.kind';
import {AgpRecordVO} from '@/modules/glucose/vo/AgpRecord.vo';
import PickerField from '@/lib/aaruy-design/picker/PickerField.vue';
import {INVALID_ID} from '@/utils/global.vo.help';
import {notifyInfo} from '@/lib/aaruy-design/notify/notify';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useOutPatientStore} from '@/modules/admission/store/out.patient.store';
import {ADMISSION_DOWN_KIND} from '@/modules/admission/config/admission.down.config';
import {AgpNewVO} from '@/modules/glucose/vo/Agp.vo.new';
import RecordDownload from '@/modules/record/components/RecordDownload.vue';
import AdmissionRecordUpload from '@/modules/admission/components/AdmissionRecordUpload.vue';
import EmptyIcon from '@/lib/aaruy-design/empty/EmptyIcon.vue';
import SpinMobile from '@/lib/aaruy-design/spin/SpinMobile.vue';
import GluContent from '@/modules/glucose/components/GluContent.vue';
import type { ChartType } from '@/modules/chart/types/chart.type';
import type { ECBasicOption } from 'echarts/types/src/util/types';
import type { WatchStopHandle } from '@vue/runtime-core';
import type {GluRangeType} from '@/modules/glucose/types/glu.types';


/**
 * 血糖分析 界面
 *
 * 归属功能
 * 院泵患者 && 签约患者 && 历史患者;
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
let chart: ChartType = null;
let unwatch: WatchStopHandle = () => {};

const MAX_RANGE = 31;
const isChartRendering = ref<boolean>(false);
const kindItem = ref<SelectItemVO<unknown>>(APG_RECORD_KIND_ALL_ITEM);
const isLoading = ref<boolean>(false);

const range = ref<[Dayjs,Dayjs] | null>(null);
const rangeMobile = computed<[Date, Date] | null>(() => range.value ? [range.value[0].toDate(), range.value[1].toDate()] : null);

const route = useRoute();
const store = useAgpStore();
const cardStore = useCardStore();
const screenStore = useScreenStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();
const outPatientStore = useOutPatientStore();

const isInPatient = computed<boolean>(() => (route.name === ROUTE_IN_PATIENT));
const isOutPatient = computed<boolean>(() => (route.name === ROUTE_OUT_PATIENT));
const isHistory = computed<boolean>(() => (route.name === ROUTE_HISTORY));

const pc = computed<boolean>(() => screenStore.isPC);
const pad = computed<boolean>(() => screenStore.isPad);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);

type SortFn = (vo1: AgpRecordVO, vo2: AgpRecordVO) => number;
const FROM_NEAR_TO_FAR: SortFn = (vo1: AgpRecordVO, vo2: AgpRecordVO) => vo2.timestamp - vo1.timestamp;
const FROM_FAR_TO_NEAR: SortFn = (vo1: AgpRecordVO, vo2: AgpRecordVO) => vo1.timestamp - vo2.timestamp;
const isNearToFar = ref<boolean>(true);

const records = computed<Array<AgpRecordVO>>(() => {
  const fn = isNearToFar.value ? FROM_NEAR_TO_FAR : FROM_FAR_TO_NEAR;
  if (kindItem.value.id === APG_RECORD_KIND.CGM) {
    return (store.newVO.cgmRecords as Array<AgpRecordVO>).sort(fn);
  }
  if (kindItem.value.id === APG_RECORD_KIND.FINGER) {
    return (store.newVO.fingerRecords as Array<AgpRecordVO>).sort(fn);
  }
  if (kindItem.value.id === APG_RECORD_KIND.VENOUS) {
    return (store.newVO.venousRecords as Array<AgpRecordVO>).sort(fn);
  }
  return (store.newVO.records as Array<AgpRecordVO>).sort(fn);
});

const displayLimit = 100;
const displayPages = ref<number>(1);
const displayRecords = computed<Array<AgpRecordVO>>(() => {
  return records.value.slice(0, displayLimit * displayPages.value);
});
const displayCount = computed<number>(() => Math.floor(displayRecords.value.length));
const displayTotalCount = computed<number>(() => Math.floor(records.value.length));


onMounted(() => {
  
  if (pc.value) {
    if (isInPatient.value) {
      unwatch = watch(() => cardStore.selectedCard, (c) => {
        if (c.admissionId === INVALID_ID) {
          return;
        }
        fetchData(c.admissionId);
      }, { immediate: true });
    }
    else if (isOutPatient.value) {
      unwatch = watch(() => outPatientStore.selectedAdmission, (data) => {
        if (data.id === INVALID_ID) {
          return;
        }
        fetchData(data.id);
      }, { immediate: true });
    }
    else {
      // history
      fetchData(admissionStore.admission.id);
    }
  }
  else {
    const c = cardStore.selectedCard;
    renderChart(new AgpNewVO().getConfig(c.gluRange));
    const id = c.isValid ? cardStore.selectedCard.admissionId : admissionStore.admission.id;
    fetchData(id);
  }
  
});

onUnmounted(() => {
  store.clear();
  if (unwatch) {
    unwatch();
  }
});

watch(() => store.filter.range, (data) => {
  range.value = data;
}, { immediate: true });


function addDisplayPage(): void {
  displayPages.value = displayPages.value + 1;
}

function onKindItemChange(data: SelectItemVO<unknown>): void {
  kindItem.value = data;
}

function onSortFnChange(data: boolean): void {
  isNearToFar.value = data;
}

function onRangeChange(data: NewDateRange): void {
  if (!data) {
    return;
  }
  if (data[1].diff(data[0], 'day') > MAX_RANGE) {
    notifyInfo('注意', `查询的日期范围不得超过 ${MAX_RANGE} 天`);
    return;
  }
  range.value = data;
  // reportStore.config.range = data;
  store.filter.range = data;
  
  let id = cardStore.selectedCard.admissionId;
  if (screenStore.isPC) {
    if (isOutPatient.value) {
      id = outPatientStore.selectedAdmission.id;
    }
    else if (isHistory.value) {
      id = admissionStore.admission.id;
    }
  }
  else {
    const c = cardStore.selectedCard;
    id = c.isValid ? cardStore.selectedCard.admissionId : admissionStore.admission.id;
  }
  fetchData(id);
}

function onMobileRangeChange(data: [Date, Date]): void {
  onRangeChange([dayjs(data[0]), dayjs(data[1])]);
}

function renderChart(c: ECBasicOption): void {
  if (!chart) {
    const el = document.getElementById(AGP_ELE_ID);
    if (el) {
      chart = echarts.init(el);
    }
  }
  if (mobile.value) {
    c.backgroundColor = 'transparent';
    // @ts-ignore
    c.yAxis.splitLine.lineStyle.color = 'rgb(58, 68, 77)';
  }
  if (chart) {
    chart.setOption(c);
  }
}

function fetchData(id: number): void {
  if (id === INVALID_ID) {
    return;
  }
  isLoading.value = true;
  store.filter.admissionId = id;
  store
    .fetch()
    .then(data => {
      
      let gluRange: GluRangeType;
      if (isInPatient.value) {
        gluRange = cardStore.selectedCard.gluRange;
      }
      else if (isOutPatient.value) {
        gluRange = outPatientStore.selectedAdmission.gluRange;
      }
      else {
        // history
        gluRange = admissionStore.admission.gluRange;
      }
      
      const c = data.getConfig(gluRange);
      isChartRendering.value = true;
      setTimeout(() => {
        isChartRendering.value = false;
        console.log(c);
        renderChart(c);
      }, 2000);
    })
    .finally(() => {
      isLoading.value = false;
    });
}
</script>

<template>
 
	<div v-if="pc" :style="{ height: isHistory ? 'calc(100vh - var(--ad-header-height) - var(--ad-menu-height))' : '100%' }">
    <div style="height: 64px;" class="flex items-center justify-end py-0 px-8">
			<div class="flex flex-1 ml-200">
        <ChartRangePicker :range="range" :max-range="MAX_RANGE" class="ml-24" @change="onRangeChange" />
        <div v-if="store.loading" class="text-weak-2 flex items-center pl-24 text-lg">数据加载中，请稍候...</div>
			</div>
      <AdmissionRecordUpload :vo="admissionStore.admission" />
      <div class="mx-16">
        <RecordDownload :disabled="store.loading" :kind="ADMISSION_DOWN_KIND.GLU" :range="range" />
      </div>
			<PrintView :report-id="REPORT.AGP" />
<!--			<CheckBox type="default" class="mr-10 ml-24" :checked="store.filter.isFingerChecked" @change="onFingerCheckedChange">指血数据</CheckBox>-->
		</div>
		<GluContent
      height="calc(100% - 64px)"
      :vo="store.newVO"
      :kindItem="kindItem"
      :records="records"
      :displayRecords="displayRecords"
      :displayCount="displayCount"
      :displayTotalCount="displayTotalCount"
      :isChartRendering="isChartRendering"
      :is-near-to-far="isNearToFar"
      @sort-change="onSortFnChange"
      @kind-change="onKindItemChange"
      @page-add="addDisplayPage"
    />
	</div>
  <div v-if="mobile" class="h-full">
    <div class="border-b-default mx-16 flex items-center justify-center" style="height: 48px;">
      <CalendarPickerMobile type="range" :max-range="MAX_RANGE" :range="rangeMobile" @rangeChange="onMobileRangeChange" />
    </div>
    <div class="overflow-hidden-auto px-16 py-16" style="height: calc(100% - 48px);">
      <!--  指标  -->
      <div class="flex mb-8">
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isHbaValid" unit="%" :data="store.newVO.hba" title="糖化血红蛋白" style="margin-right: 8px;" />
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isMgValid" unit="mmol/L" :data="store.newVO.mg" title="平均血糖" />
      </div>
      <div class="flex mb-8">
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isCvValid" unit="%" :data="store.newVO.cv" title="变异系数" style="margin-right: 8px;" />
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isSdValid" unit="mmol/L" :data="store.newVO.sd" title="血糖标准差" />
      </div>
      <div class="flex mb-8">
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isFingerCountValid" unit="" :data="store.newVO.fingerCount" title="指血检测数" style="margin-right: 8px;" />
        <CardDetailMobile width="50%" height="60px" :is-unit-bottom="true" :is-empty="!store.newVO.isCgmCountValid" unit="" :data="store.newVO.cgmCount" title="CGM检测数" />
      </div>
      <!--  血糖达标率  -->
      <CardDetailMobile title="血糖达标率 TIR" :is-col="true" width="100%" height="180px" :is-empty="!store.newVO.isTirValid" class="mt-8">
        <StackedBar :items="store.newVO.tirItems" :is-mobile="true" />
      </CardDetailMobile>
      <!--  AGP图谱  -->
      <div class="pb-16 pt-16">
        <div class="flex items-center" style="height: 24px;">
          <span class="text-s leading-s font-bold">AGP图谱</span>
          <SpinMobile tip="" :loading="isLoading" height="24px" min-height="24px" margin="0 0 0 8px" />
        </div>
        <div class="mb-8 mt-4">
          <AgpLegend :items="AGP_LEGENDS" />
        </div>
        <div :id="AGP_ELE_ID" style="height: 320px;"></div>
      </div>
      <div class="bg-2 rounded-4 p-16 text-white text-s leading-s">
        <div class="font-bold pb-16 border-b-bg-17">糖化血红蛋白详情</div>
        <div style="height: 51px;" class="flex items-center">
          <span>{{ store.newVO.hbaEstimateTimeDateText }}</span>
          <span class="ml-8">{{ store.newVO.hbaEstimateTimeTimeText }}</span>
          <div class="flex-1 flex justify-end items-center">
            <span class="ml-8">预估值</span>
            <span class="font-bold ml-8">{{ store.newVO.hbaEstimateText }}</span>
          </div>
        </div>
        <div v-for="(it,i) in store.newVO.hbaVOs"
             :key="it.id" style="height: 51px;" :class="{ 'border-t-bg-17': i > 0 }"
             class="flex items-center">
          <span>{{ it.dateText }}</span>
          <span class="ml-8">{{ it.timeText }}</span>
          <div class="flex-1 flex justify-end items-center">
            <span class="ml-8">检测值</span>
            <span class="font-bold ml-8">{{ it.valueText }}</span>
          </div>
        </div>
<!--        <EmptyIcon v-if="store.newVO.hbaVOs.length === 0" tips="暂无数据" height="200px" />-->
<!--        <template v-else>-->
<!--          <div v-for="(it,i) in store.newVO.hbaVOs"-->
<!--               :key="it.id" style="height: 51px;" :class="{ 'border-t-bg-17': i > 0 }"-->
<!--               class="flex items-center">-->
<!--            <span>{{ it.dateText }}</span>-->
<!--            <span class="ml-8">{{ it.timeText }}</span>-->
<!--            <div class="flex-1 flex justify-end items-center">-->
<!--              <span class="ml-8">检测值</span>-->
<!--              <span class="font-bold ml-8">{{ it.valueText }}</span>-->
<!--            </div>-->
<!--          </div>-->
<!--        </template>-->
      </div>
      <!--   血糖详情表 -->
      <div class="bg-2 rounded-4 p-16 text-white text-s leading-s mt-16">
        <div class="text-s leading-s font-bold flex items-center justify-between pb-8 border-b-bg-17" style="height: 32px;">
          <span>血糖详情表</span>
          <div class="flex-1 font-normal text-xs">
            <PickerField title="" hide-out-side-title :items="APG_RECORD_KIND_ITEMS" :item="kindItem" @change="onKindItemChange" />
          </div>
        </div>
        <div class="flex justify-center py-16">
          <div>
            <div class="inline-flex flex-col items-center pr-32">
              <div class="pb-8 text-xs leading-xs">指血检测</div>
              <div class="text-xl leading-xl font-bold">{{ store.newVO.fingerCountText }}</div>
            </div>
            <div class="inline-flex flex-col items-center pr-32">
              <div class="pb-8 text-xs leading-xs">静脉血检测</div>
              <div class="text-xl leading-xl font-bold">{{ store.newVO.venousCountText }}</div>
            </div>
            <div class="inline-flex flex-col items-center">
              <div class="pb-8 text-xs leading-xs">CGM数值</div>
              <div class="text-xl leading-xl font-bold">{{ store.newVO.cgmCountText }}</div>
            </div>
          </div>
        </div>
        <div class="rounded-t-4 bg-1 text-white text-xs flex px-8" style="height: 48px;">
          <span class="h-full inline-block text-center" style="width: 33.3%; line-height: 48px;">时间</span>
          <div class="h-full inline-block text-center" style="width: 33.3%;">
            <div style="line-height: 32px;">数值</div>
            <div style="line-height: 8px;" class="text-weak-2 text-xxs">mmol/L</div>
          </div>
          <span class="h-full inline-block text-center" style="width: 33.3%; line-height: 48px;">类型</span>
        </div>
        <div v-if="records.length === 0" class="bg-4 rounded-b-4" style="height: 280px;">
          <AdviceEmpty tips="暂无数据" height="100%" />
        </div>
        <GluContent
          v-else
          height="100%"
          :vo="store.newVO"
          :kindItem="kindItem"
          :records="records"
          :displayRecords="displayRecords"
          :displayCount="displayCount"
          :displayTotalCount="displayTotalCount"
          :isChartRendering="isChartRendering"
          :is-near-to-far="isNearToFar"
          @sort-change="onSortFnChange"
          @kind-change="onKindItemChange"
          @page-add="addDisplayPage"
        />
      </div>
    </div>
  </div>

</template>
