<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { ChartGluSingleVO } from '@/modules/glucose/vo/GluSingle.vo';
import ChartGluDailyDetailPM from '@/modules/glucose/components/ChartGluDailyDetailPM.vue';
import RecordDataAnalysisDetail from '@/modules/record/components/DataAnalysisDetail.vue';


interface Prop {
  charts: Array<ChartGluSingleVO>;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const isChartHaveData = computed<boolean>(() => (prop.charts.length > 0));
</script>


<template>
	
  <RecordDataAnalysisDetail :is-chart-have-data="isChartHaveData" v-if="pc">
    <template #detail>
      <ChartGluDailyDetailPM v-for="(c, i) in charts" :id="i" :key="i" :vo="c" :config="c.config" :date="c.dateText" :table="c.table" />
    </template>
  </RecordDataAnalysisDetail>

  <div v-if="mobile" class="glu-daily-mobile">
    <ChartGluDailyDetailPM v-for="(c, i) in charts" :id="i" :key="i" :vo="c" :config="c.config" :date="c.dateText" />
  </div>
</template>
