<script setup lang="ts">
import { computed, ref } from 'vue';
import { CardVO } from '@/modules/admission/vo/Card.vo';
import { useCardStore } from '@/modules/admission/store/card.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import {httpNurseAdd} from '@/modules/nurse/requests/nurse.http';
import {OPERATION_KIND} from '@/modules/nurse/config/operation.kind';
import {getNowDayjs} from '@/lib/time/util/dayjs.util';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {httpAdmissionInfo} from '@/modules/admission/requests/admission.http';
import {printSingleError} from '@/lib/log/util/log.util';
import {GLU_VALUE_DIGIT, MAX_GLU_VALUE, MIN_GLU_VALUE} from '@/modules/glucose/config/glu.config';
import {
  DEFAULT_INSPECTION_KIND,
  INSPECTION_KIND,
  INSPECTION_KIND_MAP,
  INSPECTION_PC_KINDS
} from '@/modules/glucose/config/inspection.kind';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import FormModal from '@/lib/aaruy-design/form/FormModal.vue';
import InputView from '@/lib/aaruy-design/input/InputView.vue';
import RadioButtonNew from '@/lib/aaruy-design/radio-button/new/RadioButtonNew.vue';
import {getDigitCount} from '@/lib/math/util/math.util';
import {DEFAULT_INSPECTION_NODE, INSPECTION_NODES_FOR_ADD} from '@/modules/glucose/config/inspection.node';
import SelectTab from '@/lib/aaruy-design/select/tab/SelectTab.vue';
import type {NurseAddDTO} from '@/modules/nurse/dto/nurse.dto';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 指血录入 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
	c: CardVO;
}

const TITLE = '血糖录入';
const INPUT_HEIGHT = '40px';
const prop = defineProps<Prop>();

const cardStore = useCardStore();
const screenStore = useScreenStore();
const admissionStore = useAdmissionStore();

const blood = ref<string>('');
const kindItem = ref<ItemType2>(DEFAULT_INSPECTION_KIND);
const sceneItem = ref<ItemType2>(DEFAULT_INSPECTION_NODE);  // 指血节点 仅指血

const visible = ref<boolean>(false);
const waiting = ref<boolean>(false);

const innerVO = ref<AdmissionVO>(new AdmissionVO());

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const bloodErrorTips = ref<string>('');


function onOpen(): void {
  kindItem.value = DEFAULT_INSPECTION_KIND;
  onReset();
  visible.value = true;
  httpAdmissionInfo(prop.c.admissionId)
    .then(data => {
      innerVO.value = data;
    })
    .catch(e => printSingleError(e));
}

function onClose(): void {
  visible.value = false;
}

function onSceneItemChange(data: ItemType2): void {
  sceneItem.value = data;
}

function onChange(v: string): void {
  blood.value = v;
  bloodErrorTips.value = getBloodErrorTips(v);
}

function onKindItemChange(data: ItemType2): void {
  kindItem.value = data;
}

function onReset(): void {
  blood.value = '';
  sceneItem.value = DEFAULT_INSPECTION_NODE;
}

function getBloodErrorTips(data: string): string {
  const num = Number(data);
  if (isNaN(num) || !Number.isFinite(num)) {
    return '请输入数字';
  }
  if (num <= 0) {
    return '血糖值必须大于0';
  }
  if (num < MIN_GLU_VALUE || num > MAX_GLU_VALUE) {
    return `血糖值范围为 ${MIN_GLU_VALUE}mmol/L-${MAX_GLU_VALUE}mmol/L`;
  }
  const digitCount = getDigitCount(data);
  if (digitCount > GLU_VALUE_DIGIT) {
    return `血糖值的小数位数不能超过${GLU_VALUE_DIGIT}位`;
  }
  return '';
}

function confirm(): void {
  bloodErrorTips.value = getBloodErrorTips(blood.value);
  if (bloodErrorTips.value !== '') {
    return;
  }
  const data = +blood.value;
  waiting.value = true;
  
  const dto: NurseAddDTO = {
    admission_id: innerVO.value.id,
    record_dt: getNowDayjs().format('YYYY-MM-DD HH:mm'),
    kind: OPERATION_KIND.INSPECTION,
    record_kind: kindItem.value.id,
    value: data,
  };
  if (kindItem.value.id === INSPECTION_KIND.FINGER) {
    dto.scene_id = sceneItem.value.id;
  }
  httpNurseAdd(dto)
    .then(_ => {
      const c = prop.c;
      if (data > c.gluLow && data < c.gluHigh) {
        // 超过高低血糖阈值时，PC端会有报警弹窗，不需要主动弹出提示。所以仅正常血糖值需要提示。
        const name = SelectItemVO.getText(INSPECTION_KIND_MAP, kindItem.value.id);
        notifySuccessNormal(`${name}记录 ${blood.value}mmol/L 已添加`);
      }
      onClose();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}
</script>

<template>
  
  <template v-if="pc">
    <ModalView :visible="visible" :title="TITLE" width="560px" @close="onClose">
      <FormModal :waiting="waiting" cancel-text="重 置" @cancel="onReset" @confirm="confirm">
        <div class="flex items-center"
             :class="{
               'mb-24': kindItem.id !== INSPECTION_KIND.FINGER,
               'mb-12': kindItem.id === INSPECTION_KIND.FINGER
             }"
        >
          <RadioButtonNew :item="kindItem" :items="INSPECTION_PC_KINDS" @change="onKindItemChange" />
          <div class="flex-1 pl-16">
            <InputView type="number" :data="blood" :tips="bloodErrorTips" :height="INPUT_HEIGHT"
                       use-theme-border use-suffix placeholder="请输入血糖值"
                       input-padding="0 86px 0 8px"
                       @change="onChange"
                       @enter="confirm">
              <template #suffix>
                <div :style="{ height: INPUT_HEIGHT, lineHeight: INPUT_HEIGHT }"
                     class="text-white text-s pr-16">mmol/L</div>
              </template>
            </InputView>
          </div>
        </div>
        <template v-if="kindItem.id === INSPECTION_KIND.FINGER">
          <div class="text-lg text-white font-bold mb-8">指血节点</div>
          <SelectTab :items="INSPECTION_NODES_FOR_ADD" :item="sceneItem"
                     margin="0 0 24px 0"
                     @change="onSceneItemChange" />
        </template>
      </FormModal>
    </ModalView>
    <span class="inline-flex items-center w-full h-full cursor-default" @click="onOpen">{{ TITLE }}</span>
  </template>
  <template v-else><!--  移动端添加指血在"检测记录"组件中实现  --></template>
  
</template>
