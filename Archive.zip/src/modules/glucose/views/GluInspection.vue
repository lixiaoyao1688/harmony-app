<script setup lang="ts">
import dayjs, {Dayjs} from 'dayjs';
import { ref, computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { CardVO } from '@/modules/admission/vo/Card.vo';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import {useUserStore} from '@/modules/user/store/user.store';
import {httpAdmissionInfo} from '@/modules/admission/requests/admission.http';
import {notifyErrorLackSelector, notifyErrorNormal, notifySuccessNormal} from '@/lib/aaruy-design/notify/notify';
import {notifyNoAuth} from '@/modules/auth/utils/auth.util';
import {httpNurseAdd} from '@/modules/nurse/requests/nurse.http';
import {OPERATION_KIND} from '@/modules/nurse/config/operation.kind';
import {DEFAULT_INSPECTION_KIND, INSPECTION_KIND, INSPECTION_KINDS} from '@/modules/glucose/config/inspection.kind';
import {DEFAULT_INSPECTION_NODE, INSPECTION_NODES} from '@/modules/glucose/config/inspection.node';
import {FINGER_STEP, MAX_FINGER_DIGIT,} from '@/modules/glucose/config/finger.config';
import {MAX_VEIN_DIGIT, VEIN_STEP} from '@/modules/glucose/config/vein.config';
import {HBA_STEP, MAX_HBA_DIGIT, MAX_HBA_VALUE, MIN_HBA_VALUE} from '@/modules/glucose/config/hba.config';
import {MAX_GLU_VALUE, MIN_GLU_VALUE} from '@/modules/glucose/config/glu.config';
import InputNumberField4 from '@/lib/aaruy-design/input/number/InputNumberField4.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import FieldDouble from '@/lib/aaruy-design/field/FieldDouble.vue';
import IconInspection from '@/modules/glucose/icons/IconInspection.vue';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import PageBoardContent from '@/lib/aaruy-design/page/component/PageBoardContent.vue';
import DateRangePickerField from '@/lib/aaruy-design/date-range-picker/field/DateTimePickerFieldMobile.vue';
import PickerField from '@/lib/aaruy-design/picker/PickerField.vue';
import PickerTag from '@/lib/aaruy-design/picker/tag/PickerTag.vue';
import type {NurseAddDTO} from '@/modules/nurse/dto/nurse.dto';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';
import type {InputNumberChangePayload, InputNumberExpose} from '@/lib/aaruy-design/input/number/type/input.number.field2.type';


/**
 * 检测记录 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  c: CardVO;
  isDisabled?: boolean;
}

interface Emit {
  (e: 'open'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const userStore = useUserStore();
const screenStore = useScreenStore();

const isOpened = ref<boolean>(false);
const isWaiting = ref<boolean>(false);

const vo = ref<AdmissionVO>(new AdmissionVO());  // 患者VO
const time = ref<Dayjs>(dayjs());  // 检测时间，默认当前时间
const kindItem = ref<ItemType2>(DEFAULT_INSPECTION_KIND);  // 检测类型
const nodeItem = ref<ItemType2>(DEFAULT_INSPECTION_NODE);  // 检测节点
const result = ref<string>('');  // 检测结果
const resultRef = ref<InputNumberExpose | null>(null);
const resultUnit = computed<string>(() => kindItem.value.id === INSPECTION_KIND.HBA ? '%' : 'mmol/L');
const resultName = computed<string>(() => kindItem.value.id === INSPECTION_KIND.HBA ? '糖化血红蛋白' : '血糖值');
const resultMin = computed<number>(() => getConfigMin(kindItem.value.id));
const resultMax = computed<number>(() => getConfigMax(kindItem.value.id));
const resultDigit = computed<number>(() => getConfigDigit(kindItem.value.id));
const resultStep = computed<number>(() => getConfigStep(kindItem.value.id));

const pad = computed<boolean>(() => screenStore.isPad);
const phone = computed<boolean>(() => screenStore.isNewPhone);


function getConfigMax(kind: INSPECTION_KIND): number {
  if (kind === INSPECTION_KIND.FINGER) {
    return MAX_GLU_VALUE;
  }
  if (kind === INSPECTION_KIND.VENOUS) {
    return MAX_GLU_VALUE;
  }
  return MAX_HBA_VALUE;
}

function getConfigMin(kind: INSPECTION_KIND): number {
  if (kind === INSPECTION_KIND.FINGER) {
    return MIN_GLU_VALUE;
  }
  if (kind === INSPECTION_KIND.VENOUS) {
    return MIN_GLU_VALUE;
  }
  return MIN_HBA_VALUE;
}

function getConfigDigit(kind: INSPECTION_KIND): number {
  if (kind === INSPECTION_KIND.FINGER) {
    return MAX_FINGER_DIGIT;
  }
  if (kind === INSPECTION_KIND.VENOUS) {
    return MAX_VEIN_DIGIT;
  }
  return MAX_HBA_DIGIT;
}

function getConfigStep(kind: INSPECTION_KIND): number {
  if (kind === INSPECTION_KIND.FINGER) {
    return FINGER_STEP;
  }
  if (kind === INSPECTION_KIND.VENOUS) {
    return VEIN_STEP;
  }
  return HBA_STEP;
}

function onConfirm(): void {
  if (!time.value) {
    notifyErrorLackSelector('时间');
    return;
  }
  if (!kindItem.value.isValid) {
    notifyErrorLackSelector('检测类型');
    return;
  }
  if (kindItem.value.id === INSPECTION_KIND.FINGER && !nodeItem.value.isValid) {
    notifyErrorLackSelector('检测节点');
    return;
  }
  
  let hasError = false;
  if (resultRef.value && resultRef.value.checkValueError()) {
    hasError = true;
  }
  if (hasError) {
    return;
  }

  isWaiting.value = true;
  const dto: NurseAddDTO = {
    admission_id: vo.value.id,
    record_dt: time.value.format('YYYY-MM-DD HH:mm'),
    kind: OPERATION_KIND.INSPECTION,
    record_kind: kindItem.value.id,
    value: +result.value,
  };
  if (kindItem.value.id === INSPECTION_KIND.FINGER) {
    dto.scene_id = nodeItem.value.id;
  }
  httpNurseAdd(dto)
    .then(_ => notifySuccessNormal('检测记录已添加'))
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => isWaiting.value = false);
}

function onOpen(): void {
  if (prop.isDisabled) {
    notifyNoAuth();
    return;
  }
  onReset();
  emit('open');
  isOpened.value = true;
  fetchAdmissionInfo();
}

function onBack(): void {
  isOpened.value = false;
}

function fetchAdmissionInfo(): void {
  vo.value = new AdmissionVO();
  httpAdmissionInfo(prop.c.id)
    .then(data => {
      vo.value = data;
    });
}

function onTimeChange(data: Dayjs): void {
  time.value = data;
}

function onKindItemChange(data: ItemType2): void {
  kindItem.value = data;
  result.value = '';
}

function onNodeItemChange(data: ItemType2): void {
  nodeItem.value = data;
}

function onResultChange(data: InputNumberChangePayload): void {
  result.value = data.data;
}

function onReset(): void {
  time.value = dayjs();
  kindItem.value = DEFAULT_INSPECTION_KIND;
  nodeItem.value = DEFAULT_INSPECTION_NODE;
  result.value = '';
}
</script>

<template>
  <PageMobile :visible="isOpened" @goBack="onBack">
    <template #title>检测记录</template>
    <template #content>
      <PageBoardContent>
        <FieldView2 type="double-text" is-start is-end>
          <FieldDouble t1="姓名" :use-font14="!pad" :v1="vo.nameText" t1-width="40px" t2="科室" :v2="vo.partText" />
          <FieldDouble t1="床号" :use-font14="!pad" :v1="vo.bedText"  t1-width="40px" t2="登记号" :v2="vo.codeText" is-end />
        </FieldView2>
        <FieldView2 type="other" is-start>
          <DateRangePickerField title="检测时间" :data="time" :use-font16="pad" @change="onTimeChange" />
        </FieldView2>
        <FieldView2 type="other-complex">
          <PickerTag title="检测类型" :item="kindItem" :items="INSPECTION_KINDS" :use-font16="pad"
                     use-selected-style-border
                     @change="onKindItemChange" />
        </FieldView2>
        <FieldView2 v-if="kindItem.id === INSPECTION_KIND.FINGER" type="other">
          <PickerField title="检测节点"
                       :item="nodeItem"
                       :items="INSPECTION_NODES"
                       :use-font16="pad"
                       @change="onNodeItemChange" />
        </FieldView2>
        <FieldView2 type="other-complex" padding="0" is-end>
          <div class="mx-16 py-16" style="border-top: 1px solid var(--aaruy-bg-color-0);">
            <InputNumberField4 title="检测结果"
                               ref="resultRef"
                               name="result"
                               :data="result"
                               :unit="resultUnit"
                               :min="resultMin"
                               :max="resultMax"
                               :digit="resultDigit"
                               :step="resultStep"
                               :tip-name="resultName"
                               :use-font-size14="phone"
                               show-border-bottom
                               show-border-bottom-black
                               height="32px"
                               padding="0 0 8px 0"
                               @change="onResultChange" />
          </div>
        </FieldView2>
        <template #bottom>
          <div class="h-full flex items-start justify-between px-16">
            <ButtonView type="default" text="重置" style="width: 49%; height: 80%; font-size: 16px;" @click="onReset" />
            <ButtonView type="primary" text="确认" style="width: 49%; height: 80%; font-size: 16px;" :loading="isWaiting" @click="onConfirm" />
          </div>
        </template>
      </PageBoardContent>
    </template>
  </PageMobile>
  <div class="inline-block text-center w-64-px h-64-px" @click.stop="onOpen">
    <IconInspection :is-disabled="isDisabled" />
    <div :class="{ 'text-weak-real-3': isDisabled, 'text-white': !isDisabled }">检测</div>
  </div>
</template>
