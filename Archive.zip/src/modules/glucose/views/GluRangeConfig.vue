<script setup lang="ts">
import { computed, ref } from 'vue';
import { useRoute } from 'vue-router';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useSystemConfigStore } from '@/modules/system-config/store/system.config.store';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { SYSTEM_CONFIG_GLU_RANGE_MENU_INFO } from '@/modules/system-config/configs/system.config.menu.glu.range.config';
import { httpSystemConfigUpdate } from '@/modules/system-config/requests/system.config.http';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import { useUserStore } from '@/modules/user/store/user.store';
import { getTipFromValue } from '@/modules/glucose/utils/glu.util';
import { ROUTE_IN_PATIENT } from '@/routers/global.router';
import { GLU_DIABETE_KIND } from '@/modules/glucose/config/glu.config';
import { ArrayStringVO } from '@/lib/transform/ArrayString.vo';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import GluRange from '@/modules/glucose/components/GluRangeView.vue';
import LayoutForm from '@/lib/aaruy-design/layout/LayoutForm.vue';
import type { SystemConfigUpdateDTO } from '@/modules/system-config/dto/system.config.dto';
import type { SliderData, SliderRangeType } from '@/lib/aaruy-design/slider/types/slider.type';


/**
 * 血糖范围 组件
 *
 * 模式
 * 读写
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface RangeMapType {
	one: SliderRangeType;
	two: SliderRangeType;
	onePg: SliderRangeType;
	twoPg: SliderRangeType;
	oneOld: SliderRangeType;
	twoOld: SliderRangeType;
  pregnancy: SliderRangeType;
  other: SliderRangeType;
}

interface RangeErrorType {
  one: string;
  two: string;
  onePg: string;
  twoPg: string;
  oneOld: string;
  twoOld: string;
  pregnancy: string;
  other: string;
}

const route = useRoute();

const store = useSystemConfigStore();
const userStore = useUserStore();
const screenStore = useScreenStore();

const waiting = ref<boolean>(false);

const updateDTO = ref<SystemConfigUpdateDTO>({});
const heightMobile = ref<string>('calc(100vh - var(--board-top) - var(--tab-normal-height))');
const menu = ref<SelectorFormItemVO>(SYSTEM_CONFIG_GLU_RANGE_MENU_INFO.defaultItem);
const rangeMap = ref<RangeMapType>({
  one: store.systemConfig.gluRange1,
  two: store.systemConfig.gluRange2,
  onePg: store.systemConfig.gluRange1Pg,
  twoPg: store.systemConfig.gluRange2Pg,
  oneOld: store.systemConfig.gluRange1Old,
  twoOld: store.systemConfig.gluRange2Old,
  pregnancy: store.systemConfig.gluRangePregnancy,
  other: store.systemConfig.gluRangeOther,
});
const errorMap = ref<RangeErrorType>({
  one: '',
  two: '',
  onePg: '',
  twoPg: '',
  oneOld: '',
  twoOld: '',
  pregnancy: '',
  other: '',
});
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const isWorkBench = computed<boolean>(() => (route.name === ROUTE_IN_PATIENT));


function onChange(field: keyof RangeMapType, payload: SliderData): void {
  const rangeData = payload.data;
  rangeMap.value[field] = rangeData;
  errorMap.value[field] = getTipFromValue(rangeData);
}

function onClose(): void {
  store.close(isWorkBench.value);
}

function onCancel(): void {
  onClose();
}

function onSave(): void {
  if (
    errorMap.value.one !== '' ||
    errorMap.value.two !== '' ||
    errorMap.value.onePg !== '' ||
    errorMap.value.twoPg !== '' ||
    errorMap.value.oneOld !== '' ||
    errorMap.value.twoOld !== '' ||
    errorMap.value.pregnancy !== '' ||
    errorMap.value.other !== ''
  ) {
    return;
  }
  
  const map = rangeMap.value;
  updateDTO.value = {
    glucose_kind_range: new ArrayStringVO('', [
      // 顺序和 http://192.168.1.249:8000/project/38/interface/api/719 保持一致;
      { kind_id: GLU_DIABETE_KIND.OTHER, glucose_range: new ArrayStringVO('',map.other).text  },
      { kind_id: GLU_DIABETE_KIND.ONE, glucose_range: new ArrayStringVO('',map.one).text  },
      { kind_id: GLU_DIABETE_KIND.TWO, glucose_range: new ArrayStringVO('',map.two).text  },
      { kind_id: GLU_DIABETE_KIND.ONE_PG, glucose_range: new ArrayStringVO('',map.onePg).text  },
      { kind_id: GLU_DIABETE_KIND.TWO_PG, glucose_range: new ArrayStringVO('',map.twoPg).text  },
      { kind_id: GLU_DIABETE_KIND.ONE_OLD, glucose_range: new ArrayStringVO('',map.oneOld).text  },
      { kind_id: GLU_DIABETE_KIND.TWO_OLD, glucose_range: new ArrayStringVO('',map.twoOld).text  },
      { kind_id: GLU_DIABETE_KIND.PG, glucose_range: new ArrayStringVO('',map.pregnancy).text  },
    ]).text
  };
  waiting.value = true;
  httpSystemConfigUpdate(updateDTO.value)
    .then(_ => {
      notifySuccessNormal('血糖范围已更新');
      userStore.fetchUser();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}
</script>

<template>
 
	<div v-if="pc" class="flex h-100">
		<LayoutForm :waiting="waiting" is-full-height is-split-line-hidden @save="onSave" @cancel="onCancel">
			<template #formContent>
        <div class="pt-16 px-16">
          
          <GluRange title="1型糖尿病"
                    :range="rangeMap.one" :border-color="errorMap.one ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('one', $event)" />
          <ErrorView :tips="errorMap.one" is-text-left />
          
          <GluRange title="1型糖尿病妊娠"
                    :range="rangeMap.onePg" :border-color="errorMap.onePg ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('onePg', $event)" />
          <ErrorView :tips="errorMap.onePg" is-text-left />
          
          <GluRange title="老年/高风险1型糖尿病"
                    :range="rangeMap.oneOld" :border-color="errorMap.oneOld ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('oneOld', $event)" />
          <ErrorView :tips="errorMap.oneOld" is-text-left />
          
          <GluRange title="妊娠糖尿病"
                    :range="rangeMap.pregnancy"
                    @change="onChange('pregnancy', $event)" />
          <ErrorView :tips="errorMap.pregnancy" is-text-left />
          
        </div>
			</template>
			<template #formContentRight>
        <div class="pt-16 px-16">
          
          <GluRange title="2型糖尿病"
                    :range="rangeMap.two" :border-color="errorMap.two ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('two', $event)" />
          <ErrorView :tips="errorMap.two" is-text-left />
          
          <GluRange title="2型糖尿病妊娠"
                    :range="rangeMap.twoPg" :border-color="errorMap.twoPg ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('twoPg', $event)" />
          <ErrorView :tips="errorMap.twoPg" is-text-left />
          
          <GluRange title="老年/高风险2型糖尿病"
                    :range="rangeMap.twoOld" :border-color="errorMap.twoOld ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('twoOld', $event)" />
          <ErrorView :tips="errorMap.twoOld" is-text-left />
          
          <GluRange title="其他糖尿病"
                    :range="rangeMap.other" :border-color="errorMap.other ? 'var(--aaruy-error-color)' : 'transparent'"
                    @change="onChange('other', $event)" />
          <ErrorView :tips="errorMap.other" is-text-left />
          
        </div>
			</template>
		</LayoutForm>
	</div>
	
  <div v-if="mobile"><!-- 暂不支持移动端 --></div>
	
</template>
