<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {CardVO} from '@/modules/admission/vo/Card.vo';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import {GLU, GLU_DEFAULT_RANGE} from '@/modules/glucose/config/glu.config';
import {getTipFromValue, isGluRangeInvalid} from '@/modules/glucose/utils/glu.util';
import {httpAdmissionUpdate} from '@/modules/admission/requests/admission.http';
import {notifyErrorNormal, notifyInfo, notifySuccessNormal} from '@/lib/aaruy-design/notify/notify';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import GluRange from '@/modules/glucose/components/GluRangeView.vue';
import type {GluRangeType} from '@/modules/glucose/types/glu.types';
import type {SliderData} from '@/lib/aaruy-design/slider/types/slider.type';
import type {AdmissionUpdateDTO} from '@/modules/admission/dto/admission.dto';


/**
 * 血糖目标弹窗 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  vo: CardVO;
}

const prop = defineProps<Prop>();

const TITLE = '血糖目标';

const store = useAdmissionStore();
const cardStore = useCardStore();
const screenStore = useScreenStore();

const isOpened = ref<boolean>(false);
const isWaiting = ref<boolean>(false);
const value = ref<GluRangeType>(GLU_DEFAULT_RANGE);
const tips = computed<string>(() => getTipFromValue(value.value));


watch(() => prop.vo.gluRange, (newData, oldData) => {
  if (JSON.stringify(newData) !== JSON.stringify(oldData)) {
    value.value = newData;
  }
}, { immediate: true });

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}
function onReset(): void {
  value.value = prop.vo.gluRange;
}

function onChange(data: SliderData): void {
  value.value = [...data.data] as GluRangeType;
}

function onConfirm(): void {
  if (JSON.stringify(value.value) === JSON.stringify(prop.vo.gluRange)) {
    notifyInfo('数据未改变', '请修改血糖目标范围');
    return;
  }
  if (isGluRangeInvalid(value.value)) {
    return;
  }
  const vo = prop.vo;
  const dto: AdmissionUpdateDTO = {
    id: vo.admissionId,
    glucose_range: JSON.stringify(value.value)
  };
  isWaiting.value = true;
  httpAdmissionUpdate(dto)
    .then(_ => {
      notifySuccessNormal(`患者【${vo.name}】的血糖目标范围已更新`);
      onClose();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => isWaiting.value = false);
}
</script>

<template>
  <ModalView :visible="isOpened" width="800px" :title="TITLE" @close="onClose">
    <div class="text-lg text-white px-48 py-12" style="height: 72px; line-height: 48px;">请设置血糖目标 <span>({{ GLU.MIN }}~{{ GLU.MAX }} mmol/L)</span></div>
    <div class="px-16">
      <GluRange title=""
                :range="value" :border-color="tips ? 'var(--aaruy-error-color)' : 'transparent'"
                @change="onChange" />
    </div>
    <div class="px-60 text-s font-bold text-error" style="height: 48px; line-height: 48px;" :class="{ 'hidden': !tips }">{{ tips }}</div>
    <div class="flex items-start justify-end px-24" style="height: 70px;">
      <ButtonView type="default" text="重置" style="width: 240px; height: 40px;" @click="onReset" />
      <ButtonView type="primary" text="确定" style="width: 240px; height: 40px; margin-left: 16px;" :loading="isWaiting" @click="onConfirm" />
    </div>
  </ModalView>
  <span class="inline-flex items-center w-100 h-100 cursor-default" @click="onOpen">{{ TITLE }}</span>
</template>
