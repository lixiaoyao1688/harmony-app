<script setup lang="ts">
import { computed, ref } from 'vue';
import { CardVO } from '@/modules/admission/vo/Card.vo';
import { useAgpStore } from '@/modules/glucose/store/agp.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useCardStore } from '@/modules/admission/store/card.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { httpHbaAdd } from '@/modules/glucose/requests/hba.http';
import { notifyError, notifyErrorLackInputer, notifySuccess } from '@/lib/aaruy-design/notify/notify';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import FormModal from '@/lib/aaruy-design/form/FormModal.vue';
import FormModalItem from '@/lib/aaruy-design/form/FormModalItem.vue';
import NewInputBasic from '@/lib/aaruy-design/input/basic/NewInputBasic.vue';
import InputBasic from '@/lib/aaruy-design/input/basic/InputBasic.vue';


interface Prop {
	c: CardVO;
}

interface Emit {
	(e: 'open'): void;
	(e: 'close'): void;
}


const TITLE = '糖化血红蛋白';

const emit = defineEmits<Emit>();
const prop = defineProps<Prop>();

const agpStore = useAgpStore();
const cardStore = useCardStore();
const screenStore = useScreenStore();
const admissionStore = useAdmissionStore();

const blood = ref<string>('');
const visible = ref<boolean>(false);
const waiting = ref<boolean>(false);

const disabled = computed<boolean>(() => blood.value === '');
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

function open(): void {
  emit('open');
  reset();
  visible.value = true;
}

function reset(): void {
  blood.value = '';
}

function close(): void {
  visible.value = false;
}

function onChange(v: string): void {
  blood.value = v;
}

function confirm(): void {
  if (!blood.value) {
    return notifyErrorLackInputer('糖化血红蛋白数值');
  }
  waiting.value = true;
  httpHbaAdd({ admission_id: prop.c.id, hba: +blood.value })
    .then(() => {
      agpStore.hbaUpdateWaiting = true;
      visible.value = false;
      blood.value = '';
      notifySuccess('成功', '数值已录入');
    })
    .catch(reason => {
      notifyError('失败', reason);
    })
    .finally(() => {
      waiting.value = false;
    });
}
</script>

<template>
	<ModalView :visible="visible" :is-mobile-dialog="mobile" :title="TITLE" @close="close">
		<FormModal :disabled="disabled" :waiting="waiting" @cancel="close" @confirm="confirm">
			<FormModalItem :title="pc ? '糖化血红蛋白数值 %' : '糖化血红蛋白数值'" :required="true">
				
				<template v-if="pc">
					<InputBasic type="number" :data="blood" :password="false" placeholder="请输入糖化血红蛋白数值" :maxlength="10" @change="onChange" @press-enter="confirm" />
				</template>
				
				<template v-if="mobile">
					<NewInputBasic type="number" :value="blood" placeholder="请输入糖化血红蛋白数值" @change="onChange">
						<span class="text-xs leading-xs text-white">mmol/L</span>
					</NewInputBasic>
				</template>
			
			</FormModalItem>
		</FormModal>
	</ModalView>
	<span v-if="pc" class="text" @click="open">{{ TITLE }}</span>
	<div v-if="mobile" @click.stop="open">{{ TITLE }}</div>
</template>

<style scoped>
.text {
	display: inline-flex;
	align-items: center;
	width: 100%;
	height: 100%;
	cursor: default;
}
</style>
