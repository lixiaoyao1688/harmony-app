import dayjs from 'dayjs';
import {throwFieldLackError} from '@/lib/http/util/http.utils';
import {AGP_PATH} from '@/modules/glucose/requests/glu.http';
import {realRoundTo1Digit, roundTo, roundToString} from '@/lib/math/util/math.util';
import { standardDeviation } from 'simple-statistics';
import {HbaVO} from '@/modules/glucose/vo/Hba.vo';
import {AgpRecordVO} from '@/modules/glucose/vo/AgpRecord.vo';
import {StackedBarItemVO} from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {
  AGP_FORMATTER,
  AGP_X_DATA,
  APG_LINE_25_75_COLOR, APG_LINE_5_95_COLOR,
  APG_LINE_CENTER_COLOR
} from '@/modules/glucose/config/agp.config';
import {getStackedBarItemsFromRangeAndRecord} from '@/modules/glucose/utils/agp.util';
import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';
import type {AgpNewDTO} from '@/modules/glucose/dto/agp.dto';
import type {ECBasicOption} from 'echarts/types/src/util/types';
import type {GluRangeType} from '@/modules/glucose/types/glu.types';


/**
 * 血糖分析 VO
 */
export class AgpNewVO {
  
  private readonly _entity: AgpNewDTO | null;
  
  // 长度固定288; (一天里共有288个"5分钟")
  // 每5分钟1个桶，共288个桶; (如: [00:00~00:05](桶0),[00:05~00:10](桶1),[00:05~00:10](桶2),...)
  // 每个桶里有所有天该时间范围内的数据; (如: 桶0中有 [2025/01/01~2025/01/16] 中每一天 [00:00~00:05] 时间范围内的数据)
  private _buckets: Array<Array<number>>;
  
  constructor(e?: AgpNewDTO) {
    this._entity = e || null;
  }
  
  
  // 糖化血红蛋白检测列表
  public get hbaVOs(): Array<HbaVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('hba_records');
    return this._entity.hba_records.map(dto => new HbaVO(dto));
  }
  
  // 糖化血红蛋白 预估值 保留1位小数 %
  // DeepSeek:
  // 根据平均血糖值估算糖化血红蛋白（HbA1c）最常用的方法是使用美国糖尿病协会（ADA）认可的公式，称为平均血糖估算值（eAG），
  // 血糖单位是 mg/dL，这个公式是: HbA1c (%) = (平均血糖值 (mg/dL) + 46.7) / 28.7;
  // 我们的血糖单位是 mmol/L，要先乘以 18 转为 mg/dL;
  // 那么最终的公式是：
  // HbA1c (%) = [ (平均血糖值 (mmol/L) * 18 ) + 46.7 ] / 28.7;
  public get hbaEstimate(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    return roundTo( (this.mg * 18 + 46.7) / 28.7,1);
  }
  // 糖化血红蛋白 预估值 文本 %
  public get hbaEstimateText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.hbaEstimate + '%';
  }
  // 糖化血红蛋白 预估时间
  public get hbaEstimateTimeText(): string {
    if (!this._entity) {
      return '--';
    }
    return dayjs().format('YYYY/MM/DD HH:mm:ss');
  }
  // 糖化血红蛋白 预估时间 日期
  public get hbaEstimateTimeDateText(): string {
    if (!this._entity) {
      return '--';
    }
    return dayjs().format('YYYY-MM-DD');
  }
  // 糖化血红蛋白 预估时间 时刻
  public get hbaEstimateTimeTimeText(): string {
    if (!this._entity) {
      return '--';
    }
    return dayjs().format('HH:mm:ss');
  }
  
  // 糖化血红蛋白 值 保留1位小数 %
  // "检测记录+预估记录" 的平均值
  public get hba(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('hba_records');
    const data = this._entity.hba_records;
    const recordTotal = data.reduce((pre, cur) => pre + cur.value, 0);
    return realRoundTo1Digit((recordTotal + this.hbaEstimate) / (data.length + 1));
    // return roundTo((recordTotal + this.hbaEstimate) / (data.length + 1),1);
  }
  public get isHbaValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    this._checkField('hba_records');
    return this._entity.glu_records.length > 0 || this._entity.hba_records.length > 0;
  }
  
  
  // 平均血糖 MG
  // 测量值中血糖的平均值;
  public get mg(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    if (this._entity.glu_records.length === 0) {
      return 0;
    }
    const totalValue = this._entity.glu_records.reduce((pre, cur) => pre + cur.value, 0);
    return roundTo(totalValue / this._entity.glu_records.length, 1);
  }
  public get mgText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.mg.toString();
  }
  public get isMgValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    return this._entity.glu_records !== undefined && this._entity.glu_records.length > 0;
  }
  
  
  // 标准差 SD
  // 按数学定理计算;
  public get sd(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    if (this._entity.glu_records.length === 0) {
      return 0;
    }
    return roundTo(standardDeviation(this._entity.glu_records.map(r => r.value)), 1);
  }
  public get isSdValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    return this._entity.glu_records !== undefined && this._entity.glu_records.length > 0;
  }
  
  
  // 变异系数
  // CV = (SD / MG) * 100;   // SD:标准差, MG:平均血糖;
  public get cv(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    const mg = this.mg;
    if (mg === 0) {
      return 0;
    }
    return roundTo(this.sd / mg * 100,1);
  }
  public get cvText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.cv.toString();
  }
  public get isCvValid(): boolean {
    return this.isSdValid && this.isMgValid;
  }
  
  
  // 血糖检测数
  public get gluCount(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    return this._entity.glu_records.length;
  }
  public get gluCountText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.gluCount.toString();
  }
  
  // 静脉血检测数
  public get venousCount(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.VEIN).length;
  }
  public get venousCountText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.venousCount.toString();
  }
  public get isVenousCountValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    return this._entity.glu_records !== undefined && this._entity.glu_records.length >= 0;
  }
  
  
  // 指血检测数
  public get fingerCount(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.FINGER).length;
  }
  public get fingerCountText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.FINGER).length.toString();
  }
  public get isFingerCountValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    return this._entity.glu_records !== undefined && this._entity.glu_records.length >= 0;
  }
  
  
  // CGM检测点的数量
  public get cgmCount(): number {
    if (!this._entity) {
      return 0;
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.CGM).length;
  }
  public get cgmCountText(): string {
    if (!this._entity) {
      return '--';
    }
    return this.cgmCount.toString();
  }
  public get isCgmCountValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    return this._entity.glu_records !== undefined && this._entity.glu_records.length >= 0;
  }
  
  
  // 血糖测量点 列表
  public get records(): Array<AgpRecordVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('glu_records');
    return this._entity.glu_records.map((r,i) => new AgpRecordVO(i,r));
    // return Array(20).fill(0).map(_ => ({
    //   kind: 'finger',
    //   record_dt: '2024/08/16 06:35:24',
    //   value: 10.2
    // } as AgpRecordDTO)).map((r,i) => new AgpRecordVO(i,r));
  }
  public get cgmRecords(): Array<AgpRecordVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.CGM).map((r,i) => new AgpRecordVO(i,r));
  }
  public get fingerRecords(): Array<AgpRecordVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.FINGER).map((r,i) => new AgpRecordVO(i,r));
  }
  public get venousRecords(): Array<AgpRecordVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('glu_records');
    return this._entity.glu_records.filter(r => r.kind === GLU_RECORD_KIND.VEIN).map((r,i) => new AgpRecordVO(i,r));
  }
  
  
  // 最低血糖 保留1位小数
  public get lowestText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('glu_records');
    const data = this._entity.glu_records;
    return data.length === 0 ? '--' : Math.min(...data.map(d => d.value)).toString();
  }
  
  
  // 最高血糖 保留1位小数
  public get highestText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('glu_records');
    const data = this._entity.glu_records;
    return data.length === 0 ? '--' : Math.max(...data.map(d => d.value)).toString();
  }
  
  
  // 血糖分布占比
  public get isTirValid(): boolean {
    if (!this._entity) {
      return false;
    }
    this._checkField('glu_records');
    this._checkField('glucose_range');
    return this._entity.glu_records.length > 0 && this._entity.glucose_range.length >= 4;
  }
  public get isTirEmpty(): boolean {
    return !this.isTirValid;
  }
  public get tirItems(): Array<StackedBarItemVO> {
    if (!this._entity) {
      return [];
    }
    this._checkField('glu_records');
    this._checkField('glucose_range');
    return getStackedBarItemsFromRangeAndRecord(this._entity.glucose_range, this._entity.glu_records);
    // if (!this._entity) {
    //   return [];
    // }
    // this._checkField('glucose_range');
    // return GLU.LEVEL.ITEMS
    //   .map((it, index) => {
    //     let value = 0;
    //     if (this._entity) {
    //       if (it.id === GLU_ANA_LEVEL.OK) {
    //         value = roundTo(100 - this._entity.glucose_range.reduce((pre,cur) => pre + cur, 0), 1);
    //       }
    //       else {
    //         value = this._entity.glucose_range[index];
    //       }
    //     }
    //     value = roundTo(value / 100, 3);
    //     return new StackedBarItemVO(it.id, it.text, value, it.payload.color, GLU.LEVEL.DIGITS);
    //   });
  }
  // 血糖达标率 % 保留1位小数
  public get tirOkText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('glu_records');
    this._checkField('glucose_range');
    const items = getStackedBarItemsFromRangeAndRecord(this._entity.glucose_range, this._entity.glu_records);
    return items[items.length - 1].percentValue.toString();
  }
  
  
  /**
   *
   * APG图谱
   *
   * 目标: 绘制 5 条曲线(5%,25%,50%,75%,95%);
   *
   * 原理:
   * 同一个 x(时刻，如 04:00), 算出 5 个 y(血糖值), 多个时刻的 x 连起来，这样就有 5 条线了;
   *
   * 方法:
   * 1. 构建每个 x 的 records:
   *    选择日期范围，最少15天，这样每一个 x 就至少有 15 个点， 这 15 个点按血糖值从小到大排列，存在 records 中;
   *
   * 2. 计算5个索引(records):
   *    2.1 索引的计算方法: index1 = (n+1) × p = p * n + p;  其中 n为总数 (records.length),  p为概率，如 5% 为 0.05;
   *    2.2 实际上只要计算 2个索引即可，因为 5% 和 95% 的索引对称，25%和75%的索引对称， 50%在最中间（奇数为中心值/偶数为中心两数的平均值）
   *
   * 3. 用这 5 个索引，从 records 中取出 5 个血糖值，值作为 y, 这样每个 x 得到 5 个点，不同的 x 连起来，得到 5 条线;
   *
   */
  public getConfig(gluRange: GluRangeType): ECBasicOption {
    this._initBuckets(this._entity);
    const isMobile = useScreenStore().isMobile;
    
    const FONT_SIZE_TEXT = isMobile ? 12 : 14;
    const colorLine = 'rgb(91,103,116)';
    const colorGluDataLow = 'rgb(255,36,42)';
    const colorGluDataHigh = 'rgb(235,166,48)';
    const MIN_Y = 0;
    const MAX_Y = 23;
    const MIN_Y_V = gluRange[1];
    const MAX_Y_V = gluRange[2];
    
    const y0 = this._getYValues(0.05);
    const y1 = this._getYValues(0.25);
    const y2 = this._getYValues(0.5);
    const y3 = this._getYValues(0.75);
    const y4 = this._getYValues(0.95);
    
    const markArea = {
      silent: true,
      data: [
        [
          {
            name: roundToString(MAX_Y_V, 1),
            yAxis: MAX_Y_V,
            label: {
              color: colorGluDataHigh,
              fontSize: FONT_SIZE_TEXT,
              position: 'insideTopRight',
              align: 'right',
              verticalAlign: 'bottom',
              fontWeight: 700,
              lineHeight: 28,
            },
            itemStyle: {
              color: 'rgb(58,68,77,0.5)'
            }
          },
          {
            yAxis: MIN_Y_V
          },
        ],
        [
          {
            name: roundToString(MIN_Y_V, 1),
            yAxis: MIN_Y_V,
            label: {
              color: colorGluDataLow,
              fontSize: FONT_SIZE_TEXT,
              position: 'insideTopRight',
              align: 'right',
              verticalAlign: 'top',
              fontWeight: 700,
              lineHeight: 16,
            },
            itemStyle: {
              color: 'transparent'
            }
          },
          {
            yAxis: MIN_Y,
          },
        ]
      ]
    };
    const itemStyle = {
      opacity: 0,
    };
    const o = {
      grid: {
        left: 48,
        top: 50,
        right: 12,
        bottom: 50,
      },
      animation: false,
      backgroundColor: 'rgb(58,68,77)',
      xAxis: {
        type: 'category',
        axisLabel: {
          show: true,
          color: 'rgb(255,255,255)',
          interval: 47,
          formatter: AGP_FORMATTER,
          fontSize: FONT_SIZE_TEXT,
          fontWeight: 700,
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: colorLine
          }
        },
        data: AGP_X_DATA
      },
      yAxis: {
        name: 'mmol/L',
        nameLocation: 'end',
        nameTextStyle: {
          color: 'rgb(255,255,255)',
          fontSize: FONT_SIZE_TEXT,
          fontWeight: 700,
        },
        type: 'value',
        min: MIN_Y,
        max: MAX_Y,
        axisTick: {
          show: false,
        },
        axisLine: {
          show: false,
        },
        axisLabel: {
          show: true,
          color: 'rgb(255,255,255)',
          fontSize: FONT_SIZE_TEXT,
          fontWeight: 700,
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: colorLine
          }
        }
      },
      series: [
        // 5%
        {
          type: 'line',
          silent: true,
          smooth: true,
          stack: 'agp',
          stackStrategy: 'positive',
          areaStyle: {
            color: 'transparent',
          },
          lineStyle: {
            color: 'transparent'
          },
          itemStyle: itemStyle,
          data: y0
        },
        // 25% - [5%]
        {
          type: 'line',
          silent: true,
          smooth: true,
          stack: 'agp',
          stackStrategy: 'positive',
          areaStyle: {
            color: '#426246',
          },
          lineStyle: {
            color: 'transparent'
          },
          itemStyle: itemStyle,
          data: this._getStackedValues(y1,y0)
        },
        // 50%
        {
          type: 'line',
          silent: true,
          smooth: true,
          lineStyle: {
            color: '#9FFFAC'
          },
          itemStyle: itemStyle,
          data: y2
        },
        // 75% - [25%] - [5%]
        {
          type: 'line',
          silent: true,
          smooth: true,
          stack: 'agp',
          stackStrategy: 'positive',
          areaStyle: {
            color: '#3A8344',
          },
          lineStyle: {
            color: 'transparent'
          },
          itemStyle: itemStyle,
          data: this._getStackedValues(y3,y1)
        },
        // 95% - [75%] - [25%] - [5%]
        {
          type: 'line',
          silent: true,
          smooth: true,
          stack: 'agp',
          stackStrategy: 'positive',
          areaStyle: {
            color: '#426246',
          },
          lineStyle: {
            color: 'transparent'
          },
          itemStyle: itemStyle,
          markArea: markArea,
          data: this._getStackedValues(y4,y3)
        },
      ]
    };
    
    if (isMobile) {
      o.grid.left = 24;
      o.grid.top = 36;
      o.grid.right = 4;
      o.grid.bottom = 36;
    }
    
    return o;
  }
  
  // AGP血糖报告 - AGP图谱
  public getReportConfig(range: GluRangeType): ECBasicOption {
    const c = this.getConfig(range);
    const textColor = 'rgb(51,51,51)';
    const textColor2 = 'rgb(43,145,0)';
    const fontSize = 12;
    const fontWeight = 400;
    const lineColor = 'rgb(223,223,223)';
    
    // @ts-ignore
    c.grid.bottom = 30;
    c.backgroundColor = 'transparent';
    // @ts-ignore
    c.xAxis.axisLabel.color = textColor;
    // @ts-ignore
    c.xAxis.axisLabel.fontWeight = fontWeight;
    // @ts-ignore
    c.xAxis.axisLine.show = false;
    // @ts-ignore
    c.yAxis.nameTextStyle.color = textColor;
    // @ts-ignore
    c.yAxis.nameTextStyle.fontWeight = fontWeight;
    // @ts-ignore
    c.yAxis.axisLabel.color = textColor;
    // @ts-ignore
    c.yAxis.axisLabel.fontWeight = fontWeight;
    // @ts-ignore
    c.yAxis.splitLine.lineStyle.color = lineColor;
    // @ts-ignore
    c.yAxis.splitLine.lineStyle.type = 'dashed';
    
    
    // @ts-ignore
    c.series[1].areaStyle.color = APG_LINE_5_95_COLOR;
    // @ts-ignore
    c.series[2].lineStyle.color = APG_LINE_CENTER_COLOR;
    // @ts-ignore
    c.series[3].areaStyle.color = APG_LINE_25_75_COLOR;
    // @ts-ignore
    c.series[4].areaStyle.color = APG_LINE_5_95_COLOR;
    
    
    // @ts-ignore
    c.series[4].markArea.data[0][0].itemStyle.color = 'transparent';
    
    // @ts-ignore
    c.series[4].markArea.data[0][0].label.color = textColor2;
    // @ts-ignore
    c.series[4].markArea.data[0][0].label.fontSize = fontSize;
    // @ts-ignore
    c.series[4].markArea.data[0][0].label.fontWeight = fontWeight;
    // @ts-ignore
    c.series[4].markArea.data[0][0].label.position = ['100%', -15];
    
    // @ts-ignore
    c.series[4].markArea.data[1][0].label.color = textColor2;
    // @ts-ignore
    c.series[4].markArea.data[1][0].label.fontSize = fontSize;
    // @ts-ignore
    c.series[4].markArea.data[1][0].label.fontWeight = fontWeight;
    // @ts-ignore
    c.series[4].markArea.data[1][0].label.position = ['100%', 20];
    
    return c;
  }
  
  private _initBuckets(e: AgpNewDTO | null): void {
    if (!e) {
      this._buckets = [];
    }
    else {
      this._checkField('glu_records');
      const data = e ? e.glu_records : [];
      const startTime = dayjs().year(2000).month(0).date(1).hour(0).minute(0).second(0).millisecond(0).unix();  // 单位:秒
      const interval = 300;  // 5分钟
      
      this._buckets = Array(288).fill(0).map(_ => ([]));
      data.forEach(record => {
        const currentTime = dayjs(record.record_dt).year(2000).month(0).date(1).unix();
        const value = record.value;
        const index = Math.floor((currentTime - startTime) / interval);  // 该时刻应放入第几个桶;
        this._buckets[index].push(value);
      });
    }
  }
  
  
  /**
   * 当前曲线对上一条曲线的增加值，长度固定288;
   * @param line 当前曲线
   * @param lastLine 上一条曲线
   */
  private _getStackedValues(line: Array<number | undefined>, lastLine: Array<number | undefined>): Array<number> {
    const stackLine: Array<number> = [];
    
    for (let i = 0, len = line.length; i < len; i++) {
      if (line[i] === undefined || lastLine[i] === undefined) {
        stackLine.push(0);
        continue;
      }
      const data = line[i] as number;
      const lastData = lastLine[i] as number;
      const stackData = (data - lastData) > 0 ? (data - lastData) : 0;
      stackLine.push(stackData);
    }
    
    return stackLine;
  }
  
  /**
   * 获取每条曲线的 y 值列表，长度固定288: 每5分钟一个值，1天共288个值;
   * @param p 该曲线代表的概率. 取值范围 [0,1], 如: 0.05 代表 5%; 曲线共有 5%,25%,50%,75%,95% 这5种概率;
   */
  private _getYValues(p: number): Array<number | undefined> {
    const values: Array<number | undefined> = [];
    
    this._buckets.forEach(b => {
      // 某个 5 分钟范围
      const data = b.sort((a,b) => a - b);  // 按血糖值从小到大排序;
      const index = Math.floor(p * data.length + p);
      values.push(data[index] === undefined ? undefined : data[index]);
    });
    
    return values;
  }
  
  private _checkField<T>(field: keyof AgpNewDTO, fieldChild?: keyof T): void {
    if (!this._entity) {
      return;
    }
    if (this._entity[field] === undefined) {
      throwFieldLackError(field, AGP_PATH.GET_ANA);
    }
    else if (fieldChild && (this._entity[field] as unknown as T)[fieldChild] === undefined) {
      throwFieldLackError(`${field}.${fieldChild as string}`, AGP_PATH.GET_ANA);
    }
  }
  
}
