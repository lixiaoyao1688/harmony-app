import { isObjectNull } from '@/utils/global.tool';
import { EMPTY_VALUE } from '@/utils/global.vo.help';
import { GLU } from '@/modules/glucose/config/glu.config';
import { getEmptyAgpDTO, getGluLevelOK } from '@/modules/glucose/utils/agp.util';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import { AGP_FORMATTER, AGP_X_DATA } from '@/modules/glucose/config/agp.config';
import { StackedBarItemVO } from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';
import { getPercentDataFromDigit, roundTo, roundToString } from '@/lib/math/util/math.util';
import { AgpLine, AgpDTO, AgpValueDTO, GluTirType } from '@/modules/glucose/dto/agp.dto';
import { DEFAULT_RANGE_DAYS } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import { SECONDS_PER_DAY } from '@/lib/time/config/time.config';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import type { ECBasicOption } from 'echarts/types/src/util/types';
import type {ChartDailyGetDTO} from '@/modules/record/dto/chart.daily.dto';


/**
 * 血糖分析 VO
 */
export class AgpVO {
	
	private readonly _entity: AgpDTO;
	private readonly _admission: AdmissionVO;
	private readonly _days: number;  // 时间跨度，天
	
	constructor(ad: AdmissionVO, e?: AgpDTO, body?: ChartDailyGetDTO) {
	  this._entity = e || getEmptyAgpDTO();
	  this._admission = ad;
	  this._days = this._getDays(body);
	}
	
	private _getDays(body?: ChartDailyGetDTO): number {
	  if (!body || !body.start_time || !body.end_time) {
	    return DEFAULT_RANGE_DAYS;
	  }
	  return Math.floor((body.end_time - body.start_time) / SECONDS_PER_DAY);
	}
	
	public get isHbaEmpty(): boolean {
	  return !this.isHbaValid;
	}
	
	// 糖化血红蛋白，单位%, 保留小数点后一位
	public get isHbaValid(): boolean {
	  return this._entity && this._entity.value_info && this._entity.value_info.hba !== undefined;
	}
	public get hba(): number {
	  if (!this.isHbaValid) {
	    return 0;
	  }
	  return roundTo(this._entity.value_info.hba as number, 1);
	}
	
	
	// 指血检测数 整数
	public get fingerCountText(): string {
	  if (this.isFingerCountEmpty) {
	    return '--';
	  }
	  return this.fingerCount.toString();
	}
	public get fingerCount(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.count_finger === undefined) {
	    return 0;
	  }
	  return Math.floor(this._entity.value_info.count_finger);
	}
	public get isFingerCountEmpty(): boolean {
	  return this._isValueEmpty('count_finger');
	}
	
	// 每日平均监测次数
	// 通过"指血检测数"除以"天数"获得。 by zym 2024-10-25.
	public get mgCountText(): string {
	  // if (this.isMgCountEmpty) {
	  //   return '--';
	  // }
	  if (this.isMgCountEmpty) {
	    return '--';
	  }
	  return this.mgCount.toString();
	}
	public get mgCount(): number {
	  if (!this.fingerCount || !this._days) {
	    return 0;
	  }
	  return Math.floor(this.fingerCount / this._days);
	  // if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.count_mg === undefined) {
	  //   return 0;
	  // }
	  // return this._entity.value_info.count_mg;
	}
	public get isMgCountEmpty(): boolean {
	  // return this._isValueEmpty('count_mg');
	  return !this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.count_finger === undefined;
	}
	
	
	// 平均血糖 保留1位小数
	public get mgText(): string {
	  if (this.isMgEmpty) {
	    return '--';
	  }
	  return this.mg.toString();
	}
	public get mg(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.mg === undefined) {
	    return 0;
	  }
	  return roundTo(this._entity.value_info.mg, 1);
	}
	public get isMgEmpty(): boolean {
	  return this._isValueEmpty('mg');
	}
	
	
	// 变异系数 保留1位小数
	public get cvText(): string {
	  if (this.isCvEmpty) {
	    return '--';
	  }
	  return this.cv.toString();
	}
	public get cv(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.cv === undefined) {
	    return 0;
	  }
	  return getPercentDataFromDigit(this._entity.value_info.cv, 1);
	}
	public get isCvEmpty(): boolean {
	  return this._isValueEmpty('cv');
	}
	
	
	// 最大血糖波动 保留1位小数
	public get largeText(): string {
	  if (this.isLargeEmpty) {
	    return '--';
	  }
	  return this.large.toString();
	}
	public get large(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.lage === undefined) {
	    return 0;
	  }
	  return roundTo(this._entity.value_info.lage, 1);
	}
	public get isLargeEmpty(): boolean {
	  return this._isValueEmpty('lage');
	}
	
	
	// 最低血糖 保留1位小数
	public get lowestText(): string {
	  if (this.isLowestEmpty) {
	    return '--';
	  }
	  return this.lowest.toString();
	}
	public get lowest(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.lowest === undefined) {
	    return 0;
	  }
	  return roundTo(this._entity.value_info.lowest, 1);
	}
	public get isLowestEmpty(): boolean {
	  return this._isValueEmpty('lowest');
	}
	
	
	// 最高血糖 保留1位小数
	public get highestText(): string {
	  if (this.isHighestEmpty) {
	    return '--';
	  }
	  return this.highest.toString();
	}
	public get highest(): number {
	  if (!this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.highest === undefined) {
	    return 0;
	  }
	  return roundTo(this._entity.value_info.highest, 1);
	}
	public get isHighestEmpty(): boolean {
	  return this._isValueEmpty('highest');
	}
	
	
	// 血糖分布占比  保留1位小数
	public get isTirEmpty(): boolean {
	  return !this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info) || this._entity.value_info.tir_list === undefined || this._entity.value_info.tir_list.length < GLU.LEVEL.ITEMS.length;
	}
	public get tirOkText(): string {
	  if (this.isTirEmpty) {
	    return '--';
	  }
	  return getPercentDataFromDigit((this._entity.value_info.tir_list as GluTirType)[getGluLevelOK().id], GLU.LEVEL.DIGITS).toString();
	}
	public get tirItems(): Array<StackedBarItemVO> {
	  // @ts-ignore
	  return GLU.LEVEL.ITEMS.map(it => new StackedBarItemVO(it.id, it.text, this._getTirData(it.id), it.payload.color, GLU.LEVEL.DIGITS, this._admission.getGluRangeText(it.id)));
	}
	private _getTirData(index: number): number {
	  if (this.isTirEmpty) {
	    return EMPTY_VALUE;
	  }
	  return (this._entity.value_info.tir_list as GluTirType)[index];
	}
	
	
	public getLine(index: number): AgpLine {
	  if (!this._entity || !this._entity.agp_info) {
	    return [];
	  }
		
	  if (index === 0 || index === 2) {
	    // 线1 或 中位数线
	    return this._entity.agp_info[index] || [];
	  }

	  // 求堆叠值
	  if (index == 3) {
	    // 跳过中位数线
		  const line = this._entity.agp_info[3];
		  const lastLine = this._entity.agp_info[1];
		  const stackLine: Array<number> = [];
		  
		  line.forEach((d, i) => {
			  const data = d;
			  const lastData = lastLine[i];
			  const stackData = (data - lastData) > 0 ? (data - lastData) : 0;
			  stackLine.push(stackData);
		  });
		  return stackLine;
	  }

	  // 1,4
	  const line = this._entity.agp_info[index];
	  const lastLine = this._entity.agp_info[index-1];
	  const stackLine: Array<number> = [];
		
	  line.forEach((d, i) => {
	    const data = d;
	    const lastData = lastLine[i];
	    const stackData = (data - lastData) > 0 ? (data - lastData) : 0;
	    stackLine.push(stackData);
	  });
	  return stackLine;
	}
	
	// 图形
	public get config(): ECBasicOption {
	  const isMobile = useScreenStore().isMobile;
		
	  const FONT_SIZE_TEXT = isMobile ? 12 : 14;
	  const colorLine = 'rgb(91,103,116)';
	  const colorGluDataLow = 'rgb(255,36,42)';
	  const colorGluDataHigh = 'rgb(235,166,48)';
	  const MIN_Y = 0;
	  const MAX_Y = 23;
	  const MIN_Y_V = this._admission.gluLow;
	  const MAX_Y_V = this._admission.gluHigh;
		
	  const markArea = {
	    silent: true,
	    data: [
	      [
	        {
	          name: roundToString(MAX_Y_V, 1),
	          yAxis: MAX_Y_V,
	          label: {
	            color: colorGluDataHigh,
	            fontSize: FONT_SIZE_TEXT,
	            position: 'insideTopRight',
	            align: 'right',
	            verticalAlign: 'bottom',
	            fontWeight: 700,
	            lineHeight: 28,
	          },
	          itemStyle: {
	            color: 'rgb(58,68,77,0.5)'
	          }
	        },
	        {
	          yAxis: MIN_Y_V
	        },
	      ],
	      [
	        {
	          name: roundToString(MIN_Y_V, 1),
	          yAxis: MIN_Y_V,
	          label: {
	            color: colorGluDataLow,
	            fontSize: FONT_SIZE_TEXT,
	            position: 'insideTopRight',
	            align: 'right',
	            verticalAlign: 'top',
	            fontWeight: 700,
	            lineHeight: 16,
	          },
	          itemStyle: {
	            color: 'transparent'
	          }
	        },
	        {
	          yAxis: MIN_Y,
	        },
	      ]
	    ]
	  };
	  const itemStyle = {
	    opacity: 0,
	  };
	  const o = {
	    grid: {
	      left: 35,
	      top: 50,
	      right: 4,
	      bottom: 50,
	    },
	    animation: false,
	    backgroundColor: 'rgb(67,80,91)',
	    xAxis: {
	      type: 'category',
	      axisLabel: {
	        show: true,
	        color: 'rgb(255,255,255)',
	        interval: 47,
	        formatter: AGP_FORMATTER,
	        fontSize: FONT_SIZE_TEXT,
	        fontWeight: 700,
	      },
	      axisTick: {
	        show: false,
	      },
	      axisLine: {
	        show: true,
	        lineStyle: {
	          color: colorLine
	        }
	      },
	      data: AGP_X_DATA
	    },
	    yAxis: {
	      name: 'mmol/L',
	      nameLocation: 'end',
	      nameTextStyle: {
	        color: 'rgb(255,255,255)',
	        fontSize: FONT_SIZE_TEXT,
	        fontWeight: 700,
	      },
	      type: 'value',
	      min: MIN_Y,
	      max: MAX_Y,
	      axisTick: {
	        show: false,
	      },
	      axisLine: {
	        show: false,
	      },
	      axisLabel: {
	        show: true,
	        color: 'rgb(255,255,255)',
	        fontSize: FONT_SIZE_TEXT,
	        fontWeight: 700,
	      },
	      splitLine: {
	        show: true,
	        lineStyle: {
	          color: colorLine
	        }
	      }
	    },
	    series: [
	      // 5%
	      {
	        type: 'line',
	        silent: true,
	        smooth: true,
	        stack: 'agp',
	        stackStrategy: 'positive',
	        areaStyle: {
	          color: 'transparent',
	        },
	        lineStyle: {
	          color: 'transparent'
	        },
	        itemStyle: itemStyle,
	        data: this.getLine(0)
	      },
	      // 25% - [5%]
	      {
	        type: 'line',
	        silent: true,
	        smooth: true,
	        stack: 'agp',
	        stackStrategy: 'positive',
	        areaStyle: {
	          color: '#426246',
	        },
	        lineStyle: {
	          color: 'transparent'
	        },
	        itemStyle: itemStyle,
	        data: this.getLine(1)
	      },
	      // 50%
	      {
	        type: 'line',
	        silent: true,
	        smooth: true,
	        lineStyle: {
	          color: '#9FFFAC'
	        },
	        itemStyle: itemStyle,
	        data: this.getLine(2)
	      },
	      // 75% - [25%] - [5%]
	      {
	        type: 'line',
	        silent: true,
	        smooth: true,
	        stack: 'agp',
	        stackStrategy: 'positive',
	        areaStyle: {
	          color: '#3A8344',
	        },
	        lineStyle: {
	          color: 'transparent'
	        },
	        itemStyle: itemStyle,
	        data: this.getLine(3)
	      },
	      // 95% - [75%] - [25%] - [5%]
	      {
	        type: 'line',
	        silent: true,
	        smooth: true,
	        stack: 'agp',
	        stackStrategy: 'positive',
	        areaStyle: {
	          color: '#426246',
	        },
	        lineStyle: {
	          color: 'transparent'
	        },
	        itemStyle: itemStyle,
	        markArea: markArea,
	        data: this.getLine(4)
	      },
	    ]
	  };
		
	  if (isMobile) {
	    o.grid.left = 24;
	    o.grid.top = 36;
	    o.grid.right = 4;
	    o.grid.bottom = 36;
	  }
		
	  return o;
	}
	
	private _isValueEmpty(field: keyof AgpValueDTO): boolean {
	  return this._isValueInfoEmpty || this._entity.value_info[field] === undefined;
	}
	
	private get _isValueInfoEmpty(): boolean {
	  return !this._entity || !this._entity.value_info || isObjectNull(this._entity.value_info);
	}
	
}
