import dayjs, {Dayjs} from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import type {AgpGetDTO} from '@/modules/glucose/dto/agp.dto';


/**
 * 血糖分析 过滤器 VO
 */
export class AgpFilterVO {
  
  private _admissionId: number;
  private _startDay: Dayjs;
  private _endDay: Dayjs;
  
  constructor() {
    const today = dayjs().hour(0).minute(0).second(0).millisecond(0);
    this._admissionId = INVALID_ID;
    this._startDay = today.subtract(15, 'd');
    this._endDay = today;
  }
  
  
  public get admissionId(): number {
    return this._admissionId;
  }
  public set admissionId(v) {
    this._admissionId = v;
  }
  
  
  public set startDay(v) {
    this._startDay = v;
  }
  public get startDay(): Dayjs {
    return this._startDay;
  }
  
  
  public set endDay(v) {
    this._endDay = v;
  }
  public get endDay(): Dayjs {
    return this._endDay;
  }
  
  
  public set range(v) {
    this._startDay = v[0];
    this._endDay = v[1];
  }
  public get range(): [Dayjs, Dayjs] {
    return [this._startDay, this._endDay];
  }
  
  
  public get dto(): AgpGetDTO {
    return {
      admission_id: this._admissionId,
      start_date: this._startDay.format('YYYY-MM-DD'),
      end_date: this._endDay.format('YYYY-MM-DD')
    };
  }
  
}
