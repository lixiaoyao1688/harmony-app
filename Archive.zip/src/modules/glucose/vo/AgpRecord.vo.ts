import dayjs from 'dayjs';
import {throwFieldLackError} from '@/lib/http/util/http.utils';
import {AGP_PATH} from '@/modules/glucose/requests/glu.http';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {realRoundTo1Digit} from '@/lib/math/util/math.util';
import {APG_RECORD_KIND_MAP, APG_RECORD_KIND_TO_ID_MAP} from '@/modules/glucose/config/agp.record.kind';
import type { AgpRecordDTO } from '@/modules/glucose/dto/agp.dto';


/**
 * 血糖分析 记录点 VO
 */
export class AgpRecordVO {
  
  private readonly _entity: AgpRecordDTO | null;
  private readonly _index: number;
  
  constructor(i: number, e?: AgpRecordDTO) {
    this._index = i;
    this._entity = e || null;
  }
  
  
  public get id(): number {
    return  this._index;
  }
  
  
  public get timestamp(): number {
    if (!this._entity || !this._entity.record_dt) {
      return 0;
    }
    return dayjs(this._entity.record_dt).unix();
  }
  
  public get timeText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('record_dt');
    return this._entity.record_dt;
  }
  
  // 监测日期，格式: YYYY-MM-DD
  public get dateText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('record_dt');
    return this._entity.record_dt.split(' ')[0];
  }
  
  // 监测时刻，格式: HH:mm:ss
  public get timeText2(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('record_dt');
    return this._entity.record_dt.split(' ')[1];
  }
  
  public get valueText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('value');
    return this._entity.value.toString();
  }
  public get valueText2(): string {
    if (!this._entity) {
      return '--';
    }
    return realRoundTo1Digit(this._entity.value).toString();
  }
  

  public get kindText(): string {
    if (!this._entity) {
      return '--';
    }
    this._checkField('kind');
    const id = APG_RECORD_KIND_TO_ID_MAP.get(this._entity.kind);
    return id ? SelectItemVO.getText(APG_RECORD_KIND_MAP, id) : '--';
  }
  
  
  private _checkField<T>(field: keyof AgpRecordDTO, fieldChild?: keyof T): void {
    if (!this._entity) {
      return;
    }
    if (this._entity[field] === undefined) {
      throwFieldLackError(field, AGP_PATH.GET_ANA);
    }
    else if (fieldChild && (this._entity[field] as unknown as T)[fieldChild] === undefined) {
      throwFieldLackError(`${field}.${fieldChild as string}`, AGP_PATH.GET_ANA);
    }
  }
  
}
