import dayjs, {Dayjs} from 'dayjs';
import { FingerReportRowVO } from '@/modules/glucose/vo/FingerReportRow.vo';
import {realRoundTo1Digit} from '@/lib/math/util/math.util';
import {getDayFromText} from '@/lib/time/util/dayjs.util';
import {GLU_RECORD_KIND} from '@/modules/glucose/config/agp.record.kind';
import type {FingerRecordDTO} from '@/modules/glucose/dto/agp.dto';


/**
 * 指血数据表 VO
 */
export class FingerReportVO {
	
	private readonly _entity: Array<FingerRecordDTO> | null;  // 指血检测记录
	private readonly _start: Dayjs;  // 注意: 需考虑 start 和 end 是同一天的情况
	private readonly _end: Dayjs;  // 注意: 需考虑 start 和 end 是同一天的情况
	
	constructor(e?: Array<FingerRecordDTO>, startText?: string, endText?: string) {
	  this._start = startText ? getDayFromText(startText) : dayjs().subtract(7, 'd');
	  this._end = endText ? getDayFromText(endText) : dayjs();
	  this._entity = e ? e.filter(dto => dto.kind === GLU_RECORD_KIND.FINGER) : null;
	}
	
	// 检测数
	public get count(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.length.toString();
	}
	
	// 平均血糖
	public get mg(): string {
	  if (!this._entity || !this._entity.length) {
	    return '--';
	  }
	  const data = this._entity;
	  const count = data.length;
	  const totalValue = data.reduce((pre,cur) => realRoundTo1Digit(pre + cur.value), 0);
	  return realRoundTo1Digit(totalValue / count).toString();
	}
	
	// 日均检测
	public get mgCount(): string {
	  if (!this._entity || this._end.unix() < this._start.unix()) {
	    return '--';
	  }
	  const dayDiff = this._end.diff(this._start, 'd');
	  const dayCount = dayDiff > 1 ? dayDiff : 1;
	  const totalCount = this._entity.length;
	  return Math.round(totalCount / dayCount).toString();
	}
	
	// 检测表
	public get rows(): Array<FingerReportRowVO> {
	  if (!this._entity) {
	    return [];
	  }
		
	  // 日期（时间戳）: 指血记录
	  const map = new Map<number, Array<FingerRecordDTO>>();
	  const vos: Array<FingerReportRowVO> = [];
		
	  this._entity.forEach(e => {
	    const id = this._getYMDTimeFromDateText(e.record_dt);
	    const records = map.get(id) || [];
	    records.push({...e});
	    map.set(id, records);
	  });
		
	  map.forEach((records, timestamp) => {
	    vos.push(new FingerReportRowVO(records, timestamp));
	  });
		
	  return vos;
	}
	
	private _getYMDTimeFromDateText(formatText: string): number {
	  if (!this._entity) {
	    return dayjs().unix();
	  }
	  const [ymd] = formatText.split(' ');
	  const [y,mo,d] = ymd.split('-');
	  return dayjs().year(+y).month(Math.floor((+mo) - 1)).date(+d).hour(0).minute(0).second(0).millisecond(0).unix();
	}
	
}
