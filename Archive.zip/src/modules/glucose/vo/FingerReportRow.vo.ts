import dayjs from 'dayjs';
import { INVALID_ID } from '@/utils/global.vo.help';
import type {FingerRecordDTO} from '@/modules/glucose/dto/agp.dto';


/**
 * 指血数据表 每行的结构
 */
export class FingerReportRowVO {
	
	// private readonly _entity: MergeRecordDTO | undefined;
	private readonly _entity: Array<FingerRecordDTO> | null;
	private readonly _timestamp: number | null;   // 日期，时间戳，秒;
	
	// constructor(e?: MergeRecordDTO) {
	//   this._entity = e;
	// }
	constructor(e?: Array<FingerRecordDTO>, timestamp?: number) {
	  this._entity = e || null;
	  this._timestamp = timestamp || null;
	}
	
	public get id(): number {
	  // if (!this._entity || this._entity.item_start_time === undefined) {
	  //   return INVALID_ID;
	  // }
	  // return this._entity.item_start_time;
	  if (!this._timestamp) {
	    return INVALID_ID;
	  }
	  return this._timestamp;
	}
	
	// 日期，YYYY-MM-DD;
	public get date(): string {
	  // if (!this._entity || this._entity.item_start_time === undefined) {
	  //   return '--';
	  // }
	  // return getYYYYMMDDFromServerTime(this._entity.item_start_time);
	  if (!this._timestamp) {
	    return '--';
	  }
	  return dayjs.unix(this._timestamp).format('YYYY-MM-DD');
	}
	
	// 检测数
	public get count(): string {
	  // if (!this._entity || this._entity.item_start_time === undefined) {
	  //   return '--';
	  // }
	  // return this._entity.finger_info.length.toString();
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.length.toString();
	}
	
}