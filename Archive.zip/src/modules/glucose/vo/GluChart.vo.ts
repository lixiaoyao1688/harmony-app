import { CARD_CHART, isGlu } from '@/modules/record/config/card.config';
import {getGluSeriesBaseConfig, GLU} from '@/modules/glucose/config/glu.config';
import { fillZero, serverTimeToWebTime } from '@/lib/time/util/time.util';
import { CHART_CONFIG } from '@/modules/chart/config/chart.config';
import { getDecodeHtml, getXAxisLabelFormatter } from '@/modules/chart/utils/chart.util';
import { getGluColorByValue } from '@/modules/glucose/utils/glu.util';
import {
  MINUTES_PER_HOUR,
  MS_PER_MINUTE,
  MS_PER_SECOND,
  ONE_MINUTE,
  SECONDS_PER_MINUTE,
  MINUTES_PER_INDEX,
  INDEX_FIVE_MINUTES
} from '@/lib/time/config/time.config';
import {getCgmThreshold} from '@/modules/glucose/utils/cgm.threshold.util';
import {GLU_KIND, GLU_KIND_ITEM_MAP} from '@/modules/glucose/config/glu.kind';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {ADVICE_SMART_AID_TARGET} from '@/modules/advice-closed-loop/config/advice.cl.smart.aid.target';
import {BLOOD_BG_COLOR} from '@/modules/glucose/config/blood.config';
import {realRoundTo1Digit} from '@/lib/math/util/math.util';
import type { CGMRecordDTO, ChartRecordDTO } from '@/modules/admission/dto/card.dto';
import type { ChartTooltipFormatParamType, ChartYDataType } from '@/modules/glucose/types/finger.blood.chart.type';


/**
 * 血糖图 VO
 */
export class GluChartVO {
	
	private readonly _low: number;  // 低血糖阈值
	private readonly _high: number;  // 高血糖阈值
	private readonly _startTime: number;
	private readonly _records: Array<ChartRecordDTO>;  // 指血、静脉血记录
	private readonly _cgmRecords: Array<CGMRecordDTO>;  // CGM记录
	private readonly _smartAIDTarget: ADVICE_SMART_AID_TARGET;  // 闭环目标线 mmol/L
	private readonly _symbolSize: [number, number];  // 散点图标尺寸: [宽,高], px
	private readonly _symbolLabelBgColor: string;  // 散点图底部数值的背景色，默认 BLOOD_BG_COLOR(@\src\modules\glucose\config\blood.config.ts)
	private readonly _isSymbolLabelShowed: boolean;  // 是否显示散点图标底部数值，默认"是"

	constructor(startTime: number, fingerRecords: Array<ChartRecordDTO>, low: number, high: number, cgmRecords: Array<CGMRecordDTO>, aid?: ADVICE_SMART_AID_TARGET, ss?: [number, number], isSymbolLabelShowed?: boolean, symbolLabelBgColor?: string) {
	  this._startTime = startTime;
	  this._records = fingerRecords;
	  this._low = low || GLU.RANGE_MIN_DEFAULT;
	  this._high = high || GLU.RANGE_MAX_DEFAULT;
	  this._cgmRecords = cgmRecords;
	  this._smartAIDTarget = aid || ADVICE_SMART_AID_TARGET.CLOSED;
	  this._symbolSize = ss || [11,13];
	  this._isSymbolLabelShowed = isSymbolLabelShowed === undefined ? true : isSymbolLabelShowed;
	  this._symbolLabelBgColor = symbolLabelBgColor || BLOOD_BG_COLOR;
	}
	
	public get high(): number {
	  return this._high;
	}
	
	public get low(): number {
	  return this._low;
	}
	
	private _encodeCGM(): Array<ChartYDataType> {
	  if (!this._cgmRecords || !this._cgmRecords.length) {
	    return [];
	  }
	  const yData = [] as Array<ChartYDataType>;
	  this._cgmRecords.forEach(d => {
	    const indexOfMinute = Math.floor((d.start_time - this._startTime) / SECONDS_PER_MINUTE);
	    const value = d.value;
			
	    yData.push({
	      value: [indexOfMinute, value],
	      visualMap: true,
		    payload: {
	        recordTime: serverTimeToWebTime(d.start_time),
		    }
	    });
	  });
		
	  return yData;
	}
	
	private _encodeFinger(): Array<ChartYDataType> {
	  if (!this._records || !this._records.length) {
	    return [];
	  }
		
	  const yData = [] as Array<ChartYDataType>;
	  const dtos = this._records;
	  const len = dtos.length;
		
	  for (let i = 0; i < len; i++) {
	    const d = dtos[i];
	    const indexOfMinute = Math.floor((d.record_time - this._startTime) / SECONDS_PER_MINUTE);
	    // fix(pc): http://192.168.1.236:81/redmine/issues/7858
	    // fix(app): http://192.168.1.236:81/redmine/issues/7861
	    const value = realRoundTo1Digit(d.value);
			
	    const data: ChartYDataType = {
	      value: [indexOfMinute, value],
	      visualMap: false,
	      itemStyle: {
	        color: getGluColorByValue(value, this._low, this._high)
	      },
	      payload: {
	        recordTime: serverTimeToWebTime(d.record_time),
	        kind: d.sub_kind as GLU_KIND,
	        isFromCheckin: d.isFromCheckin || false
	      },
	    };
			
	    // fix(pc): http://192.168.1.236:81/redmine/issues/7349
	    if (i > 0) {
	      const lastData = yData[i - 1];
	      const [lastIndex, lastValue] = lastData.value;
	      // index: 1 个索引代表 1 分钟
	      // 10分钟以内打的指血会错开
	      if (indexOfMinute - lastIndex < 10) {
	        if (value >= lastValue) {
	          data.label = { position: 'top' };
	        }  else {
	          lastData.label = { position: 'top' };
	        }
	      }
	    }
	    yData.push(data);
	  }
		
	  return yData;
	}
	
	private _decodeFinger(p: ChartTooltipFormatParamType): string {
	  const f = fillZero;
	  const data = p.data;
	  const indexOfMinute = data.value[0];
	  const value = data.value[1];
	  const name = data.payload ? SelectItemVO.getText(GLU_KIND_ITEM_MAP, data.payload.kind as GLU_KIND) : '血糖';
		
	  const bgColor = getGluColorByValue(value, this._low, this._high);
	  const valueText = value + ' ' + GLU.UNIT_1;
	  const d = new Date(this._startTime * MS_PER_SECOND + (indexOfMinute * MS_PER_MINUTE));
		
	  return getDecodeHtml(
	    bgColor,
		  CARD_CHART.TEXT_COLOR,
	    valueText,
	    name,
	    `${f(d.getMonth()+1)}-${f(d.getDate())} ${f(d.getHours())}:${f(d.getMinutes())}`,
	    '',
	    '',
	    '12px'
	  );
	}
	
	
	/**
	 * 将相邻数据点的 x 超过阈值（默认5分钟）的数据截成两段重新拼接，返回处理完成后的配置项列表。
	 *
	 * @param minutesPerXIndex x轴刻度代表的分钟数
	 * @param cgm 原始的 cgm 的 echarts series 配置项
	 * @param axisIndex 坐标轴索引
	 */
	public static getSplitCgmSeries<T extends { data: Array<ChartYDataType> }>(minutesPerXIndex: number, cgm: T, axisIndex: number): Array<T> {
	  const rawData = [...cgm.data];
	  rawData.sort((a,b) => a.value[0] - b.value[0]);  // 按 x 轴时间升序排列;
	  const { data, ...otherOptions } = cgm;
		
	  const series: Array<T> = [];  // 存储处理完成的配置项
	  let currentData: Array<ChartYDataType> = [];  // 存储某一段不超过阈值的数据
		
	  // 阈值（分钟）
	  // const threshold = 5;
	  const threshold = getCgmThreshold(rawData, minutesPerXIndex);
		
	  // 构造新的配置项
	  const getSeriesItem = (data: Array<ChartYDataType>, i: number) => ({ ...otherOptions, data: data, xAxisIndex: i, yAxisIndex: i }) as unknown as T;
		
		
	  if (rawData.length === 0) {
	    // 处理空数据
	    series.push(getSeriesItem([], axisIndex));
	  }
	  else {
	    for (let i = 0, len = rawData.length; i < len; i++) {
	      if (i > 0) {
	        // 当前点与前一点在x轴上的刻度数
	        const xIndexes = Math.floor(rawData[i].value[0] - rawData[i-1].value[0]);
	        if (xIndexes * minutesPerXIndex > threshold) {
	          // 当前点与前一点在x轴上的距离超过阈值，保存当前配置项
	          series.push(getSeriesItem(currentData, axisIndex));
	          // 清空存储，准备存储下一段数据
	          currentData = [];
	        }
	      }
	      currentData.push(rawData[i]);
	    }
	    // 不要忘记添加最后一个配置项
	    if (currentData.length > 0) {
	      series.push(getSeriesItem(currentData, axisIndex));
	    }
	  }
		
	  return series;
	}
	
	public get series() {
	  return [
		  {
	      ...getGluSeriesBaseConfig(this._low, this._high, this._smartAIDTarget, this._symbolSize, this._isSymbolLabelShowed, this._symbolLabelBgColor),
	      // itemStyle: {
	      //   borderColor: 'rgb(255,255,255)',
	      //   borderWidth: 1,
	      //   color: 'rgb(38,111,232)',
	      // },
	      tooltip: {
	        formatter: (p: ChartTooltipFormatParamType) => this._decodeFinger(p),
	        position: (pos, params, dom, rect, size) => {
	          // 参考:
	          // https://echarts.apache.org/zh/option.html#tooltip.position
						
	          // 鼠标left (x0 到鼠标的水平距离) (指血点的x)
	          const mouseLeft = pos[0];
	          // 图表width
	          const viewWidth = size.viewSize[0];
	          // 浮窗width
	          const tooltipWidth = size.contentSize[0];
						
	          // 是否右侧溢出: 鼠标left + 浮窗width > 图表width;
	          const isRightOverflow = (mouseLeft + tooltipWidth) > viewWidth;
	          // 是否左侧溢出: 浮窗width > 鼠标left;
	          const isLeftOverflow = viewWidth > mouseLeft;
						
	          // 最终浮窗的位置（left, top）
	          const obj = { top: pos[1] };
	          // 左右都溢出
	          if (isLeftOverflow && isRightOverflow) {
	            // 鼠标是否在图表最左三分之一区域
	            const isLeftEx = mouseLeft < (viewWidth / 3);
	            // 鼠标是否在图表最右四分之一区域
	            const isRightEx = mouseLeft > (viewWidth * 3 / 4);
							
	            if (isLeftEx) {
	              // 显示在右侧
	              obj['left'] = mouseLeft;
	            }
	            else if (isRightEx) {
	              // 显示在左侧
	              obj['left'] = mouseLeft - tooltipWidth;
	            }
	            else {
	              // 鼠标在相对居中的位置，显示在中间
	              obj['left'] = mouseLeft - (tooltipWidth / 2);
	            }
	          }
	          // 仅右侧溢出，显示在左侧
	          else if (isRightOverflow) {
	            obj['left'] = mouseLeft - tooltipWidth;
	          }
	          // 仅左侧溢出，显示在右侧
	          else {
	            obj['left'] = mouseLeft;
	          }
	          return obj;
	        }
	      },
	      emphasis: {
	        disabled: true
	      },
	      data: this._encodeFinger(),
		  },
		  {
			  type: 'line',
			  name: 'cgm',
			  smooth: true,
			  cursor: 'default',
			  itemStyle: {
				  opacity: 0,
			  },
			  tooltip: {
	        show: false,
			  },
			  data: this._encodeCGM(),
		  }
	    // V1.0 中，处理"理糖宝CGM过于分散时，院泵患者区块中看不见CGM数据点"的方式。
	    // {
	    //   type: 'line',
	    //   name: 'cgm',
	    //   smooth: true,
	    //   cursor: 'default',
	    //   symbol: 'circle',
	    //   symbolSize: 3, // 增加到3px，确保在小图中也能看见
	    //   showSymbol: true, // 确保所有点都显示
	    //   showAllSymbol: true, // 强制显示所有符号，禁用自动优化
	    //   sampling: 'none', // 禁用采样，确保所有点都渲染
	    //   itemStyle: {
	    //     opacity: 1, // 显示点
	    //   },
	    //   lineStyle: {
	    //     width: 1, // 线宽1px
	    //   },
	    //   tooltip: {
	    //     show: false,
	    //   },
	    //   data: this._encodeCGM(),
	    // }
	  ];
	}
	
	// cgm + finger
	// 1 个索引占 5 分钟
	public get config5() {
	  const c = { ...this.config };
	  c.series.forEach(s=> {
	    // 每个 x 索引变为原来的 5 分之一，如果在某一个区间 (5分钟) 内有多个点，则只取最后一个点。一般来说，cgm 3 分钟有一个数据。
	    // 过滤后的数组
	    const uniqueData: Array<ChartYDataType> = [];
	    // 存放有数据的 index。
	    const set = new Set();
	    // 按时间逆序
	    for (let i = s.data.length - 1; i >= 0; i--) {
	      const d = s.data[i];
	      const index = d.value[0];
	      const value = d.value[1];
	      // 压缩索引
	      const newIndex = Math.floor(index / INDEX_FIVE_MINUTES);
	      if (!set.has(newIndex)) {
	        // 只取最后一个点，前面的点丢弃。
	        set.add(newIndex);
	        uniqueData.unshift({ ...d, value: [newIndex, value] });
	      }
	    }
	    s.data = uniqueData;
	  });
	  return c;
	}
	
	// 1 个索引占 3 分钟
	public get config3() {
	  const c = { ...this.config };
	  c.series.forEach(s => {
	    s.data.forEach(d => {
	      // 每个 X 索引变为原来的三分之一
	      d.value = [Math.floor(d.value[0] / MINUTES_PER_INDEX), d.value[1]];
	    });
	  });
	  return c;
	}
	
	// 1 个索引占 1 分钟
	public get config() {
	  const yMax = GLU.MAX;
		
	  // 2024-08-09: 去除异常情况的 Y 轴变化，超过 GLU.MAX 的血糖值不再处理。
	  // if (FingerBloodChartVO.hasOversizeData(this._records) || FingerBloodChartVO.hasOversizeCGMData(this._cgmRecords)) {
	  //   yMax = GLU.MAX_OVERSIZE;
	  //   // @ts-ignore
	  //   series[0].markLine.data[1].yAxis = GLU.MARK_VALUE_OVERSIZE;
	  // }
		
	  return {
	    grid: {
	      left: 40,
	      right: 20,
	      top: 10,
	      bottom: 20,
	    },
	    animation: false,
	    backgroundColor: 'transparent',
		  tooltip: {
	      show: true,
	      trigger: 'item',
	      extraCssText: 'padding: 0 !important;',
	      position: function (point: Array<number>, _, dom: Element, __, size) {
	    	  // point: 鼠标位置 [x,y]。 左上角点是 [0,0]。
	    	  // dom: 鼠标悬停显示的 dom 结点。
	    	  // size.viewSize: canvas容器尺寸，如 [x,y]。

	    	  const dw = (dom ? (dom.clientWidth || 0) : 0);
	    	  const dh = (dom ? (dom.clientHeight || 0) : 0);
	    	  const cw = size.viewSize[0] || 0;

	    	  const x = point[0];
	    	  const y = point[1];

	    	  // 默认top在点的上方，left居中。
	    	  const DEFAULT_Y = y - dh - 10;
	    	  const DEFAULT_X = x - dw / 2;

	    	  let top = DEFAULT_Y;
	    	  if (DEFAULT_Y < 0) {
	    		  top = y + 10;
	    	  }

	    	  let left = DEFAULT_X;
	    	  if (DEFAULT_X < 0) {
	    		  left = x;
	    	  } else if (x + dw / 2 > cw) {
	    		  left = x - dw;
	    	  }

	    	  return { left: left, top: top };
	      },
		  },
	    visualMap: {
	      show: false,  // 仅保留数据映射的功能，不显示组件
	      type: 'piecewise',
	      pieces: [
	        { gt: this._high, color: GLU.HIGH.COLOR },
	        { gte: this._low, lte: this._high, color: GLU.NORMAL.COLOR_CGM },
	        { gte: GLU.MIN, lt: this._low, color: GLU.LOW.COLOR },
	      ]
	    },
	    xAxis: {
	      type: 'category',
	      data: CHART_CONFIG.X_DATA,
	      axisLabel: {
	        show: true,
	        color: CHART_CONFIG.TEXT_COLOR,
	        fontSize: CHART_CONFIG.FONT_SIZE_XXS,
	        interval: MINUTES_PER_HOUR * 4 - ONE_MINUTE,
	        formatter: getXAxisLabelFormatter(true, this._startTime),
	      },
	      axisTick: {
	        show: false,
	      },
	      axisLine: {
	        show: true,
	        lineStyle: {
	          color: CHART_CONFIG.AXIS_LINE_COLOR
	        }
	      }
	    },
	    yAxis: {
		    name: '',
		    nameTextStyle: {
	        color: CHART_CONFIG.TEXT_COLOR,
		    },
	      type: 'value',
	      min: GLU.MIN,
	      max: yMax,
	      axisTick: {
	        show: false,
	      },
	      axisLine: {
	        show: true,
	        lineStyle: {
	          color: CHART_CONFIG.AXIS_LINE_COLOR
	        }
	      },
	      axisLabel: {
	        show: false,
	        color: CHART_CONFIG.TEXT_COLOR,
	        fontSize: CHART_CONFIG.FONT_SIZE_XXS,
	      },
	      splitLine: {
	        show: false,
	      }
	    },
	    series: this.series
	  };
	}
	
	public static hasOversizeData(records: Array<ChartRecordDTO>): boolean {
	  return !!records.filter(data => isGlu(data.status)).find(data => data.value > GLU.MAX);
	}
	
	public static hasOversizeCGMData(cgmRecords: Array<CGMRecordDTO>): boolean {
	  return !!cgmRecords.find(data => data.value > GLU.MAX);
	}
	
}
