import { GLU } from '@/modules/glucose/config/glu.config';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { GluChartVO } from '@/modules/glucose/vo/GluChart.vo';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { ChartGluSingleVO } from '@/modules/glucose/vo/GluSingle.vo';
import type { ChartDailyResponseDTO, MergeRecordDTO } from '@/modules/record/dto/chart.daily.dto';


/**
 * 一段时间的每日血糖 VO
 */
export class GluDayVO {
	
	public charts: Array<ChartGluSingleVO>;
	
	constructor(e?: ChartDailyResponseDTO) {
	  this.charts = this._getCharts(e ? e.record_list : []);
	}
	
	private _getCharts(e: Array<MergeRecordDTO>): Array<ChartGluSingleVO> {
	  const cs: Array<ChartGluSingleVO> = [];
	  const isMobile = useScreenStore().isMobile;
	  const admission = useAdmissionStore().admission;
		
	  for (let i = 0, len = e.length; i < len; i++) {
	    const data = e[i];
	    const time = data.item_start_time;
		  const c = new GluChartVO(data.item_start_time, data.finger_info, admission.gluLow, admission.gluHigh, data.cgm_info).config;
			
	    c.grid.top = 30;
	    // c.title.show = true;
		  c.yAxis.name = GLU.UNIT_1;
			
		  if (isMobile) {
			  c.grid.left = 30;
			  c.grid.right = 30;
			  c.grid.top = 50;
			  c.grid.bottom = 30;
		  }
			
	    cs.push(new ChartGluSingleVO(time, c, data.value_info, data.cgm_info));
	  }
	  return cs;
	}

}
