import { GLU } from '@/modules/glucose/config/glu.config';
import { fillZero } from '@/lib/time/util/time.util';
import { getPercentTextFromDigit } from '@/lib/math/util/math.util';
import { getGluLevelIndex, getGluLevelReverse } from '@/modules/glucose/utils/agp.util';
import { StackedBarItemVO } from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';
import { AdmissionVO } from '@/modules/admission/vo/Admission.vo';
import { GLU_ANA_LEVEL } from '@/modules/glucose/dto/agp.dto';
import type { GluHourAgpType } from '@/modules/glucose/types/glu.hour.types';
import type { GluHourReportDTO, GluHourTimeDTO } from '@/modules/glucose/dto/glu.hour.report.dto';


/**
 * 多日分时段血糖详情表
 * 每小时的数据 VO
 */
export class GluHourVO {
	
	private readonly _hourIndex: number;  // 24小时时刻索引 范围0~23
	private readonly _entityAGP: GluHourAgpType | undefined;
	private readonly _entityTime: GluHourTimeDTO | undefined;
	private readonly _admission: AdmissionVO | undefined;
	
	constructor(i: number, e?: GluHourReportDTO, admission?: AdmissionVO) {
	  this._hourIndex = i;
	  this._entityTime = this._getEntityTime(i, e);
	  this._entityAGP = this._getEntityAGP(i, e);
	  this._admission = admission;
	}
	
	
	public get id(): number {
	  return this._hourIndex + 1;
	}
	
	// 时间段(h) 如 "00-01"、"01-02"...
	public get timeField(): string {
	  const start = this._hourIndex;
	  const end = start === 23 ? 0 : start + 1;
	  return `${fillZero(start)}-${fillZero(end)}`;
	}
	
	// 血糖阈值范围 文本
	public get superLowRangeText(): string {
	  if (!this._admission) {
	    return '--';
	  }
	  return '很低 ' + this._admission.getGluRangeText(GLU_ANA_LEVEL.SUPER_LOW);
	}
	
	public get lowRangeText(): string {
	  if (!this._admission) {
	    return '--';
	  }
	  return '偏低 ' + this._admission.getGluRangeText(GLU_ANA_LEVEL.LOW);
	}
	
	public get okRangeText(): string {
	  if (!this._admission) {
	    return '--';
	  }
	  return '正常 ' + this._admission.getGluRangeText(GLU_ANA_LEVEL.OK);
	}
	
	public get highRangeText(): string {
	  if (!this._admission) {
	    return '--';
	  }
	  return '偏高 ' + this._admission.getGluRangeText(GLU_ANA_LEVEL.HIGH);
	}
	
	public get superHighRangeText(): string {
	  if (!this._admission) {
	    return '--';
	  }
	  return '很高 ' + this._admission.getGluRangeText(GLU_ANA_LEVEL.SUPER_HIGH);
	}
	
	
	
	// 探头数值量
	public get count(): string {
	  if (!this._entityTime || this._entityTime.count === undefined) {
	    return '--';
	  }
	  return this._entityTime.count.toString();
	}
	
	// 下限
	public get bottom(): string | undefined {
	  if (!this._entityTime || !this._entityTime.glucose_range || this._entityTime.glucose_range.length < 4) {
	    return undefined;
	  }
	  return this._entityTime.glucose_range[1].toString();
	}
	
	// 上限
	public get top(): string | undefined {
	  if (!this._entityTime || !this._entityTime.glucose_range || this._entityTime.glucose_range.length < 4) {
	    return undefined;
	  }
	  return this._entityTime.glucose_range[2].toString();
	}
	

	
	public get isTirEmpty(): boolean {
	  return !this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length;
	}
	// 达标
	public get ok(): string {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return '--';
	  }
	  return this._getTirData(this._entityTime.tir_list[getGluLevelIndex(GLU_ANA_LEVEL.OK)]);
	}
	// 很高
	public get superHigh(): string {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return '--';
	  }
	  return this._getTirData(this._entityTime.tir_list[getGluLevelIndex(GLU_ANA_LEVEL.SUPER_HIGH)]);
	}
	// 偏高
	public get high(): string {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return '--';
	  }
	  return this._getTirData(this._entityTime.tir_list[getGluLevelIndex(GLU_ANA_LEVEL.HIGH)]);
	}
	// 很低
	public get superLow(): string {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return '--';
	  }
	  return this._getTirData(this._entityTime.tir_list[getGluLevelIndex(GLU_ANA_LEVEL.SUPER_LOW)]);
	}
	// 偏低
	public get low(): string {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return '--';
	  }
	  return this._getTirData(this._entityTime.tir_list[getGluLevelIndex(GLU_ANA_LEVEL.LOW)]);
	}
	public get tirItems(): Array<StackedBarItemVO> {
	  // @ts-ignore
	  return getGluLevelReverse().map(it => new StackedBarItemVO(it.id, it.text, this._getData(it.id), it.payload.color, GLU.LEVEL.DIGITS));
	}
	public get firstDataIndex(): number {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return 0;
	  }
	  const items = getGluLevelReverse();
	  for (let i = 0, len = items.length; i < len; i++) {
	    if (this._getData(items[i].id) > 0) {
	      return i;
	    }
	  }
	  return 0;
	}
	public get lastDataIndex(): number {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return 0;
	  }
	  const items = getGluLevelReverse();
	  for (let i = items.length - 1; i > -1; i--) {
	    if (this._getData(items[i].id) > 0) {
	      return i;
	    }
	  }
	  return 0;
	}
	private _getTirData(val: number): string {
	  return getPercentTextFromDigit(val, 1);
	}
	private _getData(index: number): number {
	  if (!this._entityTime || !this._entityTime.tir_list || this._entityTime.tir_list.length < GLU.LEVEL.ITEMS.length) {
	    return 0;
	  }
	  return this._entityTime.tir_list[index];
	}
	
	
	// 平均葡萄糖
	public get mg(): string {
	  if (!this._entityTime || this._entityTime.mg === undefined) {
	    return '--';
	  }
	  return this._entityTime.mg.toString();
	}
	
	// 葡萄糖标准差
	public get sd(): string {
	  if (!this._entityTime || this._entityTime.sd === undefined) {
	    return '--';
	  }
	  return this._entityTime.sd.toString();
	}
	
	// 变异系数
	public get cv(): string {
	  if (!this._entityTime || this._entityTime.cv === undefined) {
	    return '--';
	  }
	  return this._entityTime.cv.toString();
	}
	
	
	// 5%-95% 区间
	public get agpFiveToNinetyFive(): string {
	  if (!this._entityAGP || this._entityAGP.fiveToNinetyFive === undefined) {
	    return '--';
	  }
	  return this._entityAGP.fiveToNinetyFive;
	}
	
	// 50%
	public get agpFifty(): string {
	  if (!this._entityAGP || this._entityAGP.fifty === undefined) {
	    return '--';
	  }
	  return this._entityAGP.fifty;
	}
	
	// 25%-75% 区间-IQR
	public get agpTwentyFiveToSeventyFive(): string {
	  if (!this._entityAGP || this._entityAGP.twentyFiveToSeventyFive === undefined) {
	    return '--';
	  }
	  return this._entityAGP.twentyFiveToSeventyFive;
	}
	
	private _getEntityTime(i: number, e?: GluHourReportDTO): GluHourTimeDTO | undefined {
	  if (!e || !e.time_list || e.time_list.length < 24) {
	    return undefined;
	  }
	  return e.time_list[i] || undefined;
	}
	
	private _getEntityAGP(i: number, e?: GluHourReportDTO): GluHourAgpType | undefined {
	  if (!e || !e.apg_info || e.apg_info.length < 3) {
	    return undefined;
	  }
	  return {
	    fiveToNinetyFive: e.apg_info[0][i],
	    fifty: e.apg_info[1][i],
	    twentyFiveToSeventyFive: e.apg_info[2][i],
	  };
	}
}
