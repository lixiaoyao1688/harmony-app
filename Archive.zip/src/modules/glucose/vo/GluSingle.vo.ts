import { INVALID_ID } from '@/utils/global.vo.help';
import { SECONDS_PER_MINUTE } from '@/lib/time/config/time.config';
import { baseFormatTime, getMMDDFromServerTime, getYYYYMMDDFromServerTime } from '@/lib/time/util/time.util';
import { getPercentTextFromDigit, roundTo } from '@/lib/math/util/math.util';
import type { MergeDTO } from '@/modules/record/dto/merge.dto';
import type { ECBasicOption } from 'echarts/types/src/util/types';
import type { CgmInfoDTO, CGMLine } from '@/modules/glucose/dto/cgm.dto';


/**
 * 每日血糖 VO
 */
export class ChartGluSingleVO {
	
	private readonly _value: MergeDTO;
	private readonly _startTime: number;
	private readonly _cgmInfo: Array<CgmInfoDTO>;
	
	public configGlu: ECBasicOption;
	
	constructor(startTime: number, configGlu: ECBasicOption, value: MergeDTO, cgmInfo: Array<CgmInfoDTO>) {
	  this._value = value;
	  this._startTime = startTime;
	  this._cgmInfo = cgmInfo;
	  this.configGlu = configGlu;
	}
	
	public get id(): number {
	  return this._startTime || INVALID_ID;
	}
	
	public get cgmLine(): CGMLine {
	  return {
	    date: this.dateText,
	    data: this._cgmInfo.map(d => ([
	      Math.floor((d.start_time - this._startTime) / SECONDS_PER_MINUTE),
	      d.value
	    ])),
	  };
	}
	
	public get simpleDateText(): string {
	  return getMMDDFromServerTime(this._startTime, '/');
	}
	
	public get dateText(): string {
	  return getYYYYMMDDFromServerTime(this._startTime);
	}
	
	
	
	// 多日血糖报告 - LAGE
	public get lage(): string {
	  if (!this._value || this._value.lage === undefined) {
	    return '--';
	  }
	  return this._value.lage.toString();
	}
	
	// 多日血糖报告 - MAGE
	public get mage(): string {
	  if (!this._value || this._value.mage === undefined) {
	    return '--';
	  }
	  return this._value.mage.toString();
	}
	
	// 多日血糖报告 - MODD 平均血糖波动幅度
	public get modd(): string {
	  if (!this._value || this._value.modd === undefined) {
	    return '--';
	  }
	  return this._value.modd.toString();
	}
	
	// 多日血糖报告 - SD 日间血糖平均绝对差
	public get sd(): string {
	  if (!this._value || this._value.sd === undefined) {
	    return '--';
	  }
	  return this._value.sd.toString();
	}
	
	// 多日血糖报告 - CV 日间血糖平均绝对差
	public get cv(): string {
	  if (!this._value || this._value.cv === undefined) {
	    return '--';
	  }
	  return this._value.cv.toString();
	}
	
	
	public get isMgValid(): boolean {
	  return this._value && this._value.mg_glucose !== undefined;
	}
	public get mg(): string {
	  if (!this._value || this._value.mg_glucose === undefined) {
	    return '--';
	  }
	  return this.mgVal.toString();
	}
	public get mgVal(): number {
	  if (!this._value || this._value.mg_glucose === undefined) {
	    return 0;
	  }
	  return roundTo(this._value.mg_glucose, 1);
	}
	
	
	public get isTirValid(): boolean {
	  return !!(this._value && this._value.tir_list && this._value.tir_list.length >= 3);
	}
	public get tir(): string {
	  if (!this._value || !this._value.tir_list || this._value.tir_list.length < 3) {
	    return '--';
	  }
	  return getPercentTextFromDigit(this._value.tir_list[1], 1);
	}
	public get tirTime(): string {
	  if (!this._value || !this._value.tir_time || this._value.tir_time.length < 3) {
	    return '--';
	  }
	  return this._getFormatTime(this._value.tir_time[1]);
	}
	
	
	public get tar(): string {
	  if (!this._value || !this._value.tir_list || this._value.tir_list.length < 3) {
	    return '--';
	  }
	  return getPercentTextFromDigit(this._value.tir_list[2], 1);
	}
	public get tarTime(): string {
	  if (!this._value || !this._value.tir_time || this._value.tir_time.length < 3) {
	    return '--';
	  }
	  return this._getFormatTime(this._value.tir_time[2]);
	}
	
	
	public get tbr(): string {
	  if (!this._value || !this._value.tir_list || this._value.tir_list.length < 3) {
	    return '--';
	  }
	  return getPercentTextFromDigit(this._value.tir_list[0], 1);
	}
	public get tbrTime(): string {
	  if (!this._value || !this._value.tir_time || this._value.tir_time.length < 3) {
	    return '--';
	  }
	  return this._getFormatTime(this._value.tir_time[0]);
	}
	
	
	private _getFormatTime(timestamp: number): string {
	  const data = baseFormatTime(timestamp, 'sec', 'min', 'h', 'd');
	  if (!data[0][1] && !data[1][1]) {
	    return '0h';
	  }
	  if (!data[1][1]) {
	    return data[0][1] + data[0][0];
	  }
	  return data[0][1] + data[0][0] + data[1][1] + data[1][0];
	}
	
	public get isTIREmpty(): boolean {
	  return !this._value || !this._value.tir_list || this._value.tir_list.length < 3;
	}
	
	public get isTIRTimeEmpty(): boolean {
	  return !this._value || !this._value.tir_time || this._value.tir_time.length < 3;
	}
	
	
}
