import { Dayjs } from 'dayjs';
import { INVALID_ID } from '@/utils/global.vo.help';
import { getDayjsFromServerTimeText } from '@/lib/time/util/time.util';
import type { HbaDTO } from '@/modules/glucose/dto/hba.dto';


/**
 * 糖化血红蛋白 检测记录 VO
 */
export class HbaVO {

  private readonly _entity: HbaDTO | null;
  private readonly _dayTime: Dayjs | null;
  
  constructor(e?: HbaDTO) {
    this._entity = e || null;
    this._dayTime = e && e.record_dt ? getDayjsFromServerTimeText(e.record_dt) : null;
  }
  
  // 唯一标识
  public get id(): number {
    if (this._dayTime === null) {
      return INVALID_ID;
    }
    return this._dayTime.unix();
  }
  
  // 检测日期
  public get dateText(): string {
    if (this._dayTime === null) {
      return '--';
    }
    return this._dayTime.format('YYYY/MM/DD');
  }
  
  // 检测时间
  public get timeText(): string {
    if (this._dayTime === null) {
      return '--';
    }
    return this._dayTime.format('HH:mm:ss');
  }
  
  // 检测值 %
  public get valueText(): string {
    if (!this._entity) {
      return '--';
    }
    return this._entity.value + '%';
  }
  
}
