<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { ONE } from '@/lib/math/config/math.config';
import { LogLoginVO } from '@/modules/log-login/vo/LogLogin.vo';
import { LogLoginTableVO } from '@/modules/log-login/vo/LogLogin.table.vo';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { httpLogLoginGet } from '@/modules/log-login/requests/log.login.http';
import {
  getColumnForMobile,
  getDataSource,
  getPaginationAfterFetching,
  getPaginationOnMobile,
  getPaginationOnPC
} from '@/lib/aaruy-design/table/normal/util/table.normal.util';
import { TABLE_DEFAULT_TOTAL_SIZE } from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import TableNormal from '@/lib/aaruy-design/table/normal/TableNormal.vue';
import LogLoginFilter from '@/modules/log-login/components/LogLoginFilter.vue';
import { FIRST_PAGE, TableScrollType } from '@/lib/aaruy-design/table/table';
import { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import TableLayout from '@/lib/aaruy-design/table/layout/TableLayout.vue';
import type { TableColumnType, TablePaginationConfig } from 'ant-design-vue';
import type { LogLoginGetDTO, LogLoginGetFilterDTO } from '@/modules/log-login/dto/log.login.dto';


const userStore = useUserStore();
const screenStore = useScreenStore();

const COLUMNS: TableColumnType[] = [
  { title: '序号', dataIndex: 'index', width: '5%', fixed: false },
  { title: '用户账号', dataIndex: 'account', width: '10%', fixed: false },
  { title: '用户名', dataIndex: 'name', width: '10%', fixed: false },
  { title: 'IP地址', dataIndex: 'ip', width: '20%', fixed: false },
  { title: '操作系统', dataIndex: 'os', width: '20%', fixed: false },
  { title: '登录所用的浏览器', dataIndex: 'browser', width: '10%', fixed: false },
  { title: '登录时间', dataIndex: 'loginTime', width: '20%', fixed: false }
];
const MOBILE_WIDTHS: number[] = [80,100,100,200,200,100,240];

const loading = ref<boolean>(false);
const dataSource = ref<LogLoginTableVO[]>([]);
const total = ref<number>(TABLE_DEFAULT_TOTAL_SIZE);
const filter = ref<LogLoginGetFilterDTO>(getInitFilter());
const columns = ref<TableColumnType[]>(screenStore.isPC ? COLUMNS : getColumnForMobile(COLUMNS, MOBILE_WIDTHS));
const pagination = ref<TablePaginationConfig>(screenStore.isPC ? getPaginationOnPC() : getPaginationOnMobile());

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const scroll = computed<TableScrollType | null>(() => pc.value ? null : ({ x: MOBILE_WIDTHS.reduce((acc, cur) => acc + cur) - ONE }));


onMounted(() => {
  refresh();
});

function refresh(): void {
  fetchData(pagination.value.current, pagination.value.pageSize);
}

function onPageChange(p: PaginationData): void {
  fetchData(p.page, p.pageSize);
}

function onFilterChange(data: LogLoginGetFilterDTO): void {
  filter.value = data;
}

function onSearch(): void {
  fetchData(FIRST_PAGE);
}

function onReset(): void {
  resetFilter();
  fetchData(FIRST_PAGE);
}

function resetFilter(): void {
  filter.value = getInitFilter();
}

function getInitFilter(): LogLoginGetFilterDTO {
  return {
    username: '',
    name: '',
    start_dt: '',
    end_dt: '',
    box1: '',
  };
}

function fetchData(current?: number, pageSize?: number): void {
  const body: LogLoginGetDTO = {};
  const c = current || pagination.value.current as number;
  const p = pageSize || pagination.value.pageSize as number;

  body.page = c;
  body.limit = p;
	
  if (filter.value.username) {
    body.username = filter.value.username;
  }
  if (filter.value.name) {
    body.name = filter.value.name;
  }
  if (filter.value.start_dt) {
    body.start_dt = filter.value.start_dt;
  }
  if (filter.value.end_dt) {
    body.end_dt = filter.value.end_dt;
  }
  if (filter.value.box1) {
    body.box1 = filter.value.box1;
  }

  loading.value = true;
  httpLogLoginGet(body)
    .then(data => {
      total.value = data.total;
      dataSource.value = getDataSource<LogLoginVO, LogLoginTableVO>(data.vos, COLUMNS.map(d => d.dataIndex as string), c, p);
      pagination.value = getPaginationAfterFetching(pagination.value, c, p, total.value);
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => loading.value = false);
}
</script>

<template>
  <LogLoginFilter :filter="filter" @filter-change="onFilterChange" @search="onSearch" @reset="onReset" />
	<div v-if="pc" class="px-16">
		<TableLayout>
			<template #default="{ height }">
				<TableNormal
					:loading="loading"
					:pagination="pagination"
					:columns="columns"
					:dataSource="dataSource"
					:scroll="{ y: height - 336 }"
					@onChange="onPageChange"
				/>
			</template>
		</TableLayout>
	</div>
	<div v-if="mobile" class="log-login-table-mobile">
		<TableNormal
			:loading="loading"
			:pagination="pagination"
			:columns="columns"
			:dataSource="dataSource"
			:scroll="scroll"
			@onChange="onPageChange"
		/>
	</div>
</template>

<style scoped>
.log-login-table-mobile {
  overflow: auto;
  width: 100vw;
  height: calc(100% - 100px);
}
</style>
