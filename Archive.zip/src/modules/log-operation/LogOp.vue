<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useLogOpStore } from '@/modules/log-operation/store/log.op.store';
import { LogOpVO } from '@/modules/log-operation/vo/LogOp.vo';
import { LogOpTableVO } from '@/modules/log-operation/vo/LogOp.table.vo';
import TableNormal from '@/lib/aaruy-design/table/normal/TableNormal.vue';
import LogOpDetail from '@/modules/log-operation/components/LogOpDetail.vue';
import LogOperationFilter from '@/modules/log-operation/components/LogOpFilter.vue';
import {
  getColumnForMobile,
  getDataSource,
  getPaginationAfterFetching,
  getPaginationOnMobile, getPaginationOnPC
} from '@/lib/aaruy-design/table/normal/util/table.normal.util';
import { httpLogOperationGet } from '@/modules/log-operation/requests/log.op.http';
import { ONE } from '@/lib/math/config/math.config';
import { TABLE_DEFAULT_TOTAL_SIZE } from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import { FIRST_PAGE, TableScrollType } from '@/lib/aaruy-design/table/table';
import { INVALID_ID } from '@/utils/global.vo.help';
import { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import TableLayout from '@/lib/aaruy-design/table/layout/TableLayout.vue';
import type { TableColumnType, TablePaginationConfig } from 'ant-design-vue';
import type { LogOpGetDTO, LogOpGetFilterDTO } from '@/modules/log-operation/dto/log.op.dto';


/**
 * 操作日志 组件
 * 仅管理员
 */
const store = useLogOpStore();
const userStore = useUserStore();
const screenStore = useScreenStore();

const COLUMNS: TableColumnType[] = [
  { title: '序号', dataIndex: 'index', width: '4%', fixed: false },
  { title: '用户账号', dataIndex: 'account', width: '10%', fixed: false },
  { title: '用户名', dataIndex: 'name', width: '8%', fixed: false },
  { title: '操作模块', dataIndex: 'opModule', width: '10%', fixed: false },
  { title: '操作功能', dataIndex: 'opMethod', width: '10%', fixed: false },
  { title: '请求地址', dataIndex: 'url', width: '30%', fixed: false },
  { title: '请求状态', dataIndex: 'statusHtml', width: '10%', fixed: false },
  { title: '操作时间', dataIndex: 'opTime', width: '12%', fixed: false },
  { title: '操作', dataIndex: 'operator', width: '6%', fixed: false },
];
const MOBILE_WIDTHS: number[] = [80,100,150,100,100,400,100,200,100];

const loading = ref<boolean>(false);
const dataSource = ref<LogOpTableVO[]>([]);
const total = ref<number>(TABLE_DEFAULT_TOTAL_SIZE);
const filter = ref<LogOpGetFilterDTO>(getInitFilter());
const columns = ref<TableColumnType[]>(screenStore.isPC ? COLUMNS : getColumnForMobile(COLUMNS, MOBILE_WIDTHS));
const pagination = ref<TablePaginationConfig>(screenStore.isPC ? getPaginationOnPC() : getPaginationOnMobile());

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const scroll = computed<TableScrollType | null>(() => pc.value ? null : ({ x: MOBILE_WIDTHS.reduce((acc, cur) => acc + cur) - ONE }));


onMounted(() => {
  refresh();
});

function refresh() {
  fetchData(pagination.value.current, pagination.value.pageSize);
}

function onPageChange(p: PaginationData) {
  fetchData(p.page, p.pageSize);
}

function onFilterChange(data: LogOpGetFilterDTO) {
  filter.value = data;
}

function onSearch() {
  fetchData(FIRST_PAGE);
}

function onReset() {
  resetFilter();
  fetchData(FIRST_PAGE);
}

function resetFilter() {
  filter.value = getInitFilter();
}

function getInitFilter(): LogOpGetFilterDTO {
  return {
    username: '',
    operation_module: INVALID_ID,
    start_dt: '',
    end_dt: '',
    box1: '',
  };
}

function fetchData(current?: number, pageSize?: number) {
  const body: LogOpGetDTO = {};
  const c = current || pagination.value.current as number;
  const p = pageSize || pagination.value.pageSize as number;
	
  body.page = c;
  body.limit = p;
	
  if (filter.value.username) {
    body.username = filter.value.username;
  }
  if (filter.value.operation_module !== INVALID_ID) {
    body.operation_module = filter.value.operation_module;
  }
  if (filter.value.start_dt) {
    body.start_dt = filter.value.start_dt;
  }
  if (filter.value.end_dt) {
    body.end_dt = filter.value.end_dt;
  }
  if (filter.value.box1) {
    body.box1 = filter.value.box1;
  }
	
  loading.value = true;
  httpLogOperationGet(body)
    .then(data => {
      total.value = data.total;
      dataSource.value = getDataSource<LogOpVO, LogOpTableVO>(data.vos, COLUMNS.map(d => d.dataIndex as string), c, p);
      pagination.value = getPaginationAfterFetching(pagination.value, c, p, total.value);
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => loading.value = false);
}
</script>

<template>
  <LogOperationFilter :filter="filter" @filter-change="onFilterChange" @search="onSearch" @reset="onReset" />
  
	<div v-if="pc" class="px-16">
		<TableLayout>
			<template #default="{ height }">
				<TableNormal
					:loading="loading"
					:pagination="pagination"
					:columns="columns"
					:dataSource="dataSource"
					:scroll="{ y: height - 336 }"
					@onChange="onPageChange"
				>
					<template #cell="{ column, record }">
						<template v-if="column.dataIndex === 'statusHtml'">
							<span v-html="record.relatedVO.statusHtml"></span>
						</template>
					</template>
					<template #operator="{ record }">
						<LogOpDetail :vo="record.relatedVO" />
					</template>
				</TableNormal>
			</template>
		</TableLayout>
	</div>
	
	<div v-if="mobile" class="log-op-table-mobile">
		<TableNormal
			:loading="loading"
			:pagination="pagination"
			:columns="columns"
			:dataSource="dataSource"
			:scroll="scroll"
			@onChange="onPageChange"
		>
			<template #cell="{ column, record }">
				<template v-if="column.dataIndex === 'statusHtml'">
					<span v-html="record.relatedVO.statusHtml"></span>
				</template>
			</template>
			<template #operator="{ record }">
				<LogOpDetail :vo="record.relatedVO" />
			</template>
		</TableNormal>
	</div>

</template>

<style scoped>
.log-op-table-mobile {
  overflow: auto;
  width: 100vw;
  height: calc(100% - 100px);
}
</style>
