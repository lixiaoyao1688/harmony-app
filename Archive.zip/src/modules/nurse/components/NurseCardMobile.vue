<script setup lang="ts">
import { NurseVO } from '@/modules/nurse/vo/Nurse.vo';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import NurseCardMobileItem from '@/modules/nurse/components/NurseCardMobileItem.vue';


interface Prop {
	vo: NurseVO;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
</script>

<template>
  <div>
    <div style="height: 40px; line-height: 40px;"
         :class="{ 'text-s': screenStore.isPad, 'text-xs': screenStore.isNewPhone }"
         class="flex justify-between px-10 text-white font-bold bg-12 rounded-t-4">
      <span>{{ vo.timeTextApp }}</span>
      <span>{{ vo.staffName }}</span>
    </div>
		<div class="bg-18">
      <div v-if="vo.isEvent" class="px-16 pt-12 pb-8">
        <span :class="{ 'text-s': screenStore.isPad, 'text-xs': screenStore.isNewPhone }" class="text-weak-8">事件</span>
        <span class="text-lg leading-l font-bold ml-8">{{ vo.eventTextApp }}</span>
      </div>
      <template v-else>
        <div class="flex items-center px-16 pt-12 pb-8">
          <NurseCardMobileItem title="泵运行" :value="vo.pumpRunningText" :color="vo.pumpRunningTextColor" class="w-33" />
          <NurseCardMobileItem title="泵敷贴" :value="vo.pumpStickText" :color="vo.pumpStickTextColor" class="w-33" />
          <NurseCardMobileItem title="泵穿刺点" :value="vo.pumpPunctureText" :color="vo.pumpPunctureTextColor" class="w-33" />
        </div>
        <div class="flex items-center px-16 py-8">
          <NurseCardMobileItem title="泵管路" :value="vo.pumpPipeText" :color="vo.pumpPipeTextColor" class="w-33" />
          <NurseCardMobileItem title="CGM敷贴" :value="vo.cgmStickText" :color="vo.cgmStickTextColor" class="w-33" />
          <NurseCardMobileItem title="CGM穿刺点" :value="vo.cgmPunctureText" :color="vo.cgmPunctureTextColor" class="w-33" />
        </div>
      </template>
			<div v-if="!vo.isPumpUp" class="px-16 pt-8 pb-12" >
				<div :class="{ 'text-s': screenStore.isPad, 'text-xs': screenStore.isNewPhone }" class="text-weak-8">备注: {{ vo.remarkText }}</div>
			</div>
<!--			<div class="p-16 flex justify-end items-end">-->
<!--        <span class="mr-12">责任护士：</span>-->
<!--				<a-image :src="vo.signUrl" alt="护士签名" width="100px" />-->
<!--			</div>-->
		</div>
	</div>
</template>
