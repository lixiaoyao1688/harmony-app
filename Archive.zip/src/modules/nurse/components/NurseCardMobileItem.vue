<script setup lang="ts">
import {useScreenStore} from '@/lib/screen/store/screen.store';

interface Prop {
	title: string;
	value: string;
	color?: string;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
</script>

<template>
	<div>
		<div :class="{ 'text-s': screenStore.isPad, 'text-xs': screenStore.isNewPhone }"
         class="text-weak-8">{{ title }}</div>
		<div class="text-lg leading-l font-bold" :style="{ color: color || 'rgb(255,255,255)' }">{{ value }}</div>
	</div>
</template>
