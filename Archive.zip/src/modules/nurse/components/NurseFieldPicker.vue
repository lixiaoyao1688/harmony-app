<script setup lang="ts">
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {NURSE_LEVEL} from '@/modules/nurse/config/nurse.level';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import type {NurseItem} from '@/modules/nurse/types/nurse.type';


/**
 * 护理记录 字段选择器
 */
interface Prop {
  name: string;
  items: Array<NurseItem>;
  item: SelectItemVO<NurseItem>;
}

interface Emit {
  (e: 'change', data: NurseItem): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();

function onChange(data: NurseItem): void {
  emit('change', data);
}
</script>

<template>
  <div class="w-full flex justify-between items-center">
    <div :class="{ 'text-xs': screenStore.isNewPhone, 'text-s': !screenStore.isNewPhone }" class="text-white font-normal">{{ name }}</div>
    <div class="inline-flex items-center rounded-4" style="background-color: rgb(36,44,51);">
      <div v-for="it in items" :key="it.id"
           style="height: 28px; line-height: 26px;"
           class="nurse-item rounded-4 font-bold text-center px-8"
           :class="{
             'selected-level-0': it.id === item.id && item.payload.level === NURSE_LEVEL.LOW,
             'selected-level-1': it.id === item.id && item.payload.level === NURSE_LEVEL.MID,
             'selected-level-2': it.id === item.id && item.payload.level === NURSE_LEVEL.HIGH,
             'text-xs': screenStore.isNewPhone,
             'text-s': !screenStore.isNewPhone
           }"
           @click="onChange(it)">{{ it.text }}</div>
    </div>
  </div>
</template>

<style scoped>
.nurse-item {
  color: rgb(162,173,184);
  border-width: 1px;
  border-style: solid;
  border-color: rgb(36,44,51);
}

.nurse-item.selected-level-0 {
  color: rgb(245,245,245);
  border-color: rgb(105,158,245);
  background-color: rgba(105,158,245,0.2);
}

.nurse-item.selected-level-1 {
  color: rgb(245,245,245);
  border-color: rgb(253,190,82);
  background-color: rgba(253,190,82,0.2);
}

.nurse-item.selected-level-2 {
  color: rgb(245,245,245);
  border-color: rgb(245,75,80);
  background-color: rgba(245,75,80,0.2);
}
</style>
