export const TEXT_COLOR_0 = 'rgb(245,245,245)';
export const TEXT_COLOR_1 = 'rgb(253,190,82)';
export const TEXT_COLOR_2 = 'rgb(245,75,80)';