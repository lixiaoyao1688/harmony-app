// 仅PC
export const NURSE_COLUMNS = [
  {
    title: '日期时间',
    dataIndex: 'timeText',
    width: '12%',
  },
  {
    title: '泵运行',
    dataIndex: 'pumpText2',
    width: '8%',
  },
  {
    title: '管路状态',
    dataIndex: 'pipeText2',
    width: '10%',
  },
  {
    title: '泵穿刺点状态',
    dataIndex: 'punctureText2',
    width: '11%',
  },
  {
    title: '泵敷贴',
    dataIndex: 'stickText2',
    width: '8%',
  },
  {
    title: 'CGM穿刺点状态',
    dataIndex: 'cgmPunctureText2',
    width: '12%',
  },
  {
    title: 'CGM敷贴',
    dataIndex: 'cgmStickText2',
    width: '5%',
  },
  {
    title: '事件',
    dataIndex: 'eventText',
    width: '12%',
  },
  {
    title: '备注',
    dataIndex: 'remarkText2',
    width: '11%',
  },
  {
    title: '签名',
    dataIndex: 'signUrl',
    width: '11%',
    isImage: true,
  },
];
