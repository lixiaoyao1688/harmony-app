export enum NURSE_LEVEL {
  LOW = 0,
  MID,
  HIGH
}
