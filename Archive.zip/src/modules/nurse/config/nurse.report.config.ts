import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


export enum NURSE_REPORT {
	RECORD = 1000,  // 护理记录
}

export const NURSE_REPORTS = [
  new SelectorFormItemVO(NURSE_REPORT.RECORD, '护理记录'),
];
