/**
 * 护理/检测/换泵记录 新增 类型
 *
 * 配置
 */
export enum OPERATION_KIND {
  NURSE = 0,  // 护理
  INSPECTION,  // 检测
  REPLACE_SUPPLIES,  // 换耗材
  UNBIND_PUMP,  // 下泵
  BIND_PUMP,  // 上泵
  PUMP_CHANGED  // 换泵
}
