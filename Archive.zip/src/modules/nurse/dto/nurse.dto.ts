import { STICK } from '@/modules/nurse/dto/nurse.help.stick.dto';
import { NURSE_COMMON, NURSE_PIPE } from '@/modules/nurse/dto/nurse.help.dto';
import { PUNCTURE } from '@/modules/nurse/dto/nurse.help.puncture.dto';
import { OPERATION_KIND } from '@/modules/nurse/config/operation.kind';
import { INSPECTION_NODE } from '@/modules/glucose/config/inspection.node';
import { INSPECTION_KIND } from '@/modules/glucose/config/inspection.kind';
import { SUPPLIES_KIND } from '@/modules/pump/config/supplies.kind';
import { PUMP_UNBIND_REASON } from '@/modules/plan/config/pump.unbind.reason';


/**
 * 护理记录 DTO
 */
export interface NurseDTO {
	admission_id: number;  // 患者id
	create_time:	string;  // 创建时间
	ct:	string;  // CT
	hospital_id: number;  // 归属医院
	id: number;  // 唯一标识
	mri: string;  // MRI
	pipe_status: NURSE_PIPE;  // 管路状态
	pump_status: NURSE_COMMON;  // 泵运行
	puncture_status: PUNCTURE;  // 穿刺点状态
	record_dt: string;  // 护理时间，如 "2024-01-11 09:11:15"
	record_time: number;  // 护理时间，时间戳
	remark: string;  // 备注，kind=5 时为泵号
	signature: string;  // 个人签名文件名
	signature_url: string;  // 个人签名 图片地址
	stick_status: STICK;  // 敷贴
	staff_name: string;  // 操作者名字
	update_time: string;  // 更新时间
	cgm_puncture_status: PUNCTURE;  // CGM穿刺点状态
	cgm_stick_status: STICK;  // CGM敷贴
	kind: OPERATION_KIND;  //	类型
	supply_kind?: SUPPLIES_KIND; // 换耗材类型
	unbind_pump_kind?: PUMP_UNBIND_REASON;  // 下泵原因
}

/**
 * 护理记录 查 DTO
 * https://192.168.1.249:85/project/75/interface/api/4038
 */
export interface NurseGetDTO {
	admission_id: number;  // 患者id
	kind?: OPERATION_KIND;  //	类型 0-护理 1-检测 2-换耗材 3-下泵 不传-除检测外所有记录
	start_time?: number;  // 开始日期 00:00 分的时间戳
	end_time?: number;  // 结束日期后一天的 00:00分的时间戳  (不给 start_time,end_time 默认为最近七天)
}

/**
 * 护理/检测/换泵记录 新增 DTO
 */
export interface NurseAddDTO {
	admission_id: number;  // 患者id
	record_dt: string;  // 操作时间, 如: 2025-06-03 09:11:15 （【换耗材】下代表"更换时间"）
	pump_status?: NURSE_COMMON;  //	【护理记录】-泵运行 0-正常 1-暂停 2-异常
	pipe_status?: NURSE_PIPE;  //	【护理记录】-管路状态 0-正常 1-打折 2-脱管
	puncture_status?: PUNCTURE;  //	【护理记录】-穿刺点状态 0-正常 1-红肿热痛
	stick_status?: STICK;  //	【护理记录】-腹贴 0-正常 1-卷边
	ct?: string;  // 【护理记录】-CT 长度 20以内
	mri?: string;  //【护理记录】-MRI  长度 20以内
	remark?: string;  //	备注  长度 50以内
	kind: OPERATION_KIND;  //	类型
	record_kind?: INSPECTION_KIND;  // 【检测】-类型 1-指血 2-静脉血 3-糖化血红蛋白
	scene_id?: INSPECTION_NODE;  //	 【检测】-指血-检测节点 : 0夜间，1空腹，2早餐后，3午餐前，4午餐后，5晚餐前，6晚餐后，7睡前，8随机
	value?: number;  // 【检测】-测量结果
	supply_kind?: SUPPLIES_KIND;  // 【换耗材】更换类型
	cgm_puncture_status?: PUNCTURE;  //【护理记录】CGM穿刺点状态 0-正常 1-红肿热痛
	cgm_stick_status?: STICK;  //【护理记录】CGM腹贴 0-正常 1-卷边
	next_record_dt?: string;  //	【换耗材】下次更换时间, 如: 2025-06-03 09:11:15
	unbind_pump_kind?: PUMP_UNBIND_REASON;  //	下泵原因
	staff_name?: string;  // 操作者姓名
}
