import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {NURSE_LEVEL} from '@/modules/nurse/config/nurse.level';
import type {NurseItemPayload} from '@/modules/nurse/types/nurse.type';


export enum NURSE_COMMON {
	NORMAL = 0,   // 正常
	STOP,  // 暂停
	WEIRD,  // 异常
}

export enum NURSE_PIPE {
  NORMAL = 0,   // 正常
  STOP,  // 打折
  WEIRD,  // 脱管
}

export const NURSE_COMMON_OPTIONS = [
  new SelectorFormItemVO(NURSE_COMMON.NORMAL, '正常'),
  new SelectorFormItemVO(NURSE_COMMON.STOP, '暂停'),
  new SelectorFormItemVO(NURSE_COMMON.WEIRD, '异常'),
];

export const NURSE_COMMON_OPTIONS_2 = [
  new SelectItemVO<NurseItemPayload>({ id: NURSE_COMMON.NORMAL, text: '正常', payload: { level: NURSE_LEVEL.LOW } }),
  new SelectItemVO<NurseItemPayload>({ id: NURSE_COMMON.STOP, text: '暂停', payload: { level: NURSE_LEVEL.MID } }),
  new SelectItemVO<NurseItemPayload>({ id: NURSE_COMMON.WEIRD, text: '异常', payload: { level: NURSE_LEVEL.HIGH } }),
];

export const NURSE_PIPE_OPTIONS = [
  new SelectItemVO<NurseItemPayload>({ id: NURSE_PIPE.NORMAL, text: '正常', payload: { level: NURSE_LEVEL.LOW } }),
  new SelectItemVO<NurseItemPayload>({ id: NURSE_PIPE.STOP, text: '打折', payload: { level: NURSE_LEVEL.MID } }),
  new SelectItemVO<NurseItemPayload>({ id: NURSE_PIPE.WEIRD, text: '脱管', payload: { level: NURSE_LEVEL.HIGH } }),
];

export const NURSE_COMMON_MAP = new Map(
  NURSE_COMMON_OPTIONS.map(s => ([s.id, s]))
);

export const NURSE_COMMON_MAP_2 = new Map(
  NURSE_COMMON_OPTIONS_2.map(s => ([s.id, s]))
);

export const NURSE_PIPE_MAP = new Map(
  NURSE_PIPE_OPTIONS.map(s => ([s.id, s]))
);
