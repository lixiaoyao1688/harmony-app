import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {NURSE_LEVEL} from '@/modules/nurse/config/nurse.level';
import type {NurseItemPayload} from '@/modules/nurse/types/nurse.type';


export enum PUNCTURE {
	NORMAL = 0,
	HOT,
}

export const PUNCTURES = [
  new SelectorFormItemVO(PUNCTURE.NORMAL, '正常'),
  new SelectorFormItemVO(PUNCTURE.HOT, '红肿热痛'),
];

export const PUNCTURES_2 = [
  new SelectItemVO<NurseItemPayload>({ id: PUNCTURE.NORMAL, text: '正常', payload: { level: NURSE_LEVEL.LOW } }),
  new SelectItemVO<NurseItemPayload>({ id: PUNCTURE.HOT, text: '红肿热痛', payload: { level: NURSE_LEVEL.HIGH } }),
];

export const PUNCTURE_MAP = new Map(
  PUNCTURES.map(s => ([s.id, s]))
);

export const PUNCTURE_MAP_2 = new Map(
  PUNCTURES_2.map(s => ([s.id, s]))
);
