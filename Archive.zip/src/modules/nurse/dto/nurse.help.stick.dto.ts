import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {NURSE_LEVEL} from '@/modules/nurse/config/nurse.level';
import type {NurseItemPayload} from '@/modules/nurse/types/nurse.type';


export enum STICK {
	NORMAL = 0,
	SCROLL,
}

export const STICKS = [
  new SelectorFormItemVO(STICK.NORMAL, '正常'),
  new SelectorFormItemVO(STICK.SCROLL, '卷边'),
];

export const STICKS_2 = [
  new SelectItemVO<NurseItemPayload>({ id: STICK.NORMAL, text: '正常', payload: { level: NURSE_LEVEL.LOW } }),
  new SelectItemVO<NurseItemPayload>({ id: STICK.SCROLL, text: '卷边', payload: { level: NURSE_LEVEL.MID } }),
];

export const STICK_MAP = new Map(
  STICKS.map(s => ([s.id, s]))
);

export const STICK_MAP_2 = new Map(
  STICKS_2.map(s => ([s.id, s]))
);

