<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44">
    <g id="iconNurse" data-name="组 152" transform="translate(-1130 -1225)">
      <rect id="iconNurseRect" data-name="time (Background)" width="44" height="44" transform="translate(1130 1225)" fill="none"/>
      <g id="iconNurseRectG" data-name="组 151" transform="translate(2 2.5)">
        <rect id="iconNurseRectGRect1" data-name="矩形 76" width="3" height="13" rx="1" transform="translate(1133 1237)" fill="#fff"/>
        <path id="iconNurseRectGPath1" data-name="矩形 82" d="M0,0H3A0,0,0,0,1,3,0V6A1,1,0,0,1,2,7H1A1,1,0,0,1,0,6V0A0,0,0,0,1,0,0Z" transform="translate(1133 1246)" fill="#fff"/>
        <path id="iconNurseRectGPath2" data-name="矩形 83" d="M0,0H4A0,0,0,0,1,4,0V6A1,1,0,0,1,3,7H1A1,1,0,0,1,0,6V0A0,0,0,0,1,0,0Z" transform="translate(1164 1246)" fill="#fff"/>
        <path id="iconNurseRectGPath3" data-name="矩形 79" d="M3,0H20a3,3,0,0,1,3,3V5a1,1,0,0,1-1,1H1A1,1,0,0,1,0,5V3A3,3,0,0,1,3,0Z" transform="translate(1143 1236)" fill="#fff"/>
        <rect id="iconNurseRectGRect2" data-name="矩形 81" width="35" height="7" rx="1" transform="translate(1133 1243)" fill="#fff"/>
        <rect id="iconNurseRectGRect3" data-name="矩形 80" width="5" height="3" rx="1.5" transform="translate(1137 1239)" fill="#fff"/>
      </g>
    </g>
  </svg>
</template>
