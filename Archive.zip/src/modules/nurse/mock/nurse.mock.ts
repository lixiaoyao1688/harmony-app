import {randomInEnum} from '@/lib/math/util/math.util';
import {STICK} from '@/modules/nurse/dto/nurse.help.stick.dto';
import {NURSE_COMMON, NURSE_PIPE} from '@/modules/nurse/dto/nurse.help.dto';
import {PUNCTURE} from '@/modules/nurse/dto/nurse.help.puncture.dto';
import {getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {OPERATION_KIND} from '@/modules/nurse/config/operation.kind';
import {SUPPLIES_KIND} from '@/modules/pump/config/supplies.kind';
import type {NurseDTO} from '@/modules/nurse/dto/nurse.dto';


export const NURSE_MOCKING = false;

export function MOCK_nurse(): Array<NurseDTO> {
  const re = randomInEnum;
  const start = getTodayDayjs();
  
  return Array(10).fill(0).map((_,i) => {
    const timeDay = start.subtract(i, 'd').add(i,'h').add(i,'m');
    const timestamp = timeDay.unix();
    const time = timeDay.format('YYYY-MM-DD HH:mm:ss');
    
    return {
      admission_id: i+1,
      create_time: time,
      ct:	'下泵',
      hospital_id: i+1,
      id: i+1,
      mri: '下泵',
      pipe_status: re(NURSE_PIPE.NORMAL, NURSE_PIPE.STOP, NURSE_PIPE.WEIRD),
      pump_status: re(NURSE_COMMON.NORMAL, NURSE_COMMON.STOP, NURSE_COMMON.WEIRD),
      puncture_status: re(PUNCTURE.NORMAL, PUNCTURE.HOT),
      cgm_puncture_status: re(PUNCTURE.NORMAL, PUNCTURE.HOT),
      cgm_stick_status: re(STICK.NORMAL, STICK.SCROLL),
      record_dt: time,
      record_time: timestamp,
      remark: '护理完成',
      signature: '',
      signature_url: 'http://192.168.1.181:2000/hospital/file/staff-signature/2497ae044b4d11f08d79e0be037f63e4.png',
      stick_status: re(STICK.NORMAL, STICK.SCROLL),
      update_time: time,
      kind: OPERATION_KIND.REPLACE_SUPPLIES,
      supply_kind: re(SUPPLIES_KIND.DRUG_RESERVOIR, SUPPLIES_KIND.SUBCUTANEOUS_INJECTION_SET, SUPPLIES_KIND.TUBELESS_SUBCUTANEOUS_INJECTION_SET),
      staff_name: ''
    };
		
  });
}
