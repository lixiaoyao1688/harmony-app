<script setup lang="ts">
import { watch } from 'vue';
import { INVALID_ID } from '@/utils/global.vo.help';
import { REPORT } from '@/modules/report/configs/report.config';
import { SECONDS_PER_DAY } from '@/lib/time/config/time.config';
import { NURSE_COLUMNS } from '@/modules/nurse/config/nurse.column';
import { useNurseStore } from '@/modules/nurse/store/nurse.store';
import { useReportStore } from '@/modules/report/store/report.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { getDefaultRange } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import { OPERATION_KIND } from '@/modules/nurse/config/operation.kind';
import ReportView from '@/modules/report/views/ReportView.vue';
import type { NurseGetDTO } from '@/modules/nurse/dto/nurse.dto';


/**
 * 护理记录 报告
 */
const store = useNurseStore();
const reportStore = useReportStore();
const admissionStore = useAdmissionStore();


const commonStyle = {
  border: '1px solid rgb(153,153,153)',
  padding: '8px 4px',
  lineHeight: '16px'
};
const tdStyle = commonStyle;
const thStyle = {
  ...commonStyle,
  fontWeight: 400,
};

watch(() => reportStore.config.range, (newRange) => {
  if (admissionStore.admission.id === INVALID_ID) {
    notifyErrorNormal('未选中患者');
    return;
  }
  const body: NurseGetDTO = {
    admission_id: admissionStore.admission.id,
    kind: OPERATION_KIND.NURSE
  };

  if (newRange && newRange[0] && newRange[1]) {
    body.start_time = newRange[0].unix();
    body.end_time = newRange[1].unix() + SECONDS_PER_DAY;
  }
  else {
    // 无日期时，请求最近七天
    const r = getDefaultRange();
    body.start_time = r[0].unix();
    body.end_time = r[1].unix() + SECONDS_PER_DAY;
  }
  store.fetch(body).catch(notifyErrorNormal);
}, { immediate: true });

function onImgError(i: number): void {
  store.nurses[i].isSignUrlError = true;
}
</script>

<template>
	<ReportView :id="REPORT.NURSE" :hide-border="true" :loading="store.loading"
              :range-text="reportStore.config.rangeText">
		<table style="width: 100%; border-collapse: collapse; color: rgb(34,34,34); font-weight: 400; text-align: center;">
			<thead>
				<tr style="line-height: 30px; color: rgb(51,51,51); background-color: rgb(239,239,239);">
					<th :style="{ width: NURSE_COLUMNS[0].width, ...thStyle }">{{ NURSE_COLUMNS[0].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[1].width, ...thStyle }">{{ NURSE_COLUMNS[1].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[2].width, ...thStyle }">{{ NURSE_COLUMNS[2].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[3].width, ...thStyle }">{{ NURSE_COLUMNS[3].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[4].width, ...thStyle }">{{ NURSE_COLUMNS[4].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[5].width, ...thStyle }">{{ NURSE_COLUMNS[5].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[6].width, ...thStyle }">{{ NURSE_COLUMNS[6].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[7].width, ...thStyle }">{{ NURSE_COLUMNS[7].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[8].width, ...thStyle }">{{ NURSE_COLUMNS[8].title }}</th>
					<th :style="{ width: NURSE_COLUMNS[9].width, ...thStyle }">{{ NURSE_COLUMNS[9].title }}</th>
				</tr>
			</thead>
			<tbody v-if="store.nurses.length > 0">
				<tr v-for="(vo,i) in store.nurses" :key="vo.key" style="height: 40px; line-height: 40px;">
					<td :style="{ width: NURSE_COLUMNS[0].width, ...tdStyle }" style="font-size: 12px;">
						<div>{{ vo.timeDate }}</div>
						<div>{{ vo.timeTime }}</div>
					</td>
					<td :style="{ width: NURSE_COLUMNS[1].width, ...tdStyle }">{{ vo.pumpText }}</td>
					<td :style="{ width: NURSE_COLUMNS[2].width, ...tdStyle }">{{ vo.pipeText }}</td>
					<td :style="{ width: NURSE_COLUMNS[3].width, ...tdStyle }">{{ vo.punctureText }}</td>
					<td :style="{ width: NURSE_COLUMNS[4].width, ...tdStyle }">{{ vo.stickText }}</td>
					<td :style="{ width: NURSE_COLUMNS[5].width, ...tdStyle }">{{ vo.cgmPunctureText }}</td>
					<td :style="{ width: NURSE_COLUMNS[6].width, ...tdStyle }">{{ vo.cgmStickText }}</td>
					<td :style="{ width: NURSE_COLUMNS[7].width, ...tdStyle }">{{ vo.eventText }}</td>
					<td :style="{ width: NURSE_COLUMNS[8].width, ...tdStyle }">{{ vo.remark }}</td>
					<td :style="{ width: NURSE_COLUMNS[9].width, ...tdStyle }">
						<div style="height: 100%; display: flex; align-items: center; justify-content: center">
							<img v-if="vo.signUrl && !vo.isSignUrlError" alt="img" :src="vo.signUrl" :height="30" @error="onImgError(i)" />
							<span v-else>--</span>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		<div v-if="store.nurses.length === 0" style="font-size: 16px; color: rgb(0,0,0,0.5); height: 240px; text-align: left; padding-left: 16px; padding-top: 16px; border: 1px solid rgb(153,153,153); border-top: none;">
			暂无数据
		</div>
	</ReportView>
</template>
