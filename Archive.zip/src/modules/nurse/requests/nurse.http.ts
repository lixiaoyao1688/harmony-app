import { NurseVO } from '@/modules/nurse/vo/Nurse.vo';
import { HttpGetResponseVO } from '@/lib/http/vo/http.vo';
import { httpAdd, instance } from '@/lib/http/request/http';
import { AppHttpClient } from '@/lib/http/client/AppHttpClient';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import { MOCK_nurse, NURSE_MOCKING } from '@/modules/nurse/mock/nurse.mock';
import { httpNoResponseCatcher, httpResponseCatcher, isHttpResponseError } from '@/lib/http/util/http.utils';
import type { HttpGetResponseDTO } from '@/lib/http/dto/http.dto';
import type { HTTPResponseType } from '@/lib/http/types/http.type';
import type { NurseAddDTO, NurseDTO, NurseGetDTO } from '@/modules/nurse/dto/nurse.dto';


export const NURSE_PATH = {
  ADD: '/hospital/nursing/add',
  GET: '/hospital/nursing/get',
};

enum LOG {
  ADD = '护理/检测/换泵记录 新增',
	GET = '护理/检测/换泵记录 查看',
}


export function httpNurseAdd(body: NurseAddDTO) {
  return httpAdd<NurseAddDTO>(NURSE_PATH.ADD, body, LOG.ADD);
}

export function httpNurseGet(body: NurseGetDTO) {
  return new Promise<HttpGetResponseVO<NurseVO>>((resolve, reject) => {
    const log = LOG.GET;
    const path = NURSE_PATH.GET;
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      if (NURSE_MOCKING) {
        data.data.data = MOCK_nurse();
      }
      const vs = [] as NurseVO[];
      for (let i = 0, len = data.data.data.length; i < len; i++) {
        vs.push(new NurseVO(data.data.data[i]));
      }
      resolve({ total: data.data.total, vos: vs });
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpGetResponseDTO<NurseDTO[]>>(path, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .post<NurseGetDTO>(path, body, log, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
  });
}
