import { defineStore } from 'pinia';
import { NurseVO } from '@/modules/nurse/vo/Nurse.vo';
import { httpNurseGet } from '@/modules/nurse/requests/nurse.http';
import type { NurseGetDTO } from '@/modules/nurse/dto/nurse.dto';


interface State {
	loading: boolean;
	nurses: Array<NurseVO>;
}

interface Action {
	fetch: (body: NurseGetDTO) => Promise<void>;
	setNurse: (vos: Array<NurseVO>) => void;
}

type Getter = {
}


export const useNurseStore = defineStore<string, State, Getter, Action>('nurse-store', {
	
  state: () => ({
	  loading: false,
	  nurses: [],
  }),
	
  actions: {
    fetch(body) {
      return new Promise<void>((resolve, reject) => {
        this.loading = true;
        httpNurseGet(body)
          .then(data => {
            this.nurses = data.vos;
          })
          .catch(reason => reject(reason))
          .finally(() => this.loading = false);
      });
    },
    setNurse(vos: Array<NurseVO>) {
      this.nurses = vos;
    },
  },
	
  getters: {
  }
	
});
