import {NURSE_LEVEL} from '@/modules/nurse/config/nurse.level';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export type NurseItem = SelectItemVO<NurseItemPayload>;

export interface NurseItemPayload {
	level: NURSE_LEVEL;
}
