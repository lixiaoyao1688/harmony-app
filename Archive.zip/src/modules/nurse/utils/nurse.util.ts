// import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
// import { Share } from '@capacitor/share';
//
// /**
//  * 将文本内容保存为文件并通过系统分享让用户选择保存位置
//  * @param content 要保存的文本内容
//  * @param fileName 建议的文件名（例如 "笔记.txt"）
//  * @returns 成功返回 true，失败返回 false
//  */
// export async function shareTextAsFile(content: string, fileName: string): Promise<boolean> {
//   let tempFileUri: string | null = null;
//
//   try {
//     // 1. 生成唯一的临时文件名（避免冲突）
//     const tempFileName = `share_${Date.now()}_${fileName}`;
//
//     // 2. 将内容写入应用缓存目录（Cache 目录应用有完全控制权）
//     const writeResult = await Filesystem.writeFile({
//       path: tempFileName,
//       data: content,
//       directory: Directory.Cache,   // 使用 Cache 目录，系统可能随时清理，但分享足够
//       encoding: Encoding.UTF8,
//       recursive: true,
//     });
//
//     tempFileUri = writeResult.uri;
//
//     // 3. 检查设备是否支持分享（可选）
//     const canShare = await Share.canShare();
//     if (!canShare.value) {
//       throw new Error('此设备不支持分享');
//     }
//
//     // 4. 调用系统分享
//     await Share.share({
//       title: '保存文件',
//       text: '请选择保存文件的位置',          // 一些分享界面会显示这个文本
//       url: tempFileUri,                   // 文件的 URI
//       dialogTitle: '保存或分享文件',        // Android 分享对话框标题
//     });
//
//     // 注意：分享成功后，系统会接管文件，此时可以清理临时文件吗？
//     // 不能立即清理，因为其他应用可能正在读取。通常的做法是：
//     // - 不清除，让系统或用户负责（Cache 目录文件最终会被系统清理）
//     // - 或者监听分享完成事件（但插件没有提供回调）
//     // 这里我们选择不立即删除，让系统缓存机制处理
//     console.log('分享完成，临时文件保留在:', tempFileUri);
//     return true;
//
//   } catch (error) {
//     console.error('分享失败:', error);
//
//     // 如果出错，尝试清理临时文件
//     if (tempFileUri) {
//       try {
//         const tempPath = tempFileUri.split('/').pop();
//         if (tempPath) {
//           await Filesystem.deleteFile({ path: tempPath, directory: Directory.Cache });
//         }
//       } catch (cleanupError) {
//         console.error('清理临时文件失败:', cleanupError);
//       }
//     }
//
//     return false;
//   }
// }