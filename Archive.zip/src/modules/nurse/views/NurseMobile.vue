<script setup lang="ts">
import {computed, ref} from 'vue';
import dayjs, {Dayjs} from 'dayjs';
import { CardVO } from '@/modules/admission/vo/Card.vo';
import IconNurse2 from '@/modules/nurse/icons/IconNurse2.vue';
import {INFINITE_DAY} from '@/lib/time/config/date.config';
import {NURSE_COMMON_OPTIONS_2, NURSE_PIPE_OPTIONS} from '@/modules/nurse/dto/nurse.help.dto';
import {PUNCTURES_2} from '@/modules/nurse/dto/nurse.help.puncture.dto';
import {STICKS_2} from '@/modules/nurse/dto/nurse.help.stick.dto';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import {useUserStore} from '@/modules/user/store/user.store';
import {httpNurseAdd} from '@/modules/nurse/requests/nurse.http';
import {notifyErrorNormal, notifySuccessNormal} from '@/lib/aaruy-design/notify/notify';
import {EnumTimeColumnsType} from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import {useCardStore} from '@/modules/admission/store/card.store';
import {notifyNoAuth} from '@/modules/auth/utils/auth.util';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import {OPERATION_KIND} from '@/modules/nurse/config/operation.kind';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import FieldDouble from '@/lib/aaruy-design/field/FieldDouble.vue';
import InputField from '@/lib/aaruy-design/input/field/InputField.vue';
import NurseFieldPicker from '@/modules/nurse/components/NurseFieldPicker.vue';
import PageBoardContent from '@/lib/aaruy-design/page/component/PageBoardContent.vue';
import DatePickerFormMobile from '@/lib/aaruy-design/date-picker/form/DatePickerFormMobile.vue';
import type {NurseItem} from '@/modules/nurse/types/nurse.type';
import type {NurseAddDTO} from '@/modules/nurse/dto/nurse.dto';


/**
 * 护理记录 组件（上传护理记录）
 *
 * 模式
 * 只写
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  c: CardVO;
  isDisabled?: boolean;
}

interface Emit {
  (e: 'open'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const store = useAdmissionStore();
const cardStore = useCardStore();
const userStore = useUserStore();
const screenStore = useScreenStore();
const admissionStore = useAdmissionStore();

const isWaiting = ref<boolean>(false);
const isOpened = ref<boolean>(false);
const vo = ref<AdmissionVO>(new AdmissionVO());  // 患者

const timeDay = ref<Dayjs>(dayjs());
const pumpItem = ref<NurseItem>(NURSE_COMMON_OPTIONS_2[0]);
const pipeItem = ref<NurseItem>(NURSE_PIPE_OPTIONS[0]);
const punctureItem = ref<NurseItem>(PUNCTURES_2[0]);
const stickItem = ref<NurseItem>(STICKS_2[0]);
const cgmPunctureItem = ref<NurseItem>(PUNCTURES_2[0]);
const cgmStickItem = ref<NurseItem>(STICKS_2[0]);
const ctText = ref<string>('');
const mriText = ref<string>('');
const remarkText = ref<string>('');

const pad = computed<boolean>(() => screenStore.isPad);


function onOpen(): void {
  if (prop.isDisabled) {
    notifyNoAuth();
    return;
  }
  onReset();
  emit('open');
  isOpened.value = true;
  fetchAdmission();
}

function onClose(): void {
  isOpened.value = false;
}

function fetchAdmission(): void {
  vo.value = new AdmissionVO();
  admissionStore
    .fetchInfo(prop.c.id)
    .then(data => {
      vo.value = data;
    });
}

function onTimeDayChange(data: Dayjs): void {
  timeDay.value = data;
}

function onPumpItemChange(data: NurseItem): void {
  pumpItem.value = data;
}
function onPipeItemChange(data: NurseItem): void {
  pipeItem.value = data;
}
function onPunctureItemChange(data: NurseItem): void {
  punctureItem.value = data;
}
function onCGMPunctureItemChange(data: NurseItem): void {
  cgmPunctureItem.value = data;
}
function onStickItemChange(data: NurseItem): void {
  stickItem.value = data;
}
function onCGMStickItemChange(data: NurseItem): void {
  cgmStickItem.value = data;
}

function onCtTextChange(data: string): void {
  ctText.value = data;
}
function onMriTextChange(data: string): void {
  mriText.value = data;
}
function onRemarkTextChange(data: string): void {
  remarkText.value = data;
}

function onReset(): void {
  timeDay.value = dayjs();
  pumpItem.value = NURSE_COMMON_OPTIONS_2[0];
  pipeItem.value = NURSE_PIPE_OPTIONS[0];
  punctureItem.value = PUNCTURES_2[0];
  stickItem.value = STICKS_2[0];
  cgmPunctureItem.value = PUNCTURES_2[0];
  cgmStickItem.value = STICKS_2[0];
  ctText.value = '';
  mriText.value = '';
  remarkText.value = '';
}

function onSave(): void {
  const dto: NurseAddDTO = {
    admission_id: prop.c.admissionId,
    kind: OPERATION_KIND.NURSE,
    record_dt: timeDay.value.format('YYYY-MM-DD HH:mm'),
    pump_status: pumpItem.value.id,
    pipe_status: pipeItem.value.id,
    puncture_status: punctureItem.value.id,
    stick_status: stickItem.value.id,
    cgm_puncture_status: cgmPunctureItem.value.id,
    cgm_stick_status: cgmStickItem.value.id
  };
  // if (ctText.value) {
  //   dto.ct = ctText.value;
  // }
  // if (mriText.value) {
  //   dto.mri = mriText.value;
  // }
  if (remarkText.value) {
    dto.remark = remarkText.value;
  }
  
  isWaiting.value = true;
  httpNurseAdd(dto)
    .then(() => {
      notifySuccessNormal('请在患者信息-护理记录中查看');
      // back();
      onClose();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => isWaiting.value = false);
}
</script>

<template>
  <PageMobile :visible="isOpened" @goBack="onClose">
    <template #title>
      <div class="flex items-center">护理记录</div>
    </template>
    <template #content>
      <PageBoardContent>
        <FieldView2 type="double-text" is-start is-end>
          <FieldDouble t1="姓名" :use-font14="!pad" :v1="vo.nameText" t1-width="40px" t2="登记号" :v2="vo.codeText" />
          <FieldDouble t1="床号" :use-font14="!pad" :v1="vo.bedText"  t1-width="40px" t2="住院号" :v2="vo.inPatientCodeText" is-end />
        </FieldView2>
        <FieldView2 type="other" margin-top="16px">
          <DatePickerFormMobile
            title="时间"
            is-field
            :use-font16="screenStore.isPad"
            :type="EnumTimeColumnsType.hm"
            large
            :data="timeDay"
            format="YYYY-MM-DD HH:mm"
            :max-time="INFINITE_DAY"
            placeholder="请选择"
            @change="onTimeDayChange"
          />
        </FieldView2>
        <FieldView2 type="other">
          <NurseFieldPicker name="泵运行"
                            :items="NURSE_COMMON_OPTIONS_2"
                            :item="pumpItem"
                            @change="onPumpItemChange" />
        </FieldView2>
        <FieldView2 type="other">
          <NurseFieldPicker name="泵管路"
                            :items="NURSE_PIPE_OPTIONS"
                            :item="pipeItem"
                            @change="onPipeItemChange" />
        </FieldView2>
        <FieldView2 type="other">
          <NurseFieldPicker name="泵穿刺点"
                            :items="PUNCTURES_2"
                            :item="punctureItem"
                            @change="onPunctureItemChange" />
        </FieldView2>
        <FieldView2 type="other">
          <NurseFieldPicker name="泵敷贴"
                            :items="STICKS_2"
                            :item="stickItem"
                            @change="onStickItemChange" />
        </FieldView2>
<!--        <FieldView2 type="other">-->
<!--          <InputField :data="ctText"-->
<!--                      :title="NurseVO.ctField"-->
<!--                      type="text"-->
<!--                      use-font16-->
<!--                      placeholder="请输入"-->
<!--                      is-field-->
<!--                      @change="onCtTextChange" />-->
<!--        </FieldView2>-->
<!--        <FieldView2 type="other">-->
<!--          <InputField :title="NurseVO.mriField"-->
<!--                      :data="mriText"-->
<!--                      type="text"-->
<!--                      use-font16-->
<!--                      placeholder="请输入"-->
<!--                      is-field-->
<!--                      @change="onMriTextChange" />-->
<!--        </FieldView2>-->
        <FieldView2 type="other">
          <NurseFieldPicker name="CGM穿刺点"
                            :items="PUNCTURES_2"
                            :item="cgmPunctureItem"
                            @change="onCGMPunctureItemChange" />
        </FieldView2>
        <FieldView2 type="other">
          <NurseFieldPicker name="CGM敷贴"
                            :items="STICKS_2"
                            :item="cgmStickItem"
                            @change="onCGMStickItemChange" />
        </FieldView2>
        <FieldView2 type="other" is-end>
          <InputField title="备注"
                      :data="remarkText"
                      type="text"
                      placeholder="请输入"
                      is-field
                      use-font16
                      @change="onRemarkTextChange" />
        </FieldView2>
        <template #bottom>
          <div class="h-full flex items-start justify-between px-16 pt-8 pb-12">
            <ButtonView type="default" text="重置" style="width: 48%; height: 100%; font-size: 16px;" @click="onReset" />
            <ButtonView type="primary" text="确认" style="width: 48%; height: 100%; font-size: 16px;" :loading="isWaiting" @click="onSave" />
          </div>
        </template>
      </PageBoardContent>
    </template>
  </PageMobile>
  <div class="inline-block text-center w-64-px h-64-px" @click.stop="onOpen">
    <IconNurse2 :is-disabled="isDisabled" />
    <div :class="{ 'text-weak-real-3': isDisabled, 'text-white': !isDisabled }">护理</div>
  </div>
</template>
