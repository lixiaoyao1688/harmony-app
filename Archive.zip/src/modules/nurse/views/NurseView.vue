<script setup lang="ts">
import dayjs from 'dayjs';
import {useRoute} from 'vue-router';
import {onBeforeMount, onMounted, ref, watch} from 'vue';
import {ROUTE_IN_PATIENT} from '@/routers/global.router';
import {NurseVO} from '@/modules/nurse/vo/Nurse.vo';
import {httpNurseGet} from '@/modules/nurse/requests/nurse.http';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {notifyErrorNormal} from '@/lib/aaruy-design/notify/notify';
import {useNurseStore} from '@/modules/nurse/store/nurse.store';
import {getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {REPORT} from '@/modules/report/configs/report.config';
import {INVALID_ID} from '@/utils/global.vo.help';
import {NURSE_COLUMNS} from '@/modules/nurse/config/nurse.column';
import EmptyIcon from '@/lib/aaruy-design/empty/EmptyIcon.vue';
import CardView1 from '@/lib/aaruy-design/card/CardView1.vue';
import PrintView from '@/modules/report/views/PrintView.vue';
import NurseCardMobile from '@/modules/nurse/components/NurseCardMobile.vue';
import TableReadonly from '@/lib/aaruy-design/table/readonly/TableReadonly.vue';
import SpinMobile from '@/lib/aaruy-design/spin/SpinMobile.vue';
import CalendarPickerMobile from '@/lib/aaruy-design/calendar/CalendarPickerMobile.vue';


/**
 * 护理记录 界面
 *
 * 权限
 * 仅 院泵患者-住院患者 具备
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
type RangeType = [Date, Date];

const store = useCardStore();
const nurseStore = useNurseStore();
const screenStore = useScreenStore();
const route = useRoute();

const isLoading = ref<boolean>(false);
// const isExporting = ref<boolean>(false);
const nurseRecords = ref<NurseVO[]>([]);

// 日期范围最大跨度(天)
const MAX_RANGE = 30;
// 日期范围
const ranges = ref<RangeType>([getTodayDayjs().subtract(MAX_RANGE - 1, 'd').toDate(), getTodayDayjs().toDate()]);

let timer: number | null = null;
const UPDATE_INTERVAL_MS = 60 * 1000;  // 刷新数据的时间间隔，单位ms;

// 切换院泵患者时自动刷新数据
// 新数据返回前, 重置所有数据. 仅PC.
watch(() => store.selectedCard, (data) => {
  if (!screenStore.isPC || !(route.name === ROUTE_IN_PATIENT && store.selectedCard.isInPatient)) {
    return;
  }
  fetchData(data.id, true);
}, { immediate: true });

onMounted(() => {
  if (screenStore.isPC) {
    if (route.name === ROUTE_IN_PATIENT && store.selectedCard.isInPatient) {
      startLoopFetch();
    }
  }
  else {
    if (store.selectedCard.isInPatient) {
      fetchData(store.selectedCard.id, true, true);
      startLoopFetch();
    }
  }
});

onBeforeMount(() => {
  if (screenStore.isPC) {
    if (route.name === ROUTE_IN_PATIENT && store.selectedCard.isInPatient) {
      stopLoopFetch();
    }
  }
  else {
    if (store.selectedCard.isInPatient) {
      stopLoopFetch();
    }
  }
});

function startLoopFetch(): void {
  if (timer) {
    clearInterval(timer);
  }
  timer = setInterval(() => {
    fetchData(store.selectedCard.id, false);
  }, UPDATE_INTERVAL_MS) as unknown as number;
}

function stopLoopFetch(): void {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
}

function onRangeChange(data: RangeType): void {
  const id = store.selectedCard.id;
  if (id === INVALID_ID) {
    return;
  }
  ranges.value = data;
  fetchData(id);
}

function fetchData(id: number, clearData?: boolean, showLoading?: boolean): void {
  if (id === INVALID_ID) {
    return;
  }
  const [s,e] = ranges.value;
  if (showLoading) {
    isLoading.value = true;
  }
  if (clearData) {
    nurseRecords.value = [];
    nurseStore.setNurse([]);
  }
  httpNurseGet({
    admission_id: id,
    start_time: Math.floor(s.getTime() / 1000),
    end_time: dayjs(e).add(1,'d').unix()  // end_time 代表结束日期的第二天00:00:00:000的时刻。
  })
    .then(vo => {
      const data = vo.vos;
      nurseRecords.value = data;
      nurseStore.setNurse(data);
    })
    .catch(reason => {
      notifyErrorNormal(reason);
    })
    .finally(() => {
      isLoading.value = false;
    });
}

// APP端导出护理记录
// 尝试了多种方法，发现无法实现。浏览器可以导出文件，如果需要导出护理记录，就在PC端加功能吧。by cyy 2026/03/18 17:02:00
// async function onExport() {
//   isExporting.value = true;
//   await shareTextAsFile('123456789', 'download.txt');
//   isExporting.value = false;
// }
</script>

<template>
	
	<CardView1 v-if="screenStore.isPC" type="toolContent" class="mt-8"
             title="护理记录" tool-padding="15px 12px" :min-height="280" height="calc(100% - 720px)">
		<template #tool>
      <div :style="{ height: '32px', visibility: store.selectedCard.isValid ? 'visible' : 'hidden' }">
        <PrintView :report-id="REPORT.NURSE" />
      </div>
		</template>
		<template #toolContent>
			<div class="nurse-container-table">
					<TableReadonly :columns="NURSE_COLUMNS" :data="nurseRecords">
						<template #image="{ record }">
							<a-image :src="record.signUrl" :height="'40px'" alt="签名图" />
						</template>
					</TableReadonly>
				</div>
		</template>
	</CardView1>
	<div v-else class="bg-0 overflow-hidden"
       style="height: calc(100vh - var(--board-top) - var(--admission-detail-mobile-tab-header-height) - 48px);">
    <div style="height: 60px;" class="flex items-center px-16">
      <CalendarPickerMobile type="range"
                            :max-range="MAX_RANGE" :range="ranges" padding="0"
                            width="100%" height="40px"
                            @rangeChange="onRangeChange" />
<!--      <div class="flex-1">-->
<!--        <CalendarPickerMobile type="range"-->
<!--                              :max-range="MAX_RANGE" :range="ranges" padding="0" height="40px"-->
<!--                              @rangeChange="onRangeChange" />-->
<!--      </div>-->
<!--      <ButtonView type="primary" text="导出" :loading="isExporting" style="width: 60px; height: 40px;" @click="onExport" />-->
    </div>
    <div style="height: calc(100% - 60px);" class="overflow-hidden-auto px-16">
      <SpinMobile v-if="isLoading"
                  tip="加载中..."
                  :loading="isLoading"
                  icon-size="24px"
                  :text-size="20"
                  :height="screenStore.isNewPhone ? '100%' : '240px'"
      />
      <template v-else>
        <EmptyIcon v-if="nurseRecords.length === 0" tips="暂无数据" height="100%" />
        <NurseCardMobile v-for="d in nurseRecords" :vo="d" :key="d.key" class="mb-16" />
      </template>
    </div>
	</div>

</template>

<style scoped>
.nurse-container-table {
	width: 100%;
	height: calc(100% - 45px);
}

.nurse-table-mobile td {
	height: 40px;
	text-align: center;
	border: 1px solid rgb(91,103,116);
}

.nurse-table-mobile td:nth-child(1) {
	background-color: rgb(83,94,106);
}

.nurse-table-mobile td:nth-child(2) {
	background-color: rgb(58,68,77);
}
</style>
