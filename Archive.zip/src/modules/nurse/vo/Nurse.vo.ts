import dayjs, {Dayjs} from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {getDateTimeFromText} from '@/lib/time/util/time.util';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {STICK, STICK_MAP, STICK_MAP_2} from '@/modules/nurse/dto/nurse.help.stick.dto';
import {PUNCTURE, PUNCTURE_MAP, PUNCTURE_MAP_2} from '@/modules/nurse/dto/nurse.help.puncture.dto';
import {
  NURSE_COMMON,
  NURSE_COMMON_MAP,
  NURSE_COMMON_MAP_2,
  NURSE_PIPE,
  NURSE_PIPE_MAP
} from '@/modules/nurse/dto/nurse.help.dto';
import {OPERATION_KIND} from '@/modules/nurse/config/operation.kind';
import {SUPPLIES_KIND, SUPPLIES_KIND_MAP} from '@/modules/pump/config/supplies.kind';
import {PUMP_UNBIND_REASON_MAP_APP} from '@/modules/plan/config/pump.unbind.reason';
import {throwFieldLackError} from '@/lib/http/util/http.utils';
import {NURSE_PATH} from '@/modules/nurse/requests/nurse.http';
import {TEXT_COLOR_0, TEXT_COLOR_1, TEXT_COLOR_2} from '@/modules/nurse/config/nurse.color';
import type {NurseDTO} from '@/modules/nurse/dto/nurse.dto';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 护理记录 VO
 */
export class NurseVO {
	
	private readonly _entity: NurseDTO | undefined;
	private _isSignUrlError: boolean;
	
	constructor(e?: NurseDTO) {
	  this._entity = e;
	  this._isSignUrlError = false;
	}
	
	// 唯一标识
	public get key(): number {
	  if (!this._entity || this._entity.id === undefined) {
	    return INVALID_ID;
	  }
	  return this._entity.id;
	}
	
	
	// 泵运行
	public get pumpRunningText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(NURSE_COMMON_MAP_2, this._entity.pump_status);
	}
	public get pumpRunningTextColor(): string {
	  if (!this._entity) {
	    return TEXT_COLOR_0;
	  }
	  const s = this._entity.pump_status;
	  return s === NURSE_COMMON.NORMAL ? TEXT_COLOR_0 : s === NURSE_COMMON.STOP ? TEXT_COLOR_1 : TEXT_COLOR_2;
	}
	
	// 泵敷贴
	public get pumpStickText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(STICK_MAP_2, this._entity.stick_status);
	}
	public get pumpStickTextColor(): string {
	  if (!this._entity) {
	    return TEXT_COLOR_0;
	  }
	  const s = this._entity.stick_status;
	  return s === STICK.NORMAL ? TEXT_COLOR_0 : TEXT_COLOR_1;
	}
	
	// 泵穿刺点
	public get pumpPunctureText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(PUNCTURE_MAP_2, this._entity.puncture_status);
	}
	public get pumpPunctureTextColor(): string {
	  if (!this._entity) {
	    return TEXT_COLOR_0;
	  }
	  const s = this._entity.puncture_status;
	  return s === PUNCTURE.NORMAL ? TEXT_COLOR_0 : TEXT_COLOR_2;
	}
	
	// 泵管路
	public get pumpPipeText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(NURSE_PIPE_MAP, this._entity.pipe_status);
	}
	public get pumpPipeTextColor(): string {
	  if (!this._entity) {
	    return TEXT_COLOR_0;
	  }
	  const s = this._entity.pipe_status;
	  return s === NURSE_PIPE.NORMAL ? TEXT_COLOR_0 : s === NURSE_PIPE.STOP ? TEXT_COLOR_1 : TEXT_COLOR_2;
	}
	
	// CGM敷贴 文本
	public get cgmStickText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(STICK_MAP_2, this._entity.cgm_stick_status) || '--';
	}
	public get cgmStickTextColor(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.cgm_stick_status === STICK.SCROLL ? 'rgb(253,190,82)' : 'rgb(245,245,245)';
	}
	
	// CGM穿刺点状态 文本
	public get cgmPunctureText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return SelectItemVO.getText(PUNCTURE_MAP_2, this._entity.cgm_puncture_status) || '--';
	}
	public get cgmPunctureTextColor(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.cgm_puncture_status === PUNCTURE.HOT ? 'rgb(245,75,80)' : 'rgb(245,245,245)';
	}
	
	
	public static timeField = '时间';
	public static timeFormat = 'YYYY-MM-DD HH:mm';
	public get timeEntity(): string {
	  if (!this._entity || this._entity.record_dt === undefined) {
	    return '';
	  }
	  return this._entity.record_dt;
	}
	public get timeDay(): Dayjs {
	  if (!this._entity || !this._entity.record_dt) {
	    return dayjs();
	  }
	  const dt = getDateTimeFromText(this._entity.record_dt);
	  if (!dt) {
	    return dayjs();
	  }
	  return dayjs(new Date(dt.year, dt.monthIndex, dt.day, dt.hour, dt.minute, dt.second));
	}
	public set timeDay(v) {
	  if (this._entity && v && v.isValid()) {
	    this._entity.record_dt = v.format(NurseVO.timeFormat);
	  }
	}
	public get timeTextApp(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  this._checkField('record_time');
	  return dayjs.unix(this._entity.record_time).format('MM月DD日 HH:mm');
	}
	
	public get timeTextMobile(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.record_dt;
	}
	public get timeText(): string {
	  if (!this._entity || !this._entity.record_dt || !this._entity.record_dt.includes(' ')) {
	    return '';
	  }
	  const [date, time] = this._entity.record_dt.split(' ');
	  return date + '\n' + time;
	}
	public get timeDate(): string {
	  if (!this._entity || !this._entity.record_dt || !this._entity.record_dt.includes(' ')) {
	    return '';
	  }
	  return this._entity.record_dt.split(' ')[0];
	}
	public get timeTime(): string {
	  if (!this._entity || !this._entity.record_dt || !this._entity.record_dt.includes(' ')) {
	    return '';
	  }
	  return this._entity.record_dt.split(' ')[1];
	}
	
	
	// 是否事件
	public get isEvent(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  const k = this._entity.kind;
	  return k === OPERATION_KIND.REPLACE_SUPPLIES || k === OPERATION_KIND.UNBIND_PUMP || k === OPERATION_KIND.BIND_PUMP || k === OPERATION_KIND.PUMP_CHANGED;
	}
	public get eventTextApp(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if (k === OPERATION_KIND.REPLACE_SUPPLIES) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '更换' + (SelectItemVO.getText(SUPPLIES_KIND_MAP, e.supply_kind as SUPPLIES_KIND) || '耗材');
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    return '下泵';
	  }
	  if (k === OPERATION_KIND.BIND_PUMP) {
	    return '上泵';
	  }
	  if (k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '更换胰岛素泵';
	  }
	  return '--';
	}
	
	// 是否上泵
	public get isPumpUp(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.kind === OPERATION_KIND.BIND_PUMP;
	}
	
	
	private _getCommonColor(id: NURSE_COMMON): string {
	  if (id === NURSE_COMMON.WEIRD) {
	    return 'rgb(255,36,42)';
	  }
	  else if (id === NURSE_COMMON.STOP) {
	    return 'rgb(253,190,82)';
	  }
	  else {
	    return 'rgb(255,255,255)';
	  }
	}
	
	
	// 泵运行 文本 仅PC
	public get pumpText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return this.pumpItem.text;
	}
	
	// 管路状态 文本 仅PC
	public get pipeText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return this.pipeItem.text;
	}
	
	// 泵穿刺点状态 文本 仅PC
	public get punctureText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return this.punctureItem.text;
	}
	
	// 泵敷贴 文本 仅PC
	public get stickText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return this.stickItem.text;
	}
	
	// CGM穿刺点状态 文本 仅PC
	public get cgmPunctureText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return SelectItemVO.getText(PUNCTURE_MAP_2, e.cgm_puncture_status) || '--';
	}
	
	// CGM敷贴 文本 仅PC
	public get cgmStickText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if ((k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) || k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '--';
	  }
	  if (k === OPERATION_KIND.UNBIND_PUMP) {
	    // fix: http://192.168.1.236:81/redmine/issues/8708
	    return '--';
	  }
	  return SelectItemVO.getText(STICK_MAP_2, e.cgm_stick_status) || '--';
	}
	
	// 备注 文本 仅PC
	public get remarkText2(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if (k === OPERATION_KIND.REPLACE_SUPPLIES && e.supply_kind === SUPPLIES_KIND.DRUG_RESERVOIR) {
	    return '--';
	  }
	  if (e.kind === OPERATION_KIND.UNBIND_PUMP) {
	    return SelectItemVO.getText(PUMP_UNBIND_REASON_MAP_APP, e.unbind_pump_kind as number);
	  }
	  if (e.kind === OPERATION_KIND.PUMP_CHANGED) {
	    // 泵号
	    return e.remark || '--';
	  }
	  return e.remark || '--';
	}
	
	
	public static pumpField = '泵运行';
	public get pumpColor(): string {
	  return this._getCommonColor(this.pumpId);
	}
	public get pumpEntity(): NURSE_COMMON {
	  if (!this._entity) {
	    return NURSE_COMMON.NORMAL;
	  }
	  return this._entity.pump_status;
	}
	public get pumpItem(): SelectorFormItemVO {
	  return SelectorFormItemVO.getItem(NURSE_COMMON_MAP, this.pumpEntity);
	}
	public get pumpItem2(): ItemType2 {
	  return SelectItemVO.getItem(NURSE_COMMON_MAP_2, this.pumpEntity);
	}
	public get pumpId(): number {
	  return this.pumpItem.id;
	}
	public set pumpId(v) {
	  if (this._entity) {
	    this._entity.pump_status = v;
	  }
	}
	public get pumpText(): string {
	  return this.pumpItem.text;
	}
	public get isPumpLack(): boolean {
	  return this.pumpId === INVALID_ID;
	}
	
	// 泵管路
	public static pipeField = '管路状态';
	public get pipeColor(): string {
	  return this._getCommonColor(this.pipeId);
	}
	public get pipeEntity(): NURSE_PIPE {
	  if (!this._entity) {
	    return NURSE_PIPE.NORMAL;
	  }
	  return this._entity.pipe_status;
	}
	public get pipeItem(): SelectorFormItemVO {
	  return SelectorFormItemVO.getItem(NURSE_PIPE_MAP, this.pipeEntity);
	}
	public get pipeItem2(): ItemType2 {
	  return SelectItemVO.getItem(NURSE_COMMON_MAP_2, this.pipeEntity);
	}
	public get pipeId(): number {
	  return this.pipeItem.id;
	}
	public set pipeId(v) {
	  if (this._entity) {
	    this._entity.pipe_status = v;
	  }
	}
	public get pipeText(): string {
	  return this.pipeItem.text;
	}
	public get isPipeLack(): boolean {
	  return this.pipeId === INVALID_ID;
	}
	

	



	
	
	public static punctureField = '穿刺点状态';
	public get punctureColor(): string {
	  if (this.punctureId === PUNCTURE.HOT) {
	    return 'rgb(255,36,42)';
	  }
	  return 'rgb(255,255,255)';
	}
	public get punctureEntity(): PUNCTURE {
	  if (!this._entity) {
	    return PUNCTURE.NORMAL;
	  }
	  return this._entity.puncture_status;
	}
	public get punctureItem(): SelectorFormItemVO {
	  return SelectorFormItemVO.getItem(PUNCTURE_MAP, this.punctureEntity);
	}
	public get punctureItem2(): ItemType2 {
	  return SelectItemVO.getItem(PUNCTURE_MAP_2, this.punctureEntity);
	}
	public get punctureId(): number {
	  return this.punctureItem.id;
	}
	public set punctureId(v) {
	  if (this._entity) {
	    this._entity.puncture_status = v;
	  }
	}
	public get punctureText(): string {
	  return this.punctureItem.text;
	}
	public get isPunctureLack(): boolean {
	  return this.punctureId === INVALID_ID;
	}
	
	
	public static stickField = '敷贴';
	public get stickColor(): string {
	  if (this.stickId === STICK.SCROLL) {
	    return 'rgb(255,248,10)';
	  }
	  return 'rgb(255,255,255)';
	}
	public get stickEntity(): STICK {
	  if (!this._entity) {
	    return STICK.NORMAL;
	  }
	  return this._entity.stick_status;
	}
	public get stickItem(): SelectorFormItemVO {
	  return SelectorFormItemVO.getItem(STICK_MAP, this.stickEntity);
	}
	public get stickItem2(): ItemType2 {
	  return SelectItemVO.getItem(STICK_MAP_2, this.stickEntity);
	}
	public get stickId(): number {
	  return this.stickItem.id;
	}
	public set stickId(v) {
	  if (this._entity) {
	    this._entity.stick_status = v;
	  }
	}
	public get stickText(): string {
	  return this.stickItem.text;
	}
	public get isStickLack(): boolean {
	  return this.stickId === INVALID_ID;
	}
	
	
	
	public static ctField = 'CT';
	public get ctText(): string {
	  if (!this._entity || !this._entity.ct) {
	    return '--';
	  }
	  return this._entity.ct;
	}
	public get ct(): string {
	  if (!this._entity || !this._entity.ct) {
	    return '';
	  }
	  return this._entity.ct;
	}
	public set ct(v) {
	  if (this._entity) {
	    this._entity.ct = v;
	  }
	}
	public static ctMax = 20;
	
	
	public static mriField = 'MRI';
	public get mriText(): string {
	  if (!this._entity || !this._entity.mri) {
	    return '--';
	  }
	  return this._entity.mri;
	}
	public get mri(): string {
	  if (!this._entity || !this._entity.mri) {
	    return '';
	  }
	  return this._entity.mri;
	}
	public set mri(v) {
	  if (this._entity) {
	    this._entity.mri = v;
	  }
	}
	public static mriMax = 20;
	
	// PC & APP
	public get remarkText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  if (e.kind === OPERATION_KIND.UNBIND_PUMP) {
	    return SelectItemVO.getText(PUMP_UNBIND_REASON_MAP_APP, e.unbind_pump_kind as number);
	  }
	  if (e.kind === OPERATION_KIND.PUMP_CHANGED) {
	    // 泵号
	    return e.remark || '--';
	  }
	  return e.remark || '--';
	}
	
	public get remark(): string {
	  if (!this._entity || !this._entity.remark) {
	    return '';
	  }
	  return this._entity.remark;
	}
	public set remark(v) {
	  if (this._entity) {
	    this._entity.remark = v;
	  }
	}
	
	
	// 签名(医生)
	public static signField = '签名';
	public get sign(): string {
	  if (!this._entity || !this._entity.signature) {
	    return '';
	  }
	  return this._entity.signature;
	}
	public get signUrl(): string {
	  if (!this._entity || !this._entity.signature_url) {
	    return '';
	  }
	  return this._entity.signature_url;
	}

	// 签名图是否加载出错
	public get isSignUrlError(): boolean {
	  return this._isSignUrlError;
	}
	public set isSignUrlError(data) {
	  this._isSignUrlError = data;
	}
	
	
	// 事件 文本 仅PC
	public get eventText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  const e = this._entity;
	  const k = e.kind;
	  if (k === OPERATION_KIND.REPLACE_SUPPLIES) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '更换' + (SelectItemVO.getText(SUPPLIES_KIND_MAP, e.supply_kind as SUPPLIES_KIND) || '耗材');
	  }
	  else if (k === OPERATION_KIND.UNBIND_PUMP) {
	    return '下泵';
	  }
	  else if (k === OPERATION_KIND.BIND_PUMP) {
	    return '上泵';
	  }
	  else if (k === OPERATION_KIND.PUMP_CHANGED) {
	    // fix: http://192.168.1.236:81/redmine/issues/8524
	    return '更换胰岛素泵';
	  }
	  return '--';
	}
	
	// 操作者名字
	public get staffName(): string {
	  if (!this._entity) {
	    return '';
	  }
	  this._checkField('staff_name');
	  return this._entity.staff_name || '';
	}
	
	private _checkField<T>(field: keyof NurseDTO, fieldChild?: keyof T): void {
	  if (!this._entity) {
	    return;
	  }
	  const path = NURSE_PATH.GET;
	  if (this._entity[field] === undefined) {
	    throwFieldLackError(field, path);
	  }
	  else if (fieldChild && (this._entity[field] as unknown as T)[fieldChild] === undefined) {
	    throwFieldLackError(`${field}.${fieldChild as string}`, path);
	  }
	}
	
}
