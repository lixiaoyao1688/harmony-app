<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { RoleVO } from '@/modules/role/vo/Role.vo';
import { RoleTableVO } from '@/modules/role/vo/Role.table.vo';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { ONE } from '@/lib/math/config/math.config';
import { httpRoleGet } from '@/modules/role/requests/role.http';
import { useRoleStore } from '@/modules/role/store/role.store';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {
  getAddSearchPage,
  getColumnForMobile,
  getDataSource,
  getPaginationAfterFetching, 
  getPaginationOnMobile, 
  getPaginationOnPC,
  getRemoveSearchPage
} from '@/lib/aaruy-design/table/normal/util/table.normal.util';
import { TABLE_DEFAULT_TOTAL_SIZE } from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import { FIRST_PAGE, TableScrollType } from '@/lib/aaruy-design/table/table';
import { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import TableLayout from '@/lib/aaruy-design/table/layout/TableLayout.vue';
import RoleAddOrUpdate from '@/modules/role/components/RoleAddOrUpdate.vue';
import RoleFilter from '@/modules/role/components/RoleFilter.vue';
import RoleDelete from '@/modules/role/components/RoleDelete.vue';
import TableNormal from '@/lib/aaruy-design/table/normal/TableNormal.vue';
import IconOpSplit from '@/modules/device2/icon/IconOpSplit.vue';
import type { RoleGetDTO, RoleGetFilterDTO } from '@/modules/role/dto/role.dto';
import type { TableColumnType, TablePaginationConfig } from 'ant-design-vue';


const COLUMNS: TableColumnType[] = [
  { title: '序号', dataIndex: 'index', width: '6%', fixed: false },
  { title: '名称', dataIndex: 'name', width: '15%', fixed: false },
  { title: '备注', dataIndex: 'remark', width: '20%', fixed: false },
  { title: '创建日期', dataIndex: 'createTime', width: '18%', fixed: false },
  { title: '操作', dataIndex: 'operator', width: '26%', fixed: false },
];
const MOBILE_WIDTHS: number[] = [80,100,200,200,200];

const roleStore = useRoleStore();
const userStore = useUserStore();
const screenStore = useScreenStore();

const loading = ref<boolean>(false);
const dataSource = ref<RoleTableVO[]>([]);
const total = ref<number>(TABLE_DEFAULT_TOTAL_SIZE);
const filter = ref<RoleGetFilterDTO>(getInitFilter());
const columns = ref<TableColumnType[]>(screenStore.isPC ? COLUMNS : getColumnForMobile(COLUMNS, MOBILE_WIDTHS));
const pagination = ref<TablePaginationConfig>(screenStore.isPC ? getPaginationOnPC() : getPaginationOnMobile());

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const scroll = computed<TableScrollType | null>(() => pc.value ? null : ({ x: MOBILE_WIDTHS.reduce((acc, cur) => acc + cur) - ONE }));


onMounted(() => {
  refresh();
});

function refresh(): void {
  fetchData(pagination.value.current, pagination.value.pageSize);
}

function onAddSearch(): void {
  const page = getAddSearchPage(pagination.value.total as number, pagination.value.pageSize as number);
  fetchData(page);
}

function onDeleteSearch(): void {
  const page = getRemoveSearchPage(pagination.value.current as number, dataSource.value.length);
  fetchData(page);
}

function onPageChange(p: PaginationData): void {
  fetchData(p.page, p.pageSize);
}

function onFilterChange(data: RoleGetFilterDTO): void {
  filter.value = data;
}

function onSearch(): void {
  fetchData(FIRST_PAGE);
}

function onReset(): void {
  resetFilter();
  fetchData(FIRST_PAGE);
}

function resetFilter(): void {
  filter.value = getInitFilter();
}

function getInitFilter(): RoleGetFilterDTO {
  return { name: '' };
}

function fetchData(current?: number, pageSize?: number): void {
  const body: RoleGetDTO = {};
  const c = current || pagination.value.current as number;
  const p = pageSize || pagination.value.pageSize as number;
	
  body.page = c;
  body.limit = p;

  if (filter.value.name) {
    body.name = filter.value.name;
  }

  loading.value = true;
  httpRoleGet(body)
    .then(data => {
      total.value = data.total;
      dataSource.value = getDataSource<RoleVO, RoleTableVO>(data.vos, COLUMNS.map(d => d.dataIndex as string), c, p);
      pagination.value = getPaginationAfterFetching(pagination.value, c, p, total.value);
      roleStore.setRoles(data.vos);  // 角色修改后，roleStore 同步更新。
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => loading.value = false);
}
</script>

<template>
	
	<div :class="{ 'role-tools': pc, 'role-tools-mobile': mobile }">
		<RoleFilter :filter="filter" @filter-change="onFilterChange" @search="onSearch" @reset="onReset" />
		<div :class="{ 'role-tool-add': pc, 'role-tool-add-mobile': mobile }">
			<RoleAddOrUpdate @ok="onAddSearch" />
		</div>
	</div>
	
	<div v-if="pc" class="role-table">
		<TableLayout>
			<template #default="{ height }">
				<TableNormal
					:loading="loading"
					:pagination="pagination"
					:columns="columns"
					:dataSource="dataSource"
					:scroll="{ y: height - 336 }"
					@onChange="onPageChange"
				>
					<template #operator="{ record }">
						<RoleAddOrUpdate :vo="record.relatedVO" @ok="refresh" />
            <template v-if="!record.relatedVO.isDefaultRole">
              <IconOpSplit margin="0 8px" />
              <RoleDelete :vo="record.relatedVO" @ok="onDeleteSearch" />
            </template>
					</template>
				</TableNormal>
			</template>
		</TableLayout>
	</div>
	
  <div v-if="mobile" class="role-table-mobile">
    <TableNormal
      :loading="loading"
      :pagination="pagination"
      :columns="columns"
      :dataSource="dataSource"
      :scroll="scroll"
			@onChange="onPageChange"
    >
      <template #operator="{ record }">
				<RoleAddOrUpdate :vo="record.relatedVO" @ok="refresh" />
        <RoleDelete :vo="record.relatedVO" @ok="onDeleteSearch" />
      </template>
    </TableNormal>
  </div>
	
</template>


<style scoped>
.role-tools {
	display: flex;
	align-items: center;
	margin: 17px 16px 24px;
}

.role-tools > .role-tool-add {
	flex: 1;
	display: flex;
	justify-content: flex-end;
}

.role-tools-mobile {
	margin: var(--margin-md)  var(--margin-md)  var(--margin-sm);
}

.role-tools-mobile > .role-tool-add-mobile {
	margin-top: 16px;
}

.role-table {
  padding: 0 16px;
}

.role-table-mobile {
  overflow: auto;
  width: 100vw;
  height: calc(100vh - 165px);
}
</style>
