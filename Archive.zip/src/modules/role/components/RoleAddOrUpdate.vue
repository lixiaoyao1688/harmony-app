<script setup lang="ts">
import { computed, ref } from 'vue';
import { useRoleStore } from '@/modules/role/store/role.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getPathIdFromLeafKeys } from '@/modules/auth/utils/auth.util';
import { httpRoleAdd, httpRoleUpdate } from '@/modules/role/requests/role.http';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import { TreeNodeVO } from '@/lib/aaruy-design/tree/vo/TreeNode.vo';
import { ArrayStringVO } from '@/lib/transform/ArrayString.vo';
import { RoleVO } from '@/modules/role/vo/Role.vo';
import {
  AUTH_DISABLED_NAME_DOCTOR,
  AUTH_DISABLED_NAME_NURSE,
  AUTH_DISABLED_NAME_ROOT,
  NEW_AUTHORITY,
  NORMAL_STAFF_AUTH_TREE
} from '@/modules/auth/config/auth.config';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import IconAdd from '@/modules/record/icons/IconAdd.vue';
import DrawerEdit from '@/lib/aaruy-design/drawer/edit/DrawerEdit.vue';
import TreeForm from '@/lib/aaruy-design/tree/form/TreeForm.vue';
import LayoutForm from '@/lib/aaruy-design/layout/LayoutForm.vue';
import InputForm2 from '@/lib/aaruy-design/input/form/InputForm2.vue';
import LayoutEditor from '@/lib/aaruy-design/layout/LayoutEditor.vue';
import FieldForm from '@/lib/aaruy-design/field/FieldForm.vue';
import type { TreeExposedType } from '@/lib/aaruy-design/tree/type/tree.type';
import type { RoleAddDTO, RoleUpdateDTO } from '@/modules/role/dto/role.dto';
import type { ErrorExposedType } from '@/lib/aaruy-design/error/type/error.type';


/**
 * 新增/修改角色 组件
 *
 * 归属模块
 * 角色管理
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
	vo?: RoleVO;  // 仅 update 时需传递
}

interface Emit {
  (e: 'ok'): void;
}


const store = useRoleStore();
const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const waiting = ref<boolean>(false);
const visible = ref<boolean>(false);
// 提供给当前角色选择的权限树
const authTree = computed<Array<TreeNodeVO>>(() => prop.vo ? prop.vo.authTree : NORMAL_STAFF_AUTH_TREE);

const name = ref<string>('');
const disabledNames = ref<Array<[string, string]>>([
  ['管理员','不可与系统自带角色"管理员"重名'],
  ['医生','不可与系统自带角色"医生"重名'],
  ['护士','不可与系统自带角色"护士"重名'],
]);
const nameRef = ref<ErrorExposedType | null>(null);

// const selectedAuthLeafKeys = ref<Array<number>>(getTempLeafKeys(prop.vo));  // 已选中的权限叶子结点
const selectedAuthLeafKeys = ref<Array<number>>([]);  // 已选中的权限叶子结点
const authRef = ref<TreeExposedType | null>(null);

const remark = ref<string>('');

const isAdd = computed<boolean>(() => !prop.vo);
const title = computed<string>(() => isAdd.value ? '新建角色' : '修改角色');


function save(): void {
  if (nameRef.value && nameRef.value.checkValueError()) {
    return;
  }
  if (authRef.value && authRef.value.checkValueError()) {
    return;
  }
  if (isAdd.value) {
    add();
  } else {
    update();
  }
}

function onOpen(): void {
  if (prop.vo) {
    const data = prop.vo;
    name.value = data.name;
    selectedAuthLeafKeys.value = data.selectedLeafKeys;
    remark.value = data.remark;
    disabledNames.value = getDisabledName(prop.vo);
  }
  else {
    onReset();
    disabledNames.value = getDisabledName();
  }
  visible.value = true;
}

function getDisabledName(data?: RoleVO): Array<[string,string]> {
  if (data && data.isRoot) {
    return [AUTH_DISABLED_NAME_DOCTOR, AUTH_DISABLED_NAME_NURSE];
  }
  if (data && data.isDoctor) {
    return [AUTH_DISABLED_NAME_ROOT, AUTH_DISABLED_NAME_NURSE];
  }
  if (data && data.isNurse) {
    return [AUTH_DISABLED_NAME_ROOT, AUTH_DISABLED_NAME_DOCTOR];
  }
  return [AUTH_DISABLED_NAME_ROOT, AUTH_DISABLED_NAME_DOCTOR, AUTH_DISABLED_NAME_NURSE];
}

function onClose(): void {
  visible.value = false;
}

function onReset(): void {
  name.value = '';
  selectedAuthLeafKeys.value = getTempLeafKeys(prop.vo);
  remark.value = '';
}

// 返回所有叶子的所有祖先结点，过滤重复id并正序排列，最后转成列表字符串，如: '[1,101,2,201,20101,...]'。
function getSelectedIdDTOFromLeafKeys(leafKeys: Array<number>): string {
  return new ArrayStringVO('', getPathIdFromLeafKeys(leafKeys).sort((a,b) => a - b)).text;
}

function onNameChange(data: string): void {
  name.value = data;
}

function onRemarkChange(data: string): void {
  remark.value = data;
}

function onSelectedLeafKeyChange(data: Array<number>): void {
  selectedAuthLeafKeys.value = data;
}

function add(): void {
  const dto: RoleAddDTO = {
    name: name.value,
    menu_item_ids: getSelectedIdDTOFromLeafKeys(selectedAuthLeafKeys.value),
  };
  if (remark.value) {
    dto.remark = remark.value;
  }
  waiting.value = true;
  httpRoleAdd(dto)
    .then(() => {
      notifySuccessNormal(`已新建角色【${dto.name}】`);
      onClose();
      emit('ok');
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}

function update(): void {
  if (!prop.vo) {
    return;
  }
  
  const data = prop.vo;
  const dto: RoleUpdateDTO = {
    id: data.id,
    menu_item_ids: getSelectedIdDTOFromLeafKeys(selectedAuthLeafKeys.value),
  };
  if (name.value && name.value !== data.name) {
    dto.name = name.value;
  }
  if (remark.value !== data.remark) {
    dto.remark = remark.value;
  }
  waiting.value = true;
  httpRoleUpdate(dto)
    .then(() => {
      notifySuccessNormal(`已更新角色【${name.value}】`);
      onClose();
      emit('ok');
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}

// 临时权限 2025-08-01
//    默认医生有: 责任患者;
//    默认其他有: 全院患者;
function getTempLeafKeys(vo?: RoleVO): Array<number> {
  return vo && vo.isDoctor ? [NEW_AUTHORITY.PATIENT_MANAGEMENT_GET_DUTY] : [NEW_AUTHORITY.PATIENT_MANAGEMENT_GET_HOSPITAL];
}
</script>

<template>
	
	<DrawerEdit :opened="visible" do-not-destroy-on-close @close="onClose">
		<LayoutEditor :title="title" title-position="center" @close="onClose">
			<template #body>
				<LayoutForm :waiting="waiting" :is-full-height="true" @save="save" @cancel="onClose">
					<template #formContent>
            <FieldForm v-if="vo && vo.isDefaultRole" title="名称" :value="name" />
						<InputForm2 v-else title="名称" required ref="nameRef"
                        :data="name" :max-length="RoleVO.nameMax" :disabled-data="disabledNames"
                       @change="onNameChange" />
						<TreeForm title="权限" required ref="authRef"
                      :data="authTree" :checked-keys="selectedAuthLeafKeys"
                      @change="onSelectedLeafKeyChange" />
						<InputForm2 title="备注" :data="remark" :max-length="RoleVO.remarkMax"
                       @change="onRemarkChange" />
					</template>
				</LayoutForm>
			</template>
		</LayoutEditor>
	</DrawerEdit>
	
	<template v-if="isAdd">
		<ButtonView type="primary" text="新建" class="table-add-btn-pc" @click="onOpen">
			<template #icon>
				<IconAdd class="flex mr-7" />
			</template>
		</ButtonView>
	</template>
	<template v-else>
		<span class="text-primary cursor-pointer" @click="onOpen">修改</span>
	</template>
	
</template>
