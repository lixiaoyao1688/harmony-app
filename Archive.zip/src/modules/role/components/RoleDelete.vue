<script setup lang="ts">
import { computed, ref } from 'vue';
import { RoleVO } from '@/modules/role/vo/Role.vo';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { httpRoleDelete } from '@/modules/role/requests/role.http';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import FormModal from '@/lib/aaruy-design/form/FormModal.vue';
import IconWarn from '@/modules/admission/icons/IconWarn.vue';
import FormModalText from '@/lib/aaruy-design/form/FormModalText.vue';


interface Prop {
  vo: RoleVO;
}

interface Emit {
  (e: 'ok'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const visible = ref<boolean>(false);
const waiting = ref<boolean>(false);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function onClose(): void {
  visible.value = false;
}

function onOpen(): void {
  visible.value = true;
}

function confirm(): void {
  waiting.value = true;
  httpRoleDelete({ id: prop.vo.id })
    .then(() => {
      onClose();
      emit('ok');
      notifySuccessNormal('已删除');
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}
</script>

<template>
	<ModalView :visible="visible" :is-mobile-dialog="mobile" title="删除角色" @close="onClose">
		<FormModal :waiting="waiting" @cancel="onClose" @confirm="confirm">
			<FormModalText :mobile="mobile">
				<div class="flex" :class="{ 'justify-center': mobile }">
					<IconWarn class="mr-4" />
					{{ "确定删除【" + vo.name + "】吗？" }}
				</div>
			</FormModalText>
		</FormModal>
	</ModalView>
	<span class="cursor-pointer text-error" @click="onOpen">删除</span>
</template>
