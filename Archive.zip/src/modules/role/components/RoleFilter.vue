<script setup lang="ts">
import { computed } from 'vue';
import { RoleVO } from '@/modules/role/vo/Role.vo';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import InputFilter from '@/lib/aaruy-design/input/filter/InputFilter.vue';
import InputSearch from '@/lib/aaruy-design/input/search/InputSearch.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import type { RoleGetFilterDTO } from '@/modules/role/dto/role.dto';


interface Prop {
	filter: RoleGetFilterDTO;
}

interface Emit {
	(e: 'filterChange', data: RoleGetFilterDTO): void;
  (e: 'search'): void;
  (e: 'reset'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const userStore = useUserStore();
const screenStore = useScreenStore();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function onNameChange(n: string): void {
  emit('filterChange', { ...prop.filter, name: n });
}

function search(): void {
  emit('search');
}

function reset(): void {
  emit('reset');
}
</script>

<template>
  <div class="filter" v-if="pc">
    <InputFilter
			title="角色名称"
			:value="filter.name"
			:max-length="18"
			inputer-width="200px"
			placeholder="请输入角色名称..."
			@change="onNameChange"
			@press-enter="search"
    />
		<ButtonView type="primary" text="搜索" class="table-filter-btn-pc text-s-important ml-24" @click="search" />
		<ButtonView type="default" text="重置" class="table-filter-btn-pc text-s-important ml-8" @click="reset" />
  </div>

  <div class="filter-mobile" v-if="mobile">
		<InputSearch
			:value="filter.name"
			:max-length="RoleVO.nameMax"
			placeholder="请输入角色名称"
			class="fl-1"
			@change="onNameChange"
			@search="search"
		/>
		<ButtonView type="default" text="重置" class="table-filter-btn-mobile ml-8" @click="reset" />
  </div>
</template>

<style scoped>
.filter {
	height: 100%;
  display: flex;
  align-items: center;
}

.filter-mobile {
	display: flex;
	align-items: center;
}
</style>
