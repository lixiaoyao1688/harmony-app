import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 角色 配置
 */
export enum ROLE_KIND {
  OTHER = 0,
  ROOT = 1,
  DOCTOR = 2,
  NURSE = 3,
}

export const ROLE_KIND_ITEMS = [
  new SelectItemVO({ id: ROLE_KIND.OTHER, text: '其他' }),
  new SelectItemVO({ id: ROLE_KIND.ROOT, text: '管理员' }),
  new SelectItemVO({ id: ROLE_KIND.DOCTOR, text: '医生' }),
  new SelectItemVO({ id: ROLE_KIND.NURSE, text: '护士' }),
];

export const ROLE_KIND_MAP = SelectItemVO.getMap(ROLE_KIND_ITEMS);
