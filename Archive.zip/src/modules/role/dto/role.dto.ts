import {ROLE_KIND} from '@/modules/role/config/role.config';
import type {AuthGetDTO, AuthAddOrUpdateDTO} from '@/modules/auth/dto/auth.dto';


/**
 * 角色 DTO
*/
export interface RoleDTO {
	create_time: string;  // 创建时间
	hospital_id: number;  // 归属医院id
	id: number;  // 唯一标识
	identify: string;  // 角色标识  例：医生、护士
	// menu_ids: AuthGetDTO;  // 权限 id 集合
	menu_item_ids: AuthGetDTO;  // 权限 id 集合
	kind_id: ROLE_KIND;  // 角色类型
	name: string;  // 角色名称 例：管理员、普通用户 （长度1-18）
	remark: string;  // 备注 （长度50之内）
	update_time: string;  // 更新时间
}
export const ROLE_AUTH_SPLIT_DTO = ',';

/**
 * 增
*/
export interface RoleAddDTO {
	name: string;  // 角色名称 例：管理员、普通用户 （长度1-18）
	// menu_ids: AuthAddOrUpdateDTO;  // 权限 id 集合
	menu_item_ids: AuthAddOrUpdateDTO;  // 权限 id 集合
	remark?: string;  // 备注 （长度50之内）
}

/**
 * 删
*/
export interface RoleDeleteDTO {
	id: number;  // 唯一标识
}

/**
 * 改
*/
export interface RoleUpdateDTO {
	id: number;  // 唯一标识
	name?: string;  // 角色名称 例：管理员、普通用户 （长度1-18）
	// menu_ids?: AuthAddOrUpdateDTO;  // 权限 id 集合
	menu_item_ids?: AuthAddOrUpdateDTO;  // 权限 id 集合
	remark?: string;  // 备注 （长度50之内）
}

/**
 * 查
*/
export interface RoleGetDTO {
	name?: string;  // 角色名称 长度1-18
	page?: number;  // 页数，默认为1，最小为1
	limit?: number;  // 每页显示多少条，默认为20，范围5-100
}

/**
 * 查 过滤器
*/
export type RoleGetFilterDTO = Omit<RoleGetDTO, 'page' | 'limit'>;
