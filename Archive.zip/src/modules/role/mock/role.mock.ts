import {RoleVO} from '@/modules/role/vo/Role.vo';
import {HttpGetResponseVO} from '@/lib/http/vo/http.vo';
import {NEW_AUTHORITY} from '@/modules/auth/config/auth.config';
import {ROLE_KIND} from '@/modules/role/config/role.config';
import type {RoleGetDTO} from '@/modules/role/dto/role.dto';


export const ROLE_MOCKING = false;
export function MOCK_roleGet(body: RoleGetDTO): HttpGetResponseVO<RoleVO> {
  const TOTAL = 1;
  const vos: Array<RoleVO> = [
    new RoleVO({
      create_time: '2025-07-29',
      hospital_id: 1,
      id: 1,
      identify: '管理员',
      kind_id: ROLE_KIND.ROOT,
      menu_item_ids: [
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADD,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET_HOSPITAL,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_GET,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_DATA,
        
        
        NEW_AUTHORITY.HISTORY_PATIENT,
        NEW_AUTHORITY.HISTORY_PATIENT_GET,
        // NEW_AUTHORITY.HISTORY_PATIENT_UPDATE,
        NEW_AUTHORITY.HISTORY_PATIENT_REMOVE,
        
        
        NEW_AUTHORITY.DEVICE_MANAGEMENT,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_ADD,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_GET,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_ASSIGN,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_UPDATE_REMOVE,
        
        
        NEW_AUTHORITY.STATISTICAL_ANALYSIS,
        
        NEW_AUTHORITY.SYSTEM_MANAGEMENT,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_STAFF,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_STAFF_GET,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_STAFF_ADD,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_STAFF_UPDATE,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_STAFF_REMOVE,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_ROLE,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_ROLE_GET,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_ROLE_ADD,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_ROLE_UPDATE,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_ROLE_REMOVE,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_LOGIN_LOG,
        NEW_AUTHORITY.SYSTEM_MANAGEMENT_OP_LOG,
        
      ],
      name: '管理员',
      remark: '负责系统管理',
      update_time: '2025-07-29',
    }),
    
    new RoleVO({
      create_time: '2025-07-29',
      hospital_id: 1,
      id: 2,
      identify: '医生',
      kind_id: ROLE_KIND.DOCTOR,
      menu_item_ids: [
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADD,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET_PART,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_GET,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_ADD_CANCEL,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_DATA,
        
        
        NEW_AUTHORITY.HISTORY_PATIENT,
        NEW_AUTHORITY.HISTORY_PATIENT_GET,
        // NEW_AUTHORITY.HISTORY_PATIENT_UPDATE,
        
        
        NEW_AUTHORITY.DEVICE_MANAGEMENT,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_GET,
        
        
        NEW_AUTHORITY.STATISTICAL_ANALYSIS,
      ],
      name: '医生',
      remark: '医生',
      update_time: '2025-07-29',
    }),
    
    new RoleVO({
      create_time: '2025-07-29',
      hospital_id: 1,
      id: 3,
      identify: '护士',
      menu_item_ids: [
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADD,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_GET_PART,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_GET,
        NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_RECEIVE_RETURN_SEND,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_DATA,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_NURSING_RECORD_ADD,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_TESTING_RECORD_ADD,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_TRANSFER_PART_OR_BED,
        
        NEW_AUTHORITY.PATIENT_MANAGEMENT_REPLACE_CONSUMABLES,
        
        
        NEW_AUTHORITY.HISTORY_PATIENT,
        NEW_AUTHORITY.HISTORY_PATIENT_GET,
        
        
        NEW_AUTHORITY.DEVICE_MANAGEMENT,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_ADD,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_GET,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_ASSIGN,
        NEW_AUTHORITY.DEVICE_MANAGEMENT_UPDATE_REMOVE,
        
        
        NEW_AUTHORITY.STATISTICAL_ANALYSIS,
      ],
      kind_id: ROLE_KIND.NURSE,
      name: '护士',
      remark: '护士',
      update_time: '2025-07-29',
    })
    
  ];
  return {
    total: TOTAL,
    vos: vos,
  };
}
