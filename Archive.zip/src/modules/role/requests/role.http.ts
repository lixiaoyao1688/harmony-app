import { RoleVO } from '@/modules/role/vo/Role.vo';
import { HttpGetResponseVO } from '@/lib/http/vo/http.vo';
import { httpAdd, httpDelete, httpGet, httpUpdate } from '@/lib/http/request/http';
import {MOCK_roleGet, ROLE_MOCKING} from '@/modules/role/mock/role.mock';
import type { RoleAddDTO, RoleDeleteDTO, RoleDTO, RoleGetDTO, RoleUpdateDTO } from '@/modules/role/dto/role.dto';


const PATH = {
  ADD: '/hospital/role/add',
  DELETE: '/hospital/role/delete',
  UPDATE: '/hospital/role/update',
  GET: '/hospital/role/get',
};

enum LOG {
	ADD = '角色 新增',
	DELETE = '角色 刪除',
	UPDATE = '角色 修改',
	GET = '角色 查询',
}


export function httpRoleAdd(body: RoleAddDTO): Promise<null> {
  return httpAdd<RoleAddDTO>(PATH.ADD, body, LOG.ADD);
}

export function httpRoleDelete(body: RoleDeleteDTO): Promise<null>  {
  return httpDelete<null>(PATH.DELETE + '/' + body.id,null, LOG.DELETE);
}

export function httpRoleUpdate(body: RoleUpdateDTO): Promise<null>  {
  return httpUpdate<RoleUpdateDTO>(PATH.UPDATE, body, LOG.UPDATE);
}

export function httpRoleGet(body: RoleGetDTO): Promise<HttpGetResponseVO<RoleVO>> {
  if (ROLE_MOCKING) {
    return new Promise((resolve) => {
      resolve(MOCK_roleGet(body));
    });
  }
  return httpGet<RoleGetDTO, RoleDTO, RoleVO>(PATH.GET, body, RoleVO, LOG.GET);
}
