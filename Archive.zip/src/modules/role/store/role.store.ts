import { defineStore } from 'pinia';
import { RoleVO } from '@/modules/role/vo/Role.vo';
import { httpRoleGet } from '@/modules/role/requests/role.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { TABLE_MAX_PAGE_SIZE } from '@/lib/aaruy-design/table/normal/config/table.normal.config';


interface IState {
  role: RoleVO;  // 选中的角色
	roles: RoleVO[];
}

interface IAction {
	init: () => Promise<null>;
	setRoles: (vos: Array<RoleVO>) => void;
	getItem: (id: number) => SelectorFormItemVO;
  cloneRole: (vo: RoleVO) => void;
}

type Getter = {
	roleItems: () => SelectorFormItemVO[];  // 供给下拉列表
}


export const useRoleStore = defineStore<string, IState, Getter, IAction>('role', {
	
  state: () => ({
    role: new RoleVO(),
    roles: [],
  }),
	
  actions: {
    cloneRole(vo) {
      this.role = vo.clone();
    },
    init() {
      return new Promise((resolve, reject) => {
        httpRoleGet({ limit: TABLE_MAX_PAGE_SIZE })
          .then(data => {
            this.roles = data.vos;
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    setRoles(vos) {
      this.roles = vos;
    },
    getItem(id) {
      const item = this.roleItems.find(d => d.id === id);
      return item || SelectorFormItemVO.empty();
    },
  },
	
  getters: {
    roleItems() {
      return this.roles.map(d => d.roleItem);
    },
  }
	
});
