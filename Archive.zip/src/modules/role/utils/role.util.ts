import {INVALID_ID} from '@/utils/global.vo.help';
import {useUserStore} from '@/modules/user/store/user.store';
import {ROLE_KIND} from '@/modules/role/config/role.config';
import type {RoleDTO} from '@/modules/role/dto/role.dto';


export function getEmptyRoleDTO(): RoleDTO {
  return {
    create_time: '',
    hospital_id: useUserStore().user.relatedHospitalId,
    id: INVALID_ID,
    identify: '',
    menu_item_ids: [],
    kind_id: ROLE_KIND.OTHER,
    name: '',
    remark: '',
    update_time: '',
  };
}
