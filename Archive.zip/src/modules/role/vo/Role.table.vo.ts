import { RoleVO } from '@/modules/role/vo/Role.vo';
import { TableVO } from '@/lib/aaruy-design/table/normal/vo/Table.vo';


export interface RoleTableVO extends TableVO<RoleVO> {
	key: string;
	index: number;
	relatedVO: RoleVO;
	name: string;
	identify: string;
	remark: string;
	createTime: string;
}
