import {getEmptyRoleDTO} from '@/modules/role/utils/role.util';
import {isAuthIdLeaf} from '@/modules/auth/utils/auth.util';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {deepClone} from '@/utils/global.tool';
import {ArrayStringVO} from '@/lib/transform/ArrayString.vo';
import {TreeNodeVO} from '@/lib/aaruy-design/tree/vo/TreeNode.vo';
import {
  DOCTOR_AUTH_TREE,
  NORMAL_STAFF_AUTH_TREE,
  NURSE_AUTH_TREE,
  ROOT_AUTH_TREE
} from '@/modules/auth/config/auth.config';
import { ROLE_KIND } from '@/modules/role/config/role.config';
import type {RoleDTO} from '@/modules/role/dto/role.dto';
import type {AuthAddOrUpdateDTO, AuthGetDTO} from '@/modules/auth/dto/auth.dto';


/**
 * 角色 VO
 */
export class RoleVO {
	
	private readonly _entity: RoleDTO;
	
	constructor(e?: RoleDTO) {
	  this._entity = e || getEmptyRoleDTO();
	}
	
	// 唯一标识
	public get id(): number {
	  return this._entity.id;
	}

	// 名称，如: 管理员/普通用户
	public static nameMin = 1;
	public static nameMax = 18;
	public get nameField(): string {
	  return '名称';
	}
	public get name(): string {
	  return this._entity.name || '';
	}
	public set name(v) {
	  this._entity.name = v;
	}
	public get isNameValid(): boolean {
	  return this.name.length >= RoleVO.nameMin && this.name.length <= RoleVO.nameMax;
	}
	public get isNameLack(): boolean {
	  return this.name.length === 0;
	}
	
	
	// 备注
	public static remarkMin = 0;
	public static remarkMax = 50;
	public get remark(): string {
	  return this._entity.remark || '';
	}
	public set remark(v) {
	  this._entity.remark = v;
	}
	
	
	// 创建时间
	public get createTime(): string {
	  return this._entity.create_time || '';
	}
	public set createTime(v) {
	  this._entity.create_time = v;
	}
	
	
	public get authField() {
	  return '权限';
	}
	// 已选中的叶子结点的key
	public get selectedLeafKeys(): Array<number> {
	  if (!this._entity || !this._entity.menu_item_ids) {
	    return [];
	  }
	  // 只取出叶子结点值
	  return this._entity.menu_item_ids.filter(id => isAuthIdLeaf(id));
	  // return this.selectedKeys.filter(id => !isAuthFirstLevel(id));
	}
	// 已选中的结点key（包含父子结点）
	public get selectedKeys(): AuthGetDTO {
	  return this._entity.menu_item_ids || [];
	}
	public set selectedKeys(v) {
	  this._entity.menu_item_ids = v;
	}
	public get selectedKeysDTO(): AuthAddOrUpdateDTO {
	  return new ArrayStringVO('', this.selectedKeys).text;
	}
	
	
	// 可供该角色选择的权限树
	public get authTree(): Array<TreeNodeVO> {
	  if (!this._entity) {
	    return NORMAL_STAFF_AUTH_TREE;
	  }
	  const kind = this._entity.kind_id;
	  if (kind === ROLE_KIND.ROOT) {
	    return ROOT_AUTH_TREE;
	  }
	  if (kind === ROLE_KIND.DOCTOR) {
	    return DOCTOR_AUTH_TREE;
	  }
	  if (kind === ROLE_KIND.NURSE) {
	    return NURSE_AUTH_TREE;
	  }
	  return NORMAL_STAFF_AUTH_TREE;
	}
	
	
	// 是否系统自带的默认角色
	public get isDefaultRole(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  const kind = this._entity.kind_id;
	  return kind === ROLE_KIND.ROOT || kind === ROLE_KIND.DOCTOR || kind === ROLE_KIND.NURSE;
	}
	// 是否管理员
	public get isRoot(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.kind_id === ROLE_KIND.ROOT;
	}
	// 是否医生
	public get isDoctor(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.kind_id === ROLE_KIND.DOCTOR;
	}
	// 是否护士
	public get isNurse(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.kind_id === ROLE_KIND.NURSE;
	}
	
	
	// 用于下拉选择
	public get roleItem(): SelectorFormItemVO {
	  return new SelectorFormItemVO(this.id, this.name);
	}
	
	public clone(): RoleVO {
	  return new RoleVO(deepClone<RoleDTO>(this._entity));
	}
}
