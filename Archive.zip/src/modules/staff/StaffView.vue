<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { StaffVO } from '@/modules/staff/vo/Staff.vo';
import { ONE } from '@/lib/math/config/math.config';
import { StaffTableVO } from '@/modules/staff/vo/Staff.table.vo';
import { STAFF_STATUS } from '@/modules/staff/dto/staff.help.dto';
import StaffAdd from '@/modules/staff/components/StaffAdd.vue';
import StaffUpdate from '@/modules/staff/components/StaffUpdate.vue';
import StaffDelete from '@/modules/staff/components/StaffDelete.vue';
import StaffFilter from '@/modules/staff/components/StaffFilter.vue';
import SwitchTable from '@/lib/aaruy-design/switch/SwitchTable.vue';
import StaffPassword from '@/modules/staff/components/StaffPassword.vue';
import TableNormal from '@/lib/aaruy-design/table/normal/TableNormal.vue';
import { useUserStore } from '@/modules/user/store/user.store';
import { useRoleStore } from '@/modules/role/store/role.store';
import { useStaffStore } from '@/modules/staff/store/staff.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { httpStaffGet, httpStaffUpdate } from '@/modules/staff/requests/staff.http';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import {
  getDataSource,
  getRemoveSearchPage,
  getPaginationOnMobile,
  getColumnForMobile,
  getAddSearchPage,
  getPaginationOnPC,
  getPaginationAfterFetching
} from '@/lib/aaruy-design/table/normal/util/table.normal.util';
import { TABLE_DEFAULT_TOTAL_SIZE } from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import { INVALID_ID } from '@/utils/global.vo.help';
import { FIRST_PAGE } from '@/lib/aaruy-design/table/table';
import { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import {printError, printSingleError} from '@/lib/log/util/log.util';
import {httpHospitalAboutGet} from '@/modules/hospital/request/hospital.http';
import TableLayout from '@/lib/aaruy-design/table/layout/TableLayout.vue';
import type { StaffGetDTO, StaffGetFilterDTO } from '@/modules/staff/dto/staff.dto';
import type { TableColumnType, TablePaginationConfig } from 'ant-design-vue';


const COLUMNS: TableColumnType[] = [
  { title: '序号', dataIndex: 'index', width: '6%', fixed: false },
  { title: '账号', dataIndex: 'account', width: '8%', fixed: false },
  { title: '姓名', dataIndex: 'username', width: '8%', fixed: false },
  { title: '性别', dataIndex: 'genderText', width: '8%', fixed: false },
  { title: '手机号', dataIndex: 'phoneText', width: '12%', fixed: false },
  // { title: '岗别', dataIndex: 'kindText', width: '8%', fixed: false },
  { title: '角色', dataIndex: 'roleHtml', width: '10%', fixed: false },
  { title: '创建日期', dataIndex: 'createTime', width: '16%', fixed: false },
  { title: '状态', dataIndex: 'statusEnable', width: '8%', fixed: false },
  { title: '操作', dataIndex: 'operator', width: '16%', fixed: false },
];
const MOBILE_WIDTHS: Array<number> = [80,100,150,100,150,200,200,100,200];

const store = useStaffStore();
const roleStore = useRoleStore();
const userStore = useUserStore();
const screenStore = useScreenStore();

const loading = ref<boolean>(false);
const dataSource = ref<StaffTableVO[]>([]);
const total = ref<number>(TABLE_DEFAULT_TOTAL_SIZE);
const filter = ref<StaffGetFilterDTO>(getInitFilter());
const columns = ref<TableColumnType[]>(screenStore.isPC ? COLUMNS : getColumnForMobile(COLUMNS, MOBILE_WIDTHS));
const pagination = ref<TablePaginationConfig>(screenStore.isPC ? getPaginationOnPC() : getPaginationOnMobile());
const isStaffMax = ref<boolean>(true);  // 创建用户数是否已达到系统上限

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
// 横向滚动时需使 scroll.x < width 总和
const scroll = computed<{ x: number } | null>(() => pc.value ? null : ({ x: MOBILE_WIDTHS.reduce((acc, cur) => acc + cur) - ONE }));


onMounted(() => {
  roleStore.init();
  refresh();
  fetchIsStaffMax();
});

function onStatusChange(enabled: boolean, vo: StaffVO) {
  httpStaffUpdate({ id: vo.id, status: enabled ? STAFF_STATUS.NORMAL : STAFF_STATUS.DISABLED })
    .then(() => {
      notifySuccessNormal();
      refresh();
    })
    .catch(reason => notifyErrorNormal(reason));
}

function refresh() {
  fetchData(pagination.value.current, pagination.value.pageSize);
}

function onAddOk(): void {
  fetchIsStaffMax();
  fetchData(getAddSearchPage(pagination.value.total as number, pagination.value.pageSize as number));
}

function onDeleteOk(): void {
  fetchIsStaffMax();
  fetchData(getRemoveSearchPage(pagination.value.current as number, dataSource.value.length));
}

function onPageChange(p: PaginationData) {
  fetchData(p.page, p.pageSize);
}

function onFilterChange(data: StaffGetFilterDTO) {
  filter.value = data;
}

function onSearch() {
  fetchData(FIRST_PAGE);
}

function onReset() {
  resetFilter();
  fetchData(FIRST_PAGE);
}

function resetFilter() {
  filter.value = getInitFilter();
}

function getInitFilter(): StaffGetFilterDTO {
  return { search_name: '', gender: INVALID_ID };
}

function fetchIsStaffMax(): void {
  httpHospitalAboutGet()
    .then(vo => {
      isStaffMax.value = vo.isStaffMax;
    })
    .catch(reason => printSingleError(reason));
}

function fetchData(current?: number, pageSize?: number) {
  const body: StaffGetDTO = {};
  const c = current || pagination.value.current as number;
  const p = pageSize || pagination.value.pageSize as number;

  body.page = c;
  body.limit = p;

  if (filter.value.search_name) {
    body.search_name = filter.value.search_name;
  }
  if (filter.value.gender !== INVALID_ID) {
    body.gender = filter.value.gender;
  }

  loading.value = true;
  httpStaffGet(body)
    .then(data => {
      total.value = data.total;
      dataSource.value = getDataSource<StaffVO, StaffTableVO>(data.vos, COLUMNS.map(d => d.dataIndex as string), c, p);
      pagination.value = getPaginationAfterFetching(pagination.value, c, p, total.value);
    })
    .catch(reason => printError('[HTTP ERROR]', reason))
    .finally(() => loading.value = false);
}
</script>

<template>
  <div :class="{ 'staff-tools': pc, 'staff-tools-mobile': mobile }">
    <StaffFilter :filter="filter" @filter-change="onFilterChange" @search="onSearch" @reset="onReset" />
    <div :class="{ 'staff-tool-add': pc, 'staff-tool-add-mobile': mobile }">
      <StaffAdd :is-staff-max="isStaffMax" @ok="onAddOk" />
    </div>
  </div>
	<div v-if="pc" class="staff-table">
		<TableLayout>
			<template #default="{ height }">
				<TableNormal
					:loading="loading"
					:pagination="pagination"
					:columns="columns"
					:dataSource="dataSource"
					:scroll="{ y: height - 336 }"
					@onChange="onPageChange"
				>
					<template #cell="{ column, record }">
						<template v-if="column.dataIndex === 'statusEnable'">
							<SwitchTable :data="record.statusEnable" @change="onStatusChange($event, record.relatedVO)" />
						</template>
						<template v-if="column.dataIndex === 'roleHtml'">
							<span v-html="record.relatedVO.roleHtml"></span>
						</template>
					</template>
					<template #operator="{ record }">
						<StaffUpdate :vo="record.relatedVO" @ok="refresh" />
						<StaffPassword :vo="record.relatedVO" />
						<StaffDelete :vo="record.relatedVO" @ok="onDeleteOk" />
					</template>
				</TableNormal>
			</template>
		</TableLayout>
	</div>
	<div v-if="mobile" class="staff-table-mobile">
		<TableNormal
			:loading="loading"
			:pagination="pagination"
			:columns="columns"
			:dataSource="dataSource"
			:scroll="scroll"
			@onChange="onPageChange"
		>
			<template #cell="{ column, record }">
				<template v-if="column.dataIndex === 'statusEnable'">
					<SwitchTable :data="record.statusEnable" @change="onStatusChange($event, record.relatedVO)" />
				</template>
				<template v-if="column.dataIndex === 'roleHtml'">
					<span v-html="record.relatedVO.roleHtml"></span>
				</template>
			</template>
			<template #operator="{ record }">
				<StaffUpdate :vo="record.relatedVO" @ok="refresh" />
				<StaffPassword :vo="record.relatedVO" />
				<StaffDelete :vo="record.relatedVO" @ok="onDeleteOk" />
			</template>
		</TableNormal>
	</div>
</template>

<style scoped>
.staff-tools {
  display: flex;
  align-items: center;
	margin: 17px 16px 24px;
}

.staff-tools > .staff-tool-add {
  flex: 1;
  display: flex;
  justify-content: flex-end;
}

.staff-tools-mobile {
  margin: var(--margin-md)  var(--margin-md)  var(--margin-sm);
}

.staff-tools-mobile > .staff-tool-add-mobile {
	margin-top: 16px;
}

.staff-table {
  padding: 0 16px;
}

.staff-table-mobile {
  overflow: auto;
  flex-basis: 100%;
  width: 100vw;
  height: calc(100vh - 185px);
}
</style>
