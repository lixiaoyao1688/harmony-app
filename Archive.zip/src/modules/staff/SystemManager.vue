<script setup lang="ts">
import { computed, ref } from 'vue';
import { TabVO } from '@/lib/aaruy-design/tab/Tab.vo';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useSystemManagerStore } from '@/modules/staff/store/system.manager.store';
import { SM_LOGIN, SM_OPERATION, SM_ROLE, SM_STAFF, SYSTEM_MANAGER } from '@/modules/staff/dto/system.manager.dto';
import RoleView from '@/modules/role/RoleView.vue';
import StaffView from '@/modules/staff/StaffView.vue';
import LogLogin from '@/modules/log-login/LogLogin.vue';
import LogOp from '@/modules/log-operation/LogOp.vue';
import TabBody from '@/lib/aaruy-design/tab/tab-body/TabBody.vue';


const userStore = useUserStore();
const screenStore = useScreenStore();
const systemManagerStore = useSystemManagerStore();

const options = ref<TabVO[]>([SM_ROLE,SM_STAFF,SM_LOGIN,SM_OPERATION]);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const isStaff = computed<boolean>(() => systemManagerStore.key === SYSTEM_MANAGER.STAFF);
const isRole = computed<boolean>(() => systemManagerStore.key === SYSTEM_MANAGER.ROLE);
const isLogin = computed<boolean>(() => systemManagerStore.key === SYSTEM_MANAGER.LOGIN);
const isOp = computed<boolean>(() => systemManagerStore.key === SYSTEM_MANAGER.OPERATION);

function onChange(k: SYSTEM_MANAGER): void {
  systemManagerStore.setKey(k);
}
</script>

<template>
  <div id="sm" class="sm">
    <div class="sm-main" v-if="pc">
      <TabBody :options="options" :activeKey="systemManagerStore.key" @change="onChange" />
      <RoleView v-if="isRole" />
      <StaffView v-if="isStaff" />
      <LogLogin v-if="isLogin" />
      <LogOp v-if="isOp" />
    </div>
    <div class="sm-main" v-if="mobile">
      <LogLogin  v-if="isLogin"/>
      <LogOp v-if="isOp"/>
      <StaffView v-if="isStaff" />
      <RoleView v-if="isRole" />
    </div>
  </div>
</template>

<style scoped>
.sm {
	display: flex;
	height: calc(100vh - var(--header-height));
	overflow: hidden auto;
	position: relative;
}

.sm-main {
  flex-basis: 100%;
}
</style>
