<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {BoardVO} from '@/modules/board/vo/Board.vo';


/**
 * 报警看板 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  vo: BoardVO;
  margin?: string;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <div v-if="pc" class="rounded-4 bg-1 p-16" :style="{ margin: margin }">
    <div class="inline-flex">
      <div class="pr-48">
        <div class="text-xl-1 mb-12" style="height: 64px; line-height: 64px;">消息提示</div>
        <div class="inline-flex items-center" style="height: 48px; line-height: 48px;">
          <span class="text-xl-normal leading-xl mr-16">已处理</span>
          <span class="text-xxl-2-5 leading-xxl-2-5 font-bold text-resolved-2">{{ vo.warnResolvedCountText }}</span>
        </div>
      </div>
      <div>
        <div class="text-xxl-4 mb-12 font-bold" style="height: 64px; line-height: 64px;">{{ vo.warnCountText }}</div>
        <div class="inline-flex items-center" style="height: 48px; line-height: 48px;">
          <span class="text-xl-normal leading-xl mr-16">未处理</span>
          <span class="text-xxl-2-5 leading-xxl-2-5 font-bold text-not-resolved-2">{{ vo.warnNotResolvedCountText }}</span>
        </div>
      </div>
    </div>
  </div>
  <div v-else class="rounded-4 bg-4 flex text-white py-24 mb-8 px-16" :style="{ margin: margin }">
    <div class="w-half text-center">
      <div class="text-s font-bold">消息提示</div>
      <div class="text-xxl-3 leading-xxl-3">{{ vo.warnCountText }}</div>
    </div>
    <div class="w-half inline-flex flex-col justify-between items-center">
      <div class="text-s flex items-center">已处理<span class="ml-16 text-xl-1-2 leading-xl-1-2 text-resolved">{{ vo.warnResolvedCountText }}</span></div>
      <div class="text-s flex items-center">未处理<span class="ml-16 text-xl-1-2 leading-xl-1-2 text-not-resolved">{{ vo.warnNotResolvedCountText }}</span></div>
    </div>
  </div>
</template>
