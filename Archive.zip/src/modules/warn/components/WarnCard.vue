<script setup lang="ts">
import { WarnInfoVO } from '@/modules/warn/vo/WarnInfo.vo';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import CardView2 from '@/lib/aaruy-design/card/CardView2.vue';
import CardViewMobile from '@/lib/aaruy-design/card/CardViewMobile.vue';


interface Prop {
	info: WarnInfoVO;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
</script>

<template>
  
  <CardView2 v-if="screenStore.isPC" :height="52" width="100%" padding="10px 8px">
    <div class="flex items-center justify-between h-100">
      <div class="flex items-center">
        <span v-html="info.icon" class="inline-flex"></span>
        <span class="text-s text-white ml-4 ellipsis" style="max-width: 100px;" :title="info.text">{{ info.text }}</span>
      </div>
      <div class="text-xxs text-weak-2 flex flex-col items-end">
        <span>{{ info.date }}</span>
        <span>{{ info.time }}</span>
      </div>
    </div>
  </CardView2>
	<CardViewMobile v-else class="mx-16 mb-4 border-4 py-12 px-16" :hide-header="true">
		<div class="flex items-center">
			<span v-html="info.icon" class="inline-flex"></span>
			<span class="text-s text-white ml-8 ellipsis" :title="info.text">{{ info.text }}</span>
		</div>
		<div class="text-xxs text-weak-2 mt-4">
			<span class="mr-8">{{ info.date }}</span>
			<span>{{ info.time }}</span>
		</div>
	</CardViewMobile>
	
</template>
