<script setup lang="ts">
import { useWarnStore } from '@/modules/warn/store/warn.store';
import WarnMore from '@/modules/warn/components/WarnMore.vue';
import WarnFooter from '@/modules/warn/components/WarnFooter.vue';
import DrawerBottom from '@/lib/aaruy-design/drawer/bottom/DrawerBottom.vue';


const warnStore = useWarnStore();

function close() {
  warnStore.warnTotalVisible = false;
}
</script>

<template>
  <DrawerBottom :opened="warnStore.warnTotalVisible" @close="close">
    <div class="warn-line-total">
      <div class="warn-line-total-1">
        <WarnFooter />
      </div>
      <div class="warn-line-total-2">
        <WarnMore />
      </div>
    </div>
  </DrawerBottom>
</template>

<style scoped>
.warn-line-total {
  display: flex;
  min-height: calc(var(--warn-height) * 2);
  background-color: rgb(21,26,30);
}

.warn-line-total-1 {
  flex: 1;
}

.warn-line-total-2 {
  width: fit-content;
}
</style>
