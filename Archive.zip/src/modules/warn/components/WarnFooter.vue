<script setup lang="ts">
import { onMounted } from 'vue';
import { useWarnStore } from '@/modules/warn/store/warn.store';
import { WARN_ITEM_INTERVAL, WARN_LIST_ID } from '@/modules/warn/config/warn.config';


const store = useWarnStore();

onMounted(() => {
  store.updateWarnCountAndWidth();
});

function openWarnList(): void {
  store.visibleForList = true;
}
</script>

<template>
  <div :id="WARN_LIST_ID" class="warn-list">
    <div v-if="store.warns.length === 0" class="warn-list-empty">暂无报警信息</div>
    <div
      v-for="w in store.warns"
      :key="w.id"
      :style="{
        backgroundColor: w.color,
        width: store.warnWidth + 'px',
        borderRight: `${WARN_ITEM_INTERVAL}px solid var(--warn-bg-color)`,
        borderTop: `${WARN_ITEM_INTERVAL / 2}px solid var(--warn-bg-color)`,
        borderBottom: `${WARN_ITEM_INTERVAL / 2}px solid var(--warn-bg-color)`,
      }"
      class="warn-item"
      :class="{ hidden: !store.warnTotalVisible && w.index > store.warnCountPerRow }"
			@click="openWarnList"
    >
      <span class="warn-item-text ellipsis" :title="w.bedText">{{ w.bedText }}</span>
    </div>
  </div>
</template>

<style scoped>
.warn-list {
  flex: 1;
  width: 100%;
  height: 100%;
  display: flex;
  flex-wrap: wrap;
}

.warn-list > .warn-list-empty {
  width: 100%;
  height: 100%;
  padding-left: 20px;
  display: flex;
  align-items: center;
  color: rgba(255,255,255,0.6);
  font-size: 16px;
}

.warn-list > .warn-item {
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255,255,255,1);
  height: var(--warn-height);
}

.warn-list > .warn-item:hover {
	cursor: pointer;
	filter: brightness(1.1);
}

.warn-list > .warn-item.hidden {
  display: none;
}

.warn-list > .warn-item > .warn-item-text {
  display: inline-block;
  width: 100%;
  text-align: center;
  padding: 0 2px;
  font-size: 18px;
}
</style>
