<script setup lang="ts">
import { computed } from 'vue';
import { useWarnStore } from '@/modules/warn/store/warn.store';
import IconWarnUp from '@/modules/warn/icons/IconWarnUp.vue';
import IconWarnDown from '@/modules/warn/icons/IconWarnDown.vue';
import IconWarnUpDisabled from '@/modules/warn/icons/IconWarnUpDisabled.vue';
import IconWarnMore from '@/modules/warn/icons/IconWarnMore.vue';


interface Emit {
  (e: 'ok'): void;
}

const emit = defineEmits<Emit>();

const warnStore = useWarnStore();
const disabled = computed<boolean>(() => warnStore.warns.length <= warnStore.warnCountPerRow);


function trigger(): void {
  if (disabled.value) {
    return;
  }
  warnStore.warnTotalVisible = !warnStore.warnTotalVisible;
}
</script>

<template>
	<div class="warn-more" :class="{ hidden: disabled }" @click="trigger">
		<IconWarnDown v-if="warnStore.warnTotalVisible" />
		<template v-else>
			<IconWarnMore v-if="!disabled" />
		</template>
	</div>
<!--  <div class="warn-more" :class="{ disabled: disabled, hidden: disabled }" @click="trigger">-->
<!--    <IconWarnDown v-if="warnStore.warnTotalVisible" />-->
<!--    <template v-else>-->
<!--      <IconWarnUpDisabled v-if="disabled" />-->
<!--      <IconWarnUp v-else />-->
<!--    </template>-->
<!--  </div>-->
</template>

<style scoped>
.warn-more {
  width: 44px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgb(78,87,95);
  border-top: 1px solid var(--warn-bg-color);
  border-bottom: 1px solid var(--warn-bg-color);
}

.warn-more:not(.disabled) {
  cursor: pointer;
}

.warn-more:not(.disabled):hover {
  background-color: rgb(38,111,232);
}
</style>
