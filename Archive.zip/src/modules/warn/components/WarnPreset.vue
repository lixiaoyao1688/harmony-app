<script setup lang="ts">
import { computed, onUnmounted, ref } from 'vue';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useSystemConfigStore } from '@/modules/system-config/store/system.config.store';
import { httpSystemConfigUpdate } from '@/modules/system-config/requests/system.config.http';
import { notifyErrorNormal, notifySuccessNormal } from '@/lib/aaruy-design/notify/notify';
import { SystemConfigVO } from '@/modules/system-config/vo/SystemConfig.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import LayoutForm from '@/lib/aaruy-design/layout/LayoutForm.vue';
import TabView from '@/lib/aaruy-design/tab/TabView.vue';
import CounterView from '@/lib/aaruy-design/counter/CounterView.vue';
import NewCounter from '@/lib/aaruy-design/counter/NewCounter.vue';
import LayoutDetailMobile from '@/lib/aaruy-design/layout/LayoutDetailMobile.vue';
import type { SystemConfigUpdateDTO } from '@/modules/system-config/dto/system.config.dto';


const userStore = useUserStore();
const store = useSystemConfigStore();
const screenStore = useScreenStore();

const waiting = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

const item = new SelectorFormItemVO(1, '报警预设');
const items = [item];


onUnmounted(() => {
  onReset();
});

function onChange(key: string, v: number): void {
  store.systemConfig[key] = v;
}

function onReset(): void {
  store.systemConfig = new SystemConfigVO(userStore.user.dto);
}

function onSave(): void {
  const dto: SystemConfigUpdateDTO = {
    warn_low: store.systemConfig.gluBottom,
    warn_high: store.systemConfig.gluTop,
    dose_threshold: store.systemConfig.drugBottom,
  };
  waiting.value = true;
  httpSystemConfigUpdate(dto)
    .then(_ => {
      notifySuccessNormal();
      userStore.fetchUser();
    })
    .catch(reason => notifyErrorNormal(reason))
    .finally(() => waiting.value = false);
}
</script>

<template>
	
	<div class="flex h-100" v-if="pc">
		<TabView type="vertical" :items="items" :item="item" />
		<LayoutForm :waiting="waiting" :is-full-height="true" :show-reset="true" @save="onSave" @reset="onReset">
			<template #formContent>
				<CounterView title="低药量报警阈值" unit="U" :data="store.systemConfig.drugBottom" :step="0.1" :digit="1" :min="0" :max="30" class="pt-16 mb-24" @change="onChange('drugBottom', $event)" />
				<CounterView title="低血糖报警阈值" unit="mmol" :data="store.systemConfig.gluBottom" :step="0.1" :digit="1" :min="0" :max="1000" class="mb-24" @change="onChange('gluBottom', $event)" />
				<CounterView title="高血糖报警阈值" unit="mmol" :data="store.systemConfig.gluTop" :step="0.1" :digit="1" :min="0" :max="30" class="mb-24" @change="onChange('gluTop', $event)" />
			</template>
		</LayoutForm>
	</div>
	
	<template v-if="mobile">
		<LayoutDetailMobile height="calc(100vh - var(--board-top) - var(--tab-form-height))" :waiting="waiting" :show-reset="true" :is-bg-transparent="true" :show-button-group="true" @save="onSave" @reset="onReset">
			<div class="mb-24 mt-24 px-16">
				<NewCounter title="低药量报警阈值" :value="store.systemConfig.drugBottom" :min="0" :max="30" unit="U" @change="onChange('drugBottom', $event)" />
			</div>
			<div class="mb-24 px-16">
				<NewCounter title="低血糖报警阈值" :value="store.systemConfig.gluBottom" :min="0" :max="100" unit="mmol" @change="onChange('gluBottom', $event)" />
			</div>
			<div class="mb-24 px-16">
				<NewCounter title="高血糖报警阈值" :value="store.systemConfig.gluTop" :min="0" :max="100" unit="mmol" @change="onChange('gluTop', $event)" />
			</div>
		</LayoutDetailMobile>
	</template>

</template>
