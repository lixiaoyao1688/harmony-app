<script setup lang="ts">
import type {WarnSummaryItemType} from '@/modules/warn/types/warn.summary.type';


/**
 * 报警总结卡片 组件
 *
 * 归属功能
 * 报警总结
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  title: string;
  value: string;
  item1: WarnSummaryItemType;
  item2: WarnSummaryItemType;
  useReportStyle?: boolean;  // 是否使用报告样式
}

defineProps<Prop>();
</script>

<template>
  <div v-if="useReportStyle"
       style="flex: 1; display: flex; border-radius: 4px; padding: 5px 10px; background-color: rgb(242,247,255);">
    <div style="width: 30%;">
      <div style="color: rgb(36,44,51); font-size: 14px; font-weight: 700;">{{ title }}</div>
      <div style="color: rgb(51,51,51);">
        <span style="font-size: 24px; line-height: 36px;">{{ value }}</span>
        <span style="font-size: 12px; margin-left: 4px;">次</span>
      </div>
    </div>
    <div style="width: 70%; font-size: 14px;">
      <div style="display: flex; justify-content: space-between; color: rgb(0,0,0);">
        <span>{{ item1.name }}</span><span>{{ item2.name }}</span>
      </div>
      <div style="display: flex; justify-content: space-between; font-weight: 700; color: rgb(51,51,51);">
        <span>{{ item1.value }}</span><span>{{ item2.value }}</span>
      </div>
      <div style="display: flex; height: 12px;">
        <span :style="{ width: item1.percent, backgroundColor: item1.color }"></span>
        <span :style="{ width: item2.percent, backgroundColor: item2.color }"></span>
      </div>
    </div>
  </div>
  <div v-else class="flex-1 bg-1 rounded-4 p-4 flex text-white">
    <div style="min-width: 152px;" class="bg-10 rounded-4 px-12 pt-12">
      <div class="text-xl-normal leading-xl pb-10">{{ title }}</div>
      <div>
        <span class="text-xxl-2-6 leading-xxl-2-6 font-bold">{{ value }}</span>
        <span class="text-lg leading-l text-weak-10 pl-4">次</span>
      </div>
    </div>
    <div class="flex-1 px-20">
      <div class="text-xl-normal leading-xl flex justify-between pt-12">
        <span>{{ item1.name }}</span><span>{{ item2.name }}</span>
      </div>
      <div class="text-xl-2 leading-xl-2 font-bold flex justify-between">
        <span>{{ item1.value }}</span><span>{{ item2.value }}</span>
      </div>
      <div class="flex mt-4" style="height: 24px;">
        <span :style="{ width: item1.percent, backgroundColor: item1.color }"></span>
        <span :style="{ width: item2.percent, backgroundColor: item2.color }"></span>
      </div>
    </div>
  </div>
</template>
