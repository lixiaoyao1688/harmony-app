<script setup lang="ts">
import {WarnSummaryVO} from '@/modules/warn/vo/WarnSummary.vo';
import WarnSummaryCard from '@/modules/warn/components/WarnSummaryCard.vue';
import EmptyIcon from '@/lib/aaruy-design/empty/EmptyIcon.vue';
import LegendChart from '@/lib/aaruy-design/legend/LegendChart.vue';
import TableDetail from '@/lib/aaruy-design/table/detail/TableDetail.vue';


/**
 * 报警总结-内容 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  vo: WarnSummaryVO;
  elId: string;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="flex justify-between" style="height: 128px;">
    <WarnSummaryCard title="血糖报警" :value="vo.gluCountText" :item1="vo.gluLowSumItem" :item2="vo.gluHighSumItem" />
    <div style="width: 12px;"></div>
    <WarnSummaryCard title="胰岛素泵报警" :value="vo.pumpCountText" :item1="vo.pumpBlockSumItem" :item2="vo.pumpFaultCountItem" />
  </div>
  <div class="bg-1 rounded-4 mt-12" style="height: 210px;">
    <div class="flex items-center justify-between pl-16 pr-40 pt-16" style="height: 40px;">
      <span class="text-lg leading-l font-bold mr-16">概况</span>
      <LegendChart :items="WarnSummaryVO.legends" />
    </div>
    <div :id="elId" style="height: calc(100% - 40px);"></div>
  </div>
  <div class="text-xl-normal leading-xl font-bold mt-16">每日详情</div>
  <div v-if="!vo.hasDayVOs" class="bg-1 p-12 rounded-4 mt-12" style="height: 280px;">
    <EmptyIcon tips="暂无数据" height="100%" align-center />
  </div>
  <template v-else>
    <div v-for="d in vo.dayVOs" :key="d.id" class="flex bg-1 p-12 rounded-4 mt-12" style="height: 424px;">
      <div class="flex-1">
        <div class="flex pb-16">
          <span class="text-s text-white bg-primary font-bold text-center rounded-4 mr-32"
                style="width: 120px; height: 40px; line-height: 40px;">{{ d.dateText }}</span>
          <div class="flex">
            <div v-for="(it,i) in d.summaryItems" :key="it.id"
                 :style="{ color: it.payload.color }"
                 :class="{ 'pl-32': i > 0 }">
              <div class="text-s" style="line-height: 16px;">{{ it.text }}</div>
              <div class="text-xl-2 font-bold" style="line-height: 32px;">{{ it.payload.value }}</div>
            </div>
          </div>
        </div>
        <div style="height: 300px;" class="pl-16 pr-32">
          <div class="flex h-full">
            <div v-for="(it,i) in d.counts" :key="i" :class="{ 'border-r-bg-9': i === d.counts.length-1 }"
                 class="border-l-bg-9 border-t-bg-9 flex-1">
              <div class="h-half border-b-bg-9 flex justify-center items-end">
                <div style="width: 20px;">
                  <div class="text-center">{{ it[0].value + it[1].value > 0 ? Math.floor(it[0].value + it[1].value) : '' }}</div>
                  <div>
                    <div :style="{ backgroundColor: it[0].color, height: it[0].height }"></div>
                    <div :style="{ backgroundColor: it[1].color, height: it[1].height }"></div>
                  </div>
                </div>
              </div>
              <div class="h-half flex justify-center">
                <div style="width: 20px;">
                  <div>
                    <div :style="{ backgroundColor: it[2].color, height: it[2].height }"></div>
                    <div :style="{ backgroundColor: it[3].color, height: it[3].height }"></div>
                  </div>
                  <div class="text-center">{{ it[2].value + it[3].value > 0 ? Math.floor(it[2].value + it[3].value) : '' }}</div>
                </div>
              </div>
              <div class="flex" style="height: 6px;">
                <span class="flex-1 h-full border-t-bg-9 border-l-bg-9"></span>
                <span class="flex-1 h-full border-t-bg-9 border-l-bg-9"></span>
                <span class="flex-1 h-full border-t-bg-9 border-l-bg-9" :class="{ 'border-r-bg-9':i === d.counts.length-1 }"></span>
              </div>
            </div>
          </div>
        </div>
        <div class="flex text-bg-20 text-xs leading-2 pl-16 pr-32 pt-8">
          <div class="flex-1 relative"><span class="absolute" style="left: -16px;">00:00</span></div>
          <div class="flex-1"></div>
          <div class="flex-1 relative"><span class="absolute" style="left: -16px;">06:00</span></div>
          <div class="flex-1"></div>
          <div class="flex-1 relative"><span class="absolute" style="left: -16px;">12:00</span></div>
          <div class="flex-1"></div>
          <div class="flex-1 relative"><span class="absolute" style="left: -16px;">18:00</span></div>
          <div class="flex-1 text-right relative"><span class="absolute" style="right: -16px;">24:00</span></div>
        </div>
      </div>
      <div style="width: 440px;" class="h-full">
        <TableDetail :keys="d.table.keys" :data="d.table.values" />
      </div>
    </div>
  </template>
</template>
