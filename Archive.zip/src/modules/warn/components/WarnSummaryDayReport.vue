<script setup lang="ts">
import {WarnSummaryDayForReportVO} from '@/modules/warn/vo/WarnSummaryDayForReport.vo';


/**
 * 每日报警时段 组件
 *
 * 归属功能
 * 报警总结 报告
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  vo: WarnSummaryDayForReportVO;
}

const prop = defineProps<Prop>();
</script>

<template>
  <td style="border: 1px solid rgb(173,179,186); padding: 0; width: 20%;">
    <div style="box-sizing: border-box; height: 108px;">
      <div style="height: 18px; line-height: 18px; padding-left: 4px; color: rgb(51,51,51); font-size: 12px;">{{ vo.dateText }}</div>
      <div style="height: calc(100% - 18px); display: flex; position: relative;">
        <div v-for="(c,i) in vo.counts" :key="i" style="flex: 1;">
          <div style="height: 50%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center;">
            <div style="width: 4px;" :style="{ height: c[0].height, backgroundColor: c[0].colorForReport }"></div>
            <div style="width: 4px;" :style="{ height: c[1].height, backgroundColor: c[1].colorForReport }"></div>
          </div>
          <div style="height: 50%; display: flex; flex-direction: column; justify-content: flex-start; align-items: center;">
            <div style="width: 4px;" :style="{ height: c[2].height, backgroundColor: c[2].colorForReport }"></div>
            <div style="width: 4px;" :style="{ height: c[3].height, backgroundColor: c[3].colorForReport }"></div>
          </div>
        </div>
        <div style="position: absolute; top: 50%; height: 6px; margin-top: -3px; left: 0; display: flex; width: 100%;"
        >
          <div v-for="(_,i) in vo.counts" :key="i" style="height: 100%; flex: 1;"
               :style="{ borderLeft: i > 0 ? '1px solid rgb(189,205,219)' : 'none' }"
          >
            <div style="height: 50%; border-bottom: 1px solid rgb(186,205,219);"></div>
            <div style="height: 50%;"></div>
          </div>
        </div>
      </div>
    </div>
  </td>
</template>
