<script setup lang="ts">
import {computed, onMounted, ref, watch} from 'vue';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {getInlineElementWidth} from '@/lib/dom/utils/dom.util';
import {getWarnBgColorNew, getWarnTextBgColor} from '@/modules/warn/util/warn.util.new';
import IconWarnTriangle from '@/modules/warn/icons/IconWarnTriangle.vue';
import type {WarnDTO} from '@/modules/warn/dto/warn.dto';


/**
 * 消息提示词 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  tips: string;
  width: string;
  data: WarnDTO;
  isDisconnected: boolean;
}

const screenStore = useScreenStore();
const prop = defineProps<Prop>();
const isTitleOverflow = ref<boolean>(false);
const container = ref<HTMLSpanElement | null>(null);
const content = ref<HTMLSpanElement | null>(null);
const color = computed<string>(() => getWarnBgColorNew(prop.data, false, prop.isDisconnected));  // 仅pc
const textBgColor = computed<string>(() => getWarnTextBgColor(prop.data, prop.isDisconnected));


onMounted(() => {
  check();
});

watch(() => prop.tips, () => {
  check();
}, { immediate: true, flush: 'post' });

watch(() => prop.width, () => {
  check();
}, { immediate: true, flush: 'post' });

function check(): void {
  if (container.value && content.value) {
    isTitleOverflow.value = getInlineElementWidth(content.value) > getInlineElementWidth(container.value);
  }
}
</script>

<template>
  <div class="inline-flex items-center">
    <IconWarnTriangle :color="color" :z-index="1" :scale="screenStore.is4KOrAbove ? 1.2 : 1" />
    <div :title="tips"
         :style="{
           width: width,
           backgroundColor: textBgColor,
           marginLeft: screenStore.is4KOrAbove ? '-40px' : '-12px',
           paddingLeft: screenStore.is4KOrAbove ? '44px' : '12px'
         }"
         class="pr-4 inline-flex z-0">
      <span ref="container"
            :class="{
              'aaruy-marquee-hover-fast': isTitleOverflow,
              'text-xs': !screenStore.is4KOrAbove,
              'text-xl-1-2': screenStore.is4KOrAbove
            }"
            :style="{
              height: screenStore.is4KOrAbove ? '48px' : '24px',
              lineHeight: screenStore.is4KOrAbove ? '48px' : '24px'
            }"
            class="flex-1 ellipsis inline-block text-center">
        <span ref="content">{{ tips }}</span>
      </span>
    </div>
  </div>
</template>
