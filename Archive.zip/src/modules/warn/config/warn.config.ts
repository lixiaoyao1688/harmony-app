export const WARN_LIST_ID = 'warnListId';
export const WARN_ITEM_INTERVAL = 1;
export const WARN_ITEM_WIDTH_DEFAULT = 66;
export const WARN_ITEM_COUNT_PER_ROW_DEFAULT = 28;
export const WARN_NOTIFY_LAST_TIME = 4;  // 报警弹窗保留时间 (秒)
export const WARN_VIEW_DOM_ID = 'warnView';
