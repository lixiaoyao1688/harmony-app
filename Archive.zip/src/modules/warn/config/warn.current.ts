export enum WARN_SUB_KIND {
  WARN = 0,  // 报警
  TIPS = 1,  // 提示
}

export enum WARN_SCENE {
  LOW = 0,  // 低
  HIGH = 1,  // 高
}
