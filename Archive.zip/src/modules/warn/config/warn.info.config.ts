import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


export enum WARN_SORT {
  TIME = 0,
  PRIORITY = 1,
}

export const WARN_SORT_OPTIONS = [
  new SelectorFormItemVO(WARN_SORT.TIME, '时间'),
  new SelectorFormItemVO(WARN_SORT.PRIORITY, '优先级'),
];

export const WARN_SORT_MAP = SelectorFormItemVO.getMap(WARN_SORT_OPTIONS);

export const DEFAULT_WARN_SORT_OPTION = WARN_SORT_OPTIONS[0];
