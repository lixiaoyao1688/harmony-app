import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 报警种类 配置
 */
export enum WARN_NEW_KIND {
  NORMAL = 0,
  WARN,
  TIPS,
  ADVICE
}

export const WARN_NEW_KIND_NORMAL = new SelectItemVO({ id: WARN_NEW_KIND.NORMAL, text: '正常' });
export const WARN_NEW_KIND_WARN = new SelectItemVO({ id: WARN_NEW_KIND.WARN, text: '报警' });
export const WARN_NEW_KIND_TIPS = new SelectItemVO({ id: WARN_NEW_KIND.TIPS, text: '提示' });
export const WARN_NEW_KIND_ADVICE = new SelectItemVO({ id: WARN_NEW_KIND.ADVICE, text: '医嘱' });

export const WARN_NEW_KINDS = [
  WARN_NEW_KIND_NORMAL,
  WARN_NEW_KIND_WARN,
  WARN_NEW_KIND_TIPS,
  WARN_NEW_KIND_ADVICE,
];
export const WARN_NEW_KIND_MAP = SelectItemVO.getMap(WARN_NEW_KINDS);
