import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export enum WARN_KIND {
  ALL = 1,
  WARN,
  NOTIFICATION,
  ADVICE,
}

export const WARN_KIND_ALL = new SelectItemVO({ id: WARN_KIND.ALL, text: '全部' });
export const WARN_KIND_WARN = new SelectItemVO({ id: WARN_KIND.WARN, text: '报警' });
export const WARN_KIND_NOTIFICATION = new SelectItemVO({ id: WARN_KIND.NOTIFICATION, text: '提醒' });
export const WARN_KIND_ADVICE = new SelectItemVO({ id: WARN_KIND.ADVICE, text: '医嘱' });


export const DEFAULT_WARN_KIND = WARN_KIND_ALL;
export const WARN_KINDS = [
  WARN_KIND_ALL,
  WARN_KIND_WARN,
  WARN_KIND_NOTIFICATION,
  WARN_KIND_ADVICE,
];
export const WARN_KIND_MAP = SelectItemVO.getMap(WARN_KINDS);
