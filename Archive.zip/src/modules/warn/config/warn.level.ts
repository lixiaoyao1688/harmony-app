import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 报警级别 配置
 */
export enum WARN_LEVEL {
  NORMAL = 0,
  HIGH,
  LOW,
}

export const WARN_LEVEL_NORMAL = new SelectItemVO({ id: WARN_LEVEL.NORMAL, text: '正常' });
export const WARN_LEVEL_HIGH = new SelectItemVO({ id: WARN_LEVEL.HIGH, text: '高' });
export const WARN_LEVEL_LOW = new SelectItemVO({ id: WARN_LEVEL.LOW, text: '低' });

export const WARN_LEVELS = [
  WARN_LEVEL_NORMAL,
  WARN_LEVEL_HIGH,
  WARN_LEVEL_LOW,
];
export const WARN_LEVEL_MAP = SelectItemVO.getMap(WARN_LEVELS);
