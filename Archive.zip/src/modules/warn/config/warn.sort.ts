import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 72小时报警信息 优先级排序 配置
 */
export enum WARN_LEVEL_SORT {
  LOW_TO_HIGH = 0,
  HIGH_TO_LOW = 1,
  RECENT_TIME
}

const WARN_LEVEL_SORT_RECENT_TIME = new SelectItemVO<unknown>({ id: WARN_LEVEL_SORT.RECENT_TIME, text: '按最近时间' });
const WARN_LEVEL_SORT_0 = new SelectItemVO<unknown>({ id: WARN_LEVEL_SORT.LOW_TO_HIGH, text: '优先级低到高' });
const WARN_LEVEL_SORT_1 = new SelectItemVO<unknown>({ id: WARN_LEVEL_SORT.HIGH_TO_LOW, text: '优先级高到低' });

export const DEFAULT_WARN_LEVEL_SORT = WARN_LEVEL_SORT_RECENT_TIME;
export const WARN_LEVEL_SORTS = [
  WARN_LEVEL_SORT_RECENT_TIME,
  WARN_LEVEL_SORT_0,
  WARN_LEVEL_SORT_1,
];
export const WARN_LEVEL_SORT_MAP = SelectItemVO.getMap(WARN_LEVEL_SORTS);
