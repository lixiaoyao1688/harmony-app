export enum WARN_SUMMARY_COUNT_COLOR {
  CGM_HIGH = 'rgb(248,168,30)',
  CGM_LOW = 'rgb(247,58,63)',
  PUMP_BLOCK = 'rgb(0,252,248)',
  PUMP_ERROR = 'rgb(220,233,245)',
  
  CGM_HIGH_FOR_REPORT = 'rgb(248,168,30)',
  CGM_LOW_FOR_REPORT = 'rgb(247,58,63)',
  PUMP_BLOCK_FOR_REPORT = 'rgb(20,0,203)',
  PUMP_ERROR_FOR_REPORT = 'rgb(5,156,0)',
}
