import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import type {WarnSummaryItemChartPayloadType} from '@/modules/warn/types/warn.summary.type';


export enum WARN_SUMMARY_KIND {
  GLU_HIGH = 0,
  GLU_LOW,
  GLU_SUPER_HIGH,
  GLU_SUPER_LOW,
  PUMP_ERROR,
  PUMP_BLOCK,
}

// 高血糖
export const WARN_SUMMARY_REPORT_GLU_HIGH_COLOR = 'rgb(248,168,30)';
// 低血糖
export const WARN_SUMMARY_REPORT_GLU_LOW_COLOR = 'rgb(247,58,63)';
// 泵阻塞
export const WARN_SUMMARY_REPORT_PUMP_BLOCK_COLOR = 'rgb(20,0,203)';
// 运行异常
export const WARN_SUMMARY_REPORT_PUMP_ERROR_COLOR = 'rgb(5,156,0)';


const WARN_SUMMARY_KIND_GLU_HIGH = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.GLU_HIGH,
  text: '高血糖',
  payload: {
    color: 'rgb(248,168,30)',
    colorForReport: WARN_SUMMARY_REPORT_GLU_HIGH_COLOR,
    symbol: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNCIgdmlld0JveD0iMCAwIDE2IDE0Ij4NCiAgICA8cGF0aCBpZD0i5aSa6L655b2iXzMyIiBkYXRhLW5hbWU9IuWkmui+ueW9oiAzMiIgZD0iTTgsMGw4LDE0SDBaIiBmaWxsPSIjZjhhODFlIi8+DQo8L3N2Zz4NCg==',
    symbolForReport: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNCIgdmlld0JveD0iMCAwIDE2IDE0Ij4NCiAgICA8cGF0aCBpZD0i5aSa6L655b2iXzMyIiBkYXRhLW5hbWU9IuWkmui+ueW9oiAzMiIgZD0iTTgsMGw4LDE0SDBaIiBmaWxsPSIjZjhhODFlIi8+DQo8L3N2Zz4NCg=='
  }
});
const WARN_SUMMARY_KIND_GLU_LOW = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.GLU_LOW,
  text: '低血糖',
  payload: {
    color: 'rgb(247,58,63)',
    colorForReport: WARN_SUMMARY_REPORT_GLU_LOW_COLOR,
    symbol: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4NCiAgICA8Y2lyY2xlIGlkPSLmpK3lnIZfMzUyIiBkYXRhLW5hbWU9IuakreWchiAzNTIiIGN4PSI2IiBjeT0iNiIgcj0iNiIgZmlsbD0iI2Y3M2EzZiIvPg0KPC9zdmc+DQo=',
    symbolForReport: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4NCiAgICA8Y2lyY2xlIGlkPSLmpK3lnIZfMzUyIiBkYXRhLW5hbWU9IuakreWchiAzNTIiIGN4PSI2IiBjeT0iNiIgcj0iNiIgZmlsbD0iI2Y3M2EzZiIvPg0KPC9zdmc+DQo='
  }
});
const WARN_SUMMARY_KIND_GLU_SUPER_HIGH = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.GLU_SUPER_HIGH,
  text: '血糖极高',
  payload: {
    color: 'rgb(247,58,63)',
    colorForReport: 'rgb(247,58,63)',
    symbol: '',
    symbolForReport: ''
  }
});
const WARN_SUMMARY_KIND_GLU_SUPER_LOW = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.GLU_SUPER_LOW,
  text: '血糖极低',
  payload: {
    color: '',
    colorForReport: '',
    symbol: '',
    symbolForReport: ''
  }
});
const WARN_SUMMARY_KIND_PUMP_FAULT = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.PUMP_ERROR,
  text: '运行异常',
  payload: {
    color: 'rgb(220,233,245)',
    colorForReport: WARN_SUMMARY_REPORT_PUMP_ERROR_COLOR,
    symbol: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNi45NzEiIGhlaWdodD0iMTYuOTcxIiB2aWV3Qm94PSIwIDAgMTYuOTcxIDE2Ljk3MSI+DQogICAgPHJlY3QgaWQ9IuefqeW9ol81MDgzIiBkYXRhLW5hbWU9IuefqeW9oiA1MDgzIiB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDguNDg1KSByb3RhdGUoNDUpIiBmaWxsPSIjZGNlOWY1Ii8+DQo8L3N2Zz4NCg==',
    symbolForReport: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNi45NzEiIGhlaWdodD0iMTYuOTcxIiB2aWV3Qm94PSIwIDAgMTYuOTcxIDE2Ljk3MSI+DQogICAgPHJlY3QgaWQ9IuefqeW9ol81NTgxIiBkYXRhLW5hbWU9IuefqeW9oiA1NTgxIiB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDguNDg1KSByb3RhdGUoNDUpIiBmaWxsPSIjMDU5YzAwIi8+DQo8L3N2Zz4NCg=='
  }
});
const WARN_SUMMARY_KIND_PUMP_BLOCK = new SelectItemVO<WarnSummaryItemChartPayloadType>({
  id: WARN_SUMMARY_KIND.PUMP_BLOCK,
  text: '泵阻塞',
  payload: {
    color: 'rgb(0,252,248)',
    colorForReport: WARN_SUMMARY_REPORT_PUMP_BLOCK_COLOR,
    symbol: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4NCiAgICA8cmVjdCBpZD0i55+p5b2iXzUwNTciIGRhdGEtbmFtZT0i55+p5b2iIDUwNTciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgZmlsbD0iIzAwZmNmOCIvPg0KPC9zdmc+DQo=',
    symbolForReport: 'image://data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4NCiAgICA8cmVjdCBpZD0i55+p5b2iXzU1ODAiIGRhdGEtbmFtZT0i55+p5b2iIDU1ODAiIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgZmlsbD0iIzE0MDBjYiIvPg0KPC9zdmc+DQo='
  }
});

export const WARN_SUMMARY_KINDS = [
  WARN_SUMMARY_KIND_GLU_HIGH,
  WARN_SUMMARY_KIND_GLU_LOW,
  WARN_SUMMARY_KIND_GLU_SUPER_HIGH,
  WARN_SUMMARY_KIND_GLU_SUPER_LOW,
  WARN_SUMMARY_KIND_PUMP_FAULT,
  WARN_SUMMARY_KIND_PUMP_BLOCK,
];
export const WARN_SUMMARY_KINDS_FOR_LEGEND = [
  WARN_SUMMARY_KIND_GLU_HIGH,
  WARN_SUMMARY_KIND_GLU_LOW,
  WARN_SUMMARY_KIND_PUMP_BLOCK,
  WARN_SUMMARY_KIND_PUMP_FAULT,
];
export const WARN_SUMMARY_KIND_MAP = SelectItemVO.getMap(WARN_SUMMARY_KINDS);
