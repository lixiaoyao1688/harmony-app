import {WARN_LEVEL} from '@/modules/warn/config/warn.level';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import {PART_KIND} from '@/modules/admission/config/admission.part.kind';
import {ADMISSION_TYPE_2} from '@/modules/admission/dto/admission.help.dto';
import {WARN_SCENE, WARN_SUB_KIND} from '@/modules/warn/config/warn.current';


/**
 * 报警列表 DTO
 */
export interface WarnDTO {
	admission_id: number;  //	患者id，如:37715;
	area_name: string;  // 病区名称
	bed: string;  // 床号，如:"NFM-0102";
	code: string;  // 登记号
	name: string;  //	患者姓名，如:"吕小布";
	part_name: string;  // 科室名称，如:"检验科";
	warn_id: WARNING_LEVEL;  //	报警id，如:1004;
	warn_text: string;  // 报警标题，如:"医嘱执行超时";
	warn_time: number;  // 发生时间，时间戳，单位秒
	is_admission: ADMISSION_TYPE_2; // 患者类型
	part_kind: PART_KIND;  // 院泵患者类型
	warn_kind: WARN_NEW_KIND;  // 报警种类 0-正常 1-报警 2-提示 3-医嘱
	warn_level: WARN_LEVEL;  // 报警级别 0-正常 1-高 2-低
	warn_remark: string;  // 报警备注，如"请核实患者操作与状态";
}

/**
 * 弹窗报警 删 DTO
 *
 * key: 患者id
 */
export interface WarnNotifyDeleteDTO {
	admission_id: number;
}

/**
 * 报警弹窗 DTO
 */
export interface WarnNotifyDTO {
	admission_id: number;  // 患者id
	area_name: string;  // 病区名称
	bed: string;  // 床号
	name: string;  // 患者姓名
	part_name: string;  // 科室名称
	warn_id: WARNING_LEVEL;  // 消息标识
	warn_text: string;  // 报警内容
	warn_time: number;  // 报警时刻，单位s
}

/**
 * 72小时警报记录
 */
export interface CurrentWarnDTO {
	// warn_id: WARNING_LEVEL;
	// warn_text: string;  // 报警内容
	// start_time: number;	// 警报时间戳
	warn_text: string;  // 报警内容
	start_time:	number;  //	警报时间戳
	// 1.sub_kind为1时: 消息图标为白色;
	// 2.sub_kind为0时: scene_id为0则消息图标为黄色，scene_id为1则消息图标为红色;
	sub_kind:	WARN_SUB_KIND;  // 报警类型 0-报警 1-提示
	scene_id:	WARN_SCENE;  //	报警级别 0-低 1-高
}

// 警报颜色
export enum WARNING_COLOR {
	// 背景颜色
	NEW_HIGH = 'rgb(247,58,63)',
	NEW_MIDDLE = 'rgb(248,168,30)',
	NEW_ADVICE = 'rgb(123,175,253)',
	LOW = 'rgb(78,87,95)',
	DISCONNECTED = 'rgb(21,26,30)',
	// HIGH = 'rgb(255,36,42)',
	// MIDDLE = 'rgb(235,166,48)',
	// ADVICE = 'rgb(105,158,245)',
	HIGH_2 = 'rgb(181,45,50)',
	MIDDLE_2 = 'rgb(175,124,43)',
	ADVICE_2 = 'rgb(87,119,172)',
	EVENT = 'rgb(220,233,245)',
	
	// 文本颜色
	EVENT_TEXT_COLOR = 'rgb(0,0,0)',
	NORMAL_TEXT_COLOR = 'rgb(255,255,255)',
	
	// 文本底色
	WARN_HIGH_TEXT_BG_COLOR = 'rgb(100,48,55)',
	WARN_LOW_TEXT_BG_COLOR = 'rgb(100,82,45)',
	TIP_TEXT_BG_COLOR = 'rgb(92,101,110)',
	ADVICE_TEXT_BG_COLOR = 'rgb(56,76,108)',
	
}

export enum WARNING_PRIORITY {
	LOW,
	ADVICE,
	MIDDLE,
	HIGH,
}

// 报警id
// 含义查看: warnMap
export enum WARNING_LEVEL {
	NORMAL = 0,
	LOW_BATTERY,
	MIN_BATTERY,
	LOW_REMAIN,
	MIN_REMAIN,
	MOTOR_BLOCK,
	MOTOR_FAILED,
	MOTOR_BUSY,
	
	MOTOR_MCU_BLOCK = 9,
	MOTOR_MCU_ILLEGAL,
	MOTOR_MCU_PLUSES_EXTRA,
	MOTOR_DESTRUCTIVE_ANOMALY,
	MOTOR_ERROR = 13,
	
	AUTO_POWER_OFF = 20,
	GLU_LOW_2,  // 低血糖
	
	LOW_BATTERY_2 = 1000,
	LOW_REMAIN_2,
	
	ADVICE = 1002, // 新医嘱
	OUT_SOON = 1011, // 医嘱即将过期
	REFUSED = 1012, // 医嘱退回
	PATIENT_WAITING = 1013,  // 待接收患者
	TIMEOUT_SEND = 1014, // 医嘱发送超时
	NOT_EXECUTED = 1015, // 医嘱未执行
	
	GLU_LOW = 1003,  // 低血糖
	GLU_HIGH = 1004,
	
	// 事件
	SUPPLIES_CHANGE = 1005,
	UNBIND_PUMP = 1006,
	GLU_ADD = 1007,
	
	GLU_LOW_SUPER = 1008,  // 特低血糖
	
	STOPPED_FOR_MORE_THAN_15_MIN = 10021,
	ERROR_6 = 10027,
	NOT_ACTIVATED = 10029,
	CALIBRATION_NOT_ACCEPTED = 10034,
	
	PROBE_UPPER_LIMIT = 10201,
	HIGH_PROBE_WARN,
	PROBE_LOWER_LIMIT,
	LOW_PROBE_WARN,
	PROBE_RISING_FAST,
	PAUSED_AND_PROBE_LOWER_LIMIT,
	PAUSED_AND_GLU,
	BASE_RECOVER_AND_GLU,
	PLEASE_CHANGE_PIPE,
}

// 警报映射表
export const warnMap = new Map([
	
  [WARNING_LEVEL.NORMAL, '正常'],
  [WARNING_LEVEL.LOW_BATTERY, '泵低电量(低)'],
  [WARNING_LEVEL.MIN_BATTERY, '泵电量耗尽(高)'],
  [WARNING_LEVEL.LOW_REMAIN, '低药量(低)'],
  [WARNING_LEVEL.MIN_REMAIN, '药量耗尽(高)'],
  [WARNING_LEVEL.MOTOR_BLOCK, '泵阻塞(高)'],
  [WARNING_LEVEL.MOTOR_FAILED, '泵故障 3(高)'],
  [WARNING_LEVEL.MOTOR_BUSY, '电机忙碌'],

  [WARNING_LEVEL.MOTOR_MCU_BLOCK, '泵阻塞2(高)'],
  [WARNING_LEVEL.MOTOR_MCU_ILLEGAL, '泵故障 1(高)'],
  [WARNING_LEVEL.MOTOR_MCU_PLUSES_EXTRA, '泵故障 2(高)'],
  [WARNING_LEVEL.MOTOR_DESTRUCTIVE_ANOMALY, '泵故障 4(高)'],
  [WARNING_LEVEL.MOTOR_ERROR, '泵故障 3+!'],
	
  [WARNING_LEVEL.AUTO_POWER_OFF, '泵自动关机'],
	
  [WARNING_LEVEL.LOW_BATTERY_2, '低电量'],
  [WARNING_LEVEL.LOW_REMAIN_2, '低药量'],
	
  [WARNING_LEVEL.ADVICE, '新医嘱'],
	
  [WARNING_LEVEL.GLU_LOW, '低血糖'],
  [WARNING_LEVEL.GLU_HIGH, '高血糖'],
	
  [WARNING_LEVEL.SUPPLIES_CHANGE, '更换耗材'],
  [WARNING_LEVEL.UNBIND_PUMP, '下泵'],
  [WARNING_LEVEL.GLU_ADD, '血糖检测'],
	
  [WARNING_LEVEL.STOPPED_FOR_MORE_THAN_15_MIN, '已停止输注超过15分钟'],
  [WARNING_LEVEL.ERROR_6, '运行错误6，联系售后'],
  [WARNING_LEVEL.NOT_ACTIVATED, '产品未激活，请激活'],
  [WARNING_LEVEL.CALIBRATION_NOT_ACCEPTED, '校准未被接受'],
	
  [WARNING_LEVEL.PROBE_UPPER_LIMIT, 'CGM值正在接近高CGM值界限，请检测血糖'],
  [WARNING_LEVEL.HIGH_PROBE_WARN, '高CGM值报警，请检测血糖'],
  [WARNING_LEVEL.PROBE_LOWER_LIMIT, 'CGM值正在接近低CGM值界限，请检测血糖'],
  [WARNING_LEVEL.LOW_PROBE_WARN, '低CGM值报警，请检测血糖'],
  [WARNING_LEVEL.PROBE_RISING_FAST, 'CGM值正在快速上升'],
  [WARNING_LEVEL.PAUSED_AND_PROBE_LOWER_LIMIT, '输注已暂停，CGM值正在接近低CGM值，请检测血糖'],
  [WARNING_LEVEL.PAUSED_AND_GLU, '输注已暂停，请检测血糖'],
  [WARNING_LEVEL.BASE_RECOVER_AND_GLU, '基础率恢复，请检测血糖'],
  [WARNING_LEVEL.PLEASE_CHANGE_PIPE, '请更换管路'],
	
]);
