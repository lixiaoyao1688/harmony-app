import {CGM_WARN} from '@/modules/cgm/config/cgm.warn';
import {PUMP_WARN} from '@/modules/pump/config/pump.warn';
import {HISTORY_KIND} from '@/modules/record/config/history.config';


/**
 * 报警总结 DTO
 */
export type WarnSummaryDTO = Array<WarnSummaryRecordDTO>;

/**
 * 查
 */
export interface WarnSummaryGetDTO {
  admission_id: number;  //	T文本	是  1
  start_date: string;  //	T文本	是  2025-3-1
  end_date: string;  //	T文本	是  2025-3-7
}

/**
 * 报警总结-每日详情 DTO
 *
 * 注: 这是前端自定义的 DTO，不参与协议交互，只用于界面计算。
 */
export interface WarnSummaryDayDTO {
  record_date: string;  // YYYY-MM-DD;
  records: Array<WarnSummaryRecordDTO>;
}


/**
 * 报警总结-每日详情-记录 DTO
 */
export interface WarnSummaryRecordDTO {
  id: number;
  record_time: number;  // 记录时间，秒;
  kind: HISTORY_KIND;  // 类型，仅 胰岛素泵报警、CGM报警信息;
  text: string;  // 报警标题
  value: number;  // 仅kind=203且报警类型为"低药量/药量耗尽"时可用, 代表剩余药量(U)
  // value: PUMP_WARN | CGM_WARN;  // 已废弃(和历史记录保持一致) 子类型，参考 http://192.168.1.249:8000/project/110/interface/api/6695;
}
