<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';


/**
 * 报警 图标
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  scale?: number;
}

interface Emit {
  (e: 'click'): void;
}

defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function onClick(): void {
  emit('click');
}
</script>

<template>
  <svg v-if="pc" xmlns="http://www.w3.org/2000/svg"
       :width="32 * (scale || 1)"
       :height="32 * (scale || 1)"
       viewBox="0 0 32 32"
       class="icon-warn-clock cursor-pointer"
       @click="onClick">
    <rect width="32" height="32" fill="rgba(255,255,255,0)"/>
    <path d="M14.142,26.5H11.229A2.551,2.551,0,0,1,8.7,24.353h7.98a2.555,2.555,0,0,1-2.33,2.14Zm9.983-4.3H1.243a1.217,1.217,0,0,1-1.02-.525,1.186,1.186,0,0,1-.146-1.112l.06-.134,2.7-5.287V9.668A9.774,9.774,0,0,1,12.688,0a9.73,9.73,0,0,1,9.854,9.329l0,.338v5.477l2.7,5.3a1.186,1.186,0,0,1-.021,1.131,1.251,1.251,0,0,1-.95.624ZM12.688,2.15A7.713,7.713,0,0,0,7.378,4.244a7.422,7.422,0,0,0-2.351,5.1l-.007.317v5.4a2.474,2.474,0,0,1-.167.9l-.105.227L2.779,20.053H22.6l-1.974-3.871a2.5,2.5,0,0,1-.26-.882l-.01-.249V9.668A7.6,7.6,0,0,0,12.688,2.15Z"
          transform="translate(3.31 2.75)"
          fill="#5d5d5d" />
  </svg>
  <svg v-else
       xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 32 32"
       @click="onClick">
    <rect width="32" height="32" fill="rgba(255,255,255,0)"/>
    <path d="M14.142,26.5H11.229A2.551,2.551,0,0,1,8.7,24.353h7.98a2.555,2.555,0,0,1-2.33,2.14Zm9.983-4.3H1.243a1.217,1.217,0,0,1-1.02-.525,1.186,1.186,0,0,1-.146-1.112l.06-.134,2.7-5.287V9.668A9.774,9.774,0,0,1,12.688,0a9.73,9.73,0,0,1,9.854,9.329l0,.338v5.477l2.7,5.3a1.186,1.186,0,0,1-.021,1.131,1.251,1.251,0,0,1-.95.624ZM12.688,2.15A7.713,7.713,0,0,0,7.378,4.244a7.422,7.422,0,0,0-2.351,5.1l-.007.317v5.4a2.474,2.474,0,0,1-.167.9l-.105.227L2.779,20.053H22.6l-1.974-3.871a2.5,2.5,0,0,1-.26-.882l-.01-.249V9.668A7.6,7.6,0,0,0,12.688,2.15Z"
          transform="translate(3.31 2.75)" fill="#f5f5f5" />
  </svg>
</template>

<style scoped>
.icon-warn-clock:hover > path {
  fill: var(--aaruy-primary-color-2);
}
</style>
