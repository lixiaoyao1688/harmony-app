<script setup lang="ts">
/**
 * 报警图标 组件
 */
interface Prop {
	count: number;  // 报警数量
}

defineProps<Prop>();
</script>

<template>
  <template v-if="count === 0">
		<svg id="iconWarnMobile1" data-name="组件 214 – 13" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
			<rect id="iconWarnMobile1R" data-name="矩形 5032" width="24" height="24" fill="rgba(255,255,255,0)"/>
			<path id="iconWarnMobile1P" data-name="联合 196" d="M5.259,22H.83a.831.831,0,0,1,0-1.661H20.505a.831.831,0,0,1,0,1.661ZM7.94,19.61H3.32a.829.829,0,0,1-.83-.83V12.845a8.048,8.048,0,0,1,.4-2.542c.071-.215.151-.428.24-.638h0A8.276,8.276,0,0,1,7.489,5.311a8.112,8.112,0,0,1,3.177-.645h.151a8.058,8.058,0,0,1,3.026.643A8.253,8.253,0,0,1,18.2,9.668a8.131,8.131,0,0,1,.645,3.177v5.932a.827.827,0,0,1-.827.83H8a.338.338,0,0,1-.052,0h0Zm9.249-1.66V12.845a6.481,6.481,0,0,0-.8-3.126c-.015-.02-.028-.043-.041-.064A6.549,6.549,0,0,0,10.89,6.33h-.006l-.091,0h-.124a6.527,6.527,0,0,0-6.52,6.519V17.95H17.189ZM15.982,5.167A.829.829,0,0,1,15.9,4L17.442,2.21A.83.83,0,1,1,18.7,3.294L17.154,5.081a.829.829,0,0,1-1.172.086ZM4.238,5.085,2.555,3.3A.83.83,0,1,1,3.765,2.159L5.447,3.946A.83.83,0,0,1,4.238,5.085Zm5.6-2.108V.83a.83.83,0,0,1,1.66,0V2.977a.83.83,0,0,1-1.66,0Z" transform="translate(1.23 0.75)" fill="#adb3ba"/>
		</svg>
	</template>
	<template v-else-if="count < 10">
		<svg id="iconWarnMobile2" data-name="组件 214 – 13" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
			<rect id="iconWarnMobile2R" data-name="矩形 5032" width="24" height="24" fill="rgba(255,255,255,0)"/>
			<path id="iconWarnMobile2P" data-name="路径 3898" d="M65.135,55.166a8.084,8.084,0,0,0-.646,3.178V64.28a.83.83,0,0,0,.83.83h4.623a.83.83,0,1,0,0-1.659H66.149V58.344a6.515,6.515,0,0,1,12.2-3.191.83.83,0,1,0,1.444-.818,8.209,8.209,0,0,0-7.123-4.17,8.083,8.083,0,0,0-3.177.646,8.25,8.25,0,0,0-4.355,4.355ZM71.6,65.841H62.83a.83.83,0,1,0,0,1.659H71.6a.83.83,0,1,0,0-1.659Zm1.067-16.534a.83.83,0,0,0,.83-.83V46.33a.83.83,0,1,0-1.659,0v2.147A.83.83,0,0,0,72.668,49.307Zm-6.431,1.279a.83.83,0,0,0,1.209-1.138l-1.683-1.789A.83.83,0,0,0,64.554,48.8Zm11.747.083a.83.83,0,0,0,1.17-.086L80.7,48.793a.83.83,0,1,0-1.256-1.085L77.9,49.5A.83.83,0,0,0,77.984,50.668Z" transform="translate(-60.822 -44.75)" fill="#ff242a"/>
			<rect id="iconWarnMobile2R" data-name="矩形 5030" width="12" height="12" rx="6" transform="translate(10.822 11.25)" fill="#ff242a"/>
			<text id="iconWarnMobile2T" data-name="1" transform="translate(14.179 20.75)" fill="#fff" font-size="10" font-family="SegoeUI-Bold, Segoe UI" font-weight="700"><tspan x="0" y="0">{{ count }}</tspan></text>
		</svg>
	</template>
	<template v-else-if="count < 100">
		<svg id="iconWarnMobile3" data-name="组件 214 – 13" xmlns="http://www.w3.org/2000/svg" width="30" height="24" viewBox="0 0 30 24">
			<rect id="iconWarnMobile3R" data-name="矩形 5032" width="30" height="24" fill="rgba(255,255,255,0)"/>
			<path id="iconWarnMobile3P" data-name="路径 3898" d="M65.135,55.166a8.084,8.084,0,0,0-.646,3.178V64.28a.83.83,0,0,0,.83.83h4.623a.83.83,0,1,0,0-1.659H66.149V58.344a6.515,6.515,0,0,1,12.2-3.191.83.83,0,1,0,1.444-.818,8.209,8.209,0,0,0-7.123-4.17,8.083,8.083,0,0,0-3.177.646,8.25,8.25,0,0,0-4.355,4.355ZM71.6,65.841H62.83a.83.83,0,1,0,0,1.659H71.6a.83.83,0,1,0,0-1.659Zm1.067-16.534a.83.83,0,0,0,.83-.83V46.33a.83.83,0,1,0-1.659,0v2.147A.83.83,0,0,0,72.668,49.307Zm-6.431,1.279a.83.83,0,0,0,1.209-1.138l-1.683-1.789A.83.83,0,0,0,64.554,48.8Zm11.747.083a.83.83,0,0,0,1.17-.086L80.7,48.793a.83.83,0,1,0-1.256-1.085L77.9,49.5A.83.83,0,0,0,77.984,50.668Z" transform="translate(-60.822 -44.75)" fill="#ff242a"/>
			<rect id="iconWarnMobile3R1" data-name="矩形 5030" width="18" height="12" rx="6" transform="translate(10.822 11.25)" fill="#ff242a"/>
			<text id="iconWarnMobile3T" data-name="10" transform="translate(13.822 20.75)" fill="#fff" font-size="10" font-family="SegoeUI-Bold, Segoe UI" font-weight="700"><tspan x="0" y="0">{{ count }}</tspan></text>
		</svg>
	</template>
	<template v-else-if="count < 1000">
		<svg id="iconWarnMobile4" data-name="组件 214 – 13" xmlns="http://www.w3.org/2000/svg" width="34.822" height="24" viewBox="0 0 34.822 24">
			<rect id="iconWarnMobile4R" data-name="矩形 5032" width="30" height="24" fill="rgba(255,255,255,0)"/>
			<path id="iconWarnMobile4P" data-name="路径 3898" d="M65.135,55.166a8.084,8.084,0,0,0-.646,3.178V64.28a.83.83,0,0,0,.83.83h4.623a.83.83,0,1,0,0-1.659H66.149V58.344a6.515,6.515,0,0,1,12.2-3.191.83.83,0,1,0,1.444-.818,8.209,8.209,0,0,0-7.123-4.17,8.083,8.083,0,0,0-3.177.646,8.25,8.25,0,0,0-4.355,4.355ZM71.6,65.841H62.83a.83.83,0,1,0,0,1.659H71.6a.83.83,0,1,0,0-1.659Zm1.067-16.534a.83.83,0,0,0,.83-.83V46.33a.83.83,0,1,0-1.659,0v2.147A.83.83,0,0,0,72.668,49.307Zm-6.431,1.279a.83.83,0,0,0,1.209-1.138l-1.683-1.789A.83.83,0,0,0,64.554,48.8Zm11.747.083a.83.83,0,0,0,1.17-.086L80.7,48.793a.83.83,0,1,0-1.256-1.085L77.9,49.5A.83.83,0,0,0,77.984,50.668Z" transform="translate(-60.822 -44.75)" fill="#ff242a"/>
			<rect id="iconWarnMobile4R" data-name="矩形 5030" width="24" height="12" rx="6" transform="translate(10.822 11.25)" fill="#ff242a"/>
			<text id="iconWarnMobile4T" data-name="100" transform="translate(13.822 20.75)" fill="#fff" font-size="10" font-family="SegoeUI-Bold, Segoe UI" font-weight="700"><tspan x="0" y="0">{{ count }}</tspan></text>
		</svg>
	</template>
	<template v-else>
		<svg id="iconWarnMobile5" data-name="组件 214 – 13" xmlns="http://www.w3.org/2000/svg" width="40.822" height="24" viewBox="0 0 40.822 24">
			<rect id="iconWarnMobile5R" data-name="矩形 5032" width="30" height="24" fill="rgba(255,255,255,0)"/>
			<path id="iconWarnMobile5P" data-name="路径 3898" d="M65.135,55.166a8.084,8.084,0,0,0-.646,3.178V64.28a.83.83,0,0,0,.83.83h4.623a.83.83,0,1,0,0-1.659H66.149V58.344a6.515,6.515,0,0,1,12.2-3.191.83.83,0,1,0,1.444-.818,8.209,8.209,0,0,0-7.123-4.17,8.083,8.083,0,0,0-3.177.646,8.25,8.25,0,0,0-4.355,4.355ZM71.6,65.841H62.83a.83.83,0,1,0,0,1.659H71.6a.83.83,0,1,0,0-1.659Zm1.067-16.534a.83.83,0,0,0,.83-.83V46.33a.83.83,0,1,0-1.659,0v2.147A.83.83,0,0,0,72.668,49.307Zm-6.431,1.279a.83.83,0,0,0,1.209-1.138l-1.683-1.789A.83.83,0,0,0,64.554,48.8Zm11.747.083a.83.83,0,0,0,1.17-.086L80.7,48.793a.83.83,0,1,0-1.256-1.085L77.9,49.5A.83.83,0,0,0,77.984,50.668Z" transform="translate(-60.822 -44.75)" fill="#ff242a"/>
			<rect id="iconWarnMobile5R" data-name="矩形 5030" width="30" height="12" rx="6" transform="translate(10.822 11.25)" fill="#ff242a"/>
			<text id="iconWarnMobile5T" data-name="1000" transform="translate(13.822 20.75)" fill="#fff" font-size="10" font-family="SegoeUI-Bold, Segoe UI" font-weight="700"><tspan x="0" y="0">{{ count }}</tspan></text>
		</svg>
	</template>
</template>
