<template>
	<svg xmlns="http://www.w3.org/2000/svg" width="22" height="4" viewBox="0 0 22 4">
		<g id="组_9154" data-name="组 9154" transform="translate(-1 4) rotate(-90)">
			<rect id="矩形_518" data-name="矩形 518" width="4" height="4" rx="2" transform="translate(0 1)" fill="#fff"/>
			<rect id="矩形_519" data-name="矩形 519" width="4" height="4" rx="2" transform="translate(0 10)" fill="#fff"/>
			<rect id="矩形_520" data-name="矩形 520" width="4" height="4" rx="2" transform="translate(0 19)" fill="#fff"/>
		</g>
	</svg>
</template>