<script setup lang="ts">
import {WARNING_COLOR} from '@/modules/warn/dto/warn.dto';

/**
 * 三角警告 图标
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  color: string;
  zIndex: number;
  scale?: number;
}

const prop = defineProps<Prop>();
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg"
       :width="24 * (scale || 1)" :height="24 * (scale || 1)"
       viewBox="0 0 24 24"
       :style="{ zIndex: zIndex }">
    <g transform="translate(5716 4967.004)">
      <path d="M87.518,86.509a3.043,3.043,0,0,1-2.66,1.484H67.136a3.13,3.13,0,0,1-2.8-4.53L73.2,65.723a3.125,3.125,0,0,1,5.594,0l8.861,17.74A3.048,3.048,0,0,1,87.518,86.509Z"
            transform="translate(-5779.997 -5030.997)"
            :fill="color"/>
      <path d="M99.369,98.851a1.2,1.2,0,1,0-1.2-1.2A1.2,1.2,0,0,0,99.369,98.851Zm1.8-10.2a1.8,1.8,0,1,0-3.6,0v.15l1.2,6.488h0a.6.6,0,0,0,1.2,0h0l1.2-6.488Z"
            transform="translate(-5803.368 -5046.164)"
            :fill="color === WARNING_COLOR.EVENT ? 'rgb(0,0,0)' : 'rgb(255,255,255)'"/>
    </g>
  </svg>
</template>
