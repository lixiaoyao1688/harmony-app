<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <g id="iconWarnUpG" data-name="组 8586" transform="translate(-7131 12711) rotate(180)">
      <rect id="iconWarnUpGRect" data-name="矩形 3882" width="24" height="24" transform="translate(-7155 12687)" fill="rgba(255,255,255,0)"/>
      <path id="iconWarnUpGPath" data-name="矩形 3883" d="M-2295.875,1994.719l8-8,8,8" transform="translate(-9430.875 14689.72) rotate(180)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    </g>
  </svg>
</template>