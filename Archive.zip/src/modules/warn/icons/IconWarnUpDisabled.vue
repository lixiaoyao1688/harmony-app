<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <g id="iconWarnUpDisabled" transform="translate(-7131 12711) rotate(180)">
      <rect id="iconWarnUpDisabledRect" width="24" height="24" transform="translate(-7155 12687)" fill="rgba(255,255,255,0)"/>
      <path id="iconWarnUpDisabledPath" d="M-2295.875,1994.719l8-8,8,8" transform="translate(-9430.875 14689.72) rotate(180)" fill="none" stroke="rgba(255,255,255,0.3)" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    </g>
  </svg>
</template>