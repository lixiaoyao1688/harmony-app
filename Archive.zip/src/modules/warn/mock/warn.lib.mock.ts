import {WARN_LEVEL} from '@/modules/warn/config/warn.level';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';


/**
 *
 * 报警原始VO
 *
 * 权限
 * 仅模拟数据。
 *
 * 来源
 * 见 http://192.168.1.249:5212/home/胰岛素泵数据管理软件/数据管理系统参数设置相关.xlsx: B300报警提示条目及等级。
 */
export class WarnLibMock {
  
  public name: string;  // 条目
  public remark: string;  // 辅助说明文本
  public kind: WARN_NEW_KIND;  // 类型
  public level: WARN_LEVEL;  // 报警级别（仅类型为"报警"时有效）
  
  constructor(k: WARN_NEW_KIND, l: WARN_LEVEL, n: string, r: string, ) {
    this.kind = k;
    this.level = l;
    this.name = n;
    this.remark = r;
  }
  
}
