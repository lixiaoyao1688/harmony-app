import dayjs from 'dayjs';
import {fill2Zero} from '@/lib/time/util/time.util';
import {wsLogger} from '@/lib/ws/util/ws.utils';
import {WS_EVENT} from '@/lib/ws/dto/ws.event.dto';
import {WS_STATUS} from '@/lib/ws/config/ws.config';
import {isProduction} from '@/lib/env/utils/env.util.root';
import {warnUtilGetWarnText} from '@/modules/warn/util/warn.util';
import {ONE, ONE_HUNDRED, ZERO} from '@/lib/math/config/math.config';
import {PART_KIND} from '@/modules/admission/config/admission.part.kind';
import {ADMISSION_TYPE_2} from '@/modules/admission/dto/admission.help.dto';
import {randomInEnum, randomInList, randomInRange, randomInSet} from '@/lib/math/util/math.util';
import {WarnDTO, WARNING_LEVEL, warnMap} from '@/modules/warn/dto/warn.dto';
import {MOCK_getAreaName, MOCK_getBedName, MOCK_getBedText, MOCK_getName, MOCK_getPartName} from '@/lib/mock/global.mock';
import {WARN_LEVEL} from '@/modules/warn/config/warn.level';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import { WarnLibMock } from '@/modules/warn/mock/warn.lib.mock';


export const WARN_MOCKING = false;  // 报警弹窗
export const WARN_LIST_MOCKING = false;  // 报警列表

export const WARN_BLINK_MOCKING = false;  // 闪烁测试 (移动端)
export const WARN_BLINK_INTERVAL = 5000;  // 闪烁间隔

const WARN_LIST_COUNT = 28;  // 报警列表
export const WARN_NOTIFY_INTERVAL = 3000;  // 报警弹窗 报警间隔


// 报警列表
export function MOCK_update_warn(): WarnDTO[] {
  if (isProduction()) {
    return [];
  }
  const data = Array(WARN_LIST_COUNT).fill(ZERO).map((_,i) => getRandomWarn(i + 1));
  wsLogger(WS_STATUS.RECEIVED_MOCK, WS_EVENT.SUBSCRIBE_AND_REPORT_WARN, data, false);
  return data;
}

// 报警弹窗
export function MOCK_warn_one(id?: number, warnId?: number): WarnDTO {
  return {
    // admission_id: 0,
    // area_name: '',
    // bed: '',
    // code: '',
    // name: '',
    // is_admission: 0,
    // warn_id: 1013,
    // warn_kind: 2,
    // warn_level: 2,
    // warn_remark: '',
    // warn_text: '待接收患者1',
    // warn_time: 1772766617,
    // part_kind: PART_KIND.OUT,
    // part_name: ''
    
    // admission_id: 49059,
    // area_name: '内F区',
    // bed: '02',
    // code: 'TEST9002',
    // is_admission: 0,
    // name: '王小贝',
    // part_kind: 0,
    // part_name: '内分泌科',
    // warn_id: 1005,
    // warn_kind: 2,
    // warn_level: 2,
    // warn_remark: '',
    // warn_text: '更换储药器',
    // warn_time: 1767758131,
    
    // admission_id: 49218,
    // area_name: '内1区',
    // bed: '01',
    // code: '9527ABCD',
    // is_admission: 1,
    // name: '李小赫',
    // part_kind: 0,
    // part_name: '内分泌科',
    // warn_id: 1002,
    // warn_kind: 1,
    // warn_level: 2,
    // warn_remark: '请注意患者症状',
    // warn_text: '高血糖10.8mmol/L',
    // warn_time: 1767750481,
    
    // 院泵
    admission_id: 49312,
    area_name: '内1区',
    bed: '01',
    code: '177371994942723',
    is_admission: 1,
    name: '言冰云',
    part_kind: 0,
    part_name: '内分泌科',
    warn_id: 1002,
    warn_kind: 3,
    warn_level: 2,
    warn_remark: '',
    warn_text: '新医嘱',
    warn_time: 1775726209,
    
    // 签约
    // admission_id: 49297,
    // area_name: '',
    // bed: '',
    // code: '177449260890523',
    // is_admission: 0,
    // name: '李承泽',
    // part_kind: 1,
    // part_name: '黑猫门诊',
    // warn_id: 1002,
    // warn_kind: 3,
    // warn_level: 2,
    // warn_remark: '',
    // warn_text: '新医嘱',
    // warn_time: 1775727097,
    
  };
  // const re = randomInEnum;
  // const aId = id || randomInRange(ONE, ONE_HUNDRED);
  // const innerWarnId = warnId || getRandomWarnId(true);
  // return {
  //   admission_id: aId,
  //   area_name: id ? `病区${id}` : '',
  //   bed: MOCK_getBedText(aId+1),
  //   code: '',
  //   name: id ? `患者${id}` : MOCK_getName(),
  //   part_name: id ? `科室${id}` : MOCK_getPartName(),
  //   warn_id: innerWarnId,
  //   warn_time: dayjs().unix(),
  //   is_admission: re(ADMISSION_TYPE_2.IN_HOSPITAL, ADMISSION_TYPE_2.SIGNED),
  //   part_kind: re(PART_KIND.IN, PART_KIND.OUT),
  //   warn_kind: re(WARN_NEW_KIND.NORMAL, WARN_NEW_KIND.WARN, WARN_NEW_KIND.TIPS, WARN_NEW_KIND.ADVICE),
  //   warn_level: re(WARN_LEVEL.NORMAL, WARN_LEVEL.HIGH, WARN_LEVEL.LOW),
  //   warn_text: warnUtilGetWarnText(innerWarnId),
  //   warn_remark: '请核实患者操作与状态',
  // };
}

export function getRandomCardWarn(excludeEvent?: boolean) {
  const id = getRandomWarnId(false, excludeEvent);
  const text = warnMap.get(id) || '';
  return { id, text };
}

export function getRandomWarnNew(isNormal?: boolean): WarnDTO {
  const r = randomInRange;
  const rl = randomInList;
  
  const W = WARN_NEW_KIND.WARN;
  const T = WARN_NEW_KIND.TIPS;
  const A = WARN_NEW_KIND.ADVICE;
  const L = WARN_LEVEL.LOW;
  const H = WARN_LEVEL.HIGH;
  
  const WS = [
    // new WarnLibMock(W, L, '高血糖 10.2 mmol/L', '请注意患者症状'),
    // new WarnLibMock(W, H, '特高血糖 12.8 mmol/L', '请注意患者症状', ),
    // new WarnLibMock(W, L, '低血糖 3.6 mmol/L', '请注意患者症状'),
    // new WarnLibMock(W, H, '极低血糖 2.8 mmol/L', '请注意患者症状'),
    new WarnLibMock(W, H, '药量耗尽', ''),
    new WarnLibMock(W, H, '更换泵电池', ''),
    new WarnLibMock(W, H, '输注受阻', '请检查患者佩戴状态'),
    new WarnLibMock(W, H, '泵运行错误', ''),
    new WarnLibMock(W, H, '泵严重错误', ''),
    new WarnLibMock(W, L, '泵低电量', ''),
    new WarnLibMock(W, L, '泵低药量', ''),
    new WarnLibMock(W, L, '失去CGM信号', '请检查患者佩戴状态'),
  ];
  const TS = [
    new WarnLibMock(T, L, '未输注胰岛素', '输注暂停已超过X分钟'),
    new WarnLibMock(T, L, '医嘱执行超时', '请核实患者操作与状态'),
    // new WarnLibMock(T, L, '更换皮下输液器/储药器', ''),
  ];
  const AS = [
    new WarnLibMock(A, L, '新医嘱', ''),
    new WarnLibMock(A, L, '医嘱退回', ''),
  ];
  
  const m = rl([...WS, ...TS, ...AS]);
  // const m = rl([...TS]);
  
  return {
    admission_id: r(1,100),
    area_name: MOCK_getAreaName(),
    bed: MOCK_getBedName(),
    code: '',
    name: MOCK_getName(),
    part_name: MOCK_getPartName(),
    warn_id: isNormal ? WARNING_LEVEL.NORMAL : r(WARNING_LEVEL.LOW_BATTERY, WARNING_LEVEL.MOTOR_ERROR),
    warn_text: m.name,
    warn_time: dayjs().unix(),
    is_admission: ADMISSION_TYPE_2.IN_HOSPITAL,
    part_kind: PART_KIND.IN,
    warn_kind: isNormal ? WARN_NEW_KIND.NORMAL : m.kind,
    warn_level: isNormal ? WARN_LEVEL.NORMAL : m.level,
    warn_remark: m.remark,
  };
}

export function getRandomWarn(uid: number, excludeEvent?: boolean): WarnDTO {
  const rl = randomInList;
  const f2z = fill2Zero;
  const re = randomInEnum;
  
  // return rl([
  //   {
  //     admission_id: uid,
  //     area_name: `${uid}区`,
  //     bed: `XH-${f2z(uid)}`,
  //     name: MOCK_getName(),
  //     part_name: MOCK_getPartName(),
  //     warn_id: WARNING_LEVEL.GLU_LOW,
  //     warn_time: dayjs().unix(),
  //     is_admission: ADMISSION_TYPE_2.IN_HOSPITAL,
  //     part_kind: PART_KIND.IN,
  //     warn_kind: WARN_NEW_KIND.WARN,
  //     warn_level: WARN_LEVEL.LOW,
  //     warn_text: '低血糖 3.2mmol/L',
  //     warn_remark: '请注意患者症状',
  //   },
  //   // {
  //   //   admission_id: uid,
  //   //   area_name: `${uid}区`,
  //   //   bed: `XH-${f2z(uid)}`,
  //   //   name: MOCK_getName(),
  //   //   part_name: MOCK_getPartName(),
  //   //   warn_id: WARNING_LEVEL.GLU_LOW_SUPER,
  //   //   warn_time: dayjs().unix(),
  //   //   is_admission: ADMISSION_TYPE_2.IN_HOSPITAL,
  //   //   part_kind: PART_KIND.IN,
  //   //   warn_kind: WARN_NEW_KIND.WARN,
  //   //   warn_level: WARN_LEVEL.HIGH,
  //   //   warn_text: '极低血糖 2.2mmol/L',
  //   //   warn_remark: '请注意患者症状',
  //   // }
  // ]);
  
  // const f2z = fill2Zero;
  // const re = randomInEnum;
  const id = getRandomWarnId(true,  excludeEvent === undefined ? false : excludeEvent);
  return {
    admission_id: uid,
    area_name: `${uid}区`,
    bed: `XH-${f2z(uid)}`,
    code: '',
    name: MOCK_getName(),
    part_name: MOCK_getPartName(),
    warn_id: id,
    warn_time: dayjs().unix(),
    is_admission: re(ADMISSION_TYPE_2.IN_HOSPITAL, ADMISSION_TYPE_2.SIGNED),
    part_kind: re(PART_KIND.IN, PART_KIND.OUT),
    warn_kind: re(WARN_NEW_KIND.NORMAL, WARN_NEW_KIND.WARN, WARN_NEW_KIND.TIPS, WARN_NEW_KIND.ADVICE),
    warn_level: getWarnLevel(id),
    // warn_level: re(WARN_LEVEL.NORMAL, WARN_LEVEL.HIGH, WARN_LEVEL.LOW),
    warn_text: warnUtilGetWarnText(id),
    warn_remark: '请核实患者操作与状态',
  };
}

function getRandomWarnId(excludeNormal?: boolean, excludeEvent?: boolean): WARNING_LEVEL {
  const set = new Set(warnMap.keys());
  if (excludeNormal) {
    set.delete(WARNING_LEVEL.NORMAL);
  }
  if (excludeEvent) {
    set.delete(WARNING_LEVEL.SUPPLIES_CHANGE);
    set.delete(WARNING_LEVEL.UNBIND_PUMP);
    set.delete(WARNING_LEVEL.GLU_ADD);
  }
  return randomInSet(set);
}


function getWarnLevel(id: WARNING_LEVEL): WARN_LEVEL {
  if (id === WARNING_LEVEL.NORMAL) {
    return WARN_LEVEL.LOW;
  }
  if (id === WARNING_LEVEL.ADVICE) {
    return WARN_LEVEL.LOW;
  }
  if (
    id === WARNING_LEVEL.LOW_BATTERY ||
    id === WARNING_LEVEL.LOW_BATTERY_2 ||
    id === WARNING_LEVEL.LOW_REMAIN ||
    id === WARNING_LEVEL.LOW_REMAIN_2 ||
    id === WARNING_LEVEL.GLU_HIGH ||
    id === WARNING_LEVEL.STOPPED_FOR_MORE_THAN_15_MIN ||
    id === WARNING_LEVEL.ERROR_6 ||
    id === WARNING_LEVEL.NOT_ACTIVATED ||
    id === WARNING_LEVEL.CALIBRATION_NOT_ACCEPTED ||
    id === WARNING_LEVEL.PROBE_UPPER_LIMIT ||
    id === WARNING_LEVEL.HIGH_PROBE_WARN ||
    id === WARNING_LEVEL.PROBE_LOWER_LIMIT ||
    id === WARNING_LEVEL.LOW_PROBE_WARN ||
    id === WARNING_LEVEL.PROBE_RISING_FAST ||
    id === WARNING_LEVEL.PAUSED_AND_PROBE_LOWER_LIMIT ||
    id === WARNING_LEVEL.PAUSED_AND_GLU ||
    id === WARNING_LEVEL.BASE_RECOVER_AND_GLU ||
    id === WARNING_LEVEL.PLEASE_CHANGE_PIPE
  ) {
    return WARN_LEVEL.HIGH;
  }
  return WARN_LEVEL.HIGH;
}
