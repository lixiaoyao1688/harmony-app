import { WarnInfoVO } from '@/modules/warn/vo/WarnInfo.vo';


export type WarnInfoSortFnType = (a: WarnInfoVO, b: WarnInfoVO) => number;
