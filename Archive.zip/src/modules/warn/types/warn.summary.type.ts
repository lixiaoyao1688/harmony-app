export type WarnSummaryItemType = {
  name: string;  // 项目名称
  value: string;  // 报警次数
  color: string;  // 颜色
  percent: string;  // 占比，如"80%";
}

export type WarnSummaryItemChartPayloadType = {
  color: string;  // 颜色
  colorForReport: string;  // 用于报告的颜色
  symbol: string;  // 图标
  symbolForReport: string;  // 用于报告的图标
}

export type WarnSummaryLegendType = {
  name: string;  // 项目名称
  value: number;  // 报警次数
  color: string;  // 颜色
}


// 报警项
type WarnSummaryHourItem = {
  name: string;  // 名称
  value: number;  // 次数
  color: string;  // 颜色
  colorForReport: string;  // 用于报告的颜色
  height: string;  // 高度
}

// 3小时的报警次数统计: 高血糖,低血糖,泵阻塞,运行异常
export type WarnSummaryHourCount = [WarnSummaryHourItem,WarnSummaryHourItem,WarnSummaryHourItem,WarnSummaryHourItem];

// 1天的报警统计: 0~3,3~6,6~9,9~12,12~15,15~18,18~21,21~24
export type WarnSummaryDayCount = [WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount,WarnSummaryHourCount];
