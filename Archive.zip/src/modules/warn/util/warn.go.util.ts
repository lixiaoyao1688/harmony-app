import {INVALID_ID} from '@/utils/global.vo.help';
import {CardVO} from '@/modules/admission/vo/Card.vo';
import {WarnVO} from '@/modules/warn/vo/Warn.vo';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import {ADMISSION_MENU} from '@/modules/admission/vo/Admission.help.menu.vo';
import {OutPatientAdmissionVO} from '@/modules/admission/vo/OutPatientAdmission.vo';
import {ADVICE_CL_TAB, ADVICE_CL_TAB_CURRENT, ADVICE_CL_TAB_NEW} from '@/modules/advice-closed-loop/config/advice.cl.pc.tab';
import router, {ROUTE_IN_PATIENT, ROUTE_OUT_PATIENT} from '@/routers/global.router';
import type {WarnDTO} from '@/modules/warn/dto/warn.dto';
import type {WarnStoreType} from '@/modules/warn/store/warn.store';
import type {AdmissionStoreType} from '@/modules/admission/store/admission.store';
import type {CardStoreType} from '@/modules/admission/store/card.store';
import type {OutPatientStoreType} from '@/modules/admission/store/out.patient.store';
import type {AdviceStoreType} from '@/modules/advice-closed-loop/store/advice.cl.store';


// 提示消息被点击时的跳转逻辑 仅PC
export function onWarnClickGoPC(store: WarnStoreType, cardStore: CardStoreType, outPatientStore: OutPatientStoreType, data: WarnVO, name: string): void {
  store.setRedirectingVO(data);
  
  if (data.isPatientWaiting) {
    // 待接收患者 消息
    outPatientStore.setWaitingOpenPending(true);
    if (name !== ROUTE_OUT_PATIENT) {
      // 如果不在签约患者界面，跳转过去
      router.push({ name: ROUTE_OUT_PATIENT }).then(_ => {});
    }
  }
  else if (data.isPatientHospital) {
    const selectInPatientByCode = (code: string) => {
      // 按登记号搜索患者，返回结果后选中
      // 搜索逻辑见: @src\modules\admission\views\InPatientView.vue: watch(() => store.fetchPendingCode, ...)
      cardStore.setFetchPendingCode(code);
    };
    cardStore.filter.partKindItem = data.partKindItem;
    if (name === ROUTE_IN_PATIENT) {
      // 在院泵患者界面，则根据 store 来判断有没有该患者:
      const id = data.admissionId;
      const vo = cardStore.cards.find(c => c.id === id);
      if (vo) {
        // 有-直接选中并滚动到顶部，
        // 选中逻辑见: @src\modules\admission\views\InPatientView.vue: watch(() => store.cardToSelect, ...)
        cardStore.setCardToSelect(vo as CardVO);
      } else {
        // 没有-按登记号搜索，按登记号搜索，返回结果后选中。
        // 选中逻辑见: @src\modules\admission\views\InPatientView.vue: watch(() => store.cards, ...)
        selectInPatientByCode(data.code);
      }
    }
    else {
      // 不在院泵患者界面，则跳转过来按登记号搜索。
      router.push({ name: ROUTE_IN_PATIENT }).then(_ => {});
      selectInPatientByCode(data.code);
    }
  }
  else if (data.isPatientSigned) {
    const selectOutPatientByCode = (code: string) => {
      // 按登记号搜索签约患者，返回结果后选中
      // 搜索逻辑见: @src\modules\admission\views\OutPatientView.vue: watch(() => store.fetchPendingCode, ...)
      outPatientStore.setFetchPendingCode(code);
    };
    if (name === ROUTE_OUT_PATIENT) {
      // 如果在签约患者界面，则根据 store 来判断有没有该患者: 有-直接选中并滚动到顶部，
      const code = data.code;
      const patient = outPatientStore.vo.patients.find(p => p.code === code);
      if (patient) {
        // 有-直接选中并滚动到顶部
        outPatientStore.setSelectingAdmission(patient as OutPatientAdmissionVO);
      } else {
        // 没有-按登记号搜索，按登记号搜索，返回结果后选中。
        selectOutPatientByCode(code);
      }
    } else {
      // 不在签约患者界面，则跳转过来按登记号搜索。
      router.push({ name: ROUTE_OUT_PATIENT }).then(_ => {});
      selectOutPatientByCode(data.code);
    }
  }
}

// 提示消息被点击时的跳转逻辑 仅APP
export function onWarnClickGo(data: WarnDTO, warnStore: WarnStoreType, admissionStore: AdmissionStoreType, adviceStore: AdviceStoreType): void {
  if (data.warn_kind === WARN_NEW_KIND.ADVICE) {
    adviceStore.setAdmissionId(data.admission_id);
    adviceStore.setIsOpenedByMessage(true);
    adviceStore.goTab(ADVICE_CL_TAB_NEW);
    warnStore.setWarnNotificationSelected(data);
    admissionStore.navigateAdmissionDetailMenu(ADMISSION_MENU.ADVICE);
  }
  else {
    admissionStore.navigateAdmissionDetailMenu(ADMISSION_MENU.ADMISSION);
  }
  admissionStore.fetchInfo(data.admission_id).then(_ => {});
}

// 点击消息跳转到详情界面后，退出时的逻辑 仅APP
export function onWarnClickBack(warnStore: WarnStoreType, admissionStore: AdmissionStoreType, adviceStore: AdviceStoreType): void {
  if (warnStore.warnNotificationSelected !== null) {
    warnStore.setWarnNotificationSelected(null);
  }
  if (admissionStore.admission.isValid) {
    admissionStore.admission = new AdmissionVO();
  }
  if (adviceStore.admissionId !== INVALID_ID) {
    adviceStore.setAdmissionId(INVALID_ID);
  }
  if (adviceStore.isOpenedByMessage) {
    adviceStore.setIsOpenedByMessage(false);
  }
  if (adviceStore.tabItem.id !== ADVICE_CL_TAB.CURRENT) {
    adviceStore.goTab(ADVICE_CL_TAB_CURRENT);
  }
}
