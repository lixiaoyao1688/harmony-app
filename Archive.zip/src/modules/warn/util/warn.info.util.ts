import { WarnInfoVO } from '@/modules/warn/vo/WarnInfo.vo';
import { WARN_SORT } from '@/modules/warn/config/warn.info.config';
import type { WarnInfoSortFnType } from '@/modules/warn/types/warn.info.type';


export function getSortFnById(id: WARN_SORT): WarnInfoSortFnType {
  if (id === WARN_SORT.TIME) {
    return (a: WarnInfoVO, b: WarnInfoVO) => b.timestamp - a.timestamp;
  }
  else {
	  return (a: WarnInfoVO, b: WarnInfoVO) => b.priority - a.priority;
  }
}
