import dayjs from 'dayjs';
import {CGM_WARN} from '@/modules/cgm/config/cgm.warn';
import {PUMP_WARN} from '@/modules/pump/config/pump.warn';
import {HISTORY_KIND} from '@/modules/record/config/history.config';
import {timeZeroing} from '@/lib/time/util/time.util';
import {realRoundTo2Digit} from '@/lib/math/util/math.util';
import {WARN_SUMMARY_COUNT_COLOR} from '@/modules/warn/config/warn.summary.color';
import type {WarnSummaryDayCount} from '@/modules/warn/types/warn.summary.type';
import type {WarnSummaryDayDTO, WarnSummaryRecordDTO} from '@/modules/warn/dto/warn.summary.dto';


export function isWarnSummaryPump(data: HISTORY_KIND): boolean {
  return data === HISTORY_KIND.ALARM;
}
export function isWarnSummaryCGM(data: HISTORY_KIND): boolean {
  return data === HISTORY_KIND.CGM_WARN;
}


export function isWarnSummaryGluLow(d: WarnSummaryRecordDTO): boolean {
  return d.kind === HISTORY_KIND.CGM_WARN && d.value === CGM_WARN.LOW_PROBE;
}
export function isWarnSummaryGluHigh(d: WarnSummaryRecordDTO): boolean {
  return d.kind === HISTORY_KIND.CGM_WARN && d.value === CGM_WARN.HIGH_PROBE;
}
export function isWarnSummaryPumpBlock(d: WarnSummaryRecordDTO): boolean {
  return d.kind === HISTORY_KIND.ALARM && d.value === PUMP_WARN.BLOCK;
}
export function isWarnSummaryPumpError(d: WarnSummaryRecordDTO): boolean {
  if (d.kind === HISTORY_KIND.ALARM && d.text === '泵低药量') {
    // fix(pc): http://192.168.1.236:81/redmine/issues/8705
    return false;
  }
  return d.kind === HISTORY_KIND.ALARM && d.value !== PUMP_WARN.BLOCK;
}



// 只需要统计 "低血糖"、"高血糖"、"泵阻塞"、"运行异常"这四种报警
export function getValidRecordDTO(data?: Array<WarnSummaryRecordDTO>): Array<WarnSummaryRecordDTO> {
  if (!data) {
    return [];
  }
  return data.filter(d => isWarnSummaryGluLow(d) || isWarnSummaryGluHigh(d) || isWarnSummaryPumpBlock(d) || isWarnSummaryPumpError(d));
}

/**
 * 获取报警图
 * @param data 记录列表
 * @param height 最大高度，单位px
 */
export function getWarnSummaryCounts(data: WarnSummaryDayDTO | null, height: number): WarnSummaryDayCount {
  // 每3小时统计1段，1天共8段;
  const HOURS = 3;
  const COUNT = 8;
  const result = Array(COUNT).fill(0).map(() => ([
    { name: '高血糖', value: 0, color: WARN_SUMMARY_COUNT_COLOR.CGM_HIGH, height: '0', colorForReport: WARN_SUMMARY_COUNT_COLOR.CGM_HIGH_FOR_REPORT },
    { name: '低血糖', value: 0, color: WARN_SUMMARY_COUNT_COLOR.CGM_LOW, height: '0', colorForReport: WARN_SUMMARY_COUNT_COLOR.CGM_LOW_FOR_REPORT },
    { name: '泵阻塞', value: 0, color: WARN_SUMMARY_COUNT_COLOR.PUMP_BLOCK, height: '0', colorForReport: WARN_SUMMARY_COUNT_COLOR.PUMP_BLOCK_FOR_REPORT },
    { name: '运行异常', value: 0, color: WARN_SUMMARY_COUNT_COLOR.PUMP_ERROR, height: '0', colorForReport: WARN_SUMMARY_COUNT_COLOR.PUMP_ERROR_FOR_REPORT },
  ])) as WarnSummaryDayCount;
  
  if (!data) {
    return result;
  }
  
  const start = timeZeroing(dayjs(data.record_date));
  const records = getValidRecordDTO(data.records);
  
  let cur = start;
  
  for (let i = 0; i < COUNT; i++) {
    const s = cur.unix();
    const e = cur.add(HOURS, 'h').unix();
    
    const currentRecords = records.filter(d => d.record_time >= s && d.record_time <= e);
    const cgmHigh = currentRecords.filter(d => isWarnSummaryGluHigh(d)).length;
    const cgmLow = currentRecords.filter(d => isWarnSummaryGluLow(d)).length;
    const pumpBlock = currentRecords.filter(d => isWarnSummaryPumpBlock(d)).length;
    const pumpError = currentRecords.filter(d => isWarnSummaryPumpError(d)).length;
    
    const cgmHighHeight = realRoundTo2Digit(cgmHigh / (cgmHigh+cgmLow)) * height + 'px';
    const cgmLowHeight = realRoundTo2Digit(cgmLow / (cgmHigh+cgmLow)) * height + 'px';
    const pumpBlockHeight = realRoundTo2Digit(pumpBlock / (pumpBlock+pumpError)) * height + 'px';
    const pumpErrorHeight = realRoundTo2Digit(pumpError / (pumpBlock+pumpError)) * height + 'px';
    
    result[i] = [
      { name: '高血糖', value: cgmHigh, color: WARN_SUMMARY_COUNT_COLOR.CGM_HIGH, height: cgmHighHeight, colorForReport: WARN_SUMMARY_COUNT_COLOR.CGM_HIGH_FOR_REPORT },
      { name: '低血糖',  value: cgmLow, color: WARN_SUMMARY_COUNT_COLOR.CGM_LOW, height: cgmLowHeight, colorForReport: WARN_SUMMARY_COUNT_COLOR.CGM_LOW_FOR_REPORT },
      { name: '泵阻塞',  value: pumpBlock, color: WARN_SUMMARY_COUNT_COLOR.PUMP_BLOCK, height: pumpBlockHeight, colorForReport: WARN_SUMMARY_COUNT_COLOR.PUMP_BLOCK_FOR_REPORT },
      { name: '运行异常', value: pumpError, color: WARN_SUMMARY_COUNT_COLOR.PUMP_ERROR, height: pumpErrorHeight, colorForReport: WARN_SUMMARY_COUNT_COLOR.PUMP_ERROR_FOR_REPORT },
    ];
    
    cur = cur.add(HOURS,'h');
  }
  
  return result;
}


