import {WarnDTO, WARNING_COLOR, WARNING_LEVEL} from '@/modules/warn/dto/warn.dto';
import {WARN_LEVEL} from '@/modules/warn/config/warn.level';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';


export function getWarnBgColorNew(data?: WarnDTO, mobile?: boolean, isDisconnected?: boolean): WARNING_COLOR {
  if (!data) {
    return WARNING_COLOR.LOW;
  }
  if (isDisconnected) {
    // "APP/泵"未连接属于"提示"。见: 《数据管理系统参数设置相关.xlsx》--B200报警提示条目及等级
    return WARNING_COLOR.EVENT;
  }
  const kind = data.warn_kind;
  const level = data.warn_level;
  // 正常
  if (level === WARN_LEVEL.NORMAL) {
    return WARNING_COLOR.LOW;
  }
  // 提示
  if (kind === WARN_NEW_KIND.TIPS) {
    return WARNING_COLOR.EVENT;
  }
  // 医嘱
  if (kind === WARN_NEW_KIND.ADVICE) {
    return mobile ? WARNING_COLOR.ADVICE_2 : WARNING_COLOR.NEW_ADVICE;
  }
  // 报警
  if (isWarnGluLow(data)) {
    // 为了和趋势图保持一致，低血糖报警的背景颜色显示为红色
    return mobile ? WARNING_COLOR.HIGH_2 : WARNING_COLOR.NEW_HIGH;
  }
  // 报警 - 按报警级别判断
  if (level === WARN_LEVEL.LOW) {
    return mobile ? WARNING_COLOR.MIDDLE_2 : WARNING_COLOR.NEW_MIDDLE;
  }
  if (level === WARN_LEVEL.HIGH) {
    return mobile ? WARNING_COLOR.HIGH_2 : WARNING_COLOR.NEW_HIGH;
  }
  return WARNING_COLOR.LOW;
}

export function getWarnTextBgColor(data: WarnDTO, isDisconnected?: boolean): WARNING_COLOR {
  if (isDisconnected) {
    // "APP/泵"未连接属于"提示"。见: 《数据管理系统参数设置相关.xlsx》--B200报警提示条目及等级
    return WARNING_COLOR.TIP_TEXT_BG_COLOR;
  }
  const kind = data.warn_kind;
  const level = data.warn_level;
  // 正常
  if (level === WARN_LEVEL.NORMAL) {
    return WARNING_COLOR.TIP_TEXT_BG_COLOR;
  }
  // 提示
  if (kind === WARN_NEW_KIND.TIPS) {
    return WARNING_COLOR.TIP_TEXT_BG_COLOR;
  }
  // 医嘱
  if (kind === WARN_NEW_KIND.ADVICE) {
    return WARNING_COLOR.ADVICE_TEXT_BG_COLOR;
  }
  // 报警
  if (isWarnGluLow(data)) {
    // 为了和趋势图保持一致，低血糖报警的背景颜色显示为红色
    return WARNING_COLOR.WARN_HIGH_TEXT_BG_COLOR;
  }
  // 报警 - 按报警级别判断
  if (level === WARN_LEVEL.LOW) {
    return WARNING_COLOR.WARN_LOW_TEXT_BG_COLOR;
  }
  if (level === WARN_LEVEL.HIGH) {
    return WARNING_COLOR.WARN_HIGH_TEXT_BG_COLOR;
  }
  return WARNING_COLOR.TIP_TEXT_BG_COLOR;
}

export function getWarnTextColorNew(data?: WarnDTO): WARNING_COLOR {
  if (!data) {
    return WARNING_COLOR.NORMAL_TEXT_COLOR;
  }
  if (data.warn_kind === WARN_NEW_KIND.TIPS) {
    return WARNING_COLOR.EVENT_TEXT_COLOR;
  }
  return WARNING_COLOR.NORMAL_TEXT_COLOR;
}

export function isWarnGluLow(data?: WarnDTO): boolean {
  if (!data) {
    return false;
  }
  const id = data.warn_id;
  return id === WARNING_LEVEL.GLU_LOW_2 || id === WARNING_LEVEL.GLU_LOW || id === WARNING_LEVEL.GLU_LOW_SUPER;
}
