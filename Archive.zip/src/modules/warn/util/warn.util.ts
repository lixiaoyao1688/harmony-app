import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import {WARN_VIEW_DOM_ID} from '@/modules/warn/config/warn.config';
import {WARNING_COLOR, WARNING_LEVEL, WARNING_PRIORITY, warnMap} from '@/modules/warn/dto/warn.dto';


export function isWarnEventNew(data: WARN_NEW_KIND): boolean {
  return data === WARN_NEW_KIND.TIPS;
}

export function isWarnEvent(id: WARNING_LEVEL): boolean {
  return id === WARNING_LEVEL.SUPPLIES_CHANGE || id === WARNING_LEVEL.UNBIND_PUMP || id === WARNING_LEVEL.GLU_ADD;
}

export function isWarnAdvice(id: WARNING_LEVEL): boolean {
  return id === WARNING_LEVEL.ADVICE;
}

export function isWarnWarn(id: WARNING_LEVEL): boolean {
  return !isWarnEvent(id) && !isWarnAdvice(id);
}

export function getWarnPriority(id: WARNING_LEVEL): WARNING_PRIORITY {
  if (id === WARNING_LEVEL.NORMAL) {
    return WARNING_PRIORITY.LOW;
  }
  if (id === WARNING_LEVEL.ADVICE) {
    return WARNING_PRIORITY.ADVICE;
  }
  if (
    id === WARNING_LEVEL.LOW_BATTERY ||
    id === WARNING_LEVEL.LOW_BATTERY_2 ||
    id === WARNING_LEVEL.LOW_REMAIN ||
    id === WARNING_LEVEL.LOW_REMAIN_2 ||
    id === WARNING_LEVEL.GLU_HIGH ||
    id === WARNING_LEVEL.STOPPED_FOR_MORE_THAN_15_MIN ||
    id === WARNING_LEVEL.ERROR_6 ||
    id === WARNING_LEVEL.NOT_ACTIVATED ||
    id === WARNING_LEVEL.CALIBRATION_NOT_ACCEPTED ||
    id === WARNING_LEVEL.PROBE_UPPER_LIMIT ||
    id === WARNING_LEVEL.HIGH_PROBE_WARN ||
    id === WARNING_LEVEL.PROBE_LOWER_LIMIT ||
    id === WARNING_LEVEL.LOW_PROBE_WARN ||
    id === WARNING_LEVEL.PROBE_RISING_FAST ||
    id === WARNING_LEVEL.PAUSED_AND_PROBE_LOWER_LIMIT ||
    id === WARNING_LEVEL.PAUSED_AND_GLU ||
    id === WARNING_LEVEL.BASE_RECOVER_AND_GLU ||
    id === WARNING_LEVEL.PLEASE_CHANGE_PIPE
  ) {
    return WARNING_PRIORITY.MIDDLE;
  }
  return WARNING_PRIORITY.HIGH;
}

export function warnUtilGetColor(id: WARNING_LEVEL, mobile?: boolean): WARNING_COLOR {
  const p = getWarnPriority(id);
  if (isWarnEvent(id)) {
    return WARNING_COLOR.EVENT;
  }
  if (p === WARNING_PRIORITY.LOW) {
    return WARNING_COLOR.LOW;
  }
  if (p === WARNING_PRIORITY.ADVICE) {
    return mobile ? WARNING_COLOR.ADVICE_2 : WARNING_COLOR.NEW_ADVICE;
  }
  if (p === WARNING_PRIORITY.MIDDLE) {
    return mobile ? WARNING_COLOR.MIDDLE_2 : WARNING_COLOR.NEW_MIDDLE;
  }
  // WARNING_PRIORITY.HIGH
  return mobile ? WARNING_COLOR.HIGH_2 : WARNING_COLOR.NEW_HIGH;
}

export function warnUtilGetTextColor(id: WARNING_LEVEL): WARNING_COLOR {
  return isWarnEvent(id) ? WARNING_COLOR.EVENT_TEXT_COLOR : WARNING_COLOR.NORMAL_TEXT_COLOR;
}

export function warnUtilGetWarnText(id: WARNING_LEVEL) {
  return warnMap.get(id) || '';
}

export function getWarnViewHeight(): number {
  const e = document.getElementById(WARN_VIEW_DOM_ID);
  if (!e) {
    return 0;
  }
  return e.clientHeight;
}

export function warnUnitGetColorAlpha(color: WARNING_COLOR): string {
  const rgbRegex = /^rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/;
  const rgb = rgbRegex.exec(color);
  
  if (rgb && rgb.length === 4) {
    const r = parseInt(rgb[1], 10);
    const g = parseInt(rgb[2], 10);
    const b = parseInt(rgb[3], 10);
    return `rgba(${r},${g},${b},0.6)`;
  }
  return 'transparent';
}
