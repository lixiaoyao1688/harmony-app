<script setup lang="ts">
import {computed, watch} from 'vue';
import { useRoute } from 'vue-router';
import {AdmissionVO} from '@/modules/admission/vo/Admission.vo';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useCurrentStore } from '@/modules/record/store/current.store';
import { ROUTE_IN_PATIENT } from '@/routers/global.router';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {WARN_LEVEL_SORT_MAP, WARN_LEVEL_SORTS} from '@/modules/warn/config/warn.sort';
import {INVALID_ID} from '@/utils/global.vo.help';
import {WarnInfoVO} from '@/modules/warn/vo/WarnInfo.vo';
import WarnCard from '@/modules/warn/components/WarnCard.vue';
import EmptyNew from '@/lib/aaruy-design/empty/EmptyNew.vue';
import CardView1 from '@/lib/aaruy-design/card/CardView1.vue';
import SelectTip from '@/lib/aaruy-design/select/tip/SelectTip.vue';
import DropdownMobile from '@/lib/aaruy-design/dropdown/DropdownMobile.vue';


/**
 * 72小时报警信息(PC) 或 报警(APP) 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  vos: Array<WarnInfoVO>;
  admission: AdmissionVO;
  loading?: boolean;  // 仅PC
}

interface Emit {
  (e: 'fetch'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const route = useRoute();
const store = useCurrentStore();
const screenStore = useScreenStore();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const isInPatient = computed<boolean>(() => (route.name === ROUTE_IN_PATIENT));

watch(() => prop.admission.id, (data) => {
  if (data !== INVALID_ID) {
    store.filter.admissionId = data;
    if (screenStore.isMobile) {
      fetchData();
    }
  }
}, { immediate: true });

function onSortChange2(data: SelectItemVO<unknown>): void {
  store.filter.setSortItem(data);
  if (store.filter.admissionId !== INVALID_ID) {
    fetchData();
  }
}

function fetchData(): void {
  emit('fetch');
}

// function onCgmChange(checked: boolean): void {
//   store.filter.isCgmChecked = checked;
//   store.fetchData();
// }

// function onSortChange(data: SelectorFormItemVO): void {
//   store.setWarnInfoSortOption(data);
// }
</script>

<template>
	
	<CardView1 v-if="pc" type="list" title="72小时报警信息" :padding="4" width="100%" height="100%">
		<template #list>
      <!--			<div class="flex items-center justify-between px-8" style="height: 45px;">-->
      <!--				<SelectorTip :item="store.warnInfoSortOption" :items="WARN_SORT_OPTIONS" @change="onSortChange" />-->
      <!--				<CheckBox type="default" :checked="store.filter.isCgmChecked" @change="onCgmChange">CGM</CheckBox>-->
      <!--			</div>-->
      <SelectTip :item="store.filter.sortItem" :items="WARN_LEVEL_SORTS"
                 width="160px" height="32px" is-sort-style margin="8px"
                 @change="onSortChange2" />
			<div class="overflow-x-hidden overflow-y-auto" style="height: calc(100% - 48px - 34px - 4px - 4px);">
        <div v-if="loading" class="text-center text-lg text-weak-2 pt-24">加载中...</div>
        <template v-else>
          <div v-if="vos.length === 0" class="text-center text-lg text-weak pt-24">暂无数据</div>
          <WarnCard v-for="it in vos" :key="it.id" :info="it" />
        </template>
			</div>
		</template>
	</CardView1>
	<div v-else>
		<div class="flex justify-between items-center pl-8 pr-16" style="height: 40px;">
			<DropdownMobile :item="store.filter.sortItem" :items="WARN_LEVEL_SORTS" :item-map="WARN_LEVEL_SORT_MAP" @change="onSortChange2" />
<!--			<CheckBoxMobile title="CGM" :checked="store.filter.isCgmChecked" @change="onCgmChange" />-->
		</div>
		<div class="overflow-x-hidden overflow-y-auto" style="height: calc(100vh - var(--board-top) - var(--admission-detail-mobile-tab-header-height) - 40px);">
      <EmptyNew v-if="vos.length === 0" tips="暂无报警信息" />
			<WarnCard v-for="it in vos" :key="it.id" :info="it" />
		</div>
	</div>
	
</template>
