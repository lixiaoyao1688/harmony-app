<script setup lang="ts">
import {watch} from 'vue';
import * as echarts from 'echarts';
import {INVALID_ID} from '@/utils/global.vo.help';
import {useWarnSummaryStore} from '@/modules/warn/store/warn.summary.store';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import WarnSummaryFilter from '@/modules/warn/view/WarnSummaryFilter.vue';
import WarnSummaryContent from '@/modules/warn/components/WarnSummaryContent.vue';
import type {ChartType} from '@/modules/chart/types/chart.type';
import type {ECBasicOption} from 'echarts/types/src/util/types';


/**
 * 报警总结 界面
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
const store = useWarnSummaryStore();
const admissionStore = useAdmissionStore();

let chart: ChartType = null;
const filterHeight = '64px';
const elId = 'warn-summary-chart';

watch(() => admissionStore.admission.id, (id) => {
  if (id !== INVALID_ID) {
    store.fetchData(id);
  }
}, { immediate: true });

watch(() => store.vo, (data) => {
  renderChart(data.config);
}, { immediate: true });

function renderChart(c: ECBasicOption): void {
  if (!chart) {
    // mount
    const el = document.getElementById(elId);
    if (el) {
      chart = echarts.init(el);
    }
  }
  if (chart) {
    // mount && update
    chart.setOption(c);
  }
}
</script>

<template>
  <WarnSummaryFilter :height="filterHeight" />
  <div :style="{ height: `calc(100% - ${filterHeight})` }" class="overflow-hidden-auto bg-3 p-24">
    <WarnSummaryContent :vo="store.vo" :el-id="elId" />
  </div>
</template>
