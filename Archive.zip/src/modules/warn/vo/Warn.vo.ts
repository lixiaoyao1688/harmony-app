import dayjs from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {WarnDTO, WARNING_LEVEL} from '@/modules/warn/dto/warn.dto';
import {WARNING_COLOR} from '@/modules/warn/dto/warn.dto';
import {ADMISSION_EMPTY_BED} from '@/modules/admission/config/admission.config';
import {WARN_KIND} from '@/modules/warn/config/warn.kind';
import {ADMISSION_TYPE_2} from '@/modules/admission/dto/admission.help.dto';
import {PART_KIND, PART_KIND_ITEM_IN, PART_KIND_ITEM_OUT} from '@/modules/admission/config/admission.part.kind';
import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import {getWarnBgColorNew, getWarnTextColorNew} from '@/modules/warn/util/warn.util.new';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 报警 VO
 */
export class WarnVO {
	
	private readonly _entity: WarnDTO | undefined;
	public index: number | undefined;
	
	constructor(e?: WarnDTO, i?: number) {
	  this._entity = e;
	  this.index = i;
	}
	
	public get isValid(): boolean {
	  return !!(this._entity);
	}
	
	// 唯一标识
	public get id(): number {
	  if (!this._entity || this._entity.warn_time === undefined) {
	    return this.index === undefined ? INVALID_ID : this.index;
	  }
	  return this._entity.warn_time;
	}
	
	// 消息id
	public get warnId(): WARNING_LEVEL {
	  if (!this._entity) {
	    return INVALID_ID as WARNING_LEVEL;
	  }
	  return this._entity.warn_id;
	}
	
	// 患者id
	public get admissionId(): number {
	  if (!this._entity) {
	    return INVALID_ID;
	  }
	  return this._entity.admission_id;
	}
	
	// 是否归属于院泵住院患者
	public get isPatientHospitalIn(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  const data = this._entity;
	  return data.is_admission === ADMISSION_TYPE_2.IN_HOSPITAL && data.part_kind === PART_KIND.IN;
	}
	// 是否归属于院泵门诊患者
	public get isPatientHospitalOut(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  const data = this._entity;
	  return data.is_admission === ADMISSION_TYPE_2.IN_HOSPITAL && data.part_kind === PART_KIND.OUT;
	}
	// 院泵患者类型 项
	public get partKindItem(): ItemType2 {
	  if (!this._entity) {
	    return new SelectItemVO<unknown>();
	  }
	  const data = this._entity;
	  return data.is_admission === ADMISSION_TYPE_2.IN_HOSPITAL && data.part_kind === PART_KIND.IN ? PART_KIND_ITEM_IN : PART_KIND_ITEM_OUT;
	}
	// 是否归属于院泵患者
	public get isPatientHospital(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.is_admission === ADMISSION_TYPE_2.IN_HOSPITAL;
	}
	// 是否归属于签约患者
	public get isPatientSigned(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.is_admission === ADMISSION_TYPE_2.SIGNED;
	}
	
	// 是否是待接收患者消息
	public get isPatientWaiting(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.warn_id === WARNING_LEVEL.PATIENT_WAITING;
	}
	
	// 登记号
	public get code(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.code;
	}
	
	// 病区
	public get areaText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.area_name || '--';
	}
	
	// 发生时刻 时间戳 秒
	public get time(): number {
	  if (!this._entity) {
	    return 0;
	  }
	  return this._entity.warn_time;
	}
	// 发生时间
	public get timeText(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return dayjs.unix(this._entity.warn_time).format('YYYY-MM-DD HH:mm:ss');
	}
	
	// 床号
	public get bed(): string {
	  if (!this._entity) {
	    return '--';
	  }
	  return this._entity.bed || '--';
	}
	
	// 床号文本
	public get bedText(): string {
	  if (!this._entity) {
	    return '未知床号';
	  }
	  const bed = this._entity.bed;
	  return bed ? (bed + '床') : '未知床号';
	}
	
	
	// 是否报警类型
	public get isWarn(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.warn_kind === WARN_NEW_KIND.WARN;
	}
	// 是否提示类型（事件）
	public get isTips(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.warn_kind === WARN_NEW_KIND.TIPS;
	}
	// 是否医嘱类型
	public get isAdvice(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.warn_kind === WARN_NEW_KIND.ADVICE;
	}
	
	
	// 标题 文本
	public get content(): string {
	  if (!this._entity) {
	    return '****';
	  }
	  return this._entity.warn_text;
	}
	// 是否具备备注
	public get hasRemark(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return !!this._entity.warn_remark;
	}
	// 提示词 文本
	public get remarkText(): string {
	  if (!this._entity) {
	    return '****';
	  }
	  return this._entity.warn_remark;
	}
	
	// 背景颜色
	public get color(): WARNING_COLOR {
	  return getWarnBgColorNew(this._entity);
	  // if (!this._entity) {
	  //   return WARNING_COLOR.LOW;
	  // }
	  // return warnUtilGetColor(this._entity.warn_id);
	}
	
	// 字体颜色
	public get textColor(): WARNING_COLOR {
	  return getWarnTextColorNew(this._entity);
	  // if (!this._entity) {
	  //   return WARNING_COLOR.NORMAL_TEXT_COLOR;
	  // }
	  // return warnUtilGetTextColor(this._entity.warn_id);
	}
	
	// 标题
	public get title(): string {
	  if (!this._entity) {
	    return '';
	  }
	  const e = this._entity;
	  const area = e.area_name;
	  const bed = e.bed;
	  const name = e.name;
	  const isBedValid = (data: string) => data && data !== ADMISSION_EMPTY_BED;
		
	  if (area && isBedValid(bed) && name) {
	    return `${area}-${bed + '床 | ' + name}`;
	  }
	  if (area && name) {
	    return area + ' | ' + name;
	  }
	  if (area && isBedValid(bed)) {
	    return `${area}-${bed + '床'}`;
	  }
	  if (isBedValid(bed) && name) {
	    return bed + '床 | ' + name;
	  }
	  if (area) {
	    return area;
	  }
	  if (isBedValid(bed)) {
	    return bed + '床';
	  }
	  if (name) {
	    return name;
	  }
	  return '----';
	}
	
	// 科室名称
	public get partText(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.part_name;
	}
	
	// 是否属于该报警类型
	public isKind(id: WARN_KIND): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  if (id === WARN_KIND.ALL) {
	    return true;
	  }
	  if (id === WARN_KIND.WARN) {
	    return this._entity.warn_kind === WARN_NEW_KIND.WARN;
	    // return isWarnWarn(this._entity.warn_id);
	  }
	  if (id === WARN_KIND.NOTIFICATION) {
	    return this._entity.warn_kind === WARN_NEW_KIND.TIPS;
	    // return isWarnEvent(this._entity.warn_id);
	  }
	  if (id === WARN_KIND.ADVICE) {
	    return this._entity.warn_kind === WARN_NEW_KIND.ADVICE;
	    // return isWarnAdvice(this._entity.warn_id);
	  }
	  return false;
	}
	
	public get dto(): WarnDTO | null {
	  if (!this._entity) {
	    return null;
	  }
	  return this._entity;
	}
	
}
