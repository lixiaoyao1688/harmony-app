import {INVALID_ID} from '@/utils/global.vo.help';
import {WARN_SCENE, WARN_SUB_KIND} from '@/modules/warn/config/warn.current';
import {isEntityEmpty, isObjectNull} from '@/utils/global.tool';
import {WARNING_PRIORITY} from '@/modules/warn/dto/warn.dto';
import {getHHmmFromServerTime, getYYYYMMDDFromServerTime} from '@/lib/time/util/time.util';
import type { CurrentWarnDTO } from '@/modules/warn/dto/warn.dto';


/**
 * 报警信息 VO
 */
export class WarnInfoVO {
	
	private readonly _entity: CurrentWarnDTO;
	
	constructor(e: CurrentWarnDTO) {
	  this._entity = e;
	}
	
	// 唯一标识（非报警id）
	public get id(): number {
	  if (!this._entity) {
	    return INVALID_ID;
	  }
	  return this._entity.start_time;
	}
	
	// 报警内容
	public get text(): string {
	  if (!this._entity || isObjectNull(this._entity)) {
	    return '----';
	  }
	  return this._entity.warn_text || '----';
	}
	
	public get priority(): WARNING_PRIORITY {
	  if (this._isEmpty) {
	    return WARNING_PRIORITY.LOW;
	  }
	  return this._entity.scene_id === WARN_SCENE.HIGH ? WARNING_PRIORITY.HIGH : WARNING_PRIORITY.LOW;
	  // return getWarnPriority(this._entity.warn_id);
	}
	
	public get icon(): string {
	  const WHITE_ICON = `
			<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
				<g transform="translate(5716 4967.004)">
					<path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#fff"/>
					<path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#5b6774"/>
				</g>
			</svg>
    `;
	  const YELLOW_ICON = `
			<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
				<g transform="translate(5716 4967.004)">
					<path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#eba630"/>
					<path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#fff"/>
				</g>
			</svg>
		`;
	  const RED_ICON = `
		  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
				<g transform="translate(5716 4967.004)">
					<path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#ff242a"/>
					<path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#fff"/>
				</g>
			</svg>
    `;

	  if (!this._entity) {
	    return WHITE_ICON;
	  }
		
	  const data = this._entity;
	  if (data.sub_kind === WARN_SUB_KIND.TIPS) {
	    return WHITE_ICON;
	  }
	  if (data.sub_kind === WARN_SUB_KIND.WARN) {
	    return data.scene_id === WARN_SCENE.HIGH ? RED_ICON : YELLOW_ICON;
	  }
	  return WHITE_ICON;
		
	  // switch (this.priority) {
	  //   case WARNING_PRIORITY.ADVICE: {
	  //     return `
	  // 		<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
	  // 		  <g transform="translate(5716 4967.004)">
	  // 		    <path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#699ef5"/>
	  // 		    <path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#fff"/>
	  // 		  </g>
	  // 		</svg>
	  // 	`;
	  //   }
	  //   case WARNING_PRIORITY.MIDDLE: {
	  //     return `
	  // 			<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
	  // 			  <g transform="translate(5716 4967.004)">
	  // 			    <path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#eba630"/>
	  // 			    <path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#fff"/>
	  // 			  </g>
	  // 			</svg>
	  //     `;
	  //   }
	  //   case WARNING_PRIORITY.HIGH: {
	  //     return `
	  //       <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
	  // 			  <g transform="translate(5716 4967.004)">
	  // 			    <path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#ff242a"/>
	  // 			    <path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#fff"/>
	  // 			  </g>
	  // 			</svg>
	  //     `;
	  //   }
	  //   case WARNING_PRIORITY.LOW:
	  //   default: {
	  // 	  return `
	  // 	    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
	  // 			  <g transform="translate(5716 4967.004)">
	  // 			    <path d="M91.438,90.261a3.55,3.55,0,0,1-3.1,1.732H67.659A3.651,3.651,0,0,1,64.4,86.709l10.338-20.7a3.646,3.646,0,0,1,6.526,0L91.6,86.709A3.556,3.556,0,0,1,91.438,90.261Z" transform="translate(-5779.997 -5030.997)" fill="#fff"/>
	  // 			    <path d="M100.025,103.228a1.638,1.638,0,1,0-1.638-1.638A1.638,1.638,0,0,0,100.025,103.228Zm2.457-13.921a2.457,2.457,0,1,0-4.913,0v.2l1.638,8.854h0a.819.819,0,0,0,1.634,0h0l1.638-8.854Z" transform="translate(-5802.025 -5046.702)" fill="#5b6774"/>
	  // 			  </g>
	  // 			</svg>
	  //     `;
	  //   }
	  // }
	}

	public get date(): string {
	  if (this._isEmpty || !this._entity.start_time) {
	    return '----';
	  }
	  return getYYYYMMDDFromServerTime(this._entity.start_time);
	}
	
	public get time(): string {
	  if (this._isEmpty || !this._entity.start_time) {
	    return '----';
	  }
	  return getHHmmFromServerTime(this._entity.start_time);
	}
	
	public get timestamp(): number {
	  if (this._isEmpty || !this._entity.start_time) {
	    return 0;
	  }
	  return this._entity.start_time;
	}
	
	private get _isEmpty(): boolean {
	  return isEntityEmpty(this._entity);
	}
}
