import {WARN_NEW_KIND} from '@/modules/warn/config/warn.kind.new';
import {WarnDTO, WARNING_COLOR} from '@/modules/warn/dto/warn.dto';
import {getWarnBgColorNew} from '@/modules/warn/util/warn.util.new';
import { ADMISSION_EMPTY_BED } from '@/modules/admission/config/admission.config';


/**
 * 报警弹窗 VO
 */
export class WarnNotifyVO {
	
	private readonly _entity: WarnDTO | undefined;
	
	constructor(e?: WarnDTO) {
	  this._entity = e;
	}
	
	public get isValid(): boolean {
	  return !!(this._entity);
	}
	
	// 该消息是否是事件类型
	public get isEvent(): boolean {
	  if (!this._entity) {
	    return false;
	  }
	  return this._entity.warn_kind === WARN_NEW_KIND.TIPS;
	}
	
	public get name(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.name || '';
	}
	
	public get bedText(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.bed === ADMISSION_EMPTY_BED ? '' : (this._entity.bed + '床');
	}
	
	public get message(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this.bedText ? (this.bedText + ' ' + this.name) : this.name;
	}
	
	public get message2(): string {
	  if (!this._entity) {
	    return '';
	  }
	  const data = this._entity;
	  if (data.area_name && data.bed && data.name) {
	    return `${data.area_name}-${data.bed}床 ${data.name}`;
	  }
	  else if (data.bed && data.name) {
	    return `${data.bed}床 ${data.name}`;
	  }
	  else if (data.name) {
	    return `${data.name}`;
	  }
	  return '';
	  // return this.bedText ? (this.bedText + ' ' + this.name) : this.name;
	}
	
	public get warnText(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.warn_text || '';
	}
	public get remarkText(): string {
	  if (!this._entity) {
	    return '';
	  }
	  return this._entity.warn_remark || '';
	}
	
	
	public get warnBgColor(): WARNING_COLOR {
	  return getWarnBgColorNew(this._entity);
	  // if (!this._entity) {
	  //   return WARNING_COLOR.LOW;
	  // }
	  // return warnUtilGetColor(this._entity.warn_id);
	}
	
	public get warnBgColorOnMobile(): WARNING_COLOR {
	  return getWarnBgColorNew(this._entity);
	  // if (!this._entity) {
	  //   return WARNING_COLOR.LOW;
	  // }
	  // return warnUtilGetColor(this._entity.warn_id, true);
	}
	
	public get dto(): WarnDTO | null {
	  if (!this._entity) {
	    return null;
	  }
	  return this._entity;
	}
	
}
