import dayjs, {Dayjs} from 'dayjs';
import {throwFieldLackError} from '@/lib/http/util/http.utils';
import {WARN_SUMMARY_PATH} from '@/modules/warn/request/warn.summary.http';
import {getPercentTextFromDigit, nearestTen, realRoundTo2Digit, roundTo} from '@/lib/math/util/math.util';
import {CLINIC} from '@/modules/clinic/configs/clinic.config';
import {InsData, InsSeries, InsTooltipParams} from '@/modules/ins/types/ins.type';
import {getMMDotDDFromDate, getYYYYMMDDFromTime, serverTimeToWebTime, timeZeroing} from '@/lib/time/util/time.util';
import {getNDayAgoDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {WARN_SUMMARY_KIND, WARN_SUMMARY_KIND_MAP, WARN_SUMMARY_KINDS_FOR_LEGEND} from '@/modules/warn/config/warn.summary.kind';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {WarnSummaryDayVO} from '@/modules/warn/vo/WarnSummaryDay.vo';
import {WarnSummaryDayForReportVO} from '@/modules/warn/vo/WarnSummaryDayForReport.vo';
import {
  getValidRecordDTO,
  isWarnSummaryGluHigh,
  isWarnSummaryGluLow,
  isWarnSummaryPumpBlock,
  isWarnSummaryPumpError
} from '@/modules/warn/util/warn.summary.util';
import type {ECBasicOption} from 'echarts/types/src/util/types';
import type {LegendChartType} from '@/lib/aaruy-design/legend/types/legend.chart.type';
import type {WarnSummaryDayDTO, WarnSummaryDTO, WarnSummaryRecordDTO} from '@/modules/warn/dto/warn.summary.dto';
import type {WarnSummaryDayCount, WarnSummaryItemChartPayloadType, WarnSummaryItemType} from '@/modules/warn/types/warn.summary.type';


/**
 * 报警总结 VO
 */
export class WarnSummaryVO {
  
  private readonly _entity: Array<WarnSummaryDayDTO>;
  private readonly _start: Dayjs;  // 前端选中的开始日期
  private readonly _end: Dayjs;  // 前端选中的结束日期
  
  private readonly _totalCount: number;  // 总的报警次数
  private readonly _cgmLowCount: number;  // 低血糖报警次数
  private readonly _cgmHighCount: number;  // 高血糖报警次数
  private readonly _pumpBlockCount: number;  // 泵阻塞报警次数
  private readonly _pumpErrorCount: number;  // 泵运行异常报警次数
  
  public static legends: Array<LegendChartType> = WARN_SUMMARY_KINDS_FOR_LEGEND.map(it => ({
    id: it.id,
    text: it.text,
    color: it.payload.color
  }));
  
  public static legendsForReport: Array<LegendChartType> = WARN_SUMMARY_KINDS_FOR_LEGEND.map(it => ({
    id: it.id,
    text: it.text,
    color: it.payload.colorForReport
  }));
  
  public static getCounts(data: WarnSummaryDayDTO | null): WarnSummaryDayCount {
    // 每3小时统计1段，1天共8段;
    const HOURS = 3;
    const COUNT = 8;
    const result = Array(COUNT).fill(0).map(() => ([
      { name: '高血糖', value: 0, color: 'rgb(248,168,30)', height: '0', colorForReport: 'rgb(0,0,0)' },
      { name: '低血糖', value: 0, color: 'rgb(247,58,63)', height: '0', colorForReport: 'rgb(0,0,0)' },
      { name: '泵阻塞', value: 0, color: 'rgb(0,252,248)', height: '0', colorForReport: 'rgb(0,0,0)' },
      { name: '运行异常', value: 0, color: 'rgb(220,233,245)', height: '0', colorForReport: 'rgb(0,0,0)' },
    ])) as WarnSummaryDayCount;
    
    if (!data) {
      return result;
    }
    
    const start = timeZeroing(dayjs(data.record_date));
    const height = 100; // 149px - 49px(给顶部数量留的高度)
    const records = getValidRecordDTO(data.records);
    
    let cur = start;
    
    for (let i = 0; i < COUNT; i++) {
      const s = cur.unix();
      const e = cur.add(HOURS, 'h').unix();
      
      const currentRecords = records.filter(d => d.record_time >= s && d.record_time <= e);
      const cgmHigh = currentRecords.filter(d => isWarnSummaryGluHigh(d)).length;
      const cgmLow = currentRecords.filter(d => isWarnSummaryGluLow(d)).length;
      const pumpBlock = currentRecords.filter(d => isWarnSummaryPumpBlock(d)).length;
      const pumpError = currentRecords.filter(d => isWarnSummaryPumpError(d)).length;
      
      const cgmHighHeight = realRoundTo2Digit(cgmHigh / (cgmHigh+cgmLow)) * height + 'px';
      const cgmLowHeight = realRoundTo2Digit(cgmLow / (cgmHigh+cgmLow)) * height + 'px';
      const pumpBlockHeight = realRoundTo2Digit(pumpBlock / (pumpBlock+pumpError)) * height + 'px';
      const pumpErrorHeight = realRoundTo2Digit(pumpError / (pumpBlock+pumpError)) * height + 'px';
      
      result[i] = [
        { name: '高血糖', value: cgmHigh, color: 'rgb(248,168,30)', height: cgmHighHeight, colorForReport: 'rgb(0,0,0)' },
        { name: '低血糖',  value: cgmLow, color: 'rgb(247,58,63)', height: cgmLowHeight, colorForReport: 'rgb(0,0,0)' },
        { name: '泵阻塞',  value: pumpBlock, color: 'rgb(0,252,248)', height: pumpBlockHeight, colorForReport: 'rgb(0,0,0)' },
        { name: '运行异常', value: pumpError, color: 'rgb(220,233,245)', height: pumpErrorHeight, colorForReport: 'rgb(0,0,0)' },
      ];
      
      cur = cur.add(HOURS,'h');
    }
    
    return result;
  }
  
  
  constructor(data?: WarnSummaryDTO, sd?: Dayjs, ed?: Dayjs) {
    const start = sd || getNDayAgoDayjs(14);
    const end = ed || getTodayDayjs();
    
    const e = this._getValidRecordDTO(data);
    this._entity = e ? this._getDayDTOs(e, start, end) : [];
    this._start = start;
    this._end = end;
    this._totalCount = e ? e.length : 0;
    this._cgmLowCount = e ? e.filter(d => isWarnSummaryGluLow(d)).length : 0;
    this._cgmHighCount = e ? e.filter(d => isWarnSummaryGluHigh(d)).length : 0;
    this._pumpBlockCount = e ? e.filter(d => isWarnSummaryPumpBlock(d)).length : 0;
    this._pumpErrorCount = e ? e.filter(d => isWarnSummaryPumpError(d)).length : 0;
  }
  
  
  // 报警次数
  public get warnCountText(): string {
    return this._totalCount.toString();
  }
  
  
  // 血糖报警次数 文本
  public get gluCountText(): string {
    return Math.floor(this._cgmLowCount + this._cgmHighCount).toString();
  }
  public get gluLowSumItem(): WarnSummaryItemType {
    const l = this._cgmLowCount;
    const h = this._cgmHighCount;
    return {
      name: '低血糖',
      value: l.toString(),
      color: 'rgb(247,58,63)',
      percent: this._getPercentText(l,l + h)
    };
  }
  public get gluHighSumItem(): WarnSummaryItemType {
    const l = this._cgmLowCount;
    const h = this._cgmHighCount;
    return {
      name: '高血糖',
      value: h.toString(),
      color: 'rgb(248,168,30)',
      percent: this._getPercentText(h,l + h)
    };
  }
  
  
  // 泵报警次数
  public get pumpCountText(): string {
    return Math.floor(this._pumpBlockCount + this._pumpErrorCount).toString();
  }
  public get pumpBlockSumItem(): WarnSummaryItemType {
    const b = this._pumpBlockCount;
    const e = this._pumpErrorCount;
    return {
      name: '泵阻塞',
      value: b.toString(),
      color: 'rgb(0,252,248)',
      percent: this._getPercentText(b,b + e)
    };
  }
  public get pumpBlockSumForReportItem(): WarnSummaryItemType {
    const b = this._pumpBlockCount;
    const e = this._pumpErrorCount;
    return {
      name: '泵阻塞',
      value: b.toString(),
      color: 'rgb(20,0,203)',
      percent: this._getPercentText(b,b + e)
    };
  }
  public get pumpFaultCountItem(): WarnSummaryItemType {
    const b = this._pumpBlockCount;
    const e = this._pumpErrorCount;
    return {
      name: '运行异常',
      value: e.toString(),
      color: 'rgb(220,233,245)',
      percent: this._getPercentText(e,b + e)
    };
  }
  public get pumpFaultCountForReportItem(): WarnSummaryItemType {
    const b = this._pumpBlockCount;
    const e = this._pumpErrorCount;
    return {
      name: '运行异常',
      value: e.toString(),
      color: 'rgb(5,156,0)',
      percent: this._getPercentText(e,b + e)
    };
  }
  
  
  // 概况图
  public get config(): ECBasicOption {
    const yValues: Array<number> = [];
    
    const s1 = this._getSeries(WARN_SUMMARY_KIND.GLU_HIGH);
    const s2 = this._getSeries(WARN_SUMMARY_KIND.GLU_LOW);
    const s3 = this._getSeries(WARN_SUMMARY_KIND.PUMP_BLOCK);
    const s4 = this._getSeries(WARN_SUMMARY_KIND.PUMP_ERROR);
    s1.data.forEach(d => { yValues.push(d.value[1]); });
    s2.data.forEach(d => { yValues.push(d.value[1]); });
    s3.data.forEach(d => { yValues.push(d.value[1]); });
    s4.data.forEach(d => { yValues.push(d.value[1]); });
    
    const MAX_Y = this._getYMax(yValues);
    const MIN_Y = 0;
    const SPLIT_NUMBER = 3;
    const INTERVAL_Y =  Math.floor((MAX_Y - MIN_Y) / SPLIT_NUMBER);
    const isSmallY = MAX_Y < 100;
    
    return {
      animation: false,
      backgroundColor: 'transparent',
      grid: {
        top: 32,
        right: 40,
        bottom: 45,
        left: 75
      },
      tooltip: {
        show: yValues.length > 0,
        trigger: 'axis',
        transitionDuration: 0,
        extraCssText: 'padding: 0 !important; border: none !important',
        axisPointer: {
          type: 'line',
          lineStyle: {
            type: 'solid',
            color: CLINIC.TOOLTIP.LINE_COLOR.PC,
          }
        },
        position: function (point: Array<number>, _, dom: Element, __, size: { viewSize: Array<number> }) {
          const dw = (dom ? (dom.clientWidth || 0) : 0);
          const cw = size.viewSize[0] || 0;
          const x = point[0];
          
          let left = x;
          if (left + dw > cw) {
            // 右边没位置时，面板右边界和 x 对齐
            left = x - dw;
          }
          // top: grid[0].top
          return { left: left, top: 20 };
        },
        formatter: (params: Array<InsTooltipParams>) => {
          return this._decodeData(params);
        }
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          show: true,
          color: 'rgb(255,255,255)',
          margin: 16,
          fontSize: 14
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: false
        },
        boundaryGap: true,
        data: this._getXData(),
      },
      yAxis: {
        type: 'value',
        axisLabel: { show: false },
        min: MIN_Y,
        max: MAX_Y,
        splitNumber: SPLIT_NUMBER,
        interval: INTERVAL_Y,
        name: '次',
        nameTextStyle: {
          width: '200px',
          align: 'left',
          padding: [0,0,-22, isSmallY ? -41 : -56],
          color: 'rgb(255,255,255)',
          fontWeight: 'normal',
          fontSize: 14,
        },
        splitLine: { show: false },
      },
      series: [
        {
          ...s1,
          markLine: {
            silent: true,
            animation: false,
            label: {
              show: true,
              position: 'start',
              distance: 6,
              color: 'rgb(255,255,255)',
              fontSize: 14,
            },
            lineStyle: {
              type: 'dashed',
              width: 1,
              color: 'rgb(91,103,116)',
            },
            symbol: 'none',
            data: Array(SPLIT_NUMBER + 1).fill(0).map((_,i) => {
              return { yAxis: i === SPLIT_NUMBER ? MAX_Y : MIN_Y + i*INTERVAL_Y };
            })
          }
        },
        s2,
        s3,
        s4
      ]
    };
  }
  
  // 概况图 (报告)
  public get configForReport(): ECBasicOption {
    const yValues: Array<number> = [];
    
    const s1 = this._getSeries(WARN_SUMMARY_KIND.GLU_HIGH, true);
    const s2 = this._getSeries(WARN_SUMMARY_KIND.GLU_LOW, true);
    const s3 = this._getSeries(WARN_SUMMARY_KIND.PUMP_BLOCK, true);
    const s4 = this._getSeries(WARN_SUMMARY_KIND.PUMP_ERROR, true);
    s1.data.forEach(d => { yValues.push(d.value[1]); });
    s2.data.forEach(d => { yValues.push(d.value[1]); });
    s3.data.forEach(d => { yValues.push(d.value[1]); });
    s4.data.forEach(d => { yValues.push(d.value[1]); });
    
    const MAX_Y = this._getYMax(yValues);
    const MIN_Y = 0;
    const SPLIT_NUMBER = 3;
    const INTERVAL_Y =  Math.floor((MAX_Y - MIN_Y) / SPLIT_NUMBER);
    const isSmallY = MAX_Y < 100;
    const TEXT_COLOR = 'rgb(0,0,0)';
    
    return {
      animation: false,
      backgroundColor: 'transparent',
      grid: {
        top: 10,
        right: 15,
        bottom: 45,
        left: 55
      },
      tooltip: {
        show: false,
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          show: true,
          color: TEXT_COLOR,
          margin: 16,
          fontSize: 14
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: false
        },
        boundaryGap: true,
        data: this._getXData(),
      },
      yAxis: {
        type: 'value',
        axisLabel: { show: false },
        min: MIN_Y,
        max: MAX_Y,
        splitNumber: SPLIT_NUMBER,
        interval: INTERVAL_Y,
        name: '次',
        nameTextStyle: {
          width: '200px',
          align: 'left',
          padding: [0,0,-22, isSmallY ? -41 : -56],
          color: TEXT_COLOR,
          fontWeight: 'normal',
          fontSize: 14,
        },
        splitLine: { show: false },
      },
      series: [
        {
          ...s1,
          markLine: {
            silent: true,
            animation: false,
            label: {
              show: true,
              position: 'start',
              distance: 6,
              color: TEXT_COLOR,
              fontSize: 14,
            },
            lineStyle: {
              type: 'dashed',
              width: 1,
              color: 'rgb(100,115,128)',
            },
            symbol: 'none',
            data: Array(SPLIT_NUMBER + 1).fill(0).map((_,i) => {
              return { yAxis: i === SPLIT_NUMBER ? MAX_Y : MIN_Y + i*INTERVAL_Y };
            })
          }
        },
        s2,
        s3,
        s4
      ]
    };
  }
  
  
  // 每日详情 结构列表
  public get dayVOs(): Array<WarnSummaryDayVO> {
    return this._entity.map(dto => new WarnSummaryDayVO(dto));
  }
  public get hasDayVOs(): boolean {
    return this._entity.length > 0;
  }
  
  
  // 每日报警时段 列表 (报告)
  public get detailRow0(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(0,5);
  }
  public get detailRow1(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(5,10);
  }
  public get detailRow2(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(10,15);
  }
  public get detailRow3(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(15,20);
  }
  public get detailRow4(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(20,25);
  }
  public get detailRow5(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(25,30);
  }
  public get detailRow6(): Array<WarnSummaryDayForReportVO> {
    return this._getSlice(30,31);
  }
  public get hasRow0(): boolean {
    return this.detailRow0.length > 0;
  }
  public get hasRow1(): boolean {
    return this.detailRow1.length > 0;
  }
  public get hasRow2(): boolean {
    return this.detailRow2.length > 0;
  }
  public get hasRow3(): boolean {
    return this.detailRow3.length > 0;
  }
  public get hasRow4(): boolean {
    return this.detailRow4.length > 0;
  }
  public get hasRow5(): boolean {
    return this.detailRow5.length > 0;
  }
  public get hasRow6(): boolean {
    return this.detailRow6.length > 0;
  }
  private _getSlice(start: number, end: number): Array<WarnSummaryDayForReportVO> {
    return this._entity.slice(start,end).map(dto => new WarnSummaryDayForReportVO(dto));
  }
  
  private _getSeries(id: WARN_SUMMARY_KIND, isForReport?: boolean): InsSeries {
    const it = WARN_SUMMARY_KIND_MAP.get(id) as SelectItemVO<WarnSummaryItemChartPayloadType>;
    const p = it.payload;
    const series: InsSeries = {
      type: 'line',
      name: it.text,
      symbol: isForReport ? p.symbolForReport : p.symbol,
      symbolSize: 12,
      cursor: 'default',
      lineStyle: { color: isForReport ? p.colorForReport : p.color },
      data: [],
    };
    const isCurrentKind = (d: WarnSummaryRecordDTO) => {
      if (id === WARN_SUMMARY_KIND.GLU_LOW) {
        return isWarnSummaryGluLow(d);
      }
      if (id === WARN_SUMMARY_KIND.GLU_HIGH) {
        return isWarnSummaryGluHigh(d);
      }
      if (id === WARN_SUMMARY_KIND.PUMP_BLOCK) {
        return isWarnSummaryPumpBlock(d);
      }
      if (id === WARN_SUMMARY_KIND.PUMP_ERROR) {
        return isWarnSummaryPumpError(d);
      }
      return false;
    };
    // 图形应按日期升序排列
    const list = [...this._entity];
    list.sort((a,b) => dayjs(a.record_date).unix() - dayjs(b.record_date).unix());
    for (let i = 0, len = list.length; i < len; i++) {
      const dto = list[i];
      series.data.push(this._encodeData(i, dto.records.filter(d => isCurrentKind(d)).length, dayjs(dto.record_date).unix()));
    }
    return series;
  }
  
  private _encodeData(i: number, v: number, startServerTime: number): InsData {
    return {
      value: [i, v] as [number, number],
      payload: {
        dateMS: serverTimeToWebTime(startServerTime)
      }
    };
  }
  
  private _decodeData(params: Array<InsTooltipParams>): string {
    
    let time = '';
    let t0 = '';
    let t1 = '';
    let t2 = '';
    let t3 = '';
    
    const getText = (p: InsTooltipParams) => p.data.value[1] + '次';
    const bgColor = CLINIC.TOOLTIP.BG_COLOR.PC;
    const [p0, p1, p2, p3] = params;
    time = getYYYYMMDDFromTime(p0.data.payload.dateMS);
    t0 = getText(p0);
    t1 = getText(p1);
    t2 = getText(p2);
    t3 = getText(p3);
    
    return `
	    <div style="line-height: 32px; font-size: 18px; background-color: ${bgColor}; color: rgb(255,255,255); border-radius: 4px; padding: 12px 16px; font-weight: 400; border: none;">
				<div style="font-size: 20px;">${time}</div>
	      <div>高血糖: ${t0}</div>
	      <div>低血糖: ${t1}</div>
	      <div>泵阻塞: ${t2}</div>
	      <div>运行异常: ${t3}</div>
			</div>
	  `;
  }
  
  private _getXData(): Array<string> {
    const xData: Array<string> = [];
    let cur: Dayjs = this._start;
    
    while (cur.isBefore(this._end) || cur.isSame(this._end)) {
      xData.push(getMMDotDDFromDate(cur.toDate()));
      cur = cur.add(1, 'day');
    }
    // xData 可能选择范围很广，但服务只返回一两天的数据
    // 没有数据的情况，X刻度仍然要展示，但数据线为空。
    return xData;
  }
  
  private _getYMax(yValues: Array<number>): number {
    const DEFAULT_MAX = 30;
    if (yValues.length === 0) {
      return DEFAULT_MAX;
    }
    const max = yValues.sort((a,b) => b - a)[0];
    if (max <= DEFAULT_MAX) {
      return DEFAULT_MAX;
    }
    return nearestTen(max);
  }
  
  private _getPercentText(v: number, total: number): string {
    return getPercentTextFromDigit(roundTo(v / total,1));
  }
  
  // 只需要统计 "低血糖"、"高血糖"、"泵阻塞"、"运行异常"这四种报警
  private _getValidRecordDTO(data?: Array<WarnSummaryRecordDTO>): Array<WarnSummaryRecordDTO> | null {
    if (!data) {
      return null;
    }
    return data.filter(d => isWarnSummaryGluLow(d) || isWarnSummaryGluHigh(d) || isWarnSummaryPumpBlock(d) || isWarnSummaryPumpError(d));
  }
  
  private _getDayDTOs(data: WarnSummaryDTO, start: Dayjs, end: Dayjs): Array<WarnSummaryDayDTO> {
    const result: Array<WarnSummaryDayDTO> = [];
    // 从"最后一天"到"第一天"
    let cur = end.add(1,'d');
    while (cur.unix() > start.unix()) {
      const prev = cur.subtract(1,'d');
      const st = prev.unix();
      const et = cur.unix();
      result.push({
        record_date: prev.format('YYYY-MM-DD'),
        records: data.filter(d => {
          const time = d.record_time;
          return time >= st && time <= et;
        })
      });
      cur = prev;
    }
    return result;
  }

}
