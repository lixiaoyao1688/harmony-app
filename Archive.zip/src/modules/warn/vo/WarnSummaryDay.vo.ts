import dayjs from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {fillZero} from '@/lib/time/util/time.util';
import {ChartTableVO} from '@/modules/ins/vo/ChartTable.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {WarnSummaryTableRowVO} from '@/modules/warn/vo/WarnSummaryTableRow.vo';
import {WARN_SUMMARY_KIND, WARN_SUMMARY_KINDS_FOR_LEGEND} from '@/modules/warn/config/warn.summary.kind';
import {
  getWarnSummaryCounts,
  isWarnSummaryGluHigh,
  isWarnSummaryGluLow,
  isWarnSummaryPumpBlock,
  isWarnSummaryPumpError
} from '@/modules/warn/util/warn.summary.util';
import type {WarnSummaryDayDTO, WarnSummaryRecordDTO} from '@/modules/warn/dto/warn.summary.dto';
import type {WarnSummaryDayCount, WarnSummaryLegendType} from '@/modules/warn/types/warn.summary.type';


/**
 * 报警总结 每日详情 VO
 */
export class WarnSummaryDayVO {

  private readonly _entity: WarnSummaryDayDTO | null;
  
  constructor(e?: WarnSummaryDayDTO) {
    this._entity = e || null;
  }
  
  public get id(): number {
    if (!this._entity) {
      return INVALID_ID;
    }
    return dayjs(this._entity.record_date).unix();
  }
  
  public get dateText(): string {
    if (!this._entity) {
      return '--';
    }
    const fz = fillZero;
    const d = dayjs(this._entity.record_date);
    return `${fz(d.month()+1)}月${fz(d.date())}日`;
  }
  
  
  // 各项报警的统计数量
  public get summaryItems(): Array<SelectItemVO<WarnSummaryLegendType>> {
    return WARN_SUMMARY_KINDS_FOR_LEGEND.map(it => new SelectItemVO<WarnSummaryLegendType>({
      id: it.id,
      text: it.text,
      payload: {
        name: it.text,
        value: this._getCount(it.id),
        color: it.payload.color,
      }
    }));
  }
  private _getCount(id: WARN_SUMMARY_KIND): number {
    if (!this._entity) {
      return 0;
    }

    let fn = (d: WarnSummaryRecordDTO) => false;
    if (id === WARN_SUMMARY_KIND.GLU_LOW) {
      fn = isWarnSummaryGluLow;
    }
    else if (id === WARN_SUMMARY_KIND.GLU_HIGH) {
      fn = isWarnSummaryGluHigh;
    }
    else if (id === WARN_SUMMARY_KIND.PUMP_BLOCK) {
      fn = isWarnSummaryPumpBlock;
    }
    else if (id === WARN_SUMMARY_KIND.PUMP_ERROR) {
      fn = isWarnSummaryPumpError;
    }
    
    return this._entity.records.filter(d => fn(d)).length;
  }
  
  
  // 报警图
  public get counts(): WarnSummaryDayCount {
    // height: 149px - 49px(给顶部数量留的高度)
    return getWarnSummaryCounts(this._entity, 100);
    // // 每3小时统计1段，1天共8段;
    // const HOURS = 3;
    // const COUNT = 8;
    // const result = Array(COUNT).fill(0).map(() => ([
    //   { name: '高血糖', value: 0, color: 'rgb(248,168,30)', height: '0', colorForReport: 'rgb(0,0,0)' },
    //   { name: '低血糖', value: 0, color: 'rgb(247,58,63)', height: '0', colorForReport: 'rgb(0,0,0)' },
    //   { name: '泵阻塞', value: 0, color: 'rgb(0,252,248)', height: '0', colorForReport: 'rgb(0,0,0)' },
    //   { name: '运行异常', value: 0, color: 'rgb(220,233,245)', height: '0', colorForReport: 'rgb(0,0,0)' },
    // ])) as WarnSummaryDayCount;
    //
    // if (!this._entity) {
    //   return result;
    // }
    //
    // const start = timeZeroing(dayjs(this._entity.record_date));
    // const height = 100; // 149px - 49px(给顶部数量留的高度)
    // const records = this._entity.records;
    //
    // let cur = start;
    //
    // for (let i = 0; i < COUNT; i++) {
    //   const s = cur.unix();
    //   const e = cur.add(HOURS, 'h').unix();
    //
    //   const currentRecords = records.filter(d => d.record_time >= s && d.record_time <= e);
    //   const cgmHigh = currentRecords.filter(d => isWarnSummaryGluHigh(d)).length;
    //   const cgmLow = currentRecords.filter(d => isWarnSummaryGluLow(d)).length;
    //   const pumpBlock = currentRecords.filter(d => isWarnSummaryPumpBlock(d)).length;
    //   const pumpError = currentRecords.filter(d => isWarnSummaryPumpError(d)).length;
    //
    //   const cgmHighHeight = roundTo(cgmHigh / (cgmHigh+cgmLow), 2) * height + 'px';
    //   const cgmLowHeight = roundTo(cgmLow / (cgmHigh+cgmLow), 2) * height + 'px';
    //   const pumpBlockHeight = roundTo(pumpBlock / (pumpBlock+pumpError), 2) * height + 'px';
    //   const pumpErrorHeight = roundTo(pumpError / (pumpBlock+pumpError), 2) * height + 'px';
    //
    //   result[i] = [
    //     { name: '高血糖', value: cgmHigh, color: 'rgb(248,168,30)', height: cgmHighHeight, colorForReport: 'rgb(0,0,0)' },
    //     { name: '低血糖',  value: cgmLow, color: 'rgb(247,58,63)', height: cgmLowHeight, colorForReport: 'rgb(0,0,0)' },
    //     { name: '泵阻塞',  value: pumpBlock, color: 'rgb(0,252,248)', height: pumpBlockHeight, colorForReport: 'rgb(0,0,0)' },
    //     { name: '运行异常', value: pumpError, color: 'rgb(220,233,245)', height: pumpErrorHeight, colorForReport: 'rgb(0,0,0)' },
    //   ];
    //
    //   cur = cur.add(HOURS,'h');
    // }
    //
    // return result;
  }
  
  // 详情表
  public get table(): ChartTableVO<WarnSummaryTableRowVO> {
    if (!this._entity) {
      return new ChartTableVO([], []);
    }
    return new ChartTableVO<WarnSummaryTableRowVO>(
      [
        { id: 1, key: 'timeText', text: '时间', width: '33%' },
        { id: 2, key: 'kindText', text: '报警', width: '33%' },
        { id: 3, key: 'detailText', text: '详情', width: '33%' },
      ],
      this.tableRows
    );
  }
  public get tableRows(): Array<WarnSummaryTableRowVO> {
    if (!this._entity) {
      return [];
    }
    return this._entity.records.map(dto => new WarnSummaryTableRowVO(dto));
  }

}
