import dayjs from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {fillZero} from '@/lib/time/util/time.util';
import {getWarnSummaryCounts} from '@/modules/warn/util/warn.summary.util';
import type {WarnSummaryDayDTO} from '@/modules/warn/dto/warn.summary.dto';
import type {WarnSummaryDayCount} from '@/modules/warn/types/warn.summary.type';


/**
 * 每日报警时段 VO
 *
 * 归属VO
 * 报警总结
 *
 * 适用功能
 * 报告
 */
export class WarnSummaryDayForReportVO {
  
  private readonly _entity: WarnSummaryDayDTO | null;
  
  constructor(e?: WarnSummaryDayDTO) {
    this._entity = e || null;
  }
  
  // 唯一标识
  public get id(): number {
    if (!this._entity) {
      return INVALID_ID;
    }
    return dayjs(this._entity.record_date).unix();
  }
  
  // 日期，YY/MM
  public get dateText(): string {
    if (!this._entity) {
      return '--';
    }
    const fz = fillZero;
    const d = dayjs(this._entity.record_date);
    return `${fz(d.month()+1)}/${fz(d.date())}`;
  }
  
  // 报警情况列表 (每3小时统计1次)
  public get counts(): WarnSummaryDayCount {
    return getWarnSummaryCounts(this._entity, 30);
    // return [
    //   [
    //     { name: '高血糖', value: 15, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '15px' },
    //     { name: '低血糖', value: 15, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '15px' },
    //     { name: '泵阻塞', value: 10, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '10px' },
    //     { name: '运行异常', value: 10, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '10px' },
    //   ],
    //   [
    //     { name: '高血糖', value: 15, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    //   [
    //     { name: '高血糖', value: 0, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 10, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '10px' },
    //     { name: '运行异常', value: 10, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '10px' },
    //   ],
    //   [
    //     { name: '高血糖', value: 15, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '15px' },
    //     { name: '低血糖', value: 15, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '15px' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    //   [
    //     { name: '高血糖', value: 0, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    //   [
    //     { name: '高血糖', value: 0, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    //   [
    //     { name: '高血糖', value: 0, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    //   [
    //     { name: '高血糖', value: 0, colorForReport: 'rgb(248,168,30)', color: 'rgb(248,168,30)', height: '0' },
    //     { name: '低血糖', value: 0, colorForReport: 'rgb(247,58,63)', color: 'rgb(247,58,63)', height: '0' },
    //     { name: '泵阻塞', value: 0, colorForReport: 'rgb(20,0,203)', color: 'rgb(0,252,248)', height: '0' },
    //     { name: '运行异常', value: 0, colorForReport: 'rgb(5,156,0)', color: 'rgb(220,233,245)', height: '0' },
    //   ],
    // ];
  }
  
}
