import {Dayjs} from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {getNDayAgoDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import type {WarnSummaryGetDTO} from '@/modules/warn/dto/warn.summary.dto';


export class WarnSummaryFilterVO {

  private _admissionId: number;
  private _startDay: Dayjs;
  private _endDay: Dayjs;
  
  public static MAX_RANGE = 14;

  constructor() {
    this._admissionId = INVALID_ID;
    this._startDay = getNDayAgoDayjs(14);
    this._endDay = getTodayDayjs();
  }

  public get dto(): WarnSummaryGetDTO {
    return {
      admission_id: this._admissionId,
      start_date: this._startDay.format('YYYY-MM-DD'),
      end_date: this._endDay.format('YYYY-MM-DD'),
    };
  }

  public get admissionId(): number {
    return this._admissionId;
  }
  public set admissionId(data) {
    this._admissionId = data;
  }
  
  public get range(): [Dayjs, Dayjs] {
    return [this._startDay, this._endDay];
  }
  public set range(data) {
    this._startDay = data[0];
    this._endDay = data[1];
  }
  
  public get startDay(): Dayjs {
    return this._startDay;
  }
  public set startDay(data) {
    this._startDay = data;
  }
  
  public get endDay(): Dayjs {
    return this._endDay;
  }
  public set endDay(data) {
    this._endDay = data;
  }
  
}
