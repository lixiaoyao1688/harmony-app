import { TabVO } from '@/lib/aaruy-design/tab/Tab.vo';
import { createRouter, createWebHashHistory } from 'vue-router';
import {
  ABOUT_ICON,
  ANALYSIS_ICON,
  HISTORY_ICON,
  IN_PATIENT_ICON, SYSTEM_CONFIG_ICON,
  SYSTEM_ICON,
  SYSTEM_LOG_OP_ICON,
} from '@/lib/icon/menu.icon';
import { useWsStore } from '@/lib/ws/store/ws.store';
import { useCardStore } from '@/modules/admission/store/card.store';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import HomeView from '@/layout/HomeView.vue';
import type { RouteComponent } from 'vue-router';


export const ROUTE_HOME = 'home';   // 主页
export const ROUTE_LOGIN = 'login';  // 登录页
export const ROUTE_IN_PATIENT = 'in_patient';  // PC端:院泵患者，移动端:院泵患者（住院）
export const ROUTE_IN_PATIENT_OUT = 'in_patient_out';  // 仅移动端:院泵患者（门诊）
export const ROUTE_OUT_PATIENT = 'out_patient';  // 仅PC端:签约患者
export const ROUTE_OUT_PATIENT_FOR_MOBILE = 'out_patient_for_mobile';  // 仅移动端:签约患者
export const ROUTE_HISTORY = 'history';  // 仅PC端:历史患者
export const ROUTE_DEVICE = 'device';  // 仅PC端:设备管理
export const ROUTE_ANALYZE = 'analyze';  // 仅PC端:统计分析
export const ROUTE_SYSTEM = 'system';  // 仅PC端:系统管理
// 注意: 下面这些 path 在 router.routes 中无对应路由组件，不可用于 router.push 方法。
export const ROUTE_SYSTEM_STAFF = ROUTE_SYSTEM + '_staff';  // 系统管理 - 用户管理
export const ROUTE_SYSTEM_ROLE = ROUTE_SYSTEM + '_role';  // 系统管理 - 角色管理
export const ROUTE_SYSTEM_LOG_LOGIN = ROUTE_SYSTEM + '_log_login';  // 系统管理 - 登录日志
export const ROUTE_SYSTEM_LOG_OP = ROUTE_SYSTEM + '_log_op';  // 系统管理 - 操作日志
export const ROUTE_SYSTEM_CONFIG_FOR_MOBILE = 'system_config';  // 系统设置
export const ROUTE_ABOUT_FOR_MOBILE = 'about';  // 关于


export const TAB_IN_PATIENT = new TabVO(ROUTE_IN_PATIENT, '院泵患者', IN_PATIENT_ICON);  // 仅PC端
export const TAB_IN_PATIENT_IN = new TabVO(ROUTE_IN_PATIENT, '院泵患者（住院）', IN_PATIENT_ICON);  // 仅移动端
export const TAB_IN_PATIENT_OUT = new TabVO(ROUTE_IN_PATIENT_OUT, '院泵患者（门诊）', IN_PATIENT_ICON);  // 仅移动端
export const TAB_OUT_PATIENT = new TabVO(ROUTE_OUT_PATIENT, '签约患者', IN_PATIENT_ICON);  // 仅PC端
export const TAB_OUT_PATIENT_FOR_MOBILE = new TabVO(ROUTE_OUT_PATIENT_FOR_MOBILE, '签约患者', IN_PATIENT_ICON);  // 仅移动端
export const TAB_HISTORY = new TabVO(ROUTE_HISTORY, '历史患者', HISTORY_ICON);
export const TAB_DEVICE = new TabVO(ROUTE_DEVICE, '设备管理', SYSTEM_LOG_OP_ICON);
export const TAB_ANALYZE = new TabVO(ROUTE_ANALYZE, '统计分析', ANALYSIS_ICON);
export const TAB_SYSTEM = new TabVO(ROUTE_SYSTEM, '系统管理', SYSTEM_ICON);

export const TAB_SYSTEM_CONFIG_FOR_MOBILE = new TabVO(ROUTE_SYSTEM_CONFIG_FOR_MOBILE, '系统设置', SYSTEM_CONFIG_ICON);
export const TAB_ABOUT_FOR_MOBILE = new TabVO(ROUTE_ABOUT_FOR_MOBILE, '关于', ABOUT_ICON);


export const ROUTE_MAP = new Map([
  [ROUTE_IN_PATIENT, '院泵患者'],
  [ROUTE_OUT_PATIENT, '签约患者'],
  [ROUTE_HISTORY, '历史患者'],
  [ROUTE_DEVICE, '设备管理'],
  [ROUTE_SYSTEM, '系统管理'],
  [ROUTE_ANALYZE, '统计分析'],
]);

export const ROUTE_TAB_MAP_ON_MOBILE = new Map<string, TabVO>([
  [ROUTE_IN_PATIENT, TAB_IN_PATIENT_IN],
  [ROUTE_IN_PATIENT_OUT, TAB_IN_PATIENT_OUT],
  [ROUTE_OUT_PATIENT_FOR_MOBILE, TAB_OUT_PATIENT_FOR_MOBILE],
]);


/**
 * 路由定义（仅PC端）
*/
const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes: [
    
    // 主页
    {
      path: '/',
      name: ROUTE_HOME,
      component: HomeView as unknown as RouteComponent,
      children: [
        {
          path: ROUTE_IN_PATIENT,
          name: ROUTE_IN_PATIENT,
          component: () => import('@/modules/admission/views/InPatientView.vue')
        },
        {
          path: ROUTE_IN_PATIENT_OUT,
          name: ROUTE_IN_PATIENT_OUT,
          component: () => import('@/modules/admission/views/InPatientView.vue')
        },
        {
          path: ROUTE_OUT_PATIENT_FOR_MOBILE,
          name: ROUTE_OUT_PATIENT_FOR_MOBILE,
          component: () => import('@/modules/admission/views/InPatientView.vue')
        },
        {
          path: ROUTE_OUT_PATIENT,
          name: ROUTE_OUT_PATIENT,
          component: () => import('@/modules/admission/views/OutPatientView.vue')
        },
        {
          path: ROUTE_HISTORY,
          name: ROUTE_HISTORY,
          component: () => import('@/modules/history/views/HistoryView.vue')
        },
        {
          path: ROUTE_DEVICE,
          name: ROUTE_DEVICE,
          // component: () => import('@/modules/device/views/DeviceView.vue')
          component: () => import('@/modules/device2/views/Device2View.vue')
        },
        {
          path: ROUTE_ANALYZE,
          name: ROUTE_ANALYZE,
          component: () => import('@/modules/analyze-2/AnalyzeView2.vue')
        },
        {
          path: ROUTE_SYSTEM,
          name: ROUTE_SYSTEM,
          component: () => import('@/modules/staff/SystemManager.vue')
        },
      ]
    },

    // 登录页
    {
      path: '/' + ROUTE_LOGIN,
      name: ROUTE_LOGIN,
      component: () => import('@/modules/user/views/LoginView.vue')
    },
	
  ]
});

router.beforeEach((to, from, next) => {
  
  const store = useCardStore();
  const wsStore = useWsStore();
  const screenStore = useScreenStore();
  
  if (from.name === ROUTE_IN_PATIENT) {
    if (to.name === ROUTE_LOGIN) {
      // 修复 token 过期时返回登录页的多次退订问题
      next();
      return;
    }
    
    if (screenStore.isPC) {
      // PC端，院泵跳转其他菜单时，退订 update all/update one;
      if (wsStore.socket) {
        store.unsubscribe('leave route: in-patient');
      }
    } else {
      // 移动端，主界面永远需要实时数据，所以不退订。
    }
  }
  
  next();
});

export default router;
