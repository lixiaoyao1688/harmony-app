function clickMask(className: string) {
  const els = document.getElementsByClassName(className);
  if (els && els.length) {
    Array.prototype.forEach.call(els as any, function(el) {
      if (el && el.style.display !== 'none') {
        el.click();
      }
    });
  }
}

export function closeDrawer() {
  clickMask('ant-drawer-mask');
}

export function closeModal() {
  clickMask('ant-modal-wrap');
}
