export function isGlobalPasswordValid(v: string): boolean {
  return /^[A-Za-z0-9!@#$%^&*]+$/.test(v);
}

export function isGlobalPhoneEnablePrefixValid(v: string): boolean {
  return isGlobalPhoneValid(v, true);
}

export function isGlobalPhoneValid(v: string, enablePrefix?: boolean): boolean {
  if (enablePrefix) {
    return /^(?:\+86)?1[3456789]\d{9}$/.test(v);
  }
  return /^1[3456789]\d{9}$/.test(v);
}

export function isGlobalEmailValid(v: string): boolean {
  return /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(v);
}

// 大陆身份证号
export function isGlobalIdCardValid(v: string): boolean {
  // ^: 开始位置
  // (\d{6}): 匹配6位数字，前6位地区代码  440582
  // (19|20)?: 匹配19或20，年份前2位  19
  // (\d{2}): 匹配2位数字，年份后2位  97
  // (0[1-9]|1[0-2]): 匹配01-09或10-12，月份  09
  // (0[1-9]|[12]\d|3[01]): 表示匹配01-09, 10-29, 30-31, 日期  21
  // (\d{3}): 匹配3位数字，顺序码  451
  // (\d|X|x)?: 匹配1位数字，或字母X，或字母x，校验码 4
  // $: 结束位置
  return /^(\d{6})(19|20)?(\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(\d{3})(\d|X|x)?$/.test(v);
}

export function isGlobalHeightValid(v: string): boolean {
  return /^\d{1,3}$/.test(v);
}

export function isGlobalWeightValid(v: string): boolean {
  return /^\d{1,5}(\.\d)?$/.test(v);
}

// 床号
export function isGlobalBedValid(v: string): boolean {
  return /^[A-Za-z0-9-]+$/.test(v);
}


/**
 * 检查一个字符串在字面上是否是有效数字
 */
export function isValidNumber(str: string): boolean {
  const numStr = str.trim();
  // 正则说明：
  // ^-?            可选的负号
  // \d+            至少一位数字
  // (\.\d+)?       可选的小数部分
  // $              结束
  const regex = /^-?\d+(\.\d+)?$/;
  return regex.test(numStr);
}

/**
 * 检查一个数字字符串是否不超过 digit 位小数
 */
export function isNumStrDigitLimit(numStr: string, digit: number): boolean {
  if (digit < 0) {
    return true;
  }
  
  const trimmed = numStr.trim();
  const match = trimmed.match(/^(-?\d+)(\.\d+)?$/);  // 正则匹配整数和小数部分
  
  if (!match) {
    return false;
  }
  const decimalPartMatch = match[2]; // 第二组是小数部分
  if (!decimalPartMatch) {
    return true; // 没有小数点
  }
  
  const decimalDigits = decimalPartMatch.slice(1); // 去掉小数点本身
  return decimalDigits.length <= digit;
}

/**
 * 检查一个值是否是数字
 */
export function isNumber(data: unknown): boolean {
  return typeof data === 'number' && !isNaN(data);
}

/**
 * 检查一个值是否是整数
 */
export function isInteger(data: unknown): boolean {
  return Number.isInteger(data);
}

/**
 * 检查一个值是否最多有 digit 位小数
 */
export function isDigitLimit(data: number, digit: number): boolean {
  // 确保是有效的数字
  if (!Number.isFinite(data)) {
    return false;
  }
  const time = Math.floor(Math.pow(10, digit));
  const roundedValue = Math.round(data * time) / time;
  return isEqual(roundedValue, data);
}

/**
 * 在 JS 的误差范围内，检查两个数值是否相等
 */
export function isEqual(a: number, b: number) {
  return Math.abs(a - b) < Number.EPSILON;
}


export function isIPv4(ip: string): boolean {
  const ipv4Pattern = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return ipv4Pattern.test(ip);
}

export function isIPv6(ip: string): boolean {
  const ipv6Pattern = /^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$/;
  return ipv6Pattern.test(ip);
}
