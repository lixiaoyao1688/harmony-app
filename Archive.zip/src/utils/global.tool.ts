import {useBoardStore} from '@/modules/board/store/board.store';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useStorageStore} from '@/lib/storage/store/storage.store';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import {sendErrorToServer} from '@/lib/log/util/log.util';
import {ZERO} from '@/lib/math/config/math.config';
import router, {ROUTE_LOGIN} from '@/routers/global.router';
import {useWsStore} from '@/lib/ws/store/ws.store';
import {useDeviceStore} from '@/modules/device/store/device.store';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {isWebHttpUsing} from '@/lib/env/utils/env.domain.util';
import {GLOBAL_YES_OR_NO} from '@/dto/global.dto';
import {useUserStore} from '@/modules/user/store/user.store';
import {useOutPatientStore} from '@/modules/admission/store/out.patient.store';
import {useAnalyze2Store} from '@/modules/analyze-2/store/analyze2.store';


/**
 * 退出登录，并处理的退登后的工作。
*/
export function doWorkAfterLogout(): void {
  router.replace({ name: ROUTE_LOGIN })
    .then(() => {
      setTimeout(() => {
        useAdmissionStore().clear();
        useCardStore().clear();
        useBoardStore().clear();
        useDeviceStore().clear();
        useAnalyze2Store().clear();
        useWsStore().disconnect();
        useUserStore().clear();
        if (isWebHttpUsing()) {
          useStorageStore().clear();
          useOutPatientStore().clear();
        } else {
          useStorageStore().clearMobile();
        }
      }, 500);
    })
    .catch(reason => {
      sendErrorToServer('[doWorkAfterLogout]', reason, '', 'global.tool.ts');
    });
}

/**
 * 深拷贝
 */
export function deepClone<T>(obj: any, hash = new WeakMap()): T {
  if (hash.has(obj)) {
    return hash.get(obj);
  }
  
  if (obj === null || obj === undefined) {
    return obj;
  }
  
  const type = [Date, RegExp, Set, Map, WeakMap, WeakSet];
  if (type.includes(obj.constructor)) {
    return new obj.constructor(obj);
  }
  
  const cloneObj = Object.create(Object.getPrototypeOf(obj));
  
  hash.set(obj, cloneObj);
  
  for (const key of Reflect.ownKeys(obj)) {
    const value = obj[key];
    const desc = Object.getOwnPropertyDescriptor(obj, key);
    
    Object.defineProperty(cloneObj, key, {
      ...desc,
      value: isComplexDataType(value) ? deepClone(value, hash) : value,
    });
  }
  
  return cloneObj;
}

function isComplexDataType(obj: any) {
  return typeof obj === 'object' && obj !== null;
}

/**
 * 返回一个经过防抖处理的函数
 * @param fn 模板函数
 * @param time 防抖时间
 * @param immediate 是否立即执行一次
 */
export function debounce(fn: Function, time: number, immediate?: boolean): Function {
  let timer: NodeJS.Timeout | null = null;
	
  return function(...args: any) {
    
    if (immediate) {
      // eslint-disable-next-line prefer-spread
      fn.apply(null, args);
      immediate = false;
      return;
    }
		
    if (timer !== null) {
      clearTimeout(timer);
    }
		
    timer = setTimeout(() => {
      // eslint-disable-next-line prefer-spread
      fn.apply(null, args);
      timer = null;
    }, time);
  };
}

export function getJSON(jsonFormatText: string): Object {
  if (jsonFormatText) {
    return JSON.parse(jsonFormatText);
  }
  return {};
}

export function isObjectNull(o: Object): boolean {
  return Object.keys(o).length === ZERO;
}

export function isUndefined(data: unknown): boolean {
  return data === (void 0);
}

export function isEntityEmpty(e: Object | null | undefined): boolean {
  return !e || isObjectNull(e);
}

/**
 * 获取数组的最大元素
 * @param arr 数组
 */
export function getMaxInArray(arr: Array<number>): number {
  return arr.reduce((a,b) => Math.max(a, b), -Infinity);
}

/**
 * 获取数组的最小元素
 * @param arr 数组
 */
export function getMixInArray(arr: Array<number>): number {
  return arr.reduce((a,b) => Math.min(a, b), Infinity);
}

/**
 * 从 items 返回 Map
 */
export function getMapFromItems(items: Array<SelectorFormItemVO>): Map<number, SelectorFormItemVO> {
  return new Map(items.map(it => ([it.id, it])));
}


/**
 * 字符串中是否包含图片后缀
 */
export function isIncludeImage(data: string): boolean {
  return /png|jpe?g|gif|bmp|tiff|webp/i.test(data);
}


/**
 * 以某个字段为基准，过滤掉数组的重复项，返回新数组。
 * @param arr 原始数组
 * @param field 有重复数据的字段
 * @param index field 对应值是一个数组时启用，指定数组的索引
 * @param keepLast 保留重复的最后一项，否则保留第一项
 */
export function removeDuplicatesByField<T>(arr: Array<T>, field: string, index?: number, keepLast?: boolean): Array<T> {
  const seen = {};
  const uniqueArray: Array<T> = [];
  const doWork = (it: T) => {
    let k = it[field];
    if (typeof index === 'number') {
      k = k[index];
    }
    if (!seen[k]) {
      seen[k] = true;
      uniqueArray.push(it);
    }
  };
  
  if (keepLast) {
    for (let i = arr.length - 1; i >= 0; i--) {
      doWork(arr[i]);
    }
  }
  else {
    for (let i = 0, len = arr.length; i < len; i++) {
      doWork(arr[i]);
    }
  }
  return uniqueArray;
}

export function getGlobalStatusText(data: GLOBAL_YES_OR_NO): string {
  return data === GLOBAL_YES_OR_NO.YES ? '开启' : '关闭';
}
