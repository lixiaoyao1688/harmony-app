export const INVALID_ID = -1;
export const EMPTY_ID = 0;
export const INVALID_VALUE = -1;
export const EMPTY_VALUE = 0;
export const TOTAL_ID = -2;
export const INVALID_KEY = '';
