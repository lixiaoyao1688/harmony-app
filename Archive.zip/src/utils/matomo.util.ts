import VueMatomo from 'vue-matomo';
import router from '@/routers/global.router';
import { app } from '@/main';
import {isOnline, isOnlineTest} from '@/lib/env/utils/env.domain.util';


const MATOMO_HOST = 'https://ns.aaruy.com/';

let initialized = false;

export function initMatomo(userId?: string) {
  if (!isOnline()) {
    return;
  }
  if (isOnlineTest()) {
    // 测试服不启用 by zym 2026-03-25 11:02
    return;
  }
  if (initialized) {
    if (userId) {
      // @ts-ignore
      window._paq.push(['setUserId', userId]);
      // @ts-ignore
      window._paq.push(['trackPageView']);
    }
    return;
  }
  initialized = true;

  app.use(VueMatomo, {
    host: MATOMO_HOST,
    siteId: 1,
    router: router,
    userId: userId,
  });

  // @ts-ignore
  window._paq.push(['trackPageView']);
}
