# 闭环app鸿蒙版 V1.0.0.1

## 兼容性
要求兼容 HarmonyOS 6.0.0(20) 以上的版本，使用API时需留意。

#### 项目配置
https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/ide-hvigor-build-profile-app#section45865492619

#### 兼容性开发指导
https://developer.huawei.com/consumer/cn/doc/harmonyos-releases/app-compatibility-scenarios

#### 所有版本
https://developer.huawei.com/consumer/cn/doc/harmonyos-releases/overview-allversion

### 接口文档
https://192.168.1.249:85/project/110/interface/api

## 提交规范
### 基本格式
`<type>(<scope>): <subject>`
#### 提交类型 (type)
| 类型     | 说明                                    | 示例                                               |
| -------- | --------------------------------------- |--------------------------------------------------|
| feat     | 新功能                                  | feat(pump): 泵信息展示                                |
| fix      | 修复缺陷                                | fix: http://192.168.1.236:81/redmine/issues/5962 |
| docs     | 文档更新                                | docs(readme): 更新 app 编译说明                        |
| style    | 代码样式调整（不影响逻辑）              | style: 调整代码缩进格式                                  |
| refactor | 重构代码（既不是新功能也不是 bug 修复） | refactor: 重构蓝牙模块                                 |
| perf     | 性能优化                                | perf: 优化图片懒加载逻辑                                  |
| test     | 测试相关                                | test: 添加用户服务单元测试                                 |
| build    | 构建系统或外部依赖更改                  | build: 更新 webpack 配置                             |
| ci       | CI/CD 配置更改                          | ci: 添加 GitHub Actions 工作流                        |
| chore    | 其他杂项（不修改源码或测试）            | chore: 更新依赖包版本                                   |
| revert   | 回滚提交                                | revert: 回滚某次提交的更改                                |

#### 作用域 (scope)
表示影响范围，通常写模块名称，如:pump。

#### 主题 (subject)
简要描述本次提交的内容，末尾不加句号，长度建议 50 个字符以内。

## 配置调试签名
真机调试前需要手动配置签名，参考:
https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/ide-signing#section297715173233
