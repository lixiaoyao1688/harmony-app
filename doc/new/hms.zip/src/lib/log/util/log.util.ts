import dayjs from 'dayjs';
import { httpLogAdd } from '@/lib/log/request/log.http';
import { LOG_ADD_KIND, LOG_COLOR } from '@/lib/log/dto/log.dto';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { isOnlineServer } from '@/lib/env/utils/env.domain.util';


export function printSingle(content: string, color: string, isMobile?: boolean) {
  if (isOnlineServer()) {
    // 项目发布后，屏蔽浏览器日志
    return;
  }
  const timeText = dayjs().format('YYYY-MM-DD HH:mm:ss:SSS');
  const contentText = timeText + ' ' + content;
  if (isMobile) {
    console.log(`%c ${contentText}`, `color: ${color}`);
  } else {
    console.log(`%c${contentText}`, `color: ${color}`);
  }
}

export function printGroup(title: string, data: unknown, color: string, isMobile?: boolean) {
  if (isOnlineServer()) {
    // 项目发布后屏蔽日志
    return;
  }
  const timeText = dayjs().format('YYYY-MM-DD HH:mm:ss:SSS');
  const titleText = timeText + ' ' + title;
  if (isMobile) {
    console.group(titleText);
    console.log(data);
    console.groupEnd();
  } else {
    console.group(`%c${titleText}`, `color: ${color}`);
    console.log(data);
    console.groupEnd();
  }
}

export function printApp(title: string, data: unknown): void {
  printGroup(title, data, LOG_COLOR.NORMAL, true);
}

export function printError(title: string, content: unknown, isMobile?: boolean) {
  printGroup(title, content, LOG_COLOR.ERROR, isMobile);
}

export function printSingleError(content: string): void  {
  printSingle(content, LOG_COLOR.ERROR, useScreenStore().isMobile);
}

export function sendErrorToServer(title: string, msg: string, lfc: string, fn: string) {
  printGroup(title, { msg, lfc, fn }, LOG_COLOR.ERROR);
	
  httpLogAdd({ kind_id: LOG_ADD_KIND.INSULIN, content: '[' + title + '] ' + msg, lifecycle: lfc, filename: fn })
    .then(_ => {})
    .catch(reason => printError('[ERROR LOG ADD]', reason));
}
