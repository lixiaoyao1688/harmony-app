import dayjs from 'dayjs';
import {LOG_COLOR} from '@/lib/log/dto/log.dto';
import {printGroup} from '@/lib/log/util/log.util';
import {randomInEnum, randomInList} from '@/lib/math/util/math.util';
import {HISTORY_KIND} from '@/modules/record/config/history.config';
import {CGM_WARN} from '@/modules/cgm/config/cgm.warn';
import {isWarnSummaryPump} from '@/modules/warn/util/warn.summary.util';
import {PUMP_WARN} from '@/modules/pump/config/pump.warn';
import type {WarnSummaryDTO, WarnSummaryGetDTO} from '@/modules/warn/dto/warn.summary.dto';


export const WARN_SUMMARY_MOCKING = false;

export function MOCK_warn_summary(body: WarnSummaryGetDTO): WarnSummaryDTO {
  const re = randomInEnum;
  const rl = randomInList;

  const start = dayjs(body.start_date);
  const end = dayjs(body.end_date).add(1,'day');
  
  const DAY_COUNT = end.diff(start, 'd');  // 天数
  const RECORD_COUNT_PER_DAY = 48;  // 每天的记录数
  const data: WarnSummaryDTO = [];
  
  let cur = start;
  for (let i = 0, len = RECORD_COUNT_PER_DAY * DAY_COUNT; i < len; i++) {
    const kind = re(HISTORY_KIND.ALARM,HISTORY_KIND.CGM_WARN);
    data.push({
      id: i+1,
      record_time: cur.unix(),
      kind: kind,
      // value: isWarnSummaryPump(kind) ? re(PUMP_WARN.BLOCK,PUMP_WARN.LOW_DOSE,PUMP_WARN.NO_DOSE) : re(CGM_WARN.HIGH_PROBE,CGM_WARN.LOW_PROBE),
      value: 0,
      text: ''
    });
    cur = cur.add(0.5,'h');
  }
  
  printGroup('[MOCK_warn_summary]', data, LOG_COLOR.WARN_HARD);
  
  return data;
}
