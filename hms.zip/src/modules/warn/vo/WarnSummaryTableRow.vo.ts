import dayjs from 'dayjs';
import {INVALID_ID} from '@/utils/global.vo.help';
import {HISTORY_KIND} from '@/modules/record/config/history.config';
import type {WarnSummaryRecordDTO} from '@/modules/warn/dto/warn.summary.dto';


/**
 *  报警总结 每日详情表 行 VO
 */
export class WarnSummaryTableRowVO {
  
  private readonly _entity: WarnSummaryRecordDTO | null;
  
  constructor(e?: WarnSummaryRecordDTO) {
    this._entity = e || null;
  }
  
  // 唯一标识
  public get id(): number {
    if (!this._entity) {
      return INVALID_ID;
    }
    return this._entity.record_time;
  }
  
  // 时间，如 03:00:00
  public get timeText(): string {
    if (!this._entity) {
      return '--';
    }
    return dayjs.unix(this._entity.record_time).format('HH:mm:ss');
  }
  
  // 报警(标题)和详情 与历史记录保持一致 by 梁美玲 2026-01-29 17:33:57 至 梁美玲 2026-01-29 17:33:57
  
  // 报警 文本
  public get kindText(): string {
    if (!this._entity) {
      return '--';
    }
    return this._entity.text || '--';
    // const kind = this._entity.kind;
    // const subKind = this._entity.value;
    //
    // if (isWarnSummaryCGM(kind)) {
    //   return subKind === CGM_WARN.LOW_PROBE ? '低血糖' : (subKind === CGM_WARN.HIGH_PROBE ? '高血糖' : '--');
    // }
    // else if (isWarnSummaryPump(kind)) {
    //   return subKind === PUMP_WARN.BLOCK ? '泵阻塞' : '运行异常';
    // }
    // return '--';
  }
  
  // 详情 文本（CGM报警无血糖值详情，所以仅泵报警有效）
  // 参考: src\modules\record\vo\Record.vo.ts: _getValueText(data === HISTORY_KIND.ALARM)
  public get detailText(): string {
    if (!this._entity) {
      return '--';
    }
    const e = this._entity;
    if (e.kind === HISTORY_KIND.ALARM && e.text.includes('药量')) {
      return `剩余${e.value}U`;
    }
    return '--';
    // const kind = this._entity.kind;
    // const subKind = this._entity.value;
    // if (isWarnSummaryPump(kind)) {
    //   return PUMP_WARN_MAP.get(subKind as PUMP_WARN) || '--';
    // }
    // else if (isWarnSummaryCGM(kind)) {
    //   return '--';
    // }
    // return '--';
  }
  
}
