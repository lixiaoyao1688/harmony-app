export const PROJECT_NAME = '胰岛素泵数据管理系统软件';
export const PROJECT_VERSION = 'V1.1.0.01';  // 见《产品技术要求》1.4 软件版本命名规则
export const SUB_VERSION = '.074';  // 子版本号 见 V1.1.0.01.075+
// 打包后，hospital.html 的 "/static"
// 替换为 "https://static-test.aaruy.com/static"