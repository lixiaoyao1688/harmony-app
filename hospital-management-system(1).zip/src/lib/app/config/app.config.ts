const isAppCoding = false;
// const isAppCoding = true;

/**
 * 是否编译成 APP
 */
export const IS_APP = isAppCoding;


/**
 * APP 软件型号
 */
export const APP_CODE_AN = 'PMS-X00AN';
export const APP_CODE_IOS = 'PMS-X00IOS';
export const APP_CODE = APP_CODE_AN;
// export const APP_CODE = APP_CODE_IOS;


/**
 * 公网版服务地址
 */
export const OUT_APP_SERVER_DOMAIN = 'https://test.aaruy.com';  // 测试服
// export const OUT_APP_SERVER_DOMAIN = 'https://server.aaruy.com';  // 正式服


/**
 * 是否将 APP 的 HTTP 交互方式转为 WEB 方式
 */
export const IS_APP_HTTP_USE_WEB = isAppCoding;


/**
 * 是否打开 APP 的开发者工具
 */
export const IS_APP_DEV_TOOL_ENABLED = false;
