import { FORMATTED_PERCENT_DIGIT, ONE_HUNDRED, PERCENT_DIGIT, ZERO } from '@/lib/math/config/math.config';


/**
 * 返回一个正整数数对 3 进行向上取整的结果。
 *
 * 解释
 * 在数学上，这相当于找到大于等于输入值的最小3的倍数。
 *
 * 示例:
 * 输入 1 返回 3;
 * 输入 3 返回 3;
 * 输入 5 返回 6;
 * 输入 2 返回 3;
 * 输入 10 返回 12;
 * 输入 56 返回 57;
 * 输入 226 返回 228;
 *
 * @param integer 一个正整数
 */
export function ceilToMultipleOfThree(integer: number): number {
  return Math.ceil(integer / 3) * 3;
}

/**
 * 返回一个数字向上取整的整十数;
 * 如:
 * 1. 输入 23 返回 30;
 * 2. 输入 10.6 返回 11;
 * 3. 输入 99 返回 100;
 */
export function nearestTen(n: number): number {
  return Math.ceil(n / 10) * 10;
}

/**
 * 返回两个数值的间距
 */
export function distance(n1: number, n2: number): number {
  return Math.abs(n1 - n2);
}


/**
 * 返回两个横坐标的中点
 */
export function getCenterPoint(x1: number, x2: number, digit: number): number {
  return x1 + roundTo((x2 - x1) / 2, digit);
}


/**
 * 返回 Map 的随机一个键
 */
export function randomInMap<T>(map: Map<number, T>): number {
  return randomInList(Array.from(map.keys()));
}


/**
 * 返回数组中的随机一个元素
 */
export function randomInList<T>(list: Array<T>): T {
  if (list.length === 0) {
    throw new Error('Error: list cannot be empty! ');
  }
  return list[randomInRange(0, list.length-1)];
}

/**
 * 返回集合中的随机一个元素
*/
export function randomInSet<T>(set: Set<T>): T {
  if (set.size === 0) {
    throw new Error('Error: set cannot be empty! ');
  }
	
  const values = set.values();
  const target = randomInRange(1, set.size);

  let item;
  let step = 0;
	
  while (step < target) {
    item = values.next().value;
    step++;
  }
	
  return item;
}

/**
 * 返回枚举中的随机一个元素
 */
export function randomInEnum<T>(...enums: Array<T>): T {
  if (enums.length === 0) {
    throw new Error('Error: enums cannot be empty! ');
  }
  return enums[randomInRange(0, enums.length-1)];
}

/**
 * 返回 [min, max] 的随机整数
*/
export function randomInRange(min: number, max: number): number {
  // [0,1) => [0, max-min+1) => [min,max+1) => [min,max]
  return Math.floor(Math.random() * (max - min + 1) + min);
}


/**
 * 返回 [min, max] 的随机浮点数，保留 digit 位小数
 */
export function randomInRangeFloat(min: number, max: number, digit: number): number {
  return +(Math.random() * (max - min) + min).toFixed(digit);
}


/**
 * 四舍五入，保留 num 的 digit 位小数 (字符串)
 * @param num 原始值
 * @param digit 保留的小数位数
*/
export function roundToString(num: number, digit: number): string {
  return Number.prototype.toFixed.call(num, digit);
}

/**
 * 四舍五入，保留 num 的 digit 位小数; 末尾的 0 不计入，如结果是 0.500 时返回 0.5;
 * @param num 原始值
 * @param digit 保留的小数位数
 */
export function roundTo(num: number, digit: number): number {
  return +roundToString(num, digit);
}

export function realRoundTo1Digit(num: number): number {
  return Math.round(num * 10) / 10;
}

export function realRoundTo2Digit(num: number): number {
  return Math.round(num * 100) / 100;
}

// 保留 3 位小数
export function realRoundTo3Digit(num: number): number {
  return Math.round(num * 1000) / 1000;
}

export function realRoundTo4Digit(num: number): number {
  return Math.round(num * 10000) / 10000;
}

/**
 * 输入一个数值，返回"截断小数点3位以后位数"的数值。
 * 如输入 0.2125，返回 0.212。
 */
export function truncTo3Digit(data: number): number {
  const factor = 1000;
  return Math.trunc(data * factor) / factor;
}

/**
 * 输入一个数字，返回它四舍五入保留 1 位小数的结果
 *
 * 数学原理：
 * 1. 将输入数字乘以 10（num * 10），将小数点向右移动一位。
 * 2. 使用 Math.round() 对结果进行四舍五入取整。
 * 3. 再除以 10（/ 10），将小数点移回原位。
 */
export function roundToOneDecimal(num: number): number {
  return Math.round(num * 10) / 10;
}

/**
 * 向下，保留 num 的 digit 位小数
 * @param num 原始值
 * @param digit 保留的小数位数
 */
export function floorTo(num: number, digit: number): number {
  const str = '' + num;
  if (str.includes('.')) {
    const [ integerText, decimalText ] = str.split('.');
    // 小数位数不大于 digit，直接返回
    if (decimalText.length <= digit) {
      return num;
    }
    const newDecimal = decimalText.slice(0, digit);
    return +(integerText + '.' + newDecimal);
  }
  else {
    // 整数直接返回
    return num;
  }
}


/**
 * 返回一个整数，代表 num 在 total 中的百分占比，
 *
 * 如传入 2,4，返回 50。
 */
export function getPercent(num: number, total: number): number {
  return Math.floor(roundTo(num / total, PERCENT_DIGIT) * ONE_HUNDRED);
}



/**
 * 返回目标数占总数的百分比（单位: %），四舍五入保留1位小数。
 *
 * 示例
 * 输入 2,4，返回 50。
 * 输入 6,9，返回 66.7。
 * 输入 1,3，返回 33.3。
 * 输入 7,8，返回 87.5。
 *
 * @param a 目标数
 * @param b 总数
 */
export function getPercentDigit1(a: number, b: number): number {
  if (a <= 0 || b <= 0) {
    return 0;
  }
  // 计算百分比，单位%
  const percentage = (a / b) * 100;
  // 四舍五入保留一位小数
  return Math.round(percentage * 10) / 10;
}

/**
 * 格式化为百分比
 * 如:
 * 1.传入 0.9722，返回 97.22。
 * 2.传入 0.9722,1，返回 97.2。
 *
 * @param num 一个小数
 * @param digits 格式化后保留的小数位数
 */
export function getPercentDataFromDigit(num: number, digits?: number): number {
  return roundTo(num * ONE_HUNDRED, digits || FORMATTED_PERCENT_DIGIT);
}
/**
 * 格式化为百分比中的整数部分，四舍五入。
 * 如: 传入 0.9722，返回 97。
 *
 * @param digit 一个小数
 */
export function getPercentIntegerFromDigit(digit: number): number {
  return Math.round(getPercentDataFromDigit(digit));
}
/**
 * 小数格式化为百分比字符串，如输入 (0.959, 1), 返回 95.9%。
 *
 * @param num 一个小数，0~1
 * @param digits 格式化后保留的小数位数
 */
export function getPercentTextFromDigit(num: number, digits?: number): string {
  return getPercentDataFromDigit(num, digits) + '%';
}


/**
 * 检查数字是否为零
 *
 * @param num
 */
export function isZero(num: number): boolean {
  return num === ZERO;
}

/**
 * 返回 n 个随机数字，保证数字之和始终为 1。
 */
export function getPercentNumbers(n: number): Array<number> {
  // 保留的小数位数
  const digit = 2;
  // 随机生成 n 个范围 0~1 的数字，正序排列。
  // a0 a1 a2 a3 a4 ... a9
  const randoms = Array(n).fill(0).map(_ => randomInRangeFloat(0,1,digit)).sort((a,b) => a - b);
  // 存储结果
  const diffs = Array(n).fill(0);
  // 得到前 n-1 个随机数字
  // b0 = a1-a0;
  // b1 = a2-a1;
  // ...
  // b8 = a9-a8
  for (let i = 0; i < n - 1; i++) {
    diffs[i] = roundTo(randoms[i+1] - randoms[i], digit);
  }
  // 得到最后一个随机数字
  // b8+b7+...+b1+b0 = (a9-a8) + (a8-a7) + (a7-a6) + (a6-a5) + ... + (a1-a0) = a9-a0;
  // b9 = 1-(a9-a0);
  diffs[n - 1] = roundTo(1 - (diffs.slice(0,n-1).reduce((acc,cur) => acc+cur, 0)), digit);
  
  // b0加到b9始终等于1。
  return diffs;
}


/**
 * 获取一个数字的小数位数
 * @param data 数字字符串
 */
export function getDigitCount(data: string): number {
  const decimalMatch = data.match(/\.(\d+)|$/);
  return decimalMatch && decimalMatch[1] ? decimalMatch[1].length : 0;
}

/**
 * 返回 data 是否是 step 的整数倍
 */
export function isMultipleStep(data: number, step: number): boolean {
  const precision = 1e-10; // 用于处理浮点数精度问题
  const remainder = Math.abs(data / step) % 1;
  return remainder < precision || 1 - remainder < precision;
}

export function isInRange(data: number, low: number, high: number): boolean {
  return data >= low && data <= high;
}

/**
 * 输入一个正整数，返回它对向下取整到30的倍数的结果。
 *
 * 示例:
 * 输入 31 返回 30
 * 输入 29 返回 0
 * 输入 59 返回 30
 * 输入 61 返回 60
 * 输入 121 返回 120
 *
 * @param num 正整数
 */
export function floorTo30(num: number): number {
  return Math.floor(num / 30) * 30;
}

/**
 * 判断两个数组是否存在相同的数字
 * @param arr1 第一个数组
 * @param arr2 第二个数组
 * @returns 如果有相同的数字返回 true，否则返回 false
 */
export function haveCommonNumber(arr1: number[], arr2: number[]): boolean {
  const set = new Set(arr1); // 将第一个数组转为 Set 以便快速查找
  for (const num of arr2) {
    if (set.has(num)) {
      return true; // 发现相同数字，立即返回 true
    }
  }
  return false; // 遍历完第二个数组未发现相同数字
}
