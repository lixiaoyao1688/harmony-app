module.exports = {
  root: true,
  // 不限制以下目录和文件
  ignorePatterns: [
    'node_modules/',
    'dist/',
    'docs/',
    '**/*.css',
  ],
  env: {
    node: true
  },
  extends: [
    'plugin:vue/vue3-essential',
    'eslint:recommended',
    '@vue/typescript'
  ],
  parserOptions: {
    parser: '@typescript-eslint/parser'
  },
  rules: {
    'no-unused-vars': 'off',
    'no-debugger': 'off',
    'no-prototype-builtins': 'off',
    'no-mixed-spaces-and-tabs': 'off',
    'semi': ['error', 'always'],  // 语句结尾使用分号
    'indent': ['error', 2],  // 使用 2 个空格缩进
    'quotes': ['error', 'single'],  // 使用单引号
  },
  globals: {
    defineProps: 'readonly',
    defineEmits: 'readonly',
    defineExpose: 'readonly',
    withDefaults: 'readonly',
  }
};
