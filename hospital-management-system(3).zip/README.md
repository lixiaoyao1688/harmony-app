# 胰岛素泵数据管理软件 V1.1.0.1

## 接口文档
https://192.168.1.249:85/project/75/interface/api


## 提交规范
### 基本格式 
<type>(<scope>): <subject>
#### 提交类型 (type)
| 类型     | 说明                                    | 示例                                             |
| -------- | --------------------------------------- | ------------------------------------------------ |
| feat     | 新功能                                  | feat(app): 新增院泵患者建档功能                  |
| fix      | 修复缺陷                                | fix: http://192.168.1.236:81/redmine/issues/5962 |
| docs     | 文档更新                                | docs(readme): 更新 app 编译说明                  |
| style    | 代码样式调整（不影响逻辑）              | style: 调整代码缩进格式                          |
| refactor | 重构代码（既不是新功能也不是 bug 修复） | refactor: 重构医嘱模块                           |
| perf     | 性能优化                                | perf: 优化图片懒加载逻辑                         |
| test     | 测试相关                                | test: 添加用户服务单元测试                       |
| build    | 构建系统或外部依赖更改                  | build: 更新 webpack 配置                         |
| ci       | CI/CD 配置更改                          | ci: 添加 GitHub Actions 工作流                   |
| chore    | 其他杂项（不修改源码或测试）            | chore: 更新依赖包版本                            |
| revert   | 回滚提交                                | revert: 回滚某次提交的更改                       |

#### 作用域 (scope)
表示影响范围。源码修改仅提供 "pc", "app", "pc && app" 这三个选项。其他修改按情况编写。可选。

#### 主题 (subject)

简要描述本次提交的内容，末尾不加句号，长度建议 50 个字符以内。

## APP端在 Android Studio 中编译前的工作
Tips: 所需资源皆位于 ~/app 中。
### 1.修改项目配置
修改 ~android/variables.gradle 中的 ext.minSdkVersion 为 26。
### 2.修改启动画面和图标
1. 右键 ~android/app/src，选择 New -> Image Asset, 在 Source Asset 中上传 ic_launcher-playstore.png，按提示生成图标。
2. 添加 ~android/app/src/res/values/strings.xml
3. 添加 ~android/app/src/res/values/styles.xml
4. 添加 ~android/app/src/res/values/colors.xml
5. 添加 ~android/app/src/res/xml/network_security_config.xml
6. 添加 ~android/app/src/res/anim
7. 替换 ~android/app/src/res/drawable
8. 替换 ~android/app/src/res/layout
9. 添加 ~android/app/src/main/java/com/aaruy/hms/SplashActivity.java
10. 替换 ~android/app/src/main/AndroidManifest.xml
### 3.生成 release apk 时所需密钥
* Key store path: hms.jks
* Key store password: 123456
* Key alias: hmsKey
* Key password: 123456

## APP端在 Android Studio 中编译前的工作
Tips: 所需资源皆位于 ~app/android 中。
1. 用 ~app/android/MainActivity.java 替换 ~hospital-management-system\android\app\src\main\java\com\aaruy\hms\MainActivity.java;

## APP端在 XCode 中编译前的工作
Tips: 所需资源皆位于 ~app/ios 中。
1. 找到 D:\release\hms_ios，执行 update_code.sh，看到 hms_code.tar.gz 修改日期变更后，上传到网盘。
2. 在 hgc 的苹果电脑上，下载 hms_code.tar.gz，替换他电脑上 hms_code 里对应的内容，然后执行 npm run build:ios。
3. 拖动 1024.png 到 App -> Assets -> AppIcon 的 1 个尺寸中。
4. 拖动 3 个 AppSplash.png 到 App -> Assets -> Splash 的 3 个尺寸中。
5. 点击 App，在右侧修改 General -> App Icons and Launch Screen -> Launch Screen File，选择 LaunchScreen.storyboard。
6. 点击 App -> LaunchScreen -> View Controller Scene -> View Controller，找到xcode上的"+"图标，拖动 1 个 View 进入编辑界面作为整体背景，在右侧 attribute inspector 中设置 View 的 background 为 rgb(199,23,30);
7. 添加 App/App/CustomLaunchViewController.swift
8. 替换 App/App/AppDelegate.swift
9. 在 App/App/Info 中，修改 Bundle display name 为 "阿瑞查房"

## 阿瑞查房APP ICP备案号
粤ICP备2020142120号-7A

## 变更通知 Skill
### 在每次通知QA同事前，在 git commit 中复制[旧版本,新版本]之间的所有消息，然后开头加上下面的提示词，一起发给AI:
下面是一段段的 git commit 消息，帮我仅保留 message 列。然后按下面规则处理:
1. 将所有的 message 分成2部分: message 中包含 pc 的是"## PC端"部分，message 中包含 app 的是"## APP端"部分，如果 message 既没有 pc 也没有 app，但包含了 feat 或 fix，则在 "## PC端" 和 "## APP端" 中各复制一份。
2. 在每1部分中分2个标题，1个是"功能变更"，1个是"修复缺陷"。
3. 将包含 feat 的消息分到"功能变更"里，每1消息都以";"结尾，且在消息开头用序号(从1开始)标序, 且去掉"feat(xx):"仅保留内容部分； 
4. 将包含 fix 的消息分到"修复缺陷"里，在"修复缺陷"中，仅保留有 issues 编号的消息，且只保留编号，且将所有编号合成为1行，其中各编号用","隔开，最后以";"结尾。 
5. 在最终结果的开头大标题写上"# 管理软件 V1.1.0.01.xxx，最终生成的文本中，每1行之间不要有空行。
返回最终结果的完整文本给我，我要直接复制到 markdown 文件里。