##!/usr/bin/env bash
#set -euo pipefail
#
#IMG=${IMG}
#BRANCH=${BRANCH}
#REPO_DIR=${REPO_DIR}
#echo "[INFO] repo: $REPO_DIR  branch: $BRANCH"
#
#git config --global --add safe.directory "$REPO_DIR" || true
#git pull
#
#docker run --rm \
#  -u "$(id -u):$(id -g)" \
#  -v "$REPO_DIR":/work -w /work \
#  "$IMG" bash -lc '
#  set -e
#  npm ci && npm run build:web
#'
#
#git add -f dist
#if git diff --cached --quiet; then
#  echo '[INFO] dist 无变更，跳过提交/推送'
#  exit 0
#fi
#
#git -c user.name=CI -c user.email=ci@ar.com commit -m "build: update dist [skip ci]"
#git push origin "$BRANCH"
#
#echo "[OK] build done."
