import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aaruy.hms',
  appName: 'hms',
  webDir: 'dist',
  server: {
    cleartext: true,
    allowNavigation: ['*']
  },
  ios: {
    contentInset: 'automatic',
    allowsLinkPreview: false,
    scrollEnabled: false,  // 解决 ios app 整体界面滚动的问题
  },
  android: {
    // 解决查房app的ws请求被阻止的问题
    // Msg: Mixed Content: The page at 'https://localhost/#/in_patient' was loaded over HTTPS, but attempted to connect to the insecure WebSocket endpoint 'ws://192.168.1.67:82/socket.io/?EIO=4&transport=websocket'.
    // This request has been blocked; this endpoint must be available over WSS.
    allowMixedContent: true,
    // fix: android app 中文输入无效的问题
    captureInput: false
  },
  plugins: {
    CapacitorHttp: {
      enabled: true
    },
    StatusBar: {
      overlaysWebView: false,  // 解决手机状态栏遮挡APP顶部内容的问题; https://capacitorjs.com/docs/apis/status-bar#configuration
      style: 'DARK',
      backgroundColor: '#707070FF',
    }
  }
};

export default config;
