<script setup lang="ts">
import dayjs from 'dayjs';
import VConsole from 'vconsole';
import { computed } from 'vue';
import { RouterView } from 'vue-router';
import { Capacitor } from '@capacitor/core';
import {printApp} from '@/lib/log/util/log.util';
import { onBeforeMount, onMounted, onUnmounted } from 'vue';
import {useStorageStore} from '@/lib/storage/store/storage.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { LocalNotifications } from '@capacitor/local-notifications';
import {IS_APP, IS_APP_DEV_TOOL_ENABLED} from '@/lib/app/config/app.config';
import {useBrowserStore} from '@/lib/browser/store/browser.store';
import { useFullscreenStore } from '@/modules/fullscreen/store/fullscreen.store';
import {PRIVACY_POLICY_URL} from '@/modules/about/config/privacy.policy.config';
import {useAppStore} from '@/lib/app/store/app.store';
import PrivacyPolicyModal from '@/lib/aaruy-design/privacy-policy-modal/PrivacyPolicyModal.vue';
import zhCN from 'ant-design-vue/es/locale/zh_CN';
import 'dayjs/locale/zh-cn';


let mobileConsole: VConsole;

const appStore = useAppStore();
const screenStore = useScreenStore();
const storageStore = useStorageStore();
const fullscreenStore = useFullscreenStore();
const browserStore = useBrowserStore();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


onBeforeMount(async () => {
  if (mobile.value) {
    // 将本地存储的域名设置为全局域名，解决: "已登录用户退出登录"的问题;
    // const { value } = await Preferences.get({ key: USER_DOMAIN_KEY });
    const value = await storageStore.getMobileDomain();
    if (value) {
      appStore.setDomain(value);
    }
    // // 2025-05-29 已废弃
    // // 由于内网IP需要输入，无IP不能请求 user/info 接口，所以 APP 首屏始终加载登录页。
    // router.replace({ name: ROUTE_LOGIN });
    // 请求本地通知权限
    LocalNotifications
      .requestPermissions()
      .then(() => {
        printApp('Local Notifications Permission Successful.', '');
      });
    // 隐藏 Capacitor 本身的日志
    Capacitor.isLoggingEnabled = false;
  }
  screenStore.listen();
  fullscreenStore.listen();
  if (screenStore.isPC) {
    browserStore.init();
  }
});

onMounted(() => {
  if (screenStore.isMobile) {
    if (IS_APP_DEV_TOOL_ENABLED) {
      mobileConsole = new VConsole({ theme: 'light' });
    }
    screenStore.showInfo();
  }
});

onUnmounted(() => {
  screenStore.stopListening();
  fullscreenStore.stopListening();
  if (mobileConsole) {
    mobileConsole.destroy();
  }
});

dayjs.locale('zh-cn');
</script>

<template>
  
  <a-config-provider v-if="IS_APP" :locale="zhCN">
    <RouterView />
    <PrivacyPolicyModal :url="PRIVACY_POLICY_URL" />
  </a-config-provider>
  <a-config-provider v-else :locale="zhCN">
    <RouterView />
  </a-config-provider>
  
</template>
