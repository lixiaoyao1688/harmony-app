import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


export const PART_ALL_ID = 999;
export const TOTAL_PART_ITEM = new SelectorFormItemVO(INVALID_ID, '全院');
export const NEW_TOTAL_PART_ITEM = new SelectItemVO({ id: PART_ALL_ID, text: '全部科室' });
