import { defineStore } from 'pinia';
import {NEW_TOTAL_PART_ITEM, TOTAL_PART_ITEM} from '@/api/department/config/department.config';
import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { httpDepartmentGet } from '@/modules/department/requests/department.http';
import { DepartmentVO } from '@/modules/department/vo/Department.vo';


/**
 * 科室 库
 *
 * 注意:
 * 此为旧版, 请使用新版, 新版位于: src/modules/department/store/department.store.ts;
 */
interface State {
	departments: DepartmentVO[];
  departmentMap: Map<number, SelectItemVO<undefined>>;
}

interface Action {
	init: () => Promise<null>;
	getItem: (id: number | undefined) => SelectorFormItemVO;
	getNewItem: (id: number | undefined) => SelectItemVO<undefined>;
  getFirstItem: () => SelectorFormItemVO;
}

type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
  itemsIncludeTotal: () => Array<SelectorFormItemVO>;   // 包含'全院'选项
  itemMapIncludeTotal: () => Map<number, SelectorFormItemVO>;
  newItemsIncludeTotal: () => Array<SelectItemVO<unknown>>;
  newItemMapIncludeTotal: () => Map<number, SelectItemVO<unknown>>;
}

export const useDepartmentStore = defineStore<string, State, Getter, Action>('department', {
	
  state: () => ({
    departments: [],
    departmentMap: new Map(),
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpDepartmentGet({})
          .then(data => {
            const vos = data.vos;
            this.departments = vos;
            this.departmentMap = new Map(vos.map(vo => ([vo.id, new SelectItemVO({ id: vo.id, text: vo.name })])));
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
    getNewItem(id) {
      if (id === undefined) {
        return new SelectItemVO();
      }
      return this.departmentMap.get(id) as SelectItemVO<undefined> || new SelectItemVO();
    },
    getFirstItem() {
      if (this.items.length === 0) {
        return SelectorFormItemVO.empty();
      }
      return this.items[0];
    }
  },
	
  getters: {
    items() {
      return this.departments.map(d => new SelectorFormItemVO(d.id, d.name));
    },
    itemMap() {
      return new Map<number, SelectorFormItemVO>(this.items.map(it => ([it.id, it])));
    },
    itemsIncludeTotal() {
      return [TOTAL_PART_ITEM, ...this.items];
    },
    itemMapIncludeTotal() {
      return new Map<number, SelectorFormItemVO>(this.itemsIncludeTotal.map(it => ([it.id, it])));
    },
    newItemsIncludeTotal() {
      return [NEW_TOTAL_PART_ITEM, ...this.departments.map(d => new SelectItemVO({ id: d.id, text: d.name }))];
    },
    newItemMapIncludeTotal() {
      return new Map<number, SelectItemVO<unknown>>(this.newItemsIncludeTotal.map(it => ([it.id, it])));
    },
  }
	
});
