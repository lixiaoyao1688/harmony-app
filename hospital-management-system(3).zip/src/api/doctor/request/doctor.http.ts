import { httpGet } from '@/lib/http/request/http';
import { DoctorVO } from '@/api/doctor/vo/Doctor.vo';
import { DoctorDTO } from '@/api/doctor/dto/doctor.dto';


const PATH = {
  GET: '/hospital/doctor/get'
};

enum LOG {
	GET = '医生 查看'
}


export function httpDoctorGet() {
  return httpGet<undefined, DoctorDTO, DoctorVO>(PATH.GET, undefined, DoctorVO, LOG.GET);
}
