import { defineStore } from 'pinia';
import { DoctorVO } from '@/api/doctor/vo/Doctor.vo';
import { httpDoctorGet } from '@/api/doctor/request/doctor.http';
import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface IState {
	doctors: DoctorVO[];
  doctorMap: Map<number, SelectItemVO<undefined>>;
}

interface IAction {
	init: () => Promise<null>;
  getItem: (id: number | undefined) => SelectorFormItemVO;
  getNewItem: (id: number | undefined) => SelectItemVO<undefined>;
}

type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
}


export const useDoctorStore = defineStore<'doctor', IState, Getter, IAction>('doctor', {
	
  state: () => ({
    doctors: [],
    doctorMap: new Map(),
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpDoctorGet()
          .then(data => {
            this.doctors = data.vos;
            this.doctorMap = SelectItemVO.getMap(data.vos.map(vo => new SelectItemVO({ id: vo.id, text: vo.name })));
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
    getNewItem(id) {
      if (id === undefined) {
        return new SelectItemVO();
      }
      return SelectItemVO.getItem(this.doctorMap as Map<number, SelectItemVO<undefined>>, id);
    }
  },
	
  getters: {
    items() {
      return this.doctors.map(d => new SelectorFormItemVO(d.id, d.name));
    },
    itemMap() {
      return new Map<number, SelectorFormItemVO>(this.items.map(it => ([it.id, it])));
    }
  }
	
});
