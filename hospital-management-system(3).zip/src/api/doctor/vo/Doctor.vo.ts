import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { DoctorDTO } from '@/api/doctor/dto/doctor.dto';
import {TransferItemVO} from '@/lib/aaruy-design/transfer/TransferItem.vo';


export class DoctorVO {
	
	public id: number;
	public name: string;
	
	constructor(e: DoctorDTO) {
	  this.id = e.id;
	  this.name = e.name;
	}
	
	public get item() {
	  return new SelectorFormItemVO(this.id, this.name);
	}
	
	public get transferItem(): TransferItemVO {
	  return new TransferItemVO(this.id, this.name);
	}
	
}
