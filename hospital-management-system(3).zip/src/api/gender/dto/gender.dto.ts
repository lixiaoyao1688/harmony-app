/**
 * 性别 DTO
 */
export interface GenderDTO {
	id: number;  // 值
	name: string;  // 英文, 如 'male' | 'female';
	text: string;  // 中文, 如 '男' | '女';
}