import {randomInEnum, randomInRange} from '@/lib/math/util/math.util';
import type {GenderDTO} from '@/api/gender/dto/gender.dto';


export function MOCK_genderInfo(): GenderDTO {
  const id = randomInEnum(1,2);
  const isMale = id === 1;
  return {
    id: id,
    name: isMale ? 'male': 'female',
    text: isMale ? '男' : '女'
  };
}
