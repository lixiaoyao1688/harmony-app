import { httpGet } from '@/lib/http/request/http';
import { GenderDTO } from '@/api/gender/dto/gender.dto';
import { GenderVO } from '@/api/gender/vo/Gender.vo';


const PATH = {
  GET: '/api/gender'
};

enum LOG {
	GET = '性别'
}


export function httpGenderGet() {
  return httpGet<unknown, GenderDTO, GenderVO>(PATH.GET, undefined, GenderVO, LOG.GET);
}
