import { defineStore } from 'pinia';
import { GenderVO } from '@/api/gender/vo/Gender.vo';
import { httpGenderGet } from '@/api/gender/requests/gender.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


interface State {
	genders: GenderVO[];
  voItems: Array<ItemType>;
  voItemMap: Map<number, ItemType>;
}

interface Action {
	init: () => Promise<null>;
	getGender: (id: number) => GenderVO;
	getItem: (id: number | undefined) => SelectorFormItemVO;
	getNewItem: (id: number | undefined) => ItemType;
}

type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
}


export const useGenderStore = defineStore<string, State, Getter, Action>('gender', {
	
  state: () => ({
    genders: [],
    voItems: [],
    voItemMap: new Map(),
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpGenderGet()
          .then(data => {
            const vos = data.vos;
            this.genders = vos;
            this.voItems = vos.map(vo => new SelectItemVO({ id: vo.id, text: vo.text }));
            this.voItemMap = new Map(this.voItems.map(it => ([it.id, it as ItemType])));
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
    getNewItem(id) {
      if (id === undefined) {
        return new SelectItemVO();
      }
      return SelectItemVO.getItem(this.voItemMap as Map<number, SelectItemVO<undefined>>, id);
    },
    getGender(id) {
      const t = this.genders.find(d => d.id === id);
      return t || GenderVO.empty();
    }
  },
	
  getters: {
    items() {
      return this.genders.map(d => d.item);
    },
    itemMap() {
      return new Map<number, SelectorFormItemVO>(this.items.map(it => ([it.id, it])));
    }
  }
	
});
