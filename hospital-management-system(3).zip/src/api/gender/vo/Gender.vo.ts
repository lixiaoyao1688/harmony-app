import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { GenderDTO } from '@/api/gender/dto/gender.dto';


export class GenderVO {
	
	public id: number;
	public text: string;  // 中文
	
	constructor(e: GenderDTO) {
	  this.id = e.id;
	  this.text = e.text || '';
	}
	
	public get item(): SelectorFormItemVO {
	  return new SelectorFormItemVO(this.id, this.text);
	}
	
	public static empty() {
	  return new GenderVO({
	    id: INVALID_ID,
	    name: '',
	    text: '',
	  });
	}
}
