export interface GluKindDTO {
	id: number;
	name: string;
	text: string;
}