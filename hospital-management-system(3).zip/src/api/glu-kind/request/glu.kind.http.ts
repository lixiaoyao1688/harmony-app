import { httpGet } from '@/lib/http/request/http';
import { GluKindVO } from '@/api/glu-kind/vo/GluKind.vo';
import type { GluKindDTO } from '@/api/glu-kind/dto/glu.kind.dto';


const PATH = {
  GET: '/api/glucose/kind'
};

enum LOG {
	GET = '糖尿病类型'
}


export function httpGluKindGet() {
  return httpGet<unknown, GluKindDTO, GluKindVO>(PATH.GET, undefined, GluKindVO, LOG.GET);
}
