import { defineStore } from 'pinia';
import { INVALID_ID, TOTAL_ID } from '@/utils/global.vo.help';
import { GluKindVO } from '@/api/glu-kind/vo/GluKind.vo';
import { httpGluKindGet } from '@/api/glu-kind/request/glu.kind.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';


interface State {
	gluKinds: GluKindVO[];
  voItems: Array<ItemType>;
  gluItemMap: Map<number, SelectItemVO<undefined>>;
}

interface Action {
	init: () => Promise<null>;
	getItem: (id: number | undefined) => SelectorFormItemVO;
  getNewItem: (id: number | undefined) => SelectItemVO<undefined>;
}

type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
  itemsIncludeTotal: () => Array<SelectorFormItemVO>;
  itemMapIncludeTotal: () => Map<number, SelectorFormItemVO>;
}


export const useGluKindStore = defineStore<string, State, Getter, Action>('glu-kind', {
	
  state: () => ({
    gluKinds: [],
    gluItemMap: new Map(),
    voItems: [],
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpGluKindGet()
          .then(data => {
            const vos = data.vos;
            this.gluKinds = vos;
            this.gluItemMap = SelectItemVO.getMap(vos.map(vo => new SelectItemVO({ id: vo.id, text: vo.text })));
            this.voItems = vos.map(vo => vo.newItem);
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getNewItem(id) {
      if (id === undefined) {
        return new SelectItemVO();
      }
      return SelectItemVO.getItem(this.gluItemMap as Map<number, SelectItemVO<undefined>>, id);
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
  },
	
  getters: {
    items() {
      return this.gluKinds.map(d => d.item);
    },
    itemMap() {
      return new Map<number, SelectorFormItemVO>(this.items.map(it => ([it.id, it])));
    },
    itemsIncludeTotal() {
      return [new SelectorFormItemVO(INVALID_ID, '所有糖尿病'), ...this.items];
    },
    itemMapIncludeTotal() {
      return new Map<number, SelectorFormItemVO>(this.itemsIncludeTotal.map(it => ([it.id, it])));
    },
  }
	
});
