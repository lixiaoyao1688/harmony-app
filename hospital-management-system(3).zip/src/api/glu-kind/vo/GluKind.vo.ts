import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { GluKindDTO } from '@/api/glu-kind/dto/glu.kind.dto';


/**
 * 糖尿病类型 VO
 */
export class GluKindVO {
	
	public id: number;
	public text: string;
	
	constructor(e: GluKindDTO) {
	  this.id = e.id;
	  this.text = e.text;
	}
	
	public get item(): SelectorFormItemVO {
	  return new SelectorFormItemVO(this.id, this.text);
	}
	
	public get newItem(): SelectItemVO<undefined> {
	  return new SelectItemVO({ id: this.id, text: this.text });
	}
	
}
