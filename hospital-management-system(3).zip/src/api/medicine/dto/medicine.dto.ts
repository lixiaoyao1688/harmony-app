import { GLOBAL_YES_OR_NO } from '@/dto/global.dto';


export interface MedicineDTO {
	approval_number: string;  // 编号，国药准字Z20013215
	company: string;
	create_time: string;
	deleted: string;
	id: number;
	medicine_id: number;
	name: string;  // 名称
	packing_size: string;  // 规格，如 250 μg X 12 片
	update_time: string;
	is_insulin: GLOBAL_YES_OR_NO;  // 是否为胰岛素：0-否 1-是
}

export interface MedicineGetDTO {
	name?: string;  // 药品名称模糊搜索，最长100
	page?: number;  // 页数，默认为1，最小为1
	limit?: number;  // 每页显示多少条，默认为20，范围5-100
}
