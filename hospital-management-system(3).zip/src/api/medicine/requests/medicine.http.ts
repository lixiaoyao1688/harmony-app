import {
  getHttpCatcherType,
  httpNoResponseCatcher,
  httpResponseCatcher,
  isHttpResponseError
} from '@/lib/http/util/http.utils';
import {httpGet, instance} from '@/lib/http/request/http';
import { printError } from '@/lib/log/util/log.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { GLOBAL_YES_OR_NO } from '@/dto/global.dto';
import { MedicineNormalVO } from '@/modules/medicine/vo/MedicineNormal.vo';
import { MedicineVO } from '@/modules/medicine/vo/Medicine.vo';
import { MedicineInsVO } from '@/modules/medicine/vo/MedicineIns.vo';
import {InsMedVO} from '@/modules/ins/vo/InsMed.vo';
import type { HttpResponseDTO } from '@/lib/http/dto/http.dto';
import type { MedicineDTO, MedicineGetDTO } from '@/api/medicine/dto/medicine.dto';


export const MED_PATH = {
  GET: '/hospital/api/medicine'
};

enum LOG {
	GET = '药品',
}


export function medicineCatcher(type: 'get'): (reason: string) => void {
  let title = '';
  const store = useScreenStore();
	
  if (type === 'get') {
    title = getHttpCatcherType(LOG.GET, MED_PATH.GET);
  }
  return (reason: string) => printError(title, reason, store.isMobile);
}

export function httpMedicineGet(body: MedicineGetDTO) {
  return new Promise<Array<MedicineVO>>((resolve, reject) => {
    instance
      .post<HttpResponseDTO<Array<MedicineDTO>>>(MED_PATH.GET, body, undefined)
      .then(data => {
        if (isHttpResponseError(data)) {
          return httpResponseCatcher(data, reject);
        }
        const vos: Array<MedicineVO> = [];
        if (data.data.data.length > 0) {
          data.data.data.forEach(dto => {
            if (dto.is_insulin === GLOBAL_YES_OR_NO.NO) {
              vos.push(new MedicineNormalVO(dto));
            } else {
              vos.push(new MedicineInsVO(dto));
            }
          });
        }
        resolve(vos);
      })
      .catch(err => httpNoResponseCatcher(err, LOG.GET, reject));
  });
}

export function httpAdviceMedGet(body: MedicineGetDTO) {
  return httpGet<MedicineGetDTO, MedicineDTO, InsMedVO>(MED_PATH.GET, body, InsMedVO, LOG.GET);
}
