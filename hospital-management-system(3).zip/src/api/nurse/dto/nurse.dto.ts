export interface NurseDTO {
  id: number;
  name: string;
}
