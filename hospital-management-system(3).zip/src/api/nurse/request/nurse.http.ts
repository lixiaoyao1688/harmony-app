import { httpGet } from '@/lib/http/request/http';
import {NurseVO} from '@/api/nurse/vo/Nurse.vo';
import type {NurseDTO} from '@/api/nurse/dto/nurse.dto';


const NURSE_PATH = {
  GET: '/hospital/nurse/get'
};

enum LOG {
  GET = '护士 查看'
}


export function httpNurseGet() {
  return httpGet<undefined, NurseDTO, NurseVO>(NURSE_PATH.GET, undefined, NurseVO, LOG.GET);
}
