import { defineStore } from 'pinia';
import { NurseVO } from '@/api/nurse/vo/Nurse.vo';
import { httpNurseGet } from '@/api/nurse/request/nurse.http';
import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


interface State {
  vos: NurseVO[];
  itemMap: Map<number, SelectItemVO<undefined>>;
}

interface Action {
  init: () => Promise<null>;
  getNewItem: (id: number | undefined) => SelectItemVO<undefined>;
}

type Getter = {}


export const useNurseStore = defineStore<string, State, Getter, Action>('nurse-store', {
  
  state: () => ({
    vos: [],
    itemMap: new Map(),
  }),
  
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpNurseGet()
          .then(data => {
            const vos = data.vos;
            this.vos = vos;
            this.itemMap = SelectItemVO.getMap(vos.map(vo => new SelectItemVO({ id: vo.id, text: vo.name })));
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getNewItem(id) {
      if (id === undefined) {
        return new SelectItemVO();
      }
      return SelectItemVO.getItem(this.itemMap as Map<number, SelectItemVO<undefined>>, id);
    }
  },
  
  getters: {
  }
  
});
