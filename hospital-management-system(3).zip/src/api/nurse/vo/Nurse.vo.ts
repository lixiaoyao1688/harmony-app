import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 护士 VO
 */
export class NurseVO {
  
  public id: number;
  public name: string;
  
  constructor(e: NurseVO) {
    this.id = e.id;
    this.name = e.name;
  }
  
  public get item(): SelectItemVO<undefined> {
    return new SelectItemVO({ id: this.id, text: this.name });
  }
  
}
