export interface OperationDTO {
	id: number;  // 唯一标识, 如 1201
	name: string;  // 操作符号, 如 "admission-get"
	text: string;  // 操作含义, 如 "患者查询"
}
