import { httpGet } from '@/lib/http/request/http';
import { OperationVO } from '@/api/operation/vo/Operation.vo';
import type { OperationDTO } from '@/api/operation/dto/operation.dto';


const PATH = {
  GET: '/hospital/api/operation'
};

enum LOG {
	GET = '操作模块'
}


export function httpOperationGet() {
  return httpGet<undefined, OperationDTO, OperationVO>(PATH.GET, undefined, OperationVO, LOG.GET);
}
