import { defineStore } from 'pinia';
import { OperationVO } from '@/api/operation/vo/Operation.vo';
import { httpOperationGet } from '@/api/operation/requests/operation.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface State {
	operations: OperationVO[];
}

interface Action {
	init: () => Promise<null>;
  getItem: (id: number | undefined) => SelectorFormItemVO;
}


type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
}


export const useOperationStore = defineStore<string, State, Getter, Action>('operation-store', {
	
  state: () => ({
    operations: [],
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpOperationGet()
          .then(data => {
            this.operations = data.vos;
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
  },
	
  getters: {
    items() {
      return this.operations.map(d => d.item);
    },
    itemMap() {
      return new Map<number, SelectorFormItemVO>(this.items.map(it => ([it.id, it])));
    }
  }
	
});
