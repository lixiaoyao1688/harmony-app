export interface RelationshipDTO {
	id: number;  // 唯一标识
	name: string;  // 英文
	text: string;  // 中文
}