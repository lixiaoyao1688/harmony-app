import { httpGet } from '@/lib/http/request/http';
import { RelationshipVO } from '@/api/relationship/vo/Relationship.vo';
import type { RelationshipDTO } from '@/api/relationship/dto/relationship.dto';


const PATH = {
  GET: '/hospital/api/relation'
};

enum LOG {
	GET = '患者关系'
}

export function httpRelationshipGet() {
  return httpGet<undefined, RelationshipDTO, RelationshipVO>(PATH.GET, undefined, RelationshipVO, LOG.GET);
}
