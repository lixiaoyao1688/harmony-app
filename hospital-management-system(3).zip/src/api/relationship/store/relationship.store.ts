import { defineStore } from 'pinia';
import { RelationshipVO } from '@/api/relationship/vo/Relationship.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { httpRelationshipGet } from '@/api/relationship/request/relationship.http';


interface State {
	relationships: RelationshipVO[];
}

interface Action {
	init: () => Promise<null>;
	getItem: (id: number) => SelectorFormItemVO;
  getFirstItem: () => SelectorFormItemVO;
}

type Getter = {
	items: () => Array<SelectorFormItemVO>;
}


export const useRelationshipStore = defineStore<string, State, Getter, Action>('relationship-store', {
	
  state: () => ({
    relationships: [],
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpRelationshipGet()
          .then(data => {
            this.relationships = data.vos;
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      const target = this.relationships.find(d => d.id === id);
      return target ? target.item : SelectorFormItemVO.empty();
    },
    getFirstItem() {
      if (this.items.length === 0) {
        return SelectorFormItemVO.empty();
      }
      return this.items[0];
    }
  },
	
  getters: {
    items() {
      return this.relationships.filter(s => !s.isPatient).map(d => new SelectorFormItemVO(d.id, d.text));
    }
  }
	
});
