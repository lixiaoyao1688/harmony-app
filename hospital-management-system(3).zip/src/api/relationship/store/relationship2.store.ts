import { defineStore } from 'pinia';
import { RelationshipVO } from '@/api/relationship/vo/Relationship.vo';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import { httpRelationshipGet } from '@/api/relationship/request/relationship.http';
import type {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';


interface State {
  relationships: Array<RelationshipVO>;
  items: Array<ItemType>;
}

interface Action {
  fetch: () => Promise<Array<RelationshipVO>>;
  getText: (id: number) => string;
  clear: () => void;
}

type Getter = {
}


export const useRelationship2Store = defineStore<string, State, Getter, Action>('relationship-2-store', {
  
  state: () => ({
    relationships: [],
    items: [],
    item: new SelectItemVO(),
  }),
  
  actions: {
    fetch() {
      return new Promise((resolve, reject) => {
        this.relationships = [];
        this.items = [];
        httpRelationshipGet()
          .then(data => {
            const vos = data.vos;
            this.relationships = vos;
            this.items = vos.map(vo => vo.newItem);
            resolve(vos);
          })
          .catch(reason => reject(reason));
      });
    },
    getText(id) {
      const it = this.items.find(it => it.id === id);
      return it ? it.text : '';
    },
    clear() {
      this.$reset();
    }
  },
  
  getters: {
  }
  
});
