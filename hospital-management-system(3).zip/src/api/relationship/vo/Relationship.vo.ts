import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { RelationshipDTO } from '@/api/relationship/dto/relationship.dto';
import {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 患者关系 VO
 */
export class RelationshipVO {
	
	public id: number;
	public text: string;
	public name: string;  // 英文代码
	
	constructor(e: RelationshipDTO) {
	  this.id = e.id;
	  this.text = e.text;
	  this.name = e.name;
	}
	
	// 是否 "患者"
	public get isPatient(): boolean {
	  return this.name === 'patient';
	}
	
	public get item() {
	  return new SelectorFormItemVO(this.id, this.text);
	}
	
	public get newItem(): ItemType {
	  return new SelectItemVO({ id: this.id, text: this.text });
	}
	
	public static empty() {
	  return new RelationshipVO({
	    id: INVALID_ID,
	    name: '',
	    text: '',
	  });
	}
}
