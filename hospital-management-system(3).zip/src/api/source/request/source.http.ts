import { httpGet } from '@/lib/http/request/http';
import { SourceVO } from '@/api/source/vo/Source.vo';
import type { SourceDTO } from '@/api/source/dto/source.dto';


const PATH = {
  GET: '/hospital/source/get'
};

enum LOG {
	GET = '患者来源'
}


export function httpSourceGet() {
  return httpGet<unknown, SourceDTO, SourceVO>(PATH.GET, undefined, SourceVO, LOG.GET);
}
