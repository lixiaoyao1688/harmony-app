import { defineStore } from 'pinia';
import { SourceVO } from '@/api/source/vo/Source.vo';
import { httpSourceGet } from '@/api/source/request/source.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface State {
	sources: SourceVO[]
}

interface Action {
	init: () => Promise<null>;
	getItem: (id: number) => SelectorFormItemVO;
}


type Getter = {
	items: () => Array<SelectorFormItemVO>;
}


export const useSourceStore = defineStore<string, State, Getter, Action>('source', {
	
  state: () => ({
    sources: [],
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpSourceGet()
          .then(data => {
            this.sources = data.vos;
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      const t = this.sources.find(d => d.id === id);
      return t ? t.item : SelectorFormItemVO.empty();
    },
  },
	
  getters: {
    items() {
      return this.sources.map(d => d.item);
    }
  }
	
});
