import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { SourceDTO } from '@/api/source/dto/source.dto';


export class SourceVO {
	
	public id: number;
	public text: string;
	
	constructor(e: SourceDTO) {
	  this.id = e.id;
	  this.text = e.text;
	}
	
	public get item(): SelectorFormItemVO {
	  return new SelectorFormItemVO(this.id, this.text);
	}
	
	public static empty() {
	  return new SourceVO({
	    id: INVALID_ID,
	    name: '',
	    text: '',
	  });
	}
}
