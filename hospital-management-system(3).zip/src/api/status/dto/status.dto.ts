export interface StatusDTO {
	id: number;
	name: string;  // 英文
	text: string;  // 中文
}