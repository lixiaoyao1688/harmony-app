import { httpGet } from '@/lib/http/request/http';
import { StatusVO } from '@/api/status/vo/Status.vo';
import type { StatusDTO } from '@/api/status/dto/status.dto';


const PATH = {
  GET: '/hospital/api/admission_status'  // 2025-01-10 停用.
};

enum LOG {
	GET = '患者状态'
}


export function httpStatusGet() {
  return httpGet<unknown, StatusDTO, StatusVO>(PATH.GET, undefined, StatusVO, LOG.GET);
}
