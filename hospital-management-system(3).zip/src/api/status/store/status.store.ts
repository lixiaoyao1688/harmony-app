import { defineStore } from 'pinia';
import { StatusVO } from '@/api/status/vo/Status.vo';
import { httpStatusGet } from '@/api/status/request/status.http';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface State {
	statuses: StatusVO[]
}

interface Action {
	init: () => Promise<null>;
  getItem: (id: number | undefined) => SelectorFormItemVO;
}


type Getter = {
	items: () => Array<SelectorFormItemVO>;
  itemMap: () => Map<number, SelectorFormItemVO>;
}


export const useStatusStore = defineStore<string, State, Getter, Action>('status', {
	
  state: () => ({
    statuses: [],
  }),
	
  actions: {
    init() {
      return new Promise((resolve, reject) => {
        httpStatusGet()
          .then(data => {
            this.statuses = data.vos;
            resolve(null);
          })
          .catch(reason => reject(reason));
      });
    },
    getItem(id) {
      if (id === undefined) {
        return SelectorFormItemVO.empty();
      }
      return this.itemMap.get(id) || SelectorFormItemVO.empty();
    },
  },
	
  getters: {
    items() {
      return this.statuses.map(d => d.item);
    },
    itemMap() {
      return new Map(this.items.map(it => ([it.id, it])));
    }
  }
	
});
