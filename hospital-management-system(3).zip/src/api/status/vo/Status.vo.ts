import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { StatusDTO } from '@/api/status/dto/status.dto';


export class StatusVO {
	
	public id: number;
	public text: string;
	
	constructor(e: StatusDTO) {
	  this.id = e.id;
	  this.text = e.text;
	}
	
	public get item(): SelectorFormItemVO {
	  return new SelectorFormItemVO(this.id, this.text);
	}
	
	public static empty() {
	  return new StatusVO({
	    id: INVALID_ID,
	    name: '',
	    text: '',
	  });
	}
	
}
