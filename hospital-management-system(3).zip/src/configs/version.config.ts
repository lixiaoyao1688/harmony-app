export const IS_CLOSED_LOOP = true;  // 是否使用闭环版;
