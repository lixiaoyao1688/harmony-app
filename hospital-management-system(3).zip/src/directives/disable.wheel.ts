import { type App, type Directive, type DirectiveBinding } from 'vue';


/**
 * 自定义指令:
 * 禁止鼠标滚轮在输入框中调节数字。
 */
interface ExtendedHTMLElement extends HTMLElement {
  _disableWheelHandler?: (event: WheelEvent) => void
}

const disableWheel: Directive = {
  mounted(el: ExtendedHTMLElement, binding: DirectiveBinding) {
    const handler = (event: WheelEvent) => {
      // 使输入框失去焦点
      (event.target as HTMLElement).blur();
      
      // 可选：阻止默认行为和事件冒泡
      event.preventDefault();
      event.stopPropagation();
    };
    
    // 保存处理器引用以便卸载时使用
    el._disableWheelHandler = handler;
    
    // 添加事件监听器
    el.addEventListener('wheel', handler, { passive: false });
  },
  
  unmounted(el: ExtendedHTMLElement) {
    if (el._disableWheelHandler) {
      el.removeEventListener('wheel', el._disableWheelHandler);
      // 删除我们自定义的属性
      delete el._disableWheelHandler;
    }
  }
};

export function setupDisableWheelDirective(app: App) {
  app.directive('disable-wheel', disableWheel);
}
