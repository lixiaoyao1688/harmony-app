// TODO: 用 ~\src\lib\yesOrNo\config\yesOrNo.config.ts 替换;
export enum GLOBAL_YES_OR_NO {
	YES = 1,
	NO = 0,
}
