<script setup lang="ts">
import { onMounted, ref } from 'vue';
import { onBeforeRouteUpdate, useRoute } from 'vue-router';
import { DOM_HEADER_ID } from '@/lib/dom/config/dom.config';
import { isOnlineTest } from '@/lib/env/utils/env.domain.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useUserStore } from '@/modules/user/store/user.store';
import { useCardStore } from '@/modules/admission/store/card.store';
import { getHandleTripleClickFn } from '@/lib/action/action.util';
import HeaderMenu from '@/layout/HomeMenu.vue';
import IconLogo from '@/modules/user/icons/IconLogo.vue';
import UserView from '@/modules/user/views/UserView.vue';
import WarnList from '@/modules/warn/view/WarnList.vue';
import BoardView from '@/modules/board/views/BoardView.vue';
import SystemConfig from '@/modules/system-config/views/SystemConfig.vue';
import FullscreenView from '@/modules/fullscreen/views/FullscreenView.vue';


/**
 * 系统顶部工具栏 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  isLogin: boolean;  // 是否已登录
}


const route = useRoute();
const userStore = useUserStore();
const cardStore = useCardStore();
const screenStore = useScreenStore();
const activedName = ref<string>('');
const prop = defineProps<Prop>();
const isScreenShowed = ref<boolean>(false);
const width = ref<number>(window.innerWidth);
const height = ref<number>(window.innerHeight);
// 设备像素比: 物理像素(设备真实像素数)/CSS像素
// 如 dpr 为 2 时，1px 会动用 2 个物理像素来表示
const dpr = ref<number>(window.devicePixelRatio);

onMounted(() => {
  updateActiveName(route.name as string);
});

onBeforeRouteUpdate((to, from, next) => {
  updateActiveName(to.name as string);
  next();
});

function updateActiveName(name: string) {
  activedName.value = name;
}

const onCodeClick = getHandleTripleClickFn(() => {
  // if (!isOnlineTest()) {
  //   return;
  // }
  width.value = window.innerWidth;
  height.value = window.innerHeight;
  dpr.value = window.devicePixelRatio;
  isScreenShowed.value = !isScreenShowed.value;
});
</script>

<template>
  
  <div :id="DOM_HEADER_ID" class="flex bg-white" style="height: var(--header-height);">
    <div :class="{ 'pl-16': !screenStore.is4KOrAbove, 'pl-32': screenStore.is4KOrAbove }"
         class="h-full inline-flex items-center"
         @click="onCodeClick">
      <IconLogo :scale="screenStore.is4KOrAbove ? 2 : 1" />
      <div v-if="isScreenShowed" :style="{ fontSize: screenStore.is4KOrAbove ? '32px' : '16px' }"
           style="color: rgb(0,0,0);">{{ width }} * {{ height }} (dpr: {{ dpr }})</div>
      <span class=" text-black font-bold ml-24"
            :class="{ 'text-xxl-2': screenStore.is4KOrAbove, 'text-xl-normal': !screenStore.is4KOrAbove }"
            style="padding-bottom: 2px;">{{ userStore.user.relatedHospitalName }}</span>
    </div>
    <template v-if="isLogin">
      <HeaderMenu margin="0 0 0 120px" />
      <template v-if="userStore.user.isValid">
        <BoardView v-if="userStore.user.auth.hasPatientBoard" :margin="screenStore.is4KOrAbove ? '0 56px 0 0' : '0 24px 0 0'" />
        <WarnList v-if="userStore.user.auth.hasPatientWarn" :margin="screenStore.is4KOrAbove ? '0 32px 0 0' : '0 16px 0 0'" />
        <UserView />
      </template>
      <SystemConfig v-if="userStore.user.auth.hasSystemConfig" />
      <FullscreenView />
    </template>
    <div v-else class="flex-1 flex items-center justify-end">
      <FullscreenView />
    </div>
  </div>
  
</template>
