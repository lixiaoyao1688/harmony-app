<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { ROUTE_MAP } from '@/routers/global.router';
import { useUserStore } from '@/modules/user/store/user.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import HomeMenu from '@/layout/HomeMenu.vue';
import UserView from '@/modules/user/views/UserView.vue';
import BoardView from '@/modules/board/views/BoardView.vue';
import UserLogout from '@/modules/user/components/UserLogout.vue';
import IconLogoMobile from '@/modules/user/icons/IconLogoMobile.vue';
import DrawerMenu from '@/lib/aaruy-design/drawer/menu/DrawerMenu.vue';
import IconMenuMobileOpened from '@/modules/user/icons/IconMenuMobileOpened.vue';
import IconMenuMobileClosed from '@/modules/user/icons/IconMenuMobileClosed.vue';
import '@/lib/aaruy-design/drawer/menu/drawer.menu.style.css';


/**
 * 主界面顶部工具栏 界面
 *
 * 适用设备
 * 平板 && 手机;
 */
const route = useRoute();
const store = useUserStore();
const screenStore = useScreenStore();

const isDisappeared = ref<boolean>(true);   // 是否移除 drawer ( drawer 会遮挡后面元素，导致事件无法触发)
const menu = computed<string>(() => ROUTE_MAP.get(route.name as string) || '');
const isSmallPhone = computed<boolean>(() => screenStore.isNewSmallPhone);

watch(() => store.isMenuOpened, (_, isOldOpened) => {
  if (isOldOpened) {
    setTimeout(() => isDisappeared.value = true, 200);
  } else {
    isDisappeared.value = false;
  }
});

function onClose(): void {
  store.closeMenu();
}

function onTrigger(): void {
  if (store.isMenuOpened) {
    store.closeMenu();
  } else {
    store.openMenu();
  }
}
</script>

<template>
  <div class="w-full text-black bg-white flex items-center justify-between px-16"
       style="height: var(--header-height);">
    <div class="inline-flex items-center cursor-pointer h-full"
         :class="{ 'justify-between pr-16': store.isMenuOpened }"
         :style="{ width: isSmallPhone ? '200px' : '264px' }"
         @click="onTrigger">
      <template v-if="store.isMenuOpened"><IconLogoMobile /><IconMenuMobileOpened /></template>
      <template v-else>
        <IconMenuMobileClosed />
        <span class="ml-10 text-xl">{{ store.user.currentTab.tab }}</span>
      </template>
    </div>
    <BoardView v-if="store.user.auth.hasPatientBoard" :is-disabled="store.isMenuOpened" />
  </div>
  <div class="w-full overflow-hidden absolute text-center bg-transparent"
       :style="{ height: isDisappeared ? '1px' : 'calc(100% - var(--header-height))' }">
    <DrawerMenu :opened="store.isMenuOpened" width="280px" @close="onClose">
      <template #content>
        <div class="h-full">
          <UserView height="120px" />
          <HomeMenu height="calc(100% - 120px - 60px)" @ok="onClose" />
          <UserLogout height="60px" />
        </div>
      </template>
    </DrawerMenu>
  </div>
</template>
