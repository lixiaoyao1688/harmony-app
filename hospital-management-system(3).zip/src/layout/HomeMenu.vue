<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import { useRoute } from 'vue-router';
import { useUserStore } from '@/modules/user/store/user.store';
import { useCardStore } from '@/modules/admission/store/card.store';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useAdmissionStore } from '@/modules/admission/store/admission.store';
import router, { ROUTE_ABOUT_FOR_MOBILE, ROUTE_HOME, ROUTE_SYSTEM_CONFIG_FOR_MOBILE } from '@/routers/global.router';
import { useSystemManagerStore } from '@/modules/staff/store/system.manager.store';
import {UserVO} from '@/modules/user/vo/User.vo';
import {TabVO} from '@/lib/aaruy-design/tab/Tab.vo';
import AboutView from '@/modules/about/views/AboutView.vue';
import TabHeader from '@/lib/aaruy-design/tab/tab-header/TabHeader.vue';
import SystemConfig from '@/modules/system-config/views/SystemConfig.vue';


interface Prop {
  height?: string;  // 组件高度，仅mobile;
  margin?: string;  // 仅 pc;
}

interface Emit {
  (e: 'ok'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const route = useRoute();
const userStore = useUserStore();
const cardStore = useCardStore();
const screenStore = useScreenStore();
const admissionStore = useAdmissionStore();
const systemManagerStore = useSystemManagerStore();

const currentRoute = ref<string>('');  // 仅PC
const currentRoutes = ref<Array<string>>(['']);  // 仅PC

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => userStore.user.menus, (ms) => {
  const r = ms.length > 0 ? ms[0].key : ROUTE_HOME;
  currentRoute.value = r;
  currentRoutes.value = [r];
}, { immediate: false });

watch(() => route.name, (data) => {
  if (!screenStore.isPC) {
    return;
  }
  currentRoute.value = data as string;
}, { immediate: false });

function onPCRouteChange(name: string): void {
  currentRoute.value = name;
  router.push({ name: name });
  cardStore.growArea();
  admissionStore.unselect(pc.value, cardStore, true);
}

function onMobileTabChange(data: TabVO): void {
  if (UserVO.isValidMobileRouteKey(data.key)) {
    userStore.user.currentTab = data;
    router.push({ name: data.key });
  }
  userStore.closeMenu();
}
</script>

<template>
  
  <div v-if="pc" class="flex flex-end flex-1 h-full" :style="{ margin: margin }">
    <TabHeader :options="userStore.user.menus" :active-key="currentRoute"
               :use4-k-style="screenStore.is4KOrAbove"
               @change="onPCRouteChange" />
  </div>
  
  <ul v-if="mobile" :style="{ height: height }" class="px-16">
    <li v-for="m in userStore.user.menusMobile"
        :key="m.key"
        :class="{ 'bg-primary': m.key === userStore.user.currentTab.key }"
        style="height: 40px;"
        class="mx-16 px-16 flex items-center flex-start rounded-4"
        @click="onMobileTabChange(m)"
    >
      <AboutView v-if="m.key === ROUTE_ABOUT_FOR_MOBILE" />
      <SystemConfig v-else-if="m.key === ROUTE_SYSTEM_CONFIG_FOR_MOBILE" />
      <template v-else>
<!--        <span v-html="m.icon" class="inline-flex items-center justify-center" style="width: 20px; height: 20px;"></span>-->
        <span class="ml-10">{{ m.tab }}</span>
      </template>
    </li>
  </ul>
  
</template>
