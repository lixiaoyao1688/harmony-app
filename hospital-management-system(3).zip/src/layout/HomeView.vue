<script setup lang="ts">
import {computed, onBeforeMount, onMounted, onUnmounted, ref} from 'vue';
import {RouterView, useRoute, useRouter} from 'vue-router';
import {printApp, printSingle, sendErrorToServer} from '@/lib/log/util/log.util';
import {useUserStore} from '@/modules/user/store/user.store';
import {useGenderStore} from '@/api/gender/store/gender.store';
import {useDoctorStore} from '@/api/doctor/store/doctor.store';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {useGluKindStore} from '@/api/glu-kind/store/glu.kind.store';
import {useOperationStore} from '@/api/operation/store/operation.store';
import {useRelationshipStore} from '@/api/relationship/store/relationship.store';
import {useWsStore} from '@/lib/ws/store/ws.store';
import {useCardStore} from '@/modules/admission/store/card.store';
import {useAdmissionStore} from '@/modules/admission/store/admission.store';
import {useSchedulerStore} from '@/lib/scheduler/store/scheduler.store';
import {useDepartmentStore} from '@/modules/department/store/department.store';
import {useTemplateStore} from '@/modules/report/modules/template/store/template.store';
import {useAdviceCLStore} from '@/modules/advice-closed-loop/store/advice.cl.store';
import {logUrl} from '@/lib/http/util/http.utils';
import {isTesting} from '@/lib/env/utils/env.domain.util';
import {initMatomo} from '@/utils/matomo.util';
import {useStorageStore} from '@/lib/storage/store/storage.store';
import {doWorkAfterLogout} from '@/utils/global.tool';
import {LocalNotifications} from '@capacitor/local-notifications';
import {ROUTE_DEVICE, ROUTE_HISTORY, ROUTE_IN_PATIENT} from '@/routers/global.router';
import {LOG_COLOR} from '@/lib/log/dto/log.dto';
import HomeHeader from '@/layout/HomeHeader.vue';
import HomeHeaderMobile from '@/layout/HomeHeaderMobile.vue';
import SpinIndicator from '@/lib/aaruy-design/spin/indicator/SpinIndicator.vue';
import SpinMobile from '@/lib/aaruy-design/spin/SpinMobile.vue';
import AdmissionDetail from '@/modules/admission/components/AdmissionDetail.vue';
import {useWarnStore} from '@/modules/warn/store/warn.store';
import {onWarnClickBack, onWarnClickGo} from '@/modules/warn/util/warn.go.util';
import type {WarnDTO} from '@/modules/warn/dto/warn.dto';
import type {PluginListenerHandle} from '@capacitor/core';


/**
 * 主页 界面
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
const route = useRoute();
const router = useRouter();

const store = useCardStore();
const wsStore = useWsStore();
const userStore = useUserStore();
const screenStore = useScreenStore();
const storageStore = useStorageStore();
const admissionStore = useAdmissionStore();
const schedulerStore = useSchedulerStore();
const warnStore = useWarnStore();
const adviceStore = useAdviceCLStore();

const isOpened = ref<boolean>(false);
const isUserLoading = ref<boolean>(false);
const isUserLoaded = ref<boolean>(false);
const isRouteLoading = ref<boolean>(false);
const notificationHandler = ref<PluginListenerHandle | null>(null);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

let loopTimer: number | null = null;
let isProcessing = false;  // 是否顺序执行任务中


onBeforeMount(() => {
  const isPC = screenStore.isPC;
  if (isPC) {
    if (isTesting()) {
      logUrl(true);
    }
    fire();
  }
  else {
    storageStore
      .hasMobileDomain()
      .then(hasDomain => {
        if (hasDomain) {
          fire();
        }
        else {
          doWorkAfterLogout();
        }
      });
  }
});

onMounted(() => {
  listenDocumentVisibility();
  if (screenStore.isMobile) {
    // 对应: @src\modules\warn\store\warn.store.ts: notify: extra
    LocalNotifications
      .addListener('localNotificationActionPerformed', (action) => {
        printApp('提示数据', action);
        const data = action.notification.extra as WarnDTO | null;
        if (data) {
          isOpened.value = true;
          onWarnClickGo(data, warnStore, admissionStore, adviceStore);
        }
      })
      .then(data => {
        notificationHandler.value = data;
      });
  }
});

onUnmounted(() => {
  stopEventLoop();
  wsStore.off();
  if (screenStore.isMobile && notificationHandler.value) {
    notificationHandler.value.remove();
  }
});

function fire() {
  isUserLoading.value = true;
  isUserLoaded.value = false;
  userStore
    .fetchUser()
    .then(async user => {
      isUserLoading.value = false;
      isUserLoaded.value = true;
      isRouteLoading.value = true;
      initMatomo(`${user.relatedHospitalName}-${user.name}-${user.id}`);
      if (pc.value) {
        startEventLoop();
      }
      const route = pc.value ? user.indexRoute : user.indexRouteOnMobile;
      const isApiNeeded = route === ROUTE_DEVICE || route === ROUTE_HISTORY;  // 需要提前加载 api;
      if (isApiNeeded) {
        await initApiStore();
      }
      router
        .push({name: route})
        .then(() => {
          isRouteLoading.value = false;
          if (!isApiNeeded) {
            // 院泵患者界面内部会按科室类型请求列表，此处不可提前请求，以免造成"可能的覆盖"。
            initApiStore(screenStore.isPC && route === ROUTE_IN_PATIENT);
          }
        });
    })
    .finally(() => {
      isUserLoading.value = false;
    });
}

function initApiStore(isPartNotNeeded?: boolean): Promise<void> {
  const isPC = useScreenStore().isPC;
  return new Promise<void>(resolve => {
    const ps: Array<Promise<null>> = [];
    if (!isPartNotNeeded) {
      ps.push(useDepartmentStore().init());
    }
    ps.push(
      useDoctorStore().init(),
      // useNurseStore().init(),
      useGenderStore().init(),
      useGluKindStore().init(),
      useRelationshipStore().init(),
      // useStatusStore().init(),
    );
    if (isPC) {
      useOperationStore().init();
      useTemplateStore().fetch(0);
    }
    Promise.allSettled(ps)
      .then(_ => {
        resolve();
      })
      .catch(reason => {
        sendErrorToServer('[ERROR][initApiStore]', reason, 'mounted', 'HomeView.vue');
      });
  });
}

function startEventLoop(): void {
  loopTimer = setInterval(() => {
    if (isProcessing || schedulerStore.queue.isEmpty) {
      // "顺序任务正在执行" 或 "队列中无任务"，返回。
      return;
    }
    isProcessing = true;
    schedulerStore
      .processOrder()
      .finally(() => {
        isProcessing = false;
      });
  }, 200) as unknown as number;
}

function stopEventLoop(): void {
  if (loopTimer) {
    clearInterval(loopTimer);
  }
}

function listenDocumentVisibility(): void {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      printSingle('[页面隐藏] 停止接收除报警外的数据.', LOG_COLOR.WARN);
    } else {
      printSingle('[页面恢复] 重新获取数据...', LOG_COLOR.NORMAL);
      store.findWhenYouComeBack();
    }
  });
}

function onClose(): void {
  isOpened.value = false;
  onWarnClickBack(warnStore, admissionStore, adviceStore);
}
</script>

<template>
  <div :class="{ 'pc-4k': screenStore.is4KOrAbove }" class="w-screen h-screen overflow-hidden text-white bg-0">
    <template v-if="pc">
      <HomeHeader :isLogin="true" />
      <div class="relative" style="height: calc(100vh - var(--header-height));">
        <!--  --warn-height: 40px; height: calc((100% - 40px) / 2);  -->
        <div v-if="isUserLoading" style="height: 50%;" class="flex items-center justify-center">
          <SpinIndicator tip="正在获取用户信息，请稍候..."
                         :font-size="screenStore.is4KOrAbove ? '48px' : null"
                         color="rgb(105,158,245)" />
        </div>
        <template v-else-if="userStore.user.isIndexRouteValidOnPC">
          <div v-if="isRouteLoading" style="height: 50%;" class="flex items-center justify-center">
            <SpinIndicator tip="正在加载资源..."
                           :font-size="screenStore.is4KOrAbove ? '48px' : null"
                           color="rgb(105,158,245)" />
          </div>
          <RouterView v-else />
        </template>
        <div v-else
             :class="{ 'text-xxl': !screenStore.is4KOrAbove, 'text-xxxl': screenStore.is4KOrAbove }"
             class="text-center text-weak-2 font-bold pt-100">当前用户不具备查看任何菜单的权限，请联系管理员增加权限。</div>
      </div>
    </template>
    <template v-else>
      <HomeHeaderMobile />
      <div style="height: calc(100vh - var(--header-height));">
<!--        <SpinMobile v-if="isUserLoading" icon-size="24px" :text-size="20" tip="加载用户..." :loading="isUserLoading" height="50%" />-->
        <SpinMobile v-if="isUserLoading" icon-size="24px" :text-size="20" tip="加载用户..." :loading="isUserLoading" height="400px" />
        <RouterView v-else-if="userStore.user.isIndexRouteValidOnMobile" />
        <div v-else class="text-center text-weak-2 text-lg" style="height: 200px; line-height: 200px;">无患者管理权限</div>
      </div>
      <AdmissionDetail v-if="isUserLoaded" :visible-mobile="isOpened" @close="onClose" />
    </template>
  </div>
</template>

<style scoped>
.pc-4k {
  --header-height: 128px;
}
</style>
