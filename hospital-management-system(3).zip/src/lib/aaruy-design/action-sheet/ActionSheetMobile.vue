<script setup lang="ts">
import IconCloseActionSheetMobile from '@/lib/aaruy-design/action-sheet/IconCloseActionSheetMobile.vue';
import '@/lib/aaruy-design/action-sheet/action.sheet.mobile.style.css';


interface Prop {
  visible: boolean;
}

interface Emit {
  (e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function close() {
  emit('close');
}
</script>

<template>
  <van-action-sheet class="action-sheet-mobile-container" :show="visible" :closeable="false" @close="close" @click-overlay.stop>
    <template #default>
      <div class="action-sheet-mobile" @click.stop>
        <div class="action-sheet-mobile-header">
          <div class="action-sheet-mobile-header-title">
            <slot name="title"></slot>
          </div>
          <IconCloseActionSheetMobile class="absolute" style="top: 16px; right: 16px;" @click.stop="close" />
        </div>
        <slot name="content"></slot>
      </div>
    </template>
  </van-action-sheet>
</template>

<style scoped>
.action-sheet-mobile {
  color: rgb(255, 255, 255);
  background-color: rgb(58, 68, 77);
}

.action-sheet-mobile > .action-sheet-mobile-header {
  display: flex;
  align-items: center;
  padding: 0 16px;
  height: 54px;
  border-bottom: 1px solid rgb(91, 103, 116);
}

.action-sheet-mobile > .action-sheet-mobile-header > .action-sheet-mobile-header-title {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
	font-weight: 700;
}
</style>
