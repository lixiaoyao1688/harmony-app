<template>
  <svg id="iconCloseActionSheetMobile" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <path id="iconCloseActionSheetMobilePath1" data-name="路径 2507" d="M0,0H20V20H0Z" fill="rgba(255,0,51,0)"/>
    <path id="iconCloseActionSheetMobilePath2" data-name="路径 2508" d="M171.318,157.989l.045.042,5.605,5.608,5.4-5.4a.825.825,0,0,1,1.209,1.122l-.041.045-5.4,5.4,5.4,5.4a.825.825,0,0,1-1.121,1.21l-.045-.042-5.4-5.4-5.605,5.609a.825.825,0,0,1-1.209-1.122l.042-.045,5.606-5.609L170.2,159.2a.825.825,0,0,1,1.121-1.209Z" transform="translate(-166.558 -154.638)" fill="#fff"/>
  </svg>
</template>