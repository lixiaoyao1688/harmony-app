<script setup lang="ts">
import { MedicineVO } from '@/modules/medicine/vo/Medicine.vo';
import '@/lib/aaruy-design/auto-complete/auto.complete.style.css';


interface Prop {
	options: Array<MedicineVO>;
	placeholder?: string;
}

interface Emit {
	(e: 'search', data: string): void;
	(e: 'select', data: MedicineVO): void;
	(e: 'blur'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function search(val: string): void {
  emit('search', val);
}

function blur(): void {
  emit('blur');
}

function onSelect(it: MedicineVO): void {
  emit('select', it);
}
</script>

<template>
	<a-auto-complete
		:dropdown-match-select-width="252"
		:options="options"
		style="width: 382px; height: 40px;"
		class="aaruy-auto-complete"
		dropdownClassName="aaruy-auto-complete-dropdown"
		@blur="blur"
	>
		<template #option="item">
			<div @click="onSelect(item)">{{ item.text }}</div>
		</template>
		<a-input-search size="large" :placeholder="placeholder || '请输入'" @search="search">
			<template #enterButton>
				<span class="text-s leading-xs" style="letter-spacing: normal; margin: 0;">搜索</span>
			</template>
		</a-input-search>
	</a-auto-complete>
</template>
