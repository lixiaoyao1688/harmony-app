<script setup lang="ts">
import {ref, watch} from 'vue';
import '@/lib/aaruy-design/auto-complete/style/auto.complete.frame.style.css';
import '@/lib/aaruy-design/auto-complete/style/auto.complete.common.style.css';
import '@/lib/aaruy-design/select/frame/select.dropdown.frame.style.css';
import type {AutoCompleteOption} from '@/lib/aaruy-design/auto-complete/type/auto.complete.type';


/**
 * 自动完成 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  data: string;  // 输入内容，仅用于清除 value 的值
  options: Array<AutoCompleteOption>;
  width?: string;
  height?: string;
  placeholder?: string;
  useFrameStyle?: boolean;
}

interface Emit {
	(e: 'search', keywords: string): void;
	(e: 'change', data: AutoCompleteOption): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref('');


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function search(keywords: string): void {
  emit('search', keywords);
}

function focus(): void {
  emit('search', value.value);
}

function select(_, data: AutoCompleteOption): void {
  value.value = data.label;
  emit('change', data);
}
</script>

<template>
  <a-auto-complete
    v-model:value="value"
    :options="options"
    class="aaruy-auto-complete"
    :class="{ 'aaruy-auto-complete-frame': useFrameStyle }"
    :style="{ width: width || '100%', height: height || '100%' }"
    :dropdownClassName="useFrameStyle ? 'select-frame-dropdown' : null"
    :placeholder="placeholder"
    @select="select"
    @search="search"
    @focus="focus"
  >
    <template #option="{ label }">
      {{ label }}
    </template>
  </a-auto-complete>
</template>
