import {INVALID_ID} from '@/utils/global.vo.help';
import type {AutoCompleteOption} from '@/lib/aaruy-design/auto-complete/type/auto.complete.type';


export const EMPTY_AUTO_COMPLETE: AutoCompleteOption = {
  value: INVALID_ID,
  label: ''
};
