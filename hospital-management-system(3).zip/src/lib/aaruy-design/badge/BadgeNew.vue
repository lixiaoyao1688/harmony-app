<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { BADGE_OVERFLOW_COUNT } from '@/lib/aaruy-design/badge/config/badge.config';


/**
 * 徽标数 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  count: number;  // 展示的数字，大于 overflowCount 时显示为 ${overflowCount}+，为 0 时隐藏;
  overflowCount?: number;  // 封顶的数字值, 默认 99;
  top?: string;  // 默认 -6px;
  isLeft?: boolean;  // 是否展示在左边（仅pc，移动端默认在左边）
  use4KStyle?: boolean;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

const MAX = prop.overflowCount || BADGE_OVERFLOW_COUNT;
const tips = computed<string>(() => prop.count > MAX ? `${MAX}+` : prop.count.toString());
const left = computed<string>(() => prop.count < 10 ? '-12px' : (prop.count <= MAX ? '-16px' : '-24px'));
const leftFor4K = computed<string>(() => prop.count < 10 ? '-16px' : (prop.count <= MAX ? '-32px' : '-48px'));
const leftOnMobile = computed<string>(() => prop.count < 10 ? '-10px' : (prop.count <= MAX ? '-16px' : '-24px'));
const right = computed<string>(() => prop.count < 10 ? '-12px' : (prop.count <= MAX ? '-16px' : '-20px'));
const padding = computed<string>(() => prop.count <= MAX ? '0 8px' : '0 4px 0 8px');
const paddingFor4K = computed<string>(() => prop.count <= MAX ? '0 16px' : '0 8px 0 16px');
</script>

<template>
  <div v-if="pc"
       class="inline-flex items-center justify-center bg-warn-0 text-white font-bold px-4 absolute"
       :class="{
         'aaruy-hidden': count === 0,
         'text-xs': !use4KStyle,
         'text-xl-1': use4KStyle,
       }"
       :style="{
         left: isLeft ? (use4KStyle ? leftFor4K : left) : null,
         right: isLeft ? null : right,
         top: top || '-6px',
         padding: use4KStyle ? paddingFor4K : padding,
         height: use4KStyle ? '40px' : '20px',
         borderRadius: use4KStyle ? '20px' : '10px'
       }">{{ tips }}</div>
  <div v-else
       class="inline-block rounded-10 bg-warn-0 text-white text-xxs leading-xs-2 font-bold px-6 absolute"
       style="height: 17px; line-height: 14px;"
       :class="{ 'aaruy-hidden': count === 0 }"
       :style="{
         top: top || '-6px',
         left: leftOnMobile || '0'
       }"
  >{{ tips }}</div>
</template>
