<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/badge/badge.number.style.css';


/**
 * 徽标数 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  count: number;
  width?: string;  // 仅PC
  overflowCount?: number;  // 封顶数字, 超过则显示为 overflowCount+，默认 999
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);

const MAX_COUNT = 999;
</script>

<template>
  <a-badge v-if="pc"
           class="badge-number-pc"
           :count="count"
           :overflow-count="overflowCount || MAX_COUNT"
           :style="{ width: width || '100%' }"
           title=""
           color="rgb(247,58,63)">
    <slot></slot>
  </a-badge>
  <van-badge v-else :content="count"
             position="top-left"
             :show-zero="false"
             :offset="[0,5]"
             :max="overflowCount || MAX_COUNT"
             class="badge-number-app"
             color="var(--aaruy-warn-color-0)">
    <slot></slot>
  </van-badge>
</template>
