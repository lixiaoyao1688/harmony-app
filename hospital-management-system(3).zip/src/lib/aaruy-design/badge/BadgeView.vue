<script setup lang="ts">
interface Prop {
	type: 'default';
	text: string;
}

defineProps<Prop>();
</script>

<template>
  <div class="ar-badge">
		<span class="ar-badge-word">{{ text }}</span>
	</div>
</template>

<style scoped>
.ar-badge {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: fit-content;
}

.ar-badge-word {
	height: 24px;
	line-height: 24px;
	border-radius: 4px;
	text-align: center;
	color: var(--aaruy-text-color);
	background-color: var(--aaruy-primary-color-1);
	padding: 0 15px;
}
</style>