<script setup lang="ts">
import { computed, ref } from 'vue';
import TooltipDefault from '@/lib/aaruy-design/tooltip/default/TooltipDefault.vue';


interface Prop {
	title: string;
	value: string;
	disabled?: boolean;
	color?: string;
	showIcon?: string;
}


const prop = defineProps<Prop>();
const visible = ref<boolean>(false);
const tooltipTitle = computed<string>(() => prop.title + ': ' + prop.value);


function onVisibleChange(data: boolean): void {
  visible.value = data;
}
</script>

<template>
  <div class="inline-flex items-center">
		<template v-if="showIcon">
			<TooltipDefault :title="tooltipTitle" :visible="visible" placement="bottom" @visible-change="onVisibleChange">
				<slot></slot>
			</TooltipDefault>
		</template>
		<template v-else>
			<span class="text-lg leading-l font-bold mr-12">{{ title }}</span>
		</template>
		<span
			class="text-xl leading-xl inline-block text-center border-4"
			style="width: 60px; height: 32px; line-height: 32px;"
			:style="{ backgroundColor: color || 'rgb(49,76,121)' }"
		>{{ disabled ? '--' : value }}</span>
	</div>
</template>
