<script setup lang="ts">
interface Prop {
	words: string;
	rgb: [number,number,number];
  hideBorder?: boolean;
  margin?: string;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="inline-flex items-center justify-center border-4 text-xxs" style="width: 60px; height: 24px;"
      :style="{
        margin: margin,
        color: `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`,
        backgroundColor: `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.15)`,
        border: hideBorder ? null : `1px solid rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.6)`,
      }">{{ words }}</div>
</template>
