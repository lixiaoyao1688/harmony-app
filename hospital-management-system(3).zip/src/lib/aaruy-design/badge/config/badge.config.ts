export const BADGE_OVERFLOW_COUNT = 99;
