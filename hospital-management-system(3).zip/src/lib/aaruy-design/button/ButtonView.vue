<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import TooltipDark from '@/lib/aaruy-design/tooltip/dark/TooltipDark.vue';
import '@/lib/aaruy-design/button/button.style.css';
import type { ButtonType } from '@/lib/aaruy-design/button/button.type';


interface Prop {
	type: ButtonType;
	text?: string;
	loading?: boolean;
	disabled?: boolean;
  disabledTips?: string;  // 按钮禁用状态下，鼠标移上去的提示，仅"disabled为true"且"PC端"可用
  useFont18?: boolean;
  useFont32?: boolean;  // 仅PC且非disabledTips
  isTextRotate90?: boolean;  // 文字是否顺时针旋转90度，用于横置屏幕时阅读按钮文字，仅 mobile;
  isBg10Primary2?: boolean;  // 是否启用此特殊样式，仅 type 为 default 时可用;
  isBg12Primary2?: boolean;  // 是否启用此特殊样式，仅 type 为 default 且 mobile 时可用;
  isBg12?: boolean;  // 是否启用此特殊样式，仅 type 为 primary 且 mobile 时可用;
}

interface Emit {
	(e: 'click'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const isDefault = computed<boolean>(() => prop.type === 'default');
const isPrimary = computed<boolean>(() => prop.type === 'primary');
const isPrimaryBordered = computed<boolean>(() => prop.type === 'primary-bordered');
const isDefaultPrimary = computed<boolean>(() => prop.type === 'default-primary');
const isDefaultPrimary2 = computed<boolean>(() => prop.type === 'default-primary-2');
const innerText = computed<string>(() => prop.text || '');

function onClick(): void {
  emit('click');
}
</script>

<template>
  
  <template v-if="screenStore.isPC">
    <!-- 启用禁用状态提示的情况，加上文字提示组件	-->
    <TooltipDark v-if="disabledTips" :title="disabledTips" placement="left">
      <a-button v-bind="$attrs"
                class="ar-btn ar-btn-text"
                :type="type"
                :loading="loading"
                :disabled="disabled"
                :class="{
                  'ar-btn-default': isDefault,
                  'ar-btn-primary': isPrimary,
                  'ar-btn-default-primary': isDefaultPrimary,
                  'ar-btn-default-primary-2': isDefaultPrimary2,
                  'use-font18': useFont18,
                  'bg-10-and-hover-primary-2': isBg10Primary2,
                }"
                @click="onClick">
        <template #icon><slot name="icon"></slot></template>
        <template v-if="innerText">{{ innerText }}</template>
        <template v-else>
          <slot name="complexContent"></slot>
        </template>
      </a-button>
    </TooltipDark>
    <a-button v-else
      v-bind="$attrs"
      class="ar-btn ar-btn-text"
      :type="type"
      :loading="loading"
      :disabled="disabled"
      :class="{
			'ar-btn-default': isDefault,
			'ar-btn-primary': isPrimary,
			'ar-btn-default-primary': isDefaultPrimary,
			'ar-btn-default-primary-2': isDefaultPrimary2,
			'use-font18': useFont18,
			'use-font32': useFont32,
			'bg-10-and-hover-primary-2': isBg10Primary2,
		}"
      @click="onClick"
    >
      <template #icon><slot name="icon"></slot></template>
      <template v-if="innerText">{{ innerText }}</template>
      <template v-else>
        <slot name="complexContent"></slot>
      </template>
    </a-button>
  </template>
  <van-button
    v-else
    v-bind="$attrs"
    class="ar-btn mobile-ar-btn text-xs"
    :type="type"
    :loading="loading"
    :disabled="disabled"
    :loading-text="innerText"
    :class="{
      'ar-btn-default': isDefault,
      'ar-btn-primary': isPrimary,
      'ar-btn-default-primary': isDefaultPrimary,
      'ar-btn-primary-bordered': isPrimaryBordered,
      'ar-btn-text-rotate-90': isTextRotate90,
      'bg-12-and-hover-primary-2': isBg12Primary2,
      'bg-12': isBg12,
    }"
    @click="onClick"
  >
    <template #icon><slot name="icon"></slot></template>
    <template v-if="innerText">{{ innerText }}</template>
    <template v-else>
      <slot name="complexContent"></slot>
    </template>
  </van-button>
  
</template>

<style scoped>
.ar-btn.ant-btn[disabled],
.ar-btn.ant-btn[disabled]:hover,
.ar-btn.ant-btn[disabled]:focus,
.ar-btn.ant-btn[disabled]:active {
	color: rgba(0, 0, 0, 0.25) !important;
	background-color: rgb(245,245,245) !important;
}

.ar-btn.ant-btn.ar-btn-default[disabled],
.ar-btn.ant-btn.ar-btn-default[disabled]:hover,
.ar-btn.ant-btn.ar-btn-default[disabled]:focus,
.ar-btn.ant-btn.ar-btn-default[disabled]:active {
  color: var(--aaruy-weak-text-color-7) !important;
  background-color: var(--aaruy-default-color-1) !important;
}

.ar-btn.ant-btn.ar-btn-default-primary[disabled],
.ar-btn.ant-btn.ar-btn-default-primary[disabled]:hover,
.ar-btn.ant-btn.ar-btn-default-primary[disabled]:focus,
.ar-btn.ant-btn.ar-btn-default-primary[disabled]:active {
	color: var(--aaruy-weak-text-color) !important;
	background-color: var(--aaruy-text-color-2) !important;
	opacity: 0.7;
}

.ar-btn {
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 0;
	border: none;
	border-radius: 4px;
}
.ar-btn,
.ar-btn:hover,
.ar-btn:focus {
	color: var(--aaruy-text-color);
}
.ar-btn.ar-btn-text {
	font-size: 16px;
}
.use-font18.ar-btn.ar-btn-text {
  font-size: 18px;
}
.use-font32.ar-btn.ar-btn-text {
  font-size: 32px;
}

.ar-btn-default,
.ar-btn-default:not(.mobile-ar-btn):focus {
	background-color: var(--aaruy-default-color-1);
}
.ar-btn-default:not(.mobile-ar-btn):hover,
.ar-btn-default:active {
	background-color: var(--aaruy-default-color-2) !important;
}

.ar-btn-default.bg-10-and-hover-primary-2,
.ar-btn-default.bg-10-and-hover-primary-2:not(.mobile-ar-btn):focus {
  background-color: var(--aaruy-bg-color-10);
}
.ar-btn-default.bg-12-and-hover-primary-2,
.ar-btn-default.bg-12-and-hover-primary-2:not(.mobile-ar-btn):focus {
  background-color: var(--aaruy-bg-color-12);
}
.ar-btn-default:not(.mobile-ar-btn):hover,
.ar-btn-default:active {
  background-color: var(--aaruy-primary-color-2) !important;
}
.ar-btn-default.bg-12-and-hover-primary-2.van-button--disabled:hover,
.ar-btn-default.bg-12-and-hover-primary-2.van-button--disabled:active {
  background-color: var(--aaruy-bg-color-12) !important;
}


.ar-btn-primary,
.ar-btn-primary.ant-btn-loading:hover,
.ar-btn-primary.van-button--loading:hover {
	background-color: var(--aaruy-primary-color-1);
}
.ar-btn.ant-btn.ar-btn-primary:not(.ant-btn-loading):not(.van-button--loading):hover,
.ar-btn.ant-btn.ar-btn-primary:not(.ant-btn-loading):not(.van-button--loading):active {
	background-color: var(--aaruy-primary-color-2);
}
.ar-btn.ant-btn.ar-btn-primary[disabled] {
	background-color: rgb(163, 175, 188) !important;
	color: rgb(255,255,255) !important;
	opacity: 0.5 !important;
}


.ar-btn-primary.bg-12,
.ar-btn-primary.bg-12.ant-btn-loading:hover,
.ar-btn-primary.bg-12.van-button--loading:hover {
  color: var(--aaruy-primary-color-6);
  background-color: var(--aaruy-bg-color-12);
}




.ar-btn-primary-bordered,
.ar-btn-primary-bordered:focus {
  background-color: transparent;
  color: var(--aaruy-primary-color-1);
  border: 1px solid var(--aaruy-primary-color-1);
}
.ar-btn-primary-bordered.ant-btn-loading:hover,
.ar-btn-primary-bordered.van-button--loading:hover {
  background-color: transparent;
  color: var(--aaruy-primary-color-2);
  border-color: var(--aaruy-primary-color-2);
}
.ar-btn.ant-btn.ar-btn-primary-bordered:not(.ant-btn-loading):not(.van-button--loading):hover,
.ar-btn.ant-btn.ar-btn-primary-bordered:not(.ant-btn-loading):not(.van-button--loading):active {
  color: var(--aaruy-primary-color-2);
  border-color: var(--aaruy-primary-color-2);
}




.ar-btn-default-primary,
.ar-btn-default-primary:focus {
	background-color: var(--aaruy-default-color-1);
}
.ar-btn-default-primary:hover,
.ar-btn-default-primary:active {
	background-color: var(--aaruy-primary-color-2) !important;
}

.ar-btn-default-primary-2 {
	display: inline-flex;
}

.ar-btn-default-primary-2,
.ar-btn-default-primary-2:focus {
	background-color: var(--aaruy-bg-color-2);
}
.ar-btn-default-primary-2:hover,
.ar-btn-default-primary-2:active {
	background-color: var(--aaruy-primary-color-2) !important;
}
</style>
