export type ButtonType = 'default' | 'primary' | 'default-primary' | 'default-primary-2' | 'primary-bordered';
