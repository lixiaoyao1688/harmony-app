<script setup lang="ts">
import { computed, ref } from 'vue';
import { MS_PER_SECOND } from '@/lib/time/config/time.config';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


interface Prop {
  isWaiting: boolean;  // 是否等待重试中
  isSending: boolean;  // 是否正在发送请求
  text: string;
}

interface Emit {
  (e: 'send'): void;
  (e: 'stopWaiting'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const INTERVAL = 60;  // 发送后等待重试的时间(秒)
const count = ref<number>(INTERVAL);
const tips = computed<string>(() => count.value + '秒后重试');

let timer: any = null;


function send(): void {
  if (prop.isWaiting) {
    return;
  }
  emit('send');
  timer = setInterval(() => {
    if (count.value === 0) {
      count.value = INTERVAL;
      emit('stopWaiting');
      clearInterval(timer);
      return;
    }
    count.value--;
  }, MS_PER_SECOND);
}
</script>

<template>
  <ButtonView type="primary"
              :loading="isSending"
              :disabled="isWaiting"
              style="height: 40px; margin-left: 10px; padding: 0 16px;"
              @click="send">
    <template #complexContent>
      {{ isWaiting ? tips : text }}
    </template>
  </ButtonView>
</template>
