<script setup lang="ts">
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


interface Prop {
	text?: string;
}

interface Emit {
	(e: 'click'): void
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClick() {
  emit('click');
}
</script>

<template>
	<ButtonView :text="text" type="primary" class="ar-btn-plain" @click="onClick">
		<template #icon><slot name="icon"></slot></template>
	</ButtonView>
</template>

<style>
.ar-btn-plain {
	background-color: transparent !important;
	color: rgb(105,158,245) !important;
	border: 1px solid rgb(105,158,245) !important;
	display: flex !important;
	align-items: center !important;
	justify-content: center !important;
	border-radius: 25% !important;
}

.ar-btn-plain:hover,
.ar-btn-plain:focus,
.ar-btn-plain:active {
	background-color: transparent !important;
	color: rgb(105,158,245) !important;
}
</style>
