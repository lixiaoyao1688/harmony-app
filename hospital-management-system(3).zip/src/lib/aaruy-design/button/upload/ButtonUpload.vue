<script setup lang="ts">
import { computed, ref } from 'vue';
import { sendErrorToServer } from '@/lib/log/util/log.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


interface Prop {
	text?: string;
	loading?: boolean;
}

interface Emit {
  (e: 'change', file: File): void;
}

const emit = defineEmits<Emit>();
const prop = defineProps<Prop>();
const screenStore = useScreenStore();

const inputer = ref<HTMLInputElement | null>();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function change(e) {
  if (!e || !e.target || !e.target.files || !e.target.files[0]) {
    sendErrorToServer('[Button Upload]', '读取文件失败', '', 'ButtonUpload.vue');
    return;
  }
  emit('change', e.target.files[0]);
}

function open() {
  if (!inputer.value) {
    return;
  }
  inputer.value.click();
}

</script>


<template>
  <div class="uploader">
    <input type="file" ref="inputer" @change="change" hidden />
		<ButtonView type="primary" :text="text" :loading="loading" class="uploader-btn" @click="open">
			<template #icon><slot name="icon"></slot></template>
		</ButtonView>
  </div>
</template>

<style>
.uploader-btn {
	height: 32px;
	padding: 0 16px !important;
}
</style>
