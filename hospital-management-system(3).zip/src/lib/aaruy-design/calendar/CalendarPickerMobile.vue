<script setup lang="ts">
import { computed, ref } from 'vue';
import { getTodayTimestamp } from '@/lib/time/util/time.util';
import { notifyError } from '@/lib/aaruy-design/notify/notify';
import { ONE_DAY_TIME_STAMP } from '@/lib/time/config/time.config';
import { DEFAULT_RANGE_DAYS } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import IconCalendar from '@/lib/icon/IconCalendar.vue';
import IconArrowLeft1 from '@/modules/admission/icons/IconArrowLeft.vue';
import IconArrowRight1 from '@/modules/admission/icons/IconArrowRight1.vue';
import '@/lib/aaruy-design/calendar/calendar.picker.mobile.style.css';


interface Prop {
	type: 'single' | 'range';
	date?: Date;
	range?: [Date, Date];
	step?: boolean;   // 是否展示前一天/后一天 (仅 single 有效)
  maxRange?: number;  // 仅 type === 'range' 时生效，可选的最大范围，默认7，单位:天;
  padding?: string;  // 默认 px-32
  height?: string;  // 默认 h-32-px
  width?: string;
}

interface Emit {
	(e: 'change', date: Date): void;
	(e: 'rangeChange', range: [Date, Date]): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const visible = ref<boolean>(false);
const words = computed<string>(() => prop.range ? prop.range.map(date => formatDate(date)).join(' - ') : formatDate(prop.date as Date));
const innerMaxRange = computed<number>(() => prop.maxRange ? prop.maxRange : DEFAULT_RANGE_DAYS);
const maxDate = new Date(getTodayTimestamp(0,0,0,0));  // 范围选择的情况下，如果限制日期则可能无法跳转下一页

function formatDate(date: Date): string {
  return `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
}

function confirm(data: Date | [Date, Date]): void {
  if (prop.type === 'single') {
    visible.value = false;
    emit('change', data as Date);
  }
  else {
    if (data[1].getTime() > maxDate.getTime()) {
      notifyError('结束日期不得超过今日');
      return;
    }
    visible.value = false;
    emit('rangeChange', data as [Date, Date]);
  }
}

function goStep(type: 'last' | 'next'): void {
  if (!prop.date) {
    return;
  }
  const date = new Date(prop.date.getTime() + (type === 'last' ? (-ONE_DAY_TIME_STAMP) : ONE_DAY_TIME_STAMP));
  if (date.getTime() > new Date().getTime()) {
    notifyError('搜索的日期不得超过今天！');
    return;
  }
  emit('change', date);
}
</script>

<template>
	<div class="flex items-center justify-between"
       :class="{ 'h-32-px': !height, 'rounded-4 bg-2 hover-primary miw-240': type === 'range' }"
       :style="{ height: height, width: width }"
  >
		<span v-if="type === 'single' && step" class="flex items-center pr-12 active-text-primary-1 active-svg-path-primary-1"
          @click="goStep('last')"><IconArrowLeft1 />前一天</span>
		<div :class="{ 'px-32': !padding }"
         :style="{ padding: padding }"
         class="h-100 flex-1 bg-2 flex items-center justify-center border-4 text-white text-xs hover-primary rounded-4"
         @click="visible = true">
			<IconCalendar />
			<span class="ml-12">{{ words }}</span>
		</div>
		<span v-if="type === 'single' && step"  class="flex items-center pl-12 active-text-primary-1 active-svg-path-primary-1"
          @click="goStep('next')">后一天<IconArrowRight1 /></span>
	</div>
	
	<van-calendar
		v-model:show="visible"
		:type="type"
		:default-date="type === 'single' ?  date : range"
		:show-confirm="false"
		:max-date="type === 'range' ? null: maxDate"
		:max-range="type === 'range' ? innerMaxRange : null"
		switch-mode="month"
		class="calendar-picker-mobile"
		@confirm="confirm"
	/>
</template>
