<script setup lang="ts">
import dayjs, {Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import '@/lib/aaruy-design/calendar/calendar.picker2.mobile.style.css';
import type {CalendarRangePickerPayloadType} from '@/lib/aaruy-design/calendar/calendar.range.picker.type';


/**
 * 日期范围选择器 组件
 *
 * 样式
 * 日历
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: CalendarRangePickerPayloadType;
  maxRange: number;
  maxDay0?: Dayjs;  // 第1个选择器可选择的最大时间
  maxDay1?: Dayjs;  // 第2个选择器可选择的最大时间
}

interface Emit {
	(e: 'change', data: CalendarRangePickerPayloadType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const visible0 = ref<boolean>(false);
const visible1 = ref<boolean>(false);

const date0 = ref<Date | null>(getInnerDate(prop.data, 0));
const date1 = ref<Date | null>(getInnerDate(prop.data, 1));
const value0Text = computed<string>(() => getText(date0.value, 0));
const value1Text = computed<string>(() => getText(date1.value, 1));

const maxDate0 = ref<Date | null>(prop.maxDay0 ? prop.maxDay0.toDate() : null);
const maxDate1 = ref<Date | null>(prop.maxDay1 ? prop.maxDay1.toDate() : null);


watch(() => prop.data, (data) => {
  date0.value = getInnerDate(data, 0);
  date1.value = getInnerDate(data, 1);
}, { immediate: true });

function getText(data: Date | null, i: 0 | 1): string {
  if (data === null) {
    return i === 0 ? '开始日期' : '结束日期';
  }
  return dayjs(data).format('YYYY-MM-DD');
}

function getInnerDate(data: CalendarRangePickerPayloadType, i: 0 | 1): Date | null {
  if (data[i] === null) {
    return null;
  }
  return (data[i] as Dayjs).toDate();
}

function confirm(data: Date, i: 0 | 1): void {
  if (i === 0) {
    date0.value = data;
    close(0);
  }
  else {
    date1.value = data;
    close(1);
  }
  onChange();
}

function onChange(): void {
  const data: CalendarRangePickerPayloadType = [null, null];
  if (date0.value !== null) {
    data[0] = dayjs(date0.value) as any;
  }
  if (date1.value !== null) {
    data[1] = dayjs(date1.value) as any;
  }
  emit('change', data);
}

function open(i: 0 | 1): void {
  if (i === 0) {
    visible0.value = true;
  }
  else {
    visible1.value = true;
  }
}

function close(i: 0 | 1): void {
  if (i === 0) {
    visible0.value = false;
  }
  else {
    visible1.value = false;
  }
}
</script>

<template>
  <div class="flex items-center" style="height: 44px;">
    <div style="width: calc(50% - 24px);" class="inline-flex items-center justify-center rounded-4 h-full"
         :class="{
           'text-primary-6 bg-primary-alpha': date0,
           'text-weak-8 bg-12': !date0,
         }"
         @click="open(0)">{{ value0Text }}</div>
    <div class="text-weak-8 font-bold inline-block text-center" style="width: 48px;">—</div>
    <div style="width: calc(50% - 24px);" class="inline-flex items-center justify-center rounded-4 h-full"
         :class="{
           'text-primary-6 bg-primary-alpha': date1,
           'text-weak-8 bg-12': !date1,
         }"
         @click="open(1)">{{ value1Text }}</div>
  </div>
  <van-calendar
    v-model:show="visible0"
    type="single"
    :default-date="date0"
    :show-confirm="false"
    :max-date="maxDate0"
    switch-mode="month"
    class="calendar-picker-mobile"
    @confirm="confirm($event, 0)"
  />
  <van-calendar
    v-model:show="visible1"
    type="single"
    :default-date="date1"
    :show-confirm="false"
    :max-date="maxDate1"
    switch-mode="month"
    class="calendar-picker-mobile"
    @confirm="confirm($event, 1)"
  />
</template>
