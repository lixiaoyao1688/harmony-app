import {Dayjs} from 'dayjs';

export type CalendarRangePickerPayloadType = [Dayjs,Dayjs] | [Dayjs,null] | [null,Dayjs] | [null,null];