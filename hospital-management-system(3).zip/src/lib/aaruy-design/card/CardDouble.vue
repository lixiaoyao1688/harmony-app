<script setup lang="ts">
import CardSingle from '@/lib/aaruy-design/card/CardSingle.vue';

interface Prop {
  t1: string;
  t2: string;
  top?: boolean;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="card-double">
    <div class="half">
      <CardSingle :title="t1" :bt="top" :bb="true" :br="false" :bl="true">
        <template #content><slot name="c1"></slot></template>
      </CardSingle>
    </div>
    <div class="half">
      <CardSingle :title="t2" :bt="top" :bb="true" :br="true" :bl="false">
        <template #content><slot name="c2"></slot></template>
      </CardSingle>
    </div>
  </div>
</template>

<style scoped>
.card-double {
  display: flex;
}

.card-double > .half {
  width: 50%;
}
</style>


