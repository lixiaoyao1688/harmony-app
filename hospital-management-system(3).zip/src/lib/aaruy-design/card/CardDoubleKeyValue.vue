<script setup lang="ts">
import { computed } from 'vue';
import CardKeyValue from '@/lib/aaruy-design/card/CardKeyValue.vue';

interface Prop {
	width: number | string;
	height: number;
	title: [string, string];
	isEmpty: [boolean, boolean];
	data: [number | string, number | string];
	unit: [string, string];
	borderRadius?: string;
}

const prop = defineProps<Prop>();
const innerWidth = computed<string | null>(() => prop.width ? (typeof prop.width === 'number' ? prop.width+'px' : prop.width) : null);
const radius1 = computed<string>(() => prop.borderRadius ? `${prop.borderRadius} 0 0 ${prop.borderRadius}` : '4px 0 0 4px');
const radius2 = computed<string>(() => prop.borderRadius ? `0 ${prop.borderRadius} ${prop.borderRadius} 0` : '0 4px 4px 0');
</script>

<template>
  <div class="inline-block" :style="{ width: innerWidth }">
		<CardKeyValue :title="title[0]" :unit="unit[0]" :data="data[0]" width="50%" :is-empty="isEmpty[0]" :height="height" :border-radius="radius1" />
		<CardKeyValue :title="title[1]" :unit="unit[1]" :data="data[1]" width="50%" :is-empty="isEmpty[1]" :height="height" :border-radius="radius2" />
	</div>
</template>
