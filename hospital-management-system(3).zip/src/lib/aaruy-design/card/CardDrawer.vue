<script setup lang="ts">
import IconModalClose from '@/lib/aaruy-design/modal/icons/IconModalClose.vue';


interface Emit {
	(e: 'close'): void;
}

const emit = defineEmits<Emit>();

function onClose(): void {
  emit('close');
}
</script>

<template>
	<div class="board">
		<div class="board-header">
			<div class="board-header-title"><slot name="icon"></slot><slot name="title"></slot></div>
			<IconModalClose @close="onClose" />
		</div>
		<div style="height: calc(100% - var(--board-header));" class="bg-2 overflow-x-hidden overflow-y-auto">
			<slot></slot>
		</div>
	</div>
</template>

<style scoped>
.board {
	width: 544px;
	height: 100%;
	--board-header: 44px;
}

.board-header {
	height: var(--board-header);
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 0 16px;
	background-color: rgb(91, 103, 116);
}

.board-header-title {
	display: flex;
	align-items: center;
	font-size: 16px;
}
</style>