<script setup lang="ts">
interface Prop {
	width?: string;
	height?: string;
	isValid: boolean;
	title: string;
	value: number;
	unit: string;
	useSlot?: boolean; // 启动后 value,unit 无效
	blt?: number;  // 边框 top 圆角
	brt?: number;
	brb?: number;
	blb?: number;
  useSmallUnit?: boolean;
}

defineProps<Prop>();
</script>

<template>
	<div
		:style="{
			width: width || '100%',
			height: height || '100%',
			borderRadius: `${blt || 0}px ${brt || 0}px ${brb || 0}px ${blb || 0}px`
		}"
		class="inline-block bg-1 p-16 text-white font-normal"
	>
		<span class="block text-xl leading-xl mb-12">{{ title }}</span>
		<span v-if="isValid" class="block">
			<slot></slot>
			<template v-if="!useSlot">
				<span class="text-xxl-2 leading-xxl-2 font-bold">{{ value }}</span>
				<span class="leading-l text-weak-2 ml-8"
              :class="{ 'text-s': useSmallUnit, 'text-lg': !useSmallUnit }">{{ unit }}</span>
			</template>
		</span>
		<span v-else class="block text-weak text-xxl leading-xxl">----</span>
	</div>
</template>
