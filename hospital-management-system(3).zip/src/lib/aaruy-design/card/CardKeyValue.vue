<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import CardView2 from '@/lib/aaruy-design/card/CardView2.vue';


interface Prop {
	width: number | string;
	height: number | string;
	title: string;
	isEmpty: boolean;
	data?: number | string;
	unit?: string;
	bottomUnit?: string;
	borderRadius?: string;
	isNotDataUnit?: boolean;
	isVertical?: boolean;
	time?: string;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const emptyText = computed<string>(() => pc.value ? '----' : '--');
</script>

<template>
	
	<CardView2 :width="width" :height="height" :padding="isVertical ? 24 : 12" :border-radius="borderRadius">
		
		<div v-if="isVertical" class="h-100 flex items-center justify-between relative">
			<div class="text-s">{{ title }}</div>
			<div>
				<span v-if="isEmpty" class="text-xxl leading-xxl text-weak-2 font-bold">{{ emptyText }}</span>
				<template v-else>
					<span class="text-xxl leading-xxl text-white font-bold">{{ data }}</span>
					<span class="text-xs leading-xs text-weak-2 ml-6">{{ unit }}</span>
				</template>
			</div>
			<div v-if="bottomUnit && !isEmpty" class="absolute text-xs leading-xs text-weak-2" style="bottom: -16px; right: 6px;">{{ bottomUnit }}</div>
			<div v-if="time" class="absolute text-xs leading-xs text-weak-2" style="bottom: -16px; right: 16px;">{{ time }}</div>
		</div>
		
		<template v-if="!isVertical">
			<div class="text-s">{{ title }}</div>
			<div class="mt-8 w-100">
				<span v-if="isEmpty" class="text-xxl leading-xxl text-weak-2 font-bold">{{ emptyText }}</span>
				
				<template v-if="!isEmpty && isNotDataUnit">
					<slot></slot>
				</template>
				
				<template v-if="!isEmpty && !isNotDataUnit">
					<span class="text-xxl leading-xxl text-white font-bold">{{ data }}</span>
					<span class="text-xs leading-xs text-weak-2 ml-6">{{ unit }}</span>
				</template>
			</div>
		</template>
		
	</CardView2>
	
</template>
