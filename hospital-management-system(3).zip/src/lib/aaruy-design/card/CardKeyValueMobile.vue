<script setup lang="ts">
import CardView2 from '@/lib/aaruy-design/card/CardView2.vue';


interface Prop {
	width: string;
	height: string;
	isEmpty: boolean;
	data: number;
	unit: string;
	title: string;
	time?: string;
}

defineProps<Prop>();
</script>

<template>
	<CardView2 :width="width" :height="height" :padding="12">
		<div class="h-100 relative">
			<div class="text-s">{{ title }}</div>
			<div>
				<span v-if="isEmpty" class="text-xxl leading-xxl text-weak-2 font-bold">----</span>
				<template v-else>
					<span class="text-xxl leading-xxl text-white font-bold">{{ data }}</span>
					<span class="text-xs leading-xs text-weak-2 ml-6">{{ unit }}</span>
				</template>
			</div>
			<div v-if="time" class="text-xs leading-xs text-weak-2 mt-4">{{ time }}</div>
		</div>
	</CardView2>
</template>
