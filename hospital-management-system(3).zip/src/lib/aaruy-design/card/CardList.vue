<script setup lang="ts">
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface Prop {
	list: Array<SelectorFormItemVO>;
}

const prop = defineProps<Prop>();
</script>

<template>
	
	<div class="border-4 bg-4 flex justify-between px-8 py-16 m-10">
		
		<div v-for="(it, index) in list" :key="it.id" :class="{ 'br-1': index < list.length-1 }" class="flex flex-1 justify-center">
			<div class="fit-content">
				<div class="text-xs text-white fit-content">{{ it.text }}</div>
				<div class="fit-content">
					<span class="text-lg font-bold">{{ it.payload.value }}</span>
					<span class="text-xxs text-weak ml-4">{{ it.payload.unit }}</span>
				</div>
			</div>
		</div>
		
	</div>
	
</template>
