<script setup lang="ts">
interface Prop {
	type: 'default';
}

defineProps<Prop>();
</script>

<template>
  <div class="card-mobile">
		<div class="card-mobile-header card-block">
			<slot name="header"></slot>
		</div>
		<div class="card-mobile-body">
			<slot></slot>
		</div>
		<div class="card-mobile-bottom card-block">
			<slot name="bottom"></slot>
		</div>
	</div>
</template>

<style scoped>
.card-mobile {
	color: rgb(255,255,255);
	background-color: rgb(37,43,48);
}

.card-block {
	height: 44px;
	display: flex;
	align-items: center;
}

.card-mobile-header {
	border-bottom: 1px solid rgb(58,68,77);
}

.card-mobile-bottom {
	border-top: 1px solid rgb(58,68,77);
}
</style>