<script setup lang="ts">
interface Prop {
	title: string;
}


const prop = defineProps<Prop>();
</script>

<template>
  <div class="card-report">
		<div class="card-title">{{ title }}</div>
		<div class="card-content">
			<slot></slot>
		</div>
	</div>
</template>

<style scoped>
.card-title {
	height: 48px;
	line-height: 48px;
	font-size: 16px;
	text-align: left;
	padding: 0 24px;
	color: rgb(255,255,255);
	background-color: rgb(21,26,30);
}

.card-content {
	color: rgb(245,245,245);
	background-color: rgb(37,43,48);
	padding: 21px 24px ;
}
</style>