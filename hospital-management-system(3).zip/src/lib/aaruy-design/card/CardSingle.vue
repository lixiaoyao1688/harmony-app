<script setup lang="ts">
interface Prop {
  title: string;
  bt: boolean;  // 是否具有 border top
  br: boolean;  // 是否具有 border right
  bb: boolean;  // 是否具有 border bottom
  bl: boolean;  // 是否具有 border left
  isOverflowAuto?: boolean;  // 是否自滚动
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="card-single" :class="{ bt: bt, br: br, bb: bb, bl: bl }">
    <div class="title">{{ title }}</div>
    <div class="content" :class="{ 'overflow-auto': isOverflowAuto }">
      <slot name="content"></slot>
    </div>
  </div>
</template>

<style scoped>
.card-single {
  display: flex;
  --card-single-border-color: rgb(91, 103, 116);
}

.overflow-auto {
  overflow: auto;
}

.bt {
  border-top: 1px solid var(--card-single-border-color);
}

.br {
  border-right: 1px solid var(--card-single-border-color);
}

.bb {
  border-bottom: 1px solid var(--card-single-border-color);
}

.bl {
  border-left: 1px solid var(--card-single-border-color);
}

.card-single > .title {
  display: flex;
  align-items: flex-start;
  justify-content: center;
  color: rgb(255, 255, 255);
  background-color: rgb(58, 68, 77);
  width: 140px;
  min-width: 140px;
  font-size: 18px;
  padding-top: 10px;
}

.card-single > .content {
  flex: 1;
  font-size: 18px;
  padding: 10px 20px;
  color: rgb(255, 255, 255);
  background-color: rgb(37, 43, 48);
  overflow-wrap: anywhere;
  min-height: 50px;
}
</style>


