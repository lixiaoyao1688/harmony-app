<script setup lang="ts">
import { computed } from 'vue';


interface Prop {
	type: 'empty' | 'titleContent' | 'list' | 'toolContent';
	id?: string;
	padding?: number | string;
	width?: number | string;
	height?: number | string;
	minHeight?: number | string;
	showLeftTop?: boolean;  // 是否提供左上角插槽
	showRightTop?: boolean;  // 是否提供右上角插槽
	showRightBottom?: boolean;  // 是否提供右下角插槽
	title?: string;
	toolPadding?: string;  // toolContent 下的 tool 内边距，仅 toolContent 有效
	showBorderBottom?: boolean;  // 是否展示 tool 的底部线，仅 toolContent 有效
}

const prop = defineProps<Prop>();
const innerWidth = computed<string | null>(() => prop.width ? (typeof prop.width === 'number' ? prop.width+'px' : prop.width) : null);
const innerHeight = computed<string | null>(() => prop.height ? (typeof prop.height === 'number' ? prop.height+'px' : prop.height) : null);
const innerMinHeight = computed<string | null>(() => prop.minHeight ? (typeof prop.minHeight === 'number' ? prop.minHeight+'px' : prop.minHeight) : null);
const innerPadding = computed<string | null>(() => prop.padding ? (typeof prop.padding === 'number' ? prop.padding+'px' : prop.padding) : null);
</script>

<template>
  <div :id="id" class="card-detail" :style="{ width: innerWidth, height: innerHeight, minHeight: innerMinHeight, padding: innerPadding }">
		<div v-if="showLeftTop" class="left-top">
			<slot name="leftTop"></slot>
		</div>
		<div v-if="showRightTop" class="right-top">
			<slot name="rightTop"></slot>
		</div>
		<div v-if="showRightBottom" class="right-bottom">
			<slot name="rightBottom"></slot>
		</div>
		<slot></slot>
		
		<template v-if="type === 'titleContent'">
			<div v-if="title" class="text-lg font-bold">{{ title }}</div>
			<slot name="titleContent"></slot>
		</template>
		
		<template v-if="type === 'toolContent'">
			<div class="flex items-center justify-between w-100" :style="{ padding: toolPadding || null, borderBottom: showBorderBottom ? '1px solid rgb(91,103,116)' : null }">
				<div class="text-lg font-bold flex-1">{{ title }}</div>
				<slot name="tool"></slot>
			</div>
			<slot name="toolContent"></slot>
		</template>
		
		<template v-if="type === 'list'">
			<div class="text-lg font-bold mt-8 pl-8 pb-4 border-b-1 border-b-solid border-b-default-1">{{ title }}</div>
			<slot name="list"></slot> 
		</template>
	</div>
</template>

<style scoped>
.card-detail {
	position: relative;
	border-radius: 4px;
	color: var(--aaruy-text-color);
	background-color: var(--aaruy-bg-color-3);
}

.left-top {
	position: absolute;
	top: 0;
	left: 0;
}

.right-bottom {
	position: absolute;
	bottom: 0;
	right: 0;
}

.right-top {
	position: absolute;
	top: 0;
	right: 0;
}
</style>
