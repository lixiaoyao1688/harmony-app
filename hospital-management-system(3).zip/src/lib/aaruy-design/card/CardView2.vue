<script setup lang="ts">
import { computed } from 'vue';

interface Prop {
	padding?: number | string;
	width?: number | string;
	height?: number | string;
	borderRadius?: string;
}

const prop = defineProps<Prop>();
const padding = computed<string>(() => prop.padding ? (typeof prop.padding === 'number' ? `${prop.padding}px` : prop.padding) : '0');
const innerWidth = computed<string | null>(() => prop.width ? (typeof prop.width === 'number' ? prop.width+'px' : prop.width) : null);
const innerHeight = computed<string | null>(() => prop.height ? (typeof prop.height === 'number' ? prop.height+'px' : prop.height) : null);
const innerBorderRadius = computed<string>(() => prop.borderRadius ? prop.borderRadius : '4px');
</script>

<template>
  <div class="card-view-2" :style="{ width: innerWidth, height: innerHeight, padding: padding, borderRadius: innerBorderRadius }">
		<slot></slot>
	</div>
</template>

<style scoped>
.card-view-2 {
	display: inline-block;
	position: relative;
	color: var(--aaruy-text-color);
	background-color: var(--aaruy-bg-color-1);
}
</style>