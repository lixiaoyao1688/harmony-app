<script setup lang="ts">
interface Prop {
	hideHeader?: boolean;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="bg-2">
		<div v-if="!hideHeader" class="flex items-center justify-between border-b-1-bg-4">
			<slot name="toolLeft"></slot>
			<slot name="toolRight"></slot>
		</div>
		<slot></slot>
	</div>
</template>
