export class CardItemVO {
	
	public id: number;
	public isValid: boolean;
	public title: string;
	public value: number;
	public unit: string;
	
	constructor(id: number, isValid: boolean, title: string, value: number, unit: string) {
	  this.id = id;
	  this.isValid = isValid;
	  this.title = title;
	  this.value = value;
	  this.unit = unit;
	}
	
}
