<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';


/**
 * 单元格 组件
 */
interface Prop {
  title: string;
  value: string;
  height?: string;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <div v-if="pc"
       :style="{ height: height || '50px' }"
       class="flex justify-between items-center text-s text-white"
       style="border-bottom: 2px solid rgba(204, 214, 225, 0.2);"
  >
    <span>{{ title }}</span>
    <span>{{ value }}</span>
  </div>
  <div v-if="mobile"
       :style="{ height: height || '50px' }"
       class="flex justify-between items-center text-s text-white"
       style="border-bottom: 2px solid rgba(204, 214, 225, 0.2);"
  >
    <span>{{ title }}</span>
    <span>{{ value }}</span>
  </div>
</template>
