<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import CheckBoxNewNew from '@/lib/aaruy-design/check-box/new/CheckBoxNewNew.vue';
import '@/lib/aaruy-design/check-box/check.box.style.css';
import type { CheckboxChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';
import type { CheckBoxType } from '@/lib/aaruy-design/check-box/check.box.type';


/**
 * 复选框 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
	type: CheckBoxType;
	checked: boolean;
	disabled?: boolean;
  margin?: string;
  iconSize?: string;  // 仅APP
  width?: string;  // 仅APP
}

interface Emit {
	(e: 'change', checked: boolean): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();

const isDefault = computed<boolean>(() => prop.type === 'default');
const isForm = computed<boolean>(() => prop.type === 'form');
const pc = computed<boolean>(() => screenStore.isPC);

function onChange(e: CheckboxChangeEvent): void {
  emit('change', e.target.checked || false);
}

function onChangeApp(data: boolean): void {
  emit('change', data);
}
</script>

<template>
	<a-checkbox v-if="pc"
              :disabled="disabled"
              :checked="checked"
              :class="{ 'ar-check-box-default': isDefault, 'ar-check-box-form': isForm }"
              :style="{ margin: margin }"
              @change="onChange">
		<slot></slot>
	</a-checkbox>
  <CheckBoxNewNew v-else :data="checked" :width="width" :is-disabled="disabled" :margin="margin" :icon-size="iconSize" @change="onChangeApp">
    <slot></slot>
  </CheckBoxNewNew>
</template>
