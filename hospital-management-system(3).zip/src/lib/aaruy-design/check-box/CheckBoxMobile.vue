<script setup lang="ts">
import {ref, watch} from 'vue';
import '@/lib/aaruy-design/check-box/checkbox.mobile.style.css';


interface Prop {
	title: string;
	checked: boolean;
}

interface Emit {
	(e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<boolean>(false);

watch(() => prop.checked, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(): void {
  const data = !value.value;
  value.value = data;
  emit('change', data);
}
</script>

<template>
	<van-checkbox :model-value="value"
                shape="square"
                class="checkbox-mobile"
                @click="onChange"
  >{{ title }}</van-checkbox>
</template>
