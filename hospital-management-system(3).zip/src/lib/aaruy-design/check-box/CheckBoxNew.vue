<script setup lang="ts">
import '@/lib/aaruy-design/check-box/check.box.style.css';
import type { CheckboxChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


interface Prop {
  type?: 'default' | 'word-left';  // 默认 default
  words?: string;  // 仅 type 为 word-left 时使用
  checked?: boolean;
  disabled?: boolean;
  margin?: string;
  height?: string;
}

interface Emit {
  (e: 'change', data: boolean): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onChange(e: CheckboxChangeEvent): void {
  emit('change', e.target.checked || false);
}

function onTrigger(): void {
  emit('change', !prop.checked);
}
</script>

<template>
  <div v-if="type === 'word-left'"
       class="flex justify-between items-center border-b-default border-b-hover-primary"
       style="height: 48px;"
       :style="{ margin: margin || '0' }"
       @click="onTrigger"
  >
    <span class="text-s text-white flex-1 cursor-pointer">{{ words }}</span>
    <a-checkbox id="abc" :checked="checked" :disabled="disabled"
                class="ar-check-box-default ar-check-box-word-left"
                @change="onChange" />
  </div>
  <div v-else :style="{ height: height || '16px' }">
    <a-checkbox :checked="checked"
                :disabled="disabled"
                :style="{ margin: margin || '0' }"
                class="ar-check-box-default"
                @change="onChange">
      <slot></slot>
    </a-checkbox>
  </div>
  
</template>
