<script setup lang="ts">
import '@/lib/aaruy-design/check-box/check.box.basic.form.style.css';
import type { CheckboxChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


/**
 * 复选框 组件
 *
 * 仅 pc;
 */
interface Prop {
  title: string;
  data: boolean;
  disabled?: boolean;
  height?: string;
  marginBottom?: string;
  isTitleAtTheEnd?: boolean;
}

interface Emit {
  (e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onChange(e: CheckboxChangeEvent): void {
  onEmit(e.target.checked || false);
}

function onTrigger(): void {
  onEmit(!prop.data);
}

function onEmit(data: boolean): void {
  emit('change', data);
}
</script>

<template>
  <div class="flex items-center" :style="{ height: height || '40px', marginBottom: marginBottom || '16px' }">
    <template v-if="isTitleAtTheEnd">
      <a-checkbox :disabled="disabled" :checked="data" class="checkbox-basic-form" @change="onChange" />
      <div class="pl-8 text-right text-white text-s cursor-pointer" @click="onTrigger">{{ title }}</div>
    </template>
    <template v-else>
      <div style="width: 120px;" class="pr-12 text-right text-white text-s cursor-pointer" @click="onTrigger">{{ title }}</div>
      <a-checkbox :disabled="disabled" :checked="data" class="checkbox-basic-form" @change="onChange" />
    </template>
  </div>
</template>
