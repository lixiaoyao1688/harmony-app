export type CheckBoxType = 'default' | 'form';
