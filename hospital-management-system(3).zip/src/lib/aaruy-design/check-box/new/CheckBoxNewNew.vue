<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/check-box/checkbox.mobile.style.css';


/**
 * 复选框 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: boolean;
  width?: string;
  margin?: string;
  iconSize?: string;  // 默认 16px
  useLineHeight14?: boolean;  // 是否使用 line-height: 14px;
  useItemStart?: boolean;  // 是否使用 align-items: flex-start;
  isLabelHidden?: boolean;
  isDisabled?: boolean;  // 是否禁用
}

interface Emit {
	(e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);

function onCheckedChange(data: boolean): void {
  emit('change', data);
}
</script>

<template>
  
  <div v-if="pc"><!--  暂不支持 pc 端  --></div>
  <template v-else>
    <van-checkbox :model-value="data"
                  :disabled="isDisabled"
                  shape="square"
                  class="checkbox-mobile"
                  :class="{
                    'checkbox-mobile-line-height-14': useLineHeight14,
                    'checkbox-mobile-item-start': useItemStart,
                    'label-hidden': isLabelHidden
                  }"
                  :icon-size="iconSize || '16px'"
                  :style="{ width: width || '100%', margin: margin }"
                  @update:model-value="onCheckedChange">
      <slot></slot>
    </van-checkbox>
  </template>
  
</template>
