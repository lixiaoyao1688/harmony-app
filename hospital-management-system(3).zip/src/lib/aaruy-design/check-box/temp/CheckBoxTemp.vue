<script setup lang="ts">
import { ref } from 'vue';
import '@/lib/aaruy-design/check-box/temp/check.box.temp.style.css';
import type { CheckboxChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


interface Emit {
  (e: 'change', data: boolean): void;
}

const emit = defineEmits<Emit>();
const isChecked = ref<boolean>(false);

function onChange(e: CheckboxChangeEvent): void {
  emit('change', e.target.checked || false);
}
</script>

<template>
  <div style="height: 44px; line-height: 44px;">
    <a-checkbox v-model:checked="isChecked"
                class="aaruy-check-box-temp"
                @change="onChange">
      <slot></slot>
    </a-checkbox>
  </div>
</template>
