<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/check/check.style.css';
import type { CheckboxChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


/**
 * 复选框 组件
 *
 * 使用范围
 * pc && mobile;
 */
interface Prop {
  checked: boolean;  // 是否选中
  disabled?: boolean;  // 仅PC
  margin?: string;
  marginNew?: string;  // 仅PC
  width?: string;  // 默认 100%，仅PC
  useLineHeight16px?: boolean;
  useStyle1?: boolean;  // 仅APP
  use4KStyle?: boolean;  // 仅PC
}

interface Emit {
  (e: 'change', data: boolean): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function onPCCheckedChange(e: CheckboxChangeEvent): void {
  emit('change', e.target.checked || false);
}

function onMobileCheckedChange(): void {
  emit('change', !prop.checked);
}
</script>

<template>
  <div v-if="pc"
       :style="{
         width: width,
         height: use4KStyle ? '64px' : '32px',
         margin: marginNew
       }">
    <a-checkbox :checked="checked"
                :disabled="disabled"
                class="aaruy-check-pc"
                :class="{
                  'aaruy-check-pc-use-leading-16px': useLineHeight16px,
                  'aaruy-check-pc-4k': use4KStyle,
                }"
                :style="{ margin: margin || '0' }"
                @change="onPCCheckedChange">
      <slot></slot>
    </a-checkbox>
  </div>
  <van-checkbox v-else
                :model-value="checked"
                shape="square"
                class="aaruy-check-mobile"
                :class="{ 'aaruy-check-mobile-style-1': useStyle1 }"
                style="height: 32px;"
                :style="{ margin: margin || '0' }"
                @click="onMobileCheckedChange">
    <slot></slot>
  </van-checkbox>
</template>
