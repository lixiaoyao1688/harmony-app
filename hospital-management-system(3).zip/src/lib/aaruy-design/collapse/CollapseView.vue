<script setup lang="ts">
import { ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import SelectorNormalIconUp from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconUp.vue';
import SelectorNormalIconDown from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconDown.vue';
import '@/lib/aaruy-design/collapse/style/collapse.normal.style.css';
import '@/lib/aaruy-design/collapse/style/collapse.primary.style.css';
import '@/lib/aaruy-design/collapse/style/collapse.history.style.css';
import '@/lib/aaruy-design/collapse/style/collapse.head.style.css';
import '@/lib/aaruy-design/collapse/style/collapse.head.app.style.css';
import type {CollapseItemType} from '@/lib/aaruy-design/collapse/type/collapse.type';


/**
 * 折叠面板 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  items: Array<SelectItemVO<any> | CollapseItemType>;  // 折叠列表（元素必须具备 id 属性，其他属性不限制）
  accordion?: boolean;  // 是否开启手风琴模式，默认不开启
  selectedKey?: string | string[];  // 已展开的某个Key，即 items[i].id.toString();  默认无，accordion 模式下默认第一个元素
  isStyleNormal?: boolean;  // 是否使用 normal 样式
  isStylePrimary?: boolean;  // 是否使用 primary 样式
  isStyleHistory?: boolean;  // 是否使用 history 样式
  isStyleHead?: boolean;  // 是否使用 head 样式
  useSlotHead?: boolean;  // 是否使用 head 插槽，仅PC
  margin?: string;
}

const prop = defineProps<Prop>();
const activeKey = ref<string | string[]>([]);
const screenStore = useScreenStore();

watch(() => prop.selectedKey, (data) => {
  if (data && data !== '-1') {
    activeKey.value = data;
  }
}, { immediate: true });

function onKeyChange(k: string[] | string): void {
  activeKey.value = k;
}
</script>

<template>
  <template v-if="screenStore.isPC">
    <a-collapse v-model:activeKey="activeKey" :bordered="false" accordion
                :class="{
                  'aaruy-collapse-normal': isStyleNormal,
                  'aaruy-collapse-primary': isStylePrimary,
                  'aaruy-collapse-history': isStyleHistory,
                  'aaruy-collapse-head': isStyleHead,
                }"
                :style="{ margin: margin }"
                @change="onKeyChange">
      <a-collapse-panel v-for="(it,i) in items" :key="it.id" :show-arrow="false">
        <template #header>
          <template v-if="useSlotHead">
            <slot name="col-head" :item="it" :index="i" :is-actived="activeKey && activeKey[i] === it.id.toString()"></slot>
          </template>
          <template v-else-if="isStyleHead">
            <slot name="col-head" :item="it" :index="i"></slot>
            <div class="inline-flex items-center" style="height: 24px;">
              <SelectorNormalIconUp v-if="activeKey && activeKey[i] === it.id.toString()" />
              <SelectorNormalIconDown v-else />
            </div>
          </template>
          <div v-else class="w-full flex items-center justify-between">
            <span class="text-s text-white">{{ it.text }}</span>
            <SelectorNormalIconUp v-if="activeKey && activeKey[i] === it.id.toString()" />
            <SelectorNormalIconDown v-else />
          </div>
        </template>
        <slot :it="it"></slot>
      </a-collapse-panel>
    </a-collapse>
  </template>
  <template v-else>
    <van-collapse v-model="activeKey"
                  :border="false"
                  :class="{
                    'aaruy-collapse-head-app': isStyleHead,
                  }">
      <van-collapse-item v-for="(it,i) in items" :key="it.id" :name="it.id">
        <template #title>
          <slot name="col-head" :item="it" :index="i" :is-actived="activeKey && activeKey[i] === it.id.toString()"></slot>
        </template>
        <slot :it="it"></slot>
      </van-collapse-item>
    </van-collapse>
  </template>
  
</template>
