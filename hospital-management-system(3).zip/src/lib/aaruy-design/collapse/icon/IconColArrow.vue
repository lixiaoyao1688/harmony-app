<script setup lang="ts">
import {computed} from 'vue';


interface Prop {
  rotate: number;
}

const prop = defineProps<Prop>();
const rotateText = computed<string>(() => `rotate(${prop.rotate}deg)`);
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="9.744" height="7.308" viewBox="0 0 9.744 7.308" :style="{ transform: rotateText }">
    <path id="down" d="M0,7.308,4.872,0,9.744,7.308Z" fill="#fff"/>
  </svg>
</template>