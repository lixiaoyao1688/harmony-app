<script setup lang="ts">
import { ref, watch } from 'vue';
import { roundTo } from '@/lib/math/util/math.util';
import { ZERO } from '@/lib/math/config/math.config';
import '@/lib/aaruy-design/counter/counter.style.css';


/**
 * 计数器 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  data: number;  // 数值
  step: number;  // 步长
  min: number;  // 最小值
  max: number;  // 最大值
  digit: number; // 保留小数点位数
	title: string;
	unit: string;
}

interface Emit {
  (e: 'change', p: number): void;  // 上层收到后，请更新 prop.data
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<number>(prop.data);


watch(() => prop.data, (newVal) => {
  value.value = roundTo(newVal, prop.digit);
});

function add() {
  onValueChange(roundTo((value.value || ZERO) + prop.step, prop.digit));
}

function reduce() {
  onValueChange(roundTo((value.value || ZERO) - prop.step, prop.digit));
}

function onValueChange(v: number | null | undefined) {
  if (v === null || v === undefined) {
    emit('change', 0);
  } else {
    v = Math.max(v, prop.min);
    v = Math.min(v, prop.max);
    emit('change', roundTo(v, prop.digit));
  }
}

// function parser(text: string) {
//   return text.replace(prop.unit, '');
// }

// function formatter(value: number) {
//   return '' + value + prop.unit;
// }
</script>

<template>
	<div>
		<p v-if="title" class="text-s leading-s mb-12">{{ title }}<span class="ml-12">{{ unit }}</span></p>
		<div class="counter">
			<!--	:parser="parser" 	:formatter="formatter" -->
      <a-button class="cb" @click="reduce">-</a-button>
			<a-input-number
				v-model:value="value"
				:min="min"
				:max="max"
				:controls="false"
        placeholder="请输入"
				class="ci"
				@change="onValueChange"
			/>
      <a-button class="cb" @click="add">+</a-button>
		</div>
	</div>
</template>

<style scoped>
.counter {
  height: 40px;
  display: flex;
}

.counter .cb {
  width: 26%;
  height: 100%;
  border: none;
  color: rgb(255,255,255);
  font-size: 20px;
  font-weight: bolder;
  background-color: rgb(91,103,116);
  border-radius: 0;
  padding: 0;
}

.counter .cb:hover {
  background-color: rgb(38,111,232);
}

.counter .cb:active {
  background-color: rgb(105,158,245);
}

.counter .cb:first-child {
  border-radius: 4px 0 0 4px;
}

.counter .cb:last-child {
  border-radius: 0 4px 4px 0;
}

.counter .ci {
  width: 48%;
  font-size: 16px;
  border: 2px solid rgb(91,103,116);
  border-radius: 0;
}

.counter .ci:hover {
	border-color: rgb(38, 111, 232);
}
</style>