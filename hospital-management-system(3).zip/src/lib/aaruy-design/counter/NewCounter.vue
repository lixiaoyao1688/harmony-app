<script setup lang="ts">
import { computed } from 'vue';
import {roundTo} from '@/lib/math/util/math.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/counter/new.counter.style.css';


/**
 * 步进器 组件
 * 仅mobile
 */
interface Prop {
	title: string;
	unit: string;
	value: number;
	min: number;
	max: number;
  step?: number;  // 步长，默认1;
  digit?: number;  // 保留的小数位数，默认1;
}

interface Emit {
	(e: 'change', v: number): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const innerStep = computed<number>(() => prop.step || 1);
const innerDigit = computed<number>(() => prop.digit || 1);


function onChange(v: number): void {
  v = Math.max(v, prop.min);
  v = Math.min(v, prop.max);
  v = roundTo(v, innerDigit.value);
  emit('change', v);
}

function add(): void {
  onChange(roundTo((+prop.value) + innerStep.value, innerDigit.value));
}

function reduce(): void {
  onChange(roundTo((+prop.value) - innerStep.value, innerDigit.value));
}
</script>

<template>
  <div v-if="pc"></div>
	<template v-if="mobile">
		<div v-if="title" class="text-s leading-s text-white mb-8">{{ title }}</div>
		<div class="flex items-center aaruy-counter">
			<van-button @click="add">+</van-button>
			<van-field
				type="number"
        placeholder="请输入"
				:model-value="value"
				@update:model-value="onChange"
			>
				<template #right-icon>
					<span>{{ unit }}</span>
				</template>
			</van-field>
			<van-button @click="reduce">-</van-button>
		</div>
	</template>
</template>
