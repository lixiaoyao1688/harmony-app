<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {getDigitCount, isMultipleStep, realRoundTo3Digit} from '@/lib/math/util/math.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {MAX_DOSE_DIGIT} from '@/modules/dose/config/dose.new.config';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/counter/new.counter.style.css';


/**
 * 步进器 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: string;  // 输入值
  step: number;  // 步长，默认1;
  digit: number;  // 小数位数
  min: number;
  max: number;
  unit: string;
}

interface Emit {
  (e: 'change', data: string): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>('');       // 数值
const errorTips = ref<string>('');   // 错误文本
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


defineExpose({
  checkValueError
});

watch(() => prop.data, (data) => {
  value.value = data;
},{ immediate: true });

function add(): void {
  const r3d = realRoundTo3Digit;
  const data = r3d((+value.value) + prop.step);
  if (data > prop.max) {
    return;
  }
  value.value = data.toString();
  onChange(data.toString());
}

function reduce(): void {
  const r3d = realRoundTo3Digit;
  const data = r3d((+value.value) - prop.step);
  if (data < 0) {
    return;
  }
  value.value = data.toString();
  onChange(data.toString());
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

function onChange(data: string): void {
  value.value = data;
  errorTips.value = getErrorTips(data);
  emit('change', data);
}

function getErrorTips(data: string): string {
  let tips = '';
  if (!data && data !== '0') {
    tips = '请输入有效数字';
  }
  
  if (+data < prop.min) {
    tips = `不得小于 ${prop.min}U`;
  }
  if (+data > prop.max) {
    return `不得大于 ${prop.max}U`;
  }
  if (!isMultipleStep(+data, prop.step)) {
    return `必须是 ${prop.step}U 的整数倍`;
  }
  if (getDigitCount(data) > MAX_DOSE_DIGIT) {
    tips = `小数位数不得超过 ${MAX_DOSE_DIGIT} 位`;
  }
  
  errorTips.value = tips;
  return tips;
}
</script>

<template>
  <div v-if="pc"></div>
  <template v-if="mobile">
    <div class="flex items-center aaruy-counter">
      <van-button @click="reduce">-</van-button>
      <van-field
        type="number"
        placeholder="请输入"
        :model-value="value"
        @update:model-value="onChange">
        <template #right-icon>
          <span>{{ unit }}</span>
        </template>
      </van-field>
      <van-button @click="add">+</van-button>
    </div>
    <ErrorView :tips="errorTips" is-text-left />
  </template>
</template>
