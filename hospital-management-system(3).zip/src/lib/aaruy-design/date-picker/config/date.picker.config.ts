/**
 * 日期选择器 默认配置
 */
export const DEFAULT_DATE_PICKER_CONFIG = {
  WIDTH: '220px',
  HEIGHT: '32px',
  MARGIN: '0',
};
