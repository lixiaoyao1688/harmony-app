<script setup lang="ts">
import dayjs, {Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import {EnumDateColumnsType} from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import {DATE_PICKER_FROM_COLUMN_TYPE} from '@/lib/aaruy-design/date-picker/form/date.picker.form';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import DatePickerMobile from '@/lib/aaruy-design/date-picker/mobile/DatePickerMobile.vue';
import '@/lib/aaruy-design/date-picker/form/date.picker.form.style.css';
import '@/lib/aaruy-design/date-picker/date.picker.dropdown.style.css';


type DataType = Dayjs | undefined;

/**
 * 日期选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: DataType;
  title: string;  // 输入框标题
  placeholder?: string;  // 占位文本
  isRequired?: boolean;  // 是否必填项
  height?: string;
  padding?: string;  // 默认 "0 0 4px";
  fontSize?: string;  // 默认 16px;
  mobileMaxDay?: Dayjs;  // 可以选择的最大日期
  mobileColumnType?: DATE_PICKER_FROM_COLUMN_TYPE;  // 类型
}

interface Emit {
	(e: 'change', data: DataType): void;
  (e: 'error-change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const PLACEHOLDER = '请选择';

const value = ref<Dayjs | undefined>(prop.data);
const errorTips = ref<string>('');

const innerPlaceholder = computed<string>(() => prop.placeholder || PLACEHOLDER);

const visibleMobile = ref<boolean>(false);
const haveValueMobile = computed<boolean>(() => !!value.value);
const textMobile = computed<string>(() => value.value ? getTextMobile(value.value) : PLACEHOLDER);
const maxDayMobile = computed<Dayjs>(() => prop.mobileMaxDay || dayjs());
const titleMobile = computed<string>(() => {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return '选择年';
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return '选择年月';
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return '选择年月日';
  }
  return '选择月日';
});
const columnTypeMobile = computed<string[]>(() => {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return EnumDateColumnsType.y;
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return EnumDateColumnsType.ym;
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return EnumDateColumnsType.ymd;
  }
  return EnumDateColumnsType.md;
});

// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError,
});

watch(() => prop.data, (newData) => {
  value.value = newData;
}, { immediate: true });

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  emit('error-change', tips);
  return tips !== '';
}

function getErrorTips(data: DataType): string {
  if (prop.isRequired && !data) {
    return '请选择';
  }
  return '';
}

function getTextMobile(day: Dayjs) {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return day.format('YYYY');
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return day.format('YYYY-MM');
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return day.format('YYYY-MM-DD');
  }
  return day.format('MM-DD');
}

function showMobile() {
  visibleMobile.value = true;
}

function closeMobile() {
  visibleMobile.value = false;
}

function okMobile(day: Dayjs) {
  value.value = day;
  checkValueError();
  emit('change', day);
  closeMobile();
}
</script>

<template>
  <div :style="{
         height: height,
         padding: padding || '0 0 4px',
         fontSize: fontSize || '16px',
         borderColor: errorTips ? 'var(--aaruy-error-color-2)' : 'var(--aaruy-bg-color-0)'
       }"
       class="flex items-center justify-between text-white border-b-bg-0">
    <div v-if="isRequired">
      <span class="text-error-2">*</span>
      <span :class="{ 'text-error-2': errorTips }">{{ title }}</span>
    </div>
    <div v-else :class="{ 'text-error-2': errorTips }">{{ title }}</div>
    <div class="date-picker-form-mobile-data flex items-center font-bold"
         :class="{ 'text-white': haveValueMobile, 'text-color-1': !haveValueMobile }"
         :style="{ fontSize: fontSize || '16px' }"
         @click="showMobile">{{ textMobile }}</div>
    <DatePickerMobile
      :title="titleMobile"
      :date="value || dayjs()"
      :show-picker="visibleMobile"
      :min-date="null"
      :max-date="maxDayMobile"
      :columns-type="columnTypeMobile"
      @click-overlay="closeMobile"
      @close="closeMobile"
      @ok="okMobile"
    />
  </div>
  <ErrorView v-if="errorTips"
             :tips="errorTips" :font-weight="400" :padding="padding"
             color="var(--aaruy-error-color-2)" />
</template>
