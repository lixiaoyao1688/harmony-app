<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import IconDate from '@/lib/icon/IconDate.vue';
import DatePickerMobile from '@/lib/aaruy-design/date-picker/mobile/DatePickerMobile.vue';
import { EnumDateColumnsType } from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import { DATE_PICKER_FROM_COLUMN_TYPE } from '@/lib/aaruy-design/date-picker/form/date.picker.form';
import { disableDayAfterToday } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import '@/lib/aaruy-design/date-picker/form/date.picker.form.style.css';
import '@/lib/aaruy-design/date-picker/date.picker.dropdown.style.css';


interface Prop {
  data: Dayjs | undefined;  // 初始值
  title: string;  // 输入框标题
  placeholder?: string;  // 占位文本
  required?: boolean;  // 是否必填项
  mobile?: boolean;  // 是否移动端
  mobileLarge?: boolean;  // 是否移动端大尺寸 (已废弃)
  mobileMaxDay?: Dayjs;  // 移动端可以选择的最大日期
  mobileColumnType?: DATE_PICKER_FROM_COLUMN_TYPE;  // 移动端类型
	disabledDate?: (d: Dayjs) => boolean;  // 禁用的日期
}

interface Emit {
  (e: 'change', v: Dayjs): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const PLACEHOLDER = '请选择';

const value = ref<Dayjs | undefined>(prop.data);
const innerPlaceholder = computed<string>(() => prop.placeholder || PLACEHOLDER);

const visibleMobile = ref<boolean>(false);
const dayMobile = ref<Dayjs | undefined>(prop.data);
const haveValueMobile = computed<boolean>(() => !!dayMobile.value);
const textMobile = computed<string>(() => dayMobile.value ? getTextMobile(dayMobile.value) : PLACEHOLDER);
const maxDayMobile = computed<Dayjs>(() => prop.mobileMaxDay || dayjs());
const titleMobile = computed<string>(() => {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return '选择年';
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return '选择年月';
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return '选择年月日';
  }
  return '选择月日';
});
const columnTypeMobile = computed<string[]>(() => {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return EnumDateColumnsType.y;
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return EnumDateColumnsType.ym;
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return EnumDateColumnsType.ymd;
  }
  return EnumDateColumnsType.md;
});


watch(() => prop.data, (newData) => {
  value.value = newData;
});

function onChange(day: Dayjs) {
  emit('change', day);
}

function getTextMobile(day: Dayjs) {
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR) {
    return day.format('YYYY');
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH) {
    return day.format('YYYY-MM');
  }
  if (prop.mobileColumnType === DATE_PICKER_FROM_COLUMN_TYPE.YEAR_MONTH_DAY) {
    return day.format('YYYY-MM-DD');
  }
  return day.format('MM-DD');
}

function showMobile() {
  visibleMobile.value = true;
}

function okMobile(day: Dayjs) {
  dayMobile.value = day;
  emit('change', day);
  closeMobile();
}

function closeMobile() {
  visibleMobile.value = false;
}
</script>

<template>
  <div
    class="date-picker-form"
    :class="{
      'date-picker-form-mobile': mobile,
      'date-picker-form-mobile-large': mobileLarge,
    }"
  >
    <div class="date-picker-form-title">{{ title }} <i v-if="required">*</i></div>

    <template v-if="!mobile">
      <a-date-picker
        v-model:value="value"
        :placeholder="innerPlaceholder"
        :allowClear="false"
				:disabled-date="disabledDate || disableDayAfterToday"
        @change="onChange"
        dropdownClassName="date-picker-form-dropdown"
      >
        <template #suffixIcon>
          <IconDate />
        </template>
      </a-date-picker>
    </template>

    <template v-if="mobile">
      <div
        class="date-picker-form-mobile-data"
        :style="{ color: haveValueMobile ? 'rgb(255,255,255)' : 'rgb(163, 175, 188)' }"
        @click="showMobile"
      >
        {{ textMobile }}
        <IconDate class="ml-4" />
      </div>
      <DatePickerMobile
        :title="titleMobile"
        :date="dayMobile || dayjs()"
        :show-picker="visibleMobile"
        :min-date="null"
        :max-date="maxDayMobile"
        :columns-type="columnTypeMobile"
        @close="closeMobile"
        @ok="okMobile"
      />
    </template>
  </div>
</template>

<style scoped>
.date-picker-form > .date-picker-form-title {
  font-size: 16px;
}

.date-picker-form > .date-picker-form-title > i {
  margin-left: 4px;
  color: rgb(255, 36, 42);
}


/* mobile */
.date-picker-form-mobile {
  font-size: 16px;
  padding-top: 20px !important;
  padding-bottom: 8px !important;
  background-color: transparent !important;
	border-bottom-width: 1px !important;
	border-bottom-color: rgb(91, 103, 116) !important;
}

.date-picker-form-mobile .date-picker-form-title {
  font-size: 16px !important;
}

.date-picker-form-mobile .date-picker-form-mobile-data {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex: 1;
}

.date-picker-form-mobile-large {
  padding-top: 26px !important;
  padding-bottom: 11px !important;
}

.date-picker-form-mobile-large .date-picker-form-title {
  font-size: 16px !important;
}
</style>
