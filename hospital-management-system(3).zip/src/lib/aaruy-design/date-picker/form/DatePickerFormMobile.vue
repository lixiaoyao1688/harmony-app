<script setup lang="ts">
import { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { TWENTY } from '@/lib/math/config/math.config';
import { EnumTimeColumnsType } from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import IconArrowRight from '@/modules/admission/icons/IconArrowRight.vue';
import DateTimePickerMobile from '@/lib/aaruy-design/date-picker/mobile/DatePickerTimeMobile.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';


interface Prop {
  data: Dayjs | undefined;  // 初始值
  title: string;  // 输入框标题
  type?: any;  // EnumTimeColumnsType
  isField?: boolean;
  format?: string;  // 如 YYYY-MM-DD HH:mm:ss
  placeholder?: string;  // 占位文本
  required?: boolean;  // 是否必填项
  large?: boolean;  // 是否大尺寸
	maxTime?: Dayjs | undefined;  // 可选的最大时间
  useFont16?: boolean;  // 仅 isField 可用
}

interface Emit {
  (e: 'change', v: Dayjs): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<Dayjs | undefined>(prop.data);
const visible = ref<boolean>(false);
const haveValue = computed<boolean>(() => (value.value !== undefined));
const text = computed<string>(() => {
  if (value.value) {
    return value.value.format(prop.format || 'YYYY-MM-DD HH:mm:ss');
  }
  return prop.placeholder || '请选择';
});


watch(() => prop.data, (newData) => {
  value.value = newData;
});

function ok(data: Dayjs) {
  emit('change', data);
  close();
}

function close() {
  visible.value = false;
}

function open() {
  visible.value = true;
}
</script>

<template>
  
  <div v-if="isField"
       class="flex items-center justify-between h-full w-full leading-l"
       :class="{ 'text-s': useFont16, 'text-xs': !useFont16 }"
       @click="open">
    <span><i v-if="required" class="mr-2 text-required" style="font-style: normal;">*</i>{{ title }}</span>
    <div class="inline-flex items-center">
      <span v-if="haveValue" class="mr-4">{{ text }}</span>
      <span v-else class="mr-4 text-weak-2">请选择</span>
      <IconPickerField />
    </div>
  </div>
  <div v-else class="date-picker-form-mobile" :class="{ 'date-picker-form-mobile-large': large }">
    <div class="date-picker-form-mobile-title">{{ title }} <i v-if="required">*</i></div>
    <div class="date-picker-form-mobile-value" @click="open">
      <span :class="{ 'valued': haveValue }">{{ text }}</span>
      <IconArrowRight :size="TWENTY" />
    </div>
  </div>
  <DateTimePickerMobile
    :title="title"
    :date="value"
    :show-picker="visible"
    @close="close"
    @ok="ok"
    :min-date="undefined"
    :max-date="maxTime"
    :time-columns-type="type || EnumTimeColumnsType.hms"
    :tabs="['日期','时间']"
  />
</template>

<style scoped>
.date-picker-form-mobile {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 0 8px 0;
  color: rgb(255, 255, 255);
  background-color: transparent;
  border-top: none;
  border-left: none;
  border-right: none;
  border-bottom: 1px solid rgb(91, 103, 116);
}

.date-picker-form-mobile:hover {
  border-color: rgb(38,111,232) !important;
}

.date-picker-form-mobile > .date-picker-form-mobile-title {
  font-size: 14px;
}

.date-picker-form-mobile > .date-picker-form-mobile-title > i {
  margin-left: 4px;
  color: rgb(255,36,42);
}

.date-picker-form-mobile > .date-picker-form-mobile-value {
  display: flex;
  align-items: center;
  color: rgb(163,175,188);
}

.date-picker-form-mobile > .date-picker-form-mobile-value > .valued {
  color: rgb(255,255,255);
}

.date-picker-form-mobile-large {
  padding: 26px 0 11px 0;
}

.date-picker-form-mobile-large .date-picker-form-mobile-title {
  font-size: 16px;
}
</style>
