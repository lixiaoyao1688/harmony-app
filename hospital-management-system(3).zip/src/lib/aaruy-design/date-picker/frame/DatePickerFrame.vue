<script setup lang="ts">
import { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { disableDayAfterToday } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import IconDate from '@/lib/icon/IconDate.vue';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/date-picker/frame/date.picker.frame.style.css';
import '@/lib/aaruy-design/date-picker/frame/time.picker.frame.style.css';


/**
 * 日期时间选择器 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  title: string;  // 输入框标题
  data: Dayjs | undefined;  // 初始值
  width?: string;  // 总体的宽度, 默认 100%;
  titleWidth?: string;
  placeholder?: string;  // 占位文本
  isRequired?: boolean;  // 是否必填项;
  marginBottom?: string;
  disabledDate?: (d: Dayjs) => boolean;  // 禁用的日期, 默认今日以后的日期不可选;
  timeFormat?: 'HH:mm:ss' | 'HH:mm';  // 默认不展示时间;
  useThemeError?: boolean;  // 是否展示报错界面
  errorPadding?: string;  // 仅 useThemeError，默认 0 0 0 100px;
  disabled?: boolean;  // 仅 useThemeError;
  customGetErrorTips?: (d?: Dayjs) => string;  // 自定义报错逻辑
}

interface Emit {
  (e: 'change', v: Dayjs): void;
}

defineExpose({
  hasError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const PLACEHOLDER = '请选择';

const value = ref<Dayjs | undefined>(prop.data);
const errorTips = ref<string>('');
const innerPlaceholder = computed<string>(() => prop.placeholder || PLACEHOLDER);
const format = computed<string>(() => prop.timeFormat ? `YYYY-MM-DD ${prop.timeFormat}` : 'YYYY-MM-DD');


watch(() => prop.data, (newData) => {
  value.value = newData;
}, { immediate: true });

function hasError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

function getErrorTips(data?: Dayjs): string {
  if (prop.customGetErrorTips) {
    return prop.customGetErrorTips.call(null, data);
  }
  if (!data) {
    return '时间不可为空';
  }
  return '';
}

function onChange(day: Dayjs): void {
  errorTips.value = getErrorTips(value.value);
  emit('change', day);
}
</script>

<template>
  
  <div v-if="useThemeError" style="height: 40px;" :style="{ width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div class="flex items-center text-white text-s">
      <div v-if="title" :style="{ width: titleWidth || '100px' }" class="text-right pr-8">
        <i v-if="isRequired" class="text-red-2 mr-8">*</i><span :class="{ 'text-white': !disabled, 'text-weak-2': disabled }">{{ title }}</span>
      </div>
      <a-date-picker
        v-model:value="value"
        :placeholder="innerPlaceholder"
        :allowClear="false"
        :disabled="disabled"
        :disabled-date="disabledDate || disableDayAfterToday"
        :show-time="timeFormat ? { format: timeFormat } : null"
        :format="format"
        :showNow="false"
        :class="errorTips ? 'date-picker-frame has-error' : 'date-picker-frame'"
        dropdownClassName="date-picker-frame-dropdown"
        @change="onChange"
      >
        <template #suffixIcon><IconDate /></template>
      </a-date-picker>
    </div>
    <ErrorView :tips="errorTips" is-text-left :padding="errorPadding || '0 0 0 100px'" />
  </div>
  <div v-else class="flex items-center text-white text-s" style="height: 40px;" :style="{ width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div v-if="title" :style="{ width: titleWidth || '100px' }"  class="text-right pr-8">
      <i v-if="isRequired" class="text-red-2 mr-8">*</i>{{ title }}
    </div>
    <a-date-picker
      v-model:value="value"
      :placeholder="innerPlaceholder"
      :allowClear="false"
      :disabled-date="disabledDate || disableDayAfterToday"
      :show-time="timeFormat ? { format: timeFormat } : null"
      :format="format"
      :showNow="false"
      :class="errorTips ? 'date-picker-frame has-error' : 'date-picker-frame'"
      dropdownClassName="date-picker-frame-dropdown"
      @change="onChange"
    >
      <template #suffixIcon><IconDate /></template>
    </a-date-picker>
  </div>
</template>
