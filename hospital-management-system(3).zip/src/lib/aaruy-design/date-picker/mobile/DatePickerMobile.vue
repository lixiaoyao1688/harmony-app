<script setup lang="ts">
import { Dayjs } from 'dayjs';
import { ONE } from '@/lib/math/config/math.config';
import { turnToDate,turnToDayjs } from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile.style.css';


interface Prop {
  date: Dayjs;
  title: string;
  showPicker: boolean;
  columnsType: string[];
  minDate: Dayjs;
  maxDate: Dayjs;
}

interface Emit {
  (e: 'ok', date: Dayjs): void;
  (e: 'close'): void;
  (e: 'click-overlay'): void;
}

const getCurrDate = (date: Dayjs) => {
  let types: string[] = prop.columnsType;
  let y: number, m: number, d: number;
  let arr: number[] = [];
  for (let item of types) {
    if (item === 'year') {
      y = date.year();
      arr.push(y);
    } else if (item === 'month') {
      m = date.month() + ONE;
      arr.push(m);
    } else if (item === 'day') {
      d = date.date();
      arr.push(d);
    }
  }
  return arr.map(it => {
    return it.toString();
  });
};

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
let currentDate = prop.date ? getCurrDate(prop.date) : new Date();
let minDate: Date = prop.minDate ? turnToDate(prop.minDate) : new Date(1950, 1, 1);
let maxDate: Date = prop.maxDate ? turnToDate(prop.maxDate) : new Date(2100, 12, 31);

function confirm(e) {
  let date :Dayjs = turnToDayjs(e.selectedValues);
  emit('ok', date);
}

function cancel() {
  emit('close');
}

function onClickOverlay(): void {
  emit('click-overlay');
}
</script>

<template>
  <van-popup :show="showPicker"
             position="bottom" class="time-picker-mobile"
             @click-overlay="onClickOverlay"
  >
    <van-date-picker
			v-model="currentDate"
			:title="title"
			:columns-type="columnsType"
			:min-date="minDate"
			:max-date="maxDate"
			confirm-button-text="确定"
			@confirm="confirm"
			@cancel="cancel"
    />
  </van-popup>
</template>
