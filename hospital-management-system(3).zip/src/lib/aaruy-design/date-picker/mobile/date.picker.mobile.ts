import dayjs, { Dayjs } from 'dayjs';


export const EnumDateColumnsType = Object.freeze({
  ymd: ['year', 'month', 'day'],
  ym: ['year', 'month'],
  y: ['year'],
  md: ['month', 'day']
});

export const EnumTimeColumnsType = Object.freeze({
  hms: ['hour', 'minute', 'second'],
  hm: ['hour', 'minute']
});

// Dayjs类型转为Date类型
export function turnToDate(date: Dayjs): Date {
  const y: number = date.year();
  const m: number = date.month();
  const d: number = date.date();
  return new Date(y, m, d);
}

/*
* 数组转为Dayjs类型
* @params dateArr: ["2020","1","1"]
* */
export function turnToDayjs(dateArr: Array<string>): Dayjs {
  const d: string = dateArr.join('-');
  const date: Dayjs = dayjs(d);
  return date;
}

// 将Dayjs类型的值转换为v-model中使用的Array<string>
export function getDayjsTypeDate(date: Dayjs): Array<string> {
  const y: number = date.year();
  const m: number = date.month() + 1;
  const d: number = date.date();
  return [y, m, d].map(it => {
    return it.toString();
  });
}

// 将Date类型的值转换为v-model中使用的Array<string>
export function getDateTypeDate(date: Date): Array<string> {
  const y: number = date.getFullYear();
  const m: number = date.getMonth()+ 1;
  const d: number = date.getDate();
  return [y, m, d].map(it => {
    return it.toString();
  });
}
