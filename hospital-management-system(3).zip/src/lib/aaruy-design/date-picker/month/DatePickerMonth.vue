<script setup lang="ts">
import { ref, watch } from 'vue';
import { Dayjs } from 'dayjs';
import IconDate from '@/lib/icon/IconDate.vue';
import '@/lib/aaruy-design/date-picker/month/date.picker.month.style.css';
import '@/lib/aaruy-design/date-picker/date.picker.dropdown.style.css';


interface Prop {
  data: Dayjs | undefined;  // 初始值
  disabledDate?: (d: Dayjs) => boolean;  // 不可选的日期
}

interface Emit {
  (e: 'change', v: Dayjs): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<Dayjs | undefined>(prop.data);


watch(() => prop.data, (newData) => {
  value.value = newData;
});

function onChange(day: Dayjs) {
  emit('change', day);
}
</script>

<template>
  <a-date-picker
    v-model:value="value"
    :disabledDate="disabledDate"
    :allowClear="false"
    picker="month"
    placeholder="选择月份"
    @change="onChange"
    class="date-picker-month"
    dropdownClassName="date-picker-form-dropdown"
  >
    <template #suffixIcon>
      <IconDate />
    </template>
  </a-date-picker>
</template>
