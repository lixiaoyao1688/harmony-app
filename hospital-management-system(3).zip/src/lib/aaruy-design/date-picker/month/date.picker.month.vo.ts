export const DATE_MONTH_FORMAT = 'YYYY-MM';
