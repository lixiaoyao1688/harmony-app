<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import { Dayjs } from 'dayjs';
import IconStepLeft from '@/lib/aaruy-design/date-picker/step/icons/IconStepLeft.vue';
import IconStepRight from '@/lib/aaruy-design/date-picker/step/icons/IconStepRight.vue';
import '@/lib/aaruy-design/date-picker/date.picker.dropdown.style.css';
import '@/lib/aaruy-design/date-picker/step/date.picker.step.style.css';


interface Prop {
	day: Dayjs;
  disabledDate?: (cur: Dayjs) => boolean;
  width?: string;
  left?: string;
  margin?: string;
}

interface Emit {
	(e: 'change', data: Dayjs): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const dayText = computed<string>(() => prop.day.format('YYYY-MM-DD'));
const isLastDisabled = ref<boolean>(false);
const isNextDisabled = ref<boolean>(false);


watch(() => prop.day, (data) => {
  if (!prop.disabledDate) {
    return;
  }
  checkIsDisabled(data);
}, { immediate: true });


function onOpen(): void {
  isOpened.value = true;
}

function onOpenChange(data: boolean) {
  isOpened.value = data;
}

function onChange(day: Dayjs): void {
  emit('change', day.hour(0).minute(0).second(0).millisecond(0));
}

function checkIsDisabled(currentDay: Dayjs): void {
  isLastDisabled.value = prop.disabledDate ? prop.disabledDate(currentDay.subtract(1, 'day')) : false;
  isNextDisabled.value = prop.disabledDate ? prop.disabledDate(currentDay.add(1, 'day')) : false;
}

function onLast(): void {
  if (isLastDisabled.value) {
    return;
  }
  onChange(prop.day.subtract(1, 'day'));
}
function onNext(): void {
  if (isNextDisabled.value) {
    return;
  }
  onChange(prop.day.add(1, 'day'));
}
</script>

<template>
	<div class="relative" :style="{ margin: margin }">
		<div
			class="bg-1 flex items-center justify-between rounded-4"
			style="height: 36px;"
      :style="{ width: width || '200px' }"
		>
			<div class="rounded-4 inline-flex items-center justify-center"
           :class="{
             'cursor-pointer bg-hover-primary-2 bg-default-1': !isLastDisabled,
             'cursor-not-allowed bg-default-2': isLastDisabled,
           }"
           style="width: 36px; height: 36px;"
           @click="onLast">
        <IconStepLeft :is-disabled="isLastDisabled" />
			</div>
			<div
				class="text-s leading-s font-bold text-white flex-1 cursor-pointer text-color-hover-primary text-center"
				@click="onOpen">{{ dayText }}</div>
			<div class="rounded-4 inline-flex items-center justify-center"
           :class="{
             'cursor-pointer bg-hover-primary-2 bg-default-1': !isNextDisabled,
             'cursor-not-allowed bg-default-6': isNextDisabled,
           }"
           style="width: 36px; height: 36px;"
           @click="onNext">
				<IconStepRight :is-disabled="isNextDisabled" />
			</div>
		</div>
		<a-date-picker
			class="date-picker-step"
			:open="isOpened"
      :disabled-date="disabledDate"
      :style="{ left: left || 0 }"
			@change="onChange"
			@openChange="onOpenChange"
			dropdownClassName="date-picker-form-dropdown"
		/>
	</div>
</template>
