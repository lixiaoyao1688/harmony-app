<script setup lang="ts">
interface Prop {
  isDisabled?: boolean;
}

const prop = defineProps<Prop>();
</script>

<template>
	<svg xmlns="http://www.w3.org/2000/svg" width="8.001" height="14.237" viewBox="0 0 8.001 14.237">
		<path d="M12.731,7.743,7.118,2.129,1.506,7.743A.882.882,0,0,1,.258,6.5L6.494.258a.883.883,0,0,1,1.247,0l.022.023L13.978,6.5a.882.882,0,1,1-1.247,1.247Z"
          transform="translate(0 14.236) rotate(-90)"
          :fill="isDisabled ? 'rgba(245,245,245,0.5)' : 'rgb(245,245,245)'" />
	</svg>
</template>
