<script setup lang="ts">
interface Prop {
  isDisabled?: boolean;
}

const prop = defineProps<Prop>();
</script>


<template>
	<svg xmlns="http://www.w3.org/2000/svg" width="8.001" height="14.237" viewBox="0 0 8.001 14.237">
		<path d="M6.494,7.743.257,1.506A.882.882,0,0,1,1.5.258L7.118,5.872,12.731.258a.882.882,0,1,1,1.247,1.247L7.763,7.72l-.021.022a.882.882,0,0,1-1.247,0Z"
          transform="translate(0 14.236) rotate(-90)"
          :fill="isDisabled ? 'rgba(245,245,245,0.5)' : 'rgb(245,245,245)'" />
	</svg>
</template>
