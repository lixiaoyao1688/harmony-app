import {Dayjs} from 'dayjs';


export type DatePickerDataType = Dayjs | null;

export type DatePickerExposedType = {
  checkValueError: () => boolean;
  getExposeErrorTips?: () => string;
}
