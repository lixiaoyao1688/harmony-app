<script setup lang="ts">
import dayjs, {Dayjs} from 'dayjs';
import {ref, watch} from 'vue';
import {DEFAULT_DATE_PICKER_CONFIG} from '@/lib/aaruy-design/date-picker/config/date.picker.config';
import IconDateRangePicker2Date from '@/lib/aaruy-design/date-range-picker/picker2/icon/IconDateRangePicker2Date.vue';
import '@/lib/aaruy-design/date-picker/style/date.picker.style.css';
import '@/lib/aaruy-design/date-picker/style/date.picker.dropdown.style.css';
import type {DatePickerDataType} from '@/lib/aaruy-design/date-picker/type/date.picker.type';


/**
 * 日期选择器 组件
 *
 * 适用项目
 * 请替换为项目名称
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  data: DatePickerDataType | undefined;
  timeFormat?: string;  // 是否展示时间，格式如: 'HH:mm';
  placeholder?: string;
  width?: string;
  height?: string;
  margin?: string;
  name?: string;
  disabledDate?: (cur: Dayjs) => boolean;  // 不可选择的日期。函数返回 true 代表该 cur 不可被选择。
  runningStopTime?: Dayjs;  // 大剂量/临时基础率的结束时刻
}

interface Emit {
	(e: 'change', data: DatePickerDataType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<DatePickerDataType>(null);
const errorTips = ref<string>('');


defineExpose({
  checkValueError
});

watch(() => prop.data, (data) => {
  if (data) {
    value.value = data;
  }
}, { immediate: true });

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

// 注意: 和 isAdviceStartTimeError 保持一致
function getErrorTips(data: DatePickerDataType | undefined): string {
  if (!data) {
    return `${prop.name}不能为空`;
  }
  const NOW = dayjs();  // 分钟数一样可通过
  if (data.unix() < NOW.subtract(1,'minute').unix()) {
    return `${prop.name}不得早于当前时刻: ${NOW.format('HH:mm')}`;
  }
  if (prop.runningStopTime && data.unix() < prop.runningStopTime.unix()) {
    return '与当前输注内容冲突';
  }
  return '';
}

function onChange(data: DatePickerDataType): void {
  errorTips.value = getErrorTips(data);
  emit('change', data);
}
</script>

<template>
  <div class="bg-10 border-bg-10 inline-flex items-center rounded-4 relative"
       :class="{ 'border-error': errorTips }"
       :style="{
          width: width || DEFAULT_DATE_PICKER_CONFIG.WIDTH,
          height: height || DEFAULT_DATE_PICKER_CONFIG.HEIGHT,
          margin: margin || DEFAULT_DATE_PICKER_CONFIG.MARGIN,
       }"
  >
    <div class="px-8 inline-flex h-full items-center">
      <IconDateRangePicker2Date />
    </div>
    <a-date-picker v-model:value="value"
                   :show-time="timeFormat ? { format: timeFormat } : null"
                   :format="'YYYY-MM-DD' + (timeFormat ? ' HH:mm' : '')"
                   :placeholder="placeholder"
                   :suffix-icon="false"
                   :allow-clear="false"
                   :show-now="false"
                   :disabled-date="disabledDate"
                   class="aaruy-date-picker"
                   dropdownClassName="aaruy-date-picker-dropdown"
                   @change="onChange" />
    <div v-if="errorTips" class="absolute text-error font-bold" style="bottom: -22px; left: 0;">{{ errorTips }}</div>
  </div>
</template>
