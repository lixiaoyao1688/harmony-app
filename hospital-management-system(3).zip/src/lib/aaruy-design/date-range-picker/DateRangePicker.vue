<script setup lang="ts">
import {ref, watch} from 'vue';
import { Dayjs } from 'dayjs';
import { getDefaultDisabledDay, getDisabledDayOnCalendarChange } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import IconDateClear from '@/lib/aaruy-design/date-range-picker/icons/IconDateClear.vue';
import IconDate from '@/lib/aaruy-design/date-range-picker/icons/IconDate.vue';
import TooltipCard from '@/lib/aaruy-design/tooltip/card/TooltipCard.vue';
import '@/lib/aaruy-design/date-range-picker/styles/date.range.picker.style.css';
import type { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


interface Prop {
	range: NewDateRange;
  maxRange?: number;  // 可选的最大范围，单位天
	width?: string;
	disabled?: boolean;
	disabledDate?: (c: Dayjs) => boolean | null;
}

interface Emit {
	(e: 'change', data: NewDateRange): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const disabledDate = ref(prop.disabledDate || getDefaultDisabledDay);


watch(() => prop.disabledDate, (data) => {
  if (!data) {
    return;
  }
  disabledDate.value = data;
}, { immediate: true });

function onRangeChange(data: NewDateRange): void {
  if (!data || !data[0] || !data[1]) {
    emit('change', null);
    return;
  }
  emit('change', [timeZeroing(data[0]), timeZeroing(data[1])]);
}

function timeZeroing(d: Dayjs): Dayjs {
  return d.hour(0).minute(0).second(0).millisecond(0);
}

function onCalendarChange(range: NewDateRange): void {
  if (!prop.disabledDate) {
    disabledDate.value = getDisabledDayOnCalendarChange(range, prop.maxRange);
  }
}

function reset(): void {
  disabledDate.value = prop.disabledDate || getDefaultDisabledDay;
  onRangeChange(null);
}
</script>

<template>
	<div class="inline-flex items-center justify-center relative" style="height: 32px;" :style="{ width: width }">
		<a-range-picker
			:value="range"
			:disabled="disabled"
			:placeholder="['开始日期', '结束日期']"
			:disabled-date="disabledDate"
			:suffix-icon="false"
			class="date-range-picker"
			dropdownClassName="date-range-picker-dropdown"
			@ok="onRangeChange"
			@change="onRangeChange"
			@calendarChange="onCalendarChange"
		/>
		<IconDate v-if="!range" class="absolute cursor-default right-10" :style="{ opacity: disabled ? 0.5 : 1 }" />
		<TooltipCard v-else title="重置日期" placement="top">
			<IconDateClear class="absolute cursor-pointer right-10" @click="reset" />
		</TooltipCard>
	</div>
</template>
