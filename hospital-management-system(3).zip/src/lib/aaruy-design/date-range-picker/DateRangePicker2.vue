<script setup lang="ts">
import {ref, watch} from 'vue';
import { Dayjs } from 'dayjs';
import {timeZeroing} from '@/lib/time/util/time.util';
import {getDisabledDay} from '@/lib/time/util/dayjs.util';
import { MAX_RANGE_FOR_NORMAL } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import IconDateClear from '@/lib/aaruy-design/date-range-picker/icons/IconDateClear.vue';
import IconDate from '@/lib/aaruy-design/date-range-picker/icons/IconDate.vue';
import TooltipCard from '@/lib/aaruy-design/tooltip/card/TooltipCard.vue';
import '@/lib/aaruy-design/date-range-picker/styles/date.range.picker.style.css';
import type { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


/**
 * 日期范围选择器 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  range: NewDateRange;
  width?: string;
  disabled?: boolean;
  margin?: string;
  maxRange?: number;  // 可选的最大范围，单位天
  disabledDate?: (c: Dayjs) => boolean;  // 禁止选择的日期，返回 true 代表该日期被禁用
}

interface Emit {
  (e: 'change', data: NewDateRange): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const innerDisabledFn = ref<(c: Dayjs) => boolean>();


watch(() => prop.disabledDate, (data) => {
  if (!data) {
    return;
  }
  innerDisabledFn.value = data;
}, { immediate: true });

function onRangeChange(data: NewDateRange): void {
  if (!data || !data[0] || !data[1]) {
    emit('change', null);
    return;
  }
  emit('change', [timeZeroing(data[0]), timeZeroing(data[1])]);
}

function onCalendarChange(range: NewDateRange): void {
  innerDisabledFn.value = getDisabledDay(range, prop.maxRange || MAX_RANGE_FOR_NORMAL, prop.disabledDate);
}

function onReset(): void {
  innerDisabledFn.value = prop.disabledDate;
  onRangeChange(null);
}
</script>

<template>
  <div class="inline-flex items-center justify-center relative"
       style="height: 32px;"
       :style="{ width: width, margin: margin }">
    <a-range-picker
      :value="range"
      :disabled="disabled"
      :placeholder="['开始日期', '结束日期']"
      :disabled-date="innerDisabledFn"
      :suffix-icon="false"
      class="date-range-picker"
      dropdownClassName="date-range-picker-dropdown"
      @ok="onRangeChange"
      @change="onRangeChange"
      @calendarChange="onCalendarChange"
    />
    <IconDate v-if="!range" class="absolute cursor-default right-10" :style="{ opacity: disabled ? 0.5 : 1 }" />
    <TooltipCard v-else title="重置日期" placement="top">
      <IconDateClear class="absolute cursor-pointer right-10" @click="onReset" />
    </TooltipCard>
  </div>
</template>
