import dayjs, { Dayjs } from 'dayjs';
import { getTomorrowTimestamp } from '@/lib/time/util/time.util';
import type { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


export const DEFAULT_RANGE_DAYS = 14;  // 默认日期范围: 最近 14 天
export const MAX_RANGE_FOR_ANALYZE = 30;  // 统计分析 最近 30 天
export const MAX_RANGE_FOR_NORMAL = 14;  // 默认最大日期范围
export const MAX_RANGE_FOR_GLU = 30;  // 血糖分析最大日期范围


// 只要一天的区间
export function getOneDayRange(date?: Date): [Dayjs, Dayjs] {
  const d = date ? dayjs(date) : dayjs();
  const start = d.hour(0).minute(0).second(0).millisecond(0);
  return [start, start];
}

// 默认范围
export function getDefaultRange(count?: number): [Dayjs, Dayjs] {
  const DAYS = count || DEFAULT_RANGE_DAYS;
  const today = dayjs().hour(0).minute(0).second(0).millisecond(0);
  return [today.subtract(DAYS - 1, 'day'), today];
}

export function getDefaultRangeForAnalyze(): [Dayjs, Dayjs] {
  const today = dayjs().hour(0).minute(0).second(0).millisecond(0);
  return [today.subtract(MAX_RANGE_FOR_ANALYZE - 1, 'day'), today];
}


// 今天以后的日期不可选
export function disableDayAfterToday(c: Dayjs): boolean {
  return c && c.toDate().getTime() >= getTomorrowTimestamp(0,0,0,0);
}

// 默认禁用的日期
export function getDefaultDisabledDay(c: Dayjs): boolean {
  return disableDayAfterToday(c);
}

// 选中日期后，下一个日期和它形成的范围，不得超过预设范围
export function getDisabledDayOnCalendarChange(range: NewDateRange, maxRange?: number): (c: Dayjs) => boolean {
  return function (c: Dayjs) {
    // 返回 true 表示禁用
    // c 表示当前正在判断的日期
    
    // 不得选择今天以后的日期
    if (c && c.toDate().getTime() >= getTomorrowTimestamp(0,0,0,0)) {
      return true;
    }
    
    // base case
    if (!range || range.length < 2) {
      return false;
    }
    
    // 选中一个日期后，只能选择范围内的日期
    const [start, end] = range;
    const max = maxRange || DEFAULT_RANGE_DAYS;
    const tooLate = (start && c.diff(start, 'days') >= max);
    const tooEarly = (end && end.diff(c, 'days') >= max);
    return tooEarly || tooLate;
  };
}
