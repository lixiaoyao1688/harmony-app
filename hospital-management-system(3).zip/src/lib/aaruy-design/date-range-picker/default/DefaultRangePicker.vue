<script setup lang="ts">
import DateRangePicker from '@/lib/aaruy-design/date-range-picker/DateRangePicker.vue';
import { getDefaultDisabledDay } from '@/lib/aaruy-design/date-range-picker/config/date.range.picker.config';
import type { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


interface Prop {
	title: string;
	data: NewDateRange;
	pickerWidth: string;
  maxRange?: number;
}

interface Emit {
	(e: 'change', data: NewDateRange): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onRangeChange(d: NewDateRange): void {
  emit('change', d);
}
</script>

<template>
	<div class="flex items-center">
		<span class="mr-12 text-s">{{ title }}</span>
		<DateRangePicker :range="data" :max-range="maxRange" :width="pickerWidth" :disabled-date="getDefaultDisabledDay"
                     @change="onRangeChange" />
	</div>
</template>
