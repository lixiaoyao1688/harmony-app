<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { fillZero as f } from '@/lib/time/util/time.util';
import IconDate from '@/lib/icon/IconDate.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import '@/lib/aaruy-design/date-range-picker/field/date.time.picker.mobile.css';


/**
 * 日期时间选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  data: Dayjs | undefined;  // 初始选中的时间
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题
  isRequired?: boolean;
  useFont16?: boolean;  // 字号是否使用 16px;
  isDisabled?: boolean;  // 是否禁用
  placeholder?: string;  // 默认"请选择"
  isStyleForm?: boolean;  // 是否使用 Form 样式
  min?: Dayjs;  // 可选的最小时间，精确到日，默认十年前
  max?: Dayjs;  // 可选的最小时间，精确到日，默认十年后
}

interface Emit {
  (e: 'change', data: Dayjs): void;
}

const NOW = dayjs();
const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const minDate = computed<Date>(() => prop.min ? prop.min.toDate() : new Date(2000, 0, 1));
const maxDate = computed<Date>(() => prop.max ? prop.max.toDate() : new Date(2100, 0, 1));
const currentDate = ref<[string, string, string]>([NOW.year().toString(), f((NOW.month()+1)), f(NOW.date())]);
const currentTime = ref<[string, string]>([f(NOW.hour()), f(NOW.minute())]);
const dataText = computed<string>(() => prop.data ? prop.data.format('YYYY-MM-DD HH:mm') : '');


watch(() => prop.data,  (d) => {
  if (d) {
    currentDate.value = [f(d.year()), f(d.month()+1), f(d.date())];
    currentTime.value = [f(d.hour()), f(d.minute())];
  }
}, { immediate: true });

function onOpen(): void {
  if (prop.isDisabled) {
    return;
  }
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onCancel(): void {
  onClose();
}

function onConfirm(): void {
  const ds = currentDate.value;
  const ts = currentTime.value;
  
  const yr = +ds[0];
  const mo = Math.floor((+ds[1]) - 1);
  const dt = +ds[2];
  const hr = +ts[0];
  const mi = +ts[1];
  
  emit('change', dayjs().year(yr).month(mo).date(dt).hour(hr).minute(mi).second(0).millisecond(0));
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" position="bottom" class="picker-mobile date-time-picker-mobile"
             @click-overlay="onClose">
    <van-picker-group
      :title="title"
      :tabs="['选择日期', '选择时间']"
      @confirm="onConfirm"
      @cancel="onCancel"
    >
      <van-date-picker
        v-model="currentDate"
        :min-date="minDate"
        :max-date="maxDate"
      />
      <van-time-picker v-model="currentTime" />
    </van-picker-group>
  </van-popup>
  <div v-if="isStyleForm" class="date-picker-form date-picker-form-mobile">
    <div class="date-picker-form-title">{{ title }} <i v-if="isRequired">*</i></div>
    <div class="date-picker-form-mobile-data"
         :style="{ color: data ? 'rgb(255,255,255)' : 'rgb(163,175,188)' }"
         @click="onOpen">
      <span v-if="data" class="mr-4">{{ dataText }}</span>
      <span v-else class="mr-4 text-weak-2">{{ placeholder || '请选择' }}</span>
      <IconDate class="ml-4" />
    </div>
  </div>
  <div v-else class="flex items-center justify-between h-full w-full leading-l text-xs"
       :class="{
          'text-s': useFont16, 'text-xs': !useFont16,
          'text-weak': isDisabled, 'text-white': !isDisabled,
       }"
       @click="onOpen">
    <span :class="{ hidden: hideOutSideTitle }">
      <i v-if="isRequired" class="mr-2 text-required" style="font-style: normal;">*</i>{{ title }}
    </span>
    <div class="inline-flex items-center">
      <span v-if="data" class="mr-4">{{ dataText }}</span>
      <span v-else class="mr-4 text-weak-2">{{ placeholder || '请选择' }}</span>
      <IconPickerField />
    </div>
  </div>
</template>

<style scoped>
.date-picker-form > .date-picker-form-title {
  font-size: 16px;
}

.date-picker-form > .date-picker-form-title > i {
  margin-left: 4px;
  color: rgb(255, 36, 42);
}

/* mobile */
.date-picker-form-mobile {
  font-size: 16px;
  padding-top: 20px !important;
  padding-bottom: 8px !important;
  background-color: transparent !important;
  border-bottom-width: 1px !important;
  border-bottom-color: rgb(91, 103, 116) !important;
}

.date-picker-form-mobile .date-picker-form-title {
  font-size: 16px !important;
}

.date-picker-form-mobile .date-picker-form-mobile-data {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex: 1;
}
</style>
