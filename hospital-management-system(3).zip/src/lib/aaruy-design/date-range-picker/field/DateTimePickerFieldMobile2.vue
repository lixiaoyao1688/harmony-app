<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { fillZero as f } from '@/lib/time/util/time.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import '@/lib/aaruy-design/date-range-picker/field/date.time.picker.mobile.css';


/**
 * 日期时间选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  data: Dayjs | undefined;  // 初始选中的时间
  disabledDate?: (c: Dayjs) => boolean;  // 禁用的日期，将日期传入该函数，返回 true 代表该日期禁用
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题
  isRequired?: boolean;
  useFont16?: boolean;  // 字号是否使用 16px;
  isDisabled?: boolean;  // 是否禁用
  placeholder?: string;  // 默认"请选择"
  padding?: string;  // 默认"0 0 4px";
}

interface Emit {
  (e: 'change', data: Dayjs): void;
  (e: 'error-change', data: string): void;
}

const NOW = dayjs();
const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const errorTips = ref<string>('');
const minDate = new Date(2000, 0, 1);
const maxDate = new Date(2100, 0, 1);
const currentDate = ref<[string, string, string]>([NOW.year().toString(), f((NOW.month()+1)), f(NOW.date())]);
const currentTime = ref<[string, string, string]>([f(NOW.hour()), f(NOW.minute()), f(NOW.second())]);
const dataText = computed<string>(() => prop.data ? prop.data.format('YYYY-MM-DD HH:mm:ss') : '');

defineExpose({
  checkValueError
});

watch(() => prop.data,  (d) => {
  if (d) {
    currentDate.value = [f(d.year()), f(d.month()+1), f(d.date())];
    currentTime.value = [f(d.hour()), f(d.minute()), f(d.second())];
  }
}, { immediate: true });

function onOpen(): void {
  if (prop.isDisabled) {
    return;
  }
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onCancel(): void {
  onClose();
}

function checkValueError(): boolean {
  const tips = getErrorTips(prop.data);
  errorTips.value = tips;
  emit('error-change', tips);
  return tips !== '';
}

function getErrorTips(data: Dayjs | undefined): string {
  if (prop.isRequired && !data) {
    return '请选择';
  }
  return '';
}

function onConfirm(): void {
  const ds = currentDate.value;
  const ts = currentTime.value;
  
  const yr = +ds[0];
  const mo = Math.floor((+ds[1]) - 1);
  const dt = +ds[2];
  const hr = +ts[0];
  const mi = +ts[1];
  const sc = +ts[2];
  
  const d = dayjs().year(yr).month(mo).date(dt).hour(hr).minute(mi).second(sc).millisecond(0);
  const tips = getErrorTips(d);
  errorTips.value = tips;
  emit('change', d);
  emit('error-change', tips);
  
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" position="bottom" class="picker-mobile date-time-picker-mobile"
             @click-overlay="onClose">
    <van-picker-group
      :title="title"
      :tabs="['选择日期', '选择时间']"
      @confirm="onConfirm"
      @cancel="onCancel"
    >
      <van-date-picker
        v-model="currentDate"
        :min-date="minDate"
        :max-date="maxDate"
      />
      <van-time-picker v-model="currentTime" :columns-type="['hour', 'minute', 'second']" />
    </van-picker-group>
  </van-popup>
  <div class="flex items-center justify-between h-full w-full leading-l border-b-bg-0"
       :style="{
         padding: padding || '0 0 4px',
         borderColor: errorTips ? 'var(--aaruy-error-color-2)' : 'var(--aaruy-bg-color-0)'
       }"
       :class="{
          'text-s': useFont16, 'text-xs': !useFont16,
          'text-weak': isDisabled, 'text-white': !isDisabled,
       }"
       @click="onOpen">
    <span :class="{ hidden: hideOutSideTitle }">
      <i v-if="isRequired" class="mr-2 text-error-2" style="font-style: normal;">*</i>
      <span :class="{ 'text-error-2': errorTips }">{{ title }}</span>
    </span>
    <div class="inline-flex items-center">
      <span v-if="data" class="mr-4">{{ dataText }}</span>
      <span v-else class="mr-4 text-default-1 font-bold">{{ placeholder || '请选择' }}</span>
      <IconPickerField />
    </div>
  </div>
  <ErrorView v-if="errorTips" :tips="errorTips" :font-weight="400" color="var(--aaruy-error-color-2)" />
</template>
