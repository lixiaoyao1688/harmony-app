<script setup lang="ts">
import { Dayjs } from 'dayjs';
import {onBeforeUpdate, ref, watch} from 'vue';
import { DateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';
import IconDateClear from '@/lib/aaruy-design/date-range-picker/icons/IconDateClear.vue';
import '@/lib/aaruy-design/date-range-picker/filter/data.range.picker.filter.style.css';


interface Prop {
  title: string;
	value: DateRange;
	pickerWidth: string;
	placeholderStart: string;
	placeholderEnd: string;
	showTime?: boolean;  // 是否展示 时分秒
	textTitle?: string | boolean;  // 是否展示 文字提示
  disabledDate?: (current: Dayjs) => boolean;  // 不可选的日期
  onCalendarChange?: (range: DateRange) => void;
  disabled?: [boolean, boolean];
}

interface Emit {
	(e: 'reset'): void;
  (e: 'rangeChange', range: DateRange): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const innerRange = ref<any>(prop.value);
const isOpened = ref<boolean>(false);


watch(() => prop.value, (data) => {
  innerRange.value = data;
}, { immediate: true });


onBeforeUpdate(() => {
  innerRange.value = prop.value;
});

function onRangeChange(): void {
  emit('rangeChange', innerRange.value);
}

function reset(): void {
  emit('rangeChange', [undefined, undefined]);
}
</script>

<template>
  <div class="range-filter">
    <template v-if="textTitle">
      <a-tooltip :title="textTitle">
        <label class="text">{{ title }}</label>
      </a-tooltip>
    </template>
    <template v-else>
      <label class="text">{{ title }}</label>
    </template>
    <a-range-picker
      v-model:value="innerRange"
			v-model:open="isOpened"
      :placeholder="[placeholderStart, placeholderEnd]"
      :style="'width: ' + pickerWidth"
      :disabled-date="disabledDate"
      :show-time="showTime"
			:suffix-icon="false"
      :disabled="disabled"
      class="item range-picker-filter"
      dropdownClassName="range-picker-filter-dropdown"
      @ok="onRangeChange"
      @change="onRangeChange"
      @calendarChange="onCalendarChange"
    />
		<IconDateClear class="range-filter-icon" @click="reset" />
  </div>
</template>

<style scoped>
.range-filter {
  width: fit-content;
  height: 32px;
  display: flex;
	align-items: center;
	position: relative;
}

.range-filter .text {
  display: inline-block;
  height: 32px;
  line-height: 32px;
  text-align: right;
  padding-right: 12px;
  font-size: 16px;
}

.range-filter-icon {
	position: absolute;
	cursor: pointer;
	right: 10px;
}
</style>
