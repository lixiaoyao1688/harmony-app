<template>
	<svg id="iconDateClear" data-name="组 7990" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 14 13.999">
		<path id="iconDateClearPath" data-name="减去 30" d="M7,14a7,7,0,1,1,7-7A7.007,7.007,0,0,1,7,14ZM7,7.824H7l2.336,2.338a.584.584,0,1,0,.825-.825L7.826,7l2.336-2.337a.584.584,0,0,0-.825-.825L7,6.175,4.662,3.837a.586.586,0,0,0-.825,0,.582.582,0,0,0,0,.825L6.175,7,3.837,9.337a.584.584,0,1,0,.825.825L7,7.824Z" fill="#a3afbc"/>
	</svg>
</template>

<style scoped>
#iconDateClear {
	outline: none !important;
}
</style>
