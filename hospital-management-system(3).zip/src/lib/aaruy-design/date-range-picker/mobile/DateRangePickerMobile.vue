<!--
组件编写需求说明
 1.当先选择了开始时间则结束时间的最小值则为开始时间
 2.当先选择了结束时间则当选择开始时间且它大于结束时间时结束时间需要清空重新选择
 3.结束时间必须大于等于开始时间
 4.开始时间与结束时间都不可编辑
 5.进入组件时首先高亮开始时间选择框
 6.当点击开始时间或结束时间则根据选择高亮不同的选框
-->
<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { onMounted, ref } from 'vue';
import {
  getDateTypeDate,
  getDayjsTypeDate,
  turnToDate,
  turnToDayjs
} from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import { DateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import '@/lib/aaruy-design/date-range-picker/mobile/date.picker.range.mobile.style.css';


/*
* 日期范围组件传递的属性说明
* 根据minDate 和 maxDate 属性来设定总的可选的时间范围
* 通过rangeDate设置默认显示的开始时间与结束时间
* 根据事件 "getDateRange" 返回 选择的范围
* 当不传递minDate 与 maxDate时，可选的时间范围为当前时间左右10年
* */

// 选择框枚举
enum EnumType {
  start,
  end
}

interface Props {
  minDate?: Dayjs, //可选的最小时间
  maxDate?: Dayjs, //可选的最大时间
  rangeDate?: DateRange, //默认的[开始时间,结束时间]
  showBottomButton?: boolean,//是否显示底部确认取消按钮
}


const props = defineProps<Props>();
const emit = defineEmits<{
  (e: 'getDateRange', value: DateRange): void,
  (e: 'confirm', value: DateRange): void,
  (e: 'cancel'): void
}>();

const currentDate = ref(); // 当前选择的时间
const clickType = ref<number>(EnumType.start); // 选择框的类型
const startDate = ref<Array<string> | undefined>(undefined);  // 选择的开始时间
const endDate = ref<Array<string> | undefined>(undefined); //选择的结束时间
const minDate = ref<Date>(); // 总的可选的最小时间
const maxDate = ref<Date>(); //总的可选的最大时间
const currMinDate = ref<Date>();//开始时间或结束时间的可选最小时间


onMounted(() => {
  if (props.minDate) {
    minDate.value = turnToDate(props.minDate);
  } else {
    let minDefault = dayjs().subtract(10, 'year');
    minDate.value = turnToDate(minDefault);
  }

  if (props.maxDate) {
    maxDate.value = turnToDate(props.maxDate);
  } else {
    let maxDefault = dayjs().add(10, 'year');
    maxDate.value = turnToDate(maxDefault);
  }

  currMinDate.value = minDate.value;

  // 如果有默认的时间范围 赋值
  if (props.rangeDate && props.rangeDate.length > 0) {
    const [startD, endD] = props.rangeDate;
    startDate.value = startD && getDayjsTypeDate(startD);
    endDate.value = endD && getDayjsTypeDate(endD);
    currentDate.value = startDate.value;
  }
});

const getCurrentDate = ({selectedValues}) => {
  //开始时间选择框
  let currTime = new Date(selectedValues.join('/')).getTime();
  if (clickType.value === EnumType.start) {
    startDate.value = selectedValues;
    //   判断结束时间是否已选择：如果选择且小于开始时间则清空结束时间
    if (endDate.value) {
      let dEnd = new Date(endDate.value.join('/')).getTime();
      if (currTime && currTime > dEnd) {
        endDate.value = undefined;
      }
    } else {
      //   如果开始时间选择的为最后一天，结束时间则与开始时间相等
      let maxD = maxDate.value?.getTime();
      if (currTime && currTime === maxD) {
        endDate.value = selectedValues;
      }
    }
  } else { // 结束时间选择框
    endDate.value = selectedValues;
  }

  let rangeDateTemp: DateRange = [
    startDate.value && turnToDayjs(startDate.value),
    endDate.value && turnToDayjs(endDate.value)
  ];
  emit('getDateRange', rangeDateTemp);
};

const changeType = (e, type) => {
  clickType.value = type;
  if (type === EnumType.start) { //选择框类型为开始时间
    currMinDate.value = minDate.value;
    if (startDate.value) {
      currentDate.value = startDate.value;
    } else {
      if (endDate.value) {
        currentDate.value = endDate.value;
      } else {
        currentDate.value = minDate.value && getDateTypeDate(minDate.value);
      }
      startDate.value = currentDate.value;
    }
  } else { //选择框类型为结束时间
    if (startDate.value) { // 开始时间有设置则结束时间可选择的最小范围为开始时间
      currMinDate.value = new Date(startDate.value.join('/'));
      if (endDate.value) {
        let dEnd = new Date(endDate.value.join('/')).getTime();
        let dStart = new Date(startDate.value.join('/')).getTime();
        if (dEnd <= dStart) {//结束时间小于开始时间
          currentDate.value = startDate.value;
          endDate.value = startDate.value;
        } else {
          currentDate.value = endDate.value;
        }
      } else {
        currentDate.value = startDate.value;
        endDate.value = startDate.value;
      }
    } else {
      currMinDate.value = minDate.value;
      if (endDate.value) {
        currentDate.value = endDate.value;
      } else {
        currentDate.value = minDate.value && getDateTypeDate(minDate.value);
        endDate.value = currentDate.value;
      }
    }
  }
};

const formatter = (type, option) => {
  if (type === 'year') {
    option.text += '年';
  }
  if (type === 'month') {
    option.text += '月';
  }
  if (type === 'day') {
    option.text += '日';
  }
  return option;
};

function cancel() {
  emit('cancel');
}

function confirm() {
  const rangeDateTemp: DateRange = [
    startDate.value && turnToDayjs(startDate.value),
    endDate.value && turnToDayjs(endDate.value)
  ];
  emit('confirm', rangeDateTemp);
}
</script>

<template>
  <van-date-picker
		v-model="currentDate"
		:min-date="currMinDate"
		:max-date="maxDate"
		:formatter="formatter"
		class="date-range-mobile"
		@change="getCurrentDate"
  >
    <template #toolbar>
      <div class="date-range-toolbar">
        <div tabindex="0"
             class="date-range-input"
             :class="clickType === EnumType.start ?  'set-select-class' :  'clear-select-class'"
             @focus="changeType($event,EnumType.start)"
        >
          {{ !Array.isArray(startDate) ? "开始时间" : startDate?.join("-") }}
        </div>
        -
        <div tabindex="0"
             class="date-range-input"
             :class="clickType === EnumType.end ?  'set-select-class' :  'clear-select-class'"
             @focus="changeType($event,EnumType.end)">
          {{ !Array.isArray(endDate) ? "结束时间" : endDate?.join("-") }}
        </div>
      </div>
    </template>
    <template #columns-bottom>
      <div class="btn-sty" v-if="showBottomButton">
				<ButtonView type="default" text="取消" class="date-range-picker-mobile-button" @click="cancel" />
				<ButtonView type="primary" text="确认" class="date-range-picker-mobile-button" @click="confirm" />
      </div>
    </template>
  </van-date-picker>
</template>

<style>
.date-range-picker-mobile-button {
	width: 45%;
	height: 40px;
	min-width: 100px;
	font-size: 16px !important;
}
</style>
