<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { NewDateRange } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';
import '@/lib/aaruy-design/date-range-picker/mobile/new.range.picker.mobile.style.css';

// todo: 替换 DateRangePickerMobile
type DayType = Dayjs | null;
type CurType = [string, string, string];   // YYYY,MM,DD

interface Prop {
	range: NewDateRange;
}

interface Emit {
	(e: 'change', data: NewDateRange): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const start = ref<DayType>(null);
const end = ref<DayType>(null);
const cur = ref<DayType>(null);


const MIN_DATE = new Date(2020,0,1);
const MAX_DATE = new Date();

const minDate = ref<Date>(MIN_DATE);
const maxDate = ref<Date>(MAX_DATE);

const curTexts = computed<CurType | null>(() => cur.value ? cur.value.format('YYYY-MM-DD').split('-') as CurType : null);
const startText = computed<string>(() => getText(start.value, '开始时间'));
const endText = computed<string>(() => getText(end.value, '结束时间'));


watch(() => prop.range, (v) => {
  if (!v) {
    start.value = null;
    end.value = null;
    cur.value = null;
  } else {
    start.value = v[0];
    end.value = v[1];
    if (!cur.value) {
      cur.value = start.value;
    }
  }
}, { immediate: true });

watch(cur, (v) => {
  if (v) {
    if (v === start.value && end.value) {
      minDate.value = MIN_DATE;
      maxDate.value = end.value.subtract(1, 'day').toDate();
    }
    if (v === end.value && start.value) {
      minDate.value = start.value.add(1, 'day').toDate();
      maxDate.value = MAX_DATE;
    }
  }
}, { immediate: true });

function getText(d: DayType, placeholder: string): string {
  return d ? d.format('YYYY-MM-DD') : placeholder;
}

function onSelect(index: 0 | 1): void {
  if (index === 0) {
    if (!start.value) {
      start.value = dayjs(minDate.value);
    }
    cur.value = start.value;
  }
  else {
    if (!end.value) {
      end.value = dayjs(maxDate.value);
    }
    cur.value = end.value;
  }
  emitData();
}

function onChange({ selectedValues }: { selectedValues: CurType }): void {
  const data = dayjs(selectedValues.join('-'));
  if (cur.value === start.value) {
    start.value = data;
    cur.value = start.value;
  }
  else {
    end.value = data;
    cur.value = end.value;
  }
  emitData();
}

function emitData(): void {
  if (start.value && end.value) {
    emit('change', [start.value, end.value]);
  }
}
</script>

<template>
	<div class="new-range-picker-mobile">
		<div class="text-s flex h-32-px leading-32 mb-12">
			<span class="picker-item" :class="{ actived: cur !== null && cur === start }" @click="onSelect(0)">{{ startText }}</span>
			<span class="inline-block text-center" style="width: 36px;">-</span>
			<span class="picker-item" :class="{ actived: cur !== null && cur === end }" @click="onSelect(1)">{{ endText }}</span>
		</div>
		<template v-if="curTexts">
			<van-date-picker
				title="选择日期"
				:model-value="curTexts"
				:show-toolbar="false"
				:min-date="minDate"
				:max-date="maxDate"
				@change="onChange"
			/>
		</template>
	</div>
</template>

<style scoped>
.picker-item.actived {
	color: var(--aaruy-text-color);
	border-color: 1px solid var(--aaruy-default-color-2);
}

.picker-item {
	flex: 1;
	text-align: center;
	color: var(--aaruy-default-color-1);
	border-radius: 4px;
	border: 1px solid rgba(163, 175, 188, 0.5);
}
</style>
