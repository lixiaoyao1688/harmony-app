<script setup lang="ts">
import { computed } from 'vue';
import { timeZeroing } from '@/lib/time/util/time.util';
import { DEFAULT_DATE_RANGE2_CONFIG } from '@/lib/aaruy-design/date-range-picker/picker2/config/date.range.picker2.config';
import IconDateRangePicker2Date from '@/lib/aaruy-design/date-range-picker/picker2/icon/IconDateRangePicker2Date.vue';
import '@/lib/aaruy-design/date-range-picker/picker2/style/date.range.picker2.style.css';
import '@/lib/aaruy-design/date-range-picker/picker2/style/date.range.picker2.dropdown.style.css';
import type { DateRangeType } from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


/**
 * 日期选择器 组件
 *
 * 默认配置
 * ~src/lib/aaruy-design/date-range-picker/config/date.range.picker2.config.ts;
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  range: DateRangeType;  // 日期范围;
  maxRange: number;  // 最大查询日期数，如 30 天;
  useTime?: boolean;  // 是否启用时间选择;
  width?: string;
  height?: string;
  margin?: string;
}

interface Emit {
	(e: 'change', data: DateRangeType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const tips = computed<string>(() => getTipFromRange(prop.range));


function getTipFromRange(data: DateRangeType): string {
  if (data === null) {
    return '日期范围不能为空';
  }
  if (data[1].diff(data[0], 'day') > prop.maxRange) {
    return `日期跨度不得超过 ${prop.maxRange} 天`;
  }
  return '';
}

function onChange(data: DateRangeType): void {
  if (!data || !data[0] || !data[1]) {
    emit('change', null);
    return;
  }
  emit('change', prop.useTime ? [data[0], data[1]] : [timeZeroing(data[0]), timeZeroing(data[1])]);
}
</script>

<template>
  <div class="bg-10 border-bg-10 inline-flex items-center rounded-4 pr-8 relative"
       :class="{ 'border-error': tips }"
       :style="{
          width: width || DEFAULT_DATE_RANGE2_CONFIG.WIDTH,
          height: height || DEFAULT_DATE_RANGE2_CONFIG.HEIGHT,
          margin: margin || DEFAULT_DATE_RANGE2_CONFIG.MARGIN,
       }"
  >
    <div class="px-8 inline-flex h-full items-center">
      <IconDateRangePicker2Date />
    </div>
    <a-range-picker
      :value="range"
      :placeholder="['开始日期', '结束日期']"
      :suffix-icon="false"
      :allow-clear="false"
      :show-time="useTime ? { format: 'HH:mm' } : null"
      :format="useTime ? 'YYYY-MM-DD HH:mm' : 'YYYY-MM-DD'"
      class="flex-1 h-full date-range-picker2"
      dropdownClassName="date-range-picker2-dropdown"
      @change="onChange"
    />
    <div v-if="tips" class="absolute text-error font-bold" style="bottom: -22px; left: 0;">{{ tips }}</div>
  </div>
</template>
