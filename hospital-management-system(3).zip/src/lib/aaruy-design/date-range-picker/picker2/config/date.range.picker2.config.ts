/**
 * 日期范围选择器 默认配置
 */
export const DEFAULT_DATE_RANGE2_CONFIG = {
  WIDTH: '280px',
  HEIGHT: '32px',
  MARGIN: '0',
};
