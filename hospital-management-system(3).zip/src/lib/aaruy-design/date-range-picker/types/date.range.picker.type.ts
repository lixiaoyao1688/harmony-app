import { Dayjs } from 'dayjs';


export type DateRange = [Dayjs | undefined, Dayjs | undefined];
export type NewDateRange = [Dayjs, Dayjs] | null;  // null 表示未选择任何范围;  todo: 用这个改掉所有结构
export type DateRangeType = [Dayjs, Dayjs] | null;  // null 表示未选择任何范围;  todo: 用这个改掉所有结构

export const DATE_RANGE_FORMAT_1 = 'YYYY-MM-DD HH:mm:ss';
export const DATE_RANGE_FORMAT_2 = 'YYYY-MM-DD';
