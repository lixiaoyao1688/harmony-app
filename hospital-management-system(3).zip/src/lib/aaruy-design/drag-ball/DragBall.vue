<script setup lang="ts">
/**
 * 悬浮球 组件
 */
import { ref, onMounted } from 'vue';
import { ZERO } from '@/lib/math/config/math.config';
import { DragBallStyle } from '@/lib/aaruy-design/drag-ball/drag.ball';


interface Props {
  width: number;  // 球体宽度
  innerRight?: number;  // 初始右边位置, 默认为 0
  onClick?: Function;  // 可绑定一个点击事件的回调，仅[点击]触发，[点击->拖动->松开]不触发
}

interface Emit {
	(e: 'pressChange', isPressed: boolean): void;
}


const prop = defineProps<Props>();
const emit = defineEmits<Emit>();

const right = ref<number>(prop.innerRight || ZERO); // 初始右边位置
const isDragging = ref<boolean>(false);  // 是否开始拖动球

let offsetX: number = 0;  // 点击位置到球右边界的距离
let moved: boolean = false;  // 本次点击是否有将球移动
let animationFrameId: number | null = null;  // requestAnimationFrame 的句柄
let minRight = ZERO;  // 最小 right
let maxRight = window.innerWidth;  // 最大 right


onMounted(() => {
  maxRight = window.innerWidth - prop.width;
});

function startDrag(event: MouseEvent): void {
  disableTextSelection();
  // 按下鼠标并开始移动，但球未有实质移动
  moved = false;
  isDragging.value = true;
  offsetX = window.innerWidth - right.value - event.clientX;   // event.clientX: 鼠标点击位置的 x
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', stopDrag);
  emit('pressChange', true);
}

function stopDrag(): void {
  enableTextSelection();
  isDragging.value = false;
  window.removeEventListener('mousemove', onMouseMove);
  window.removeEventListener('mouseup', stopDrag);

  if (!moved && prop.onClick) {
    // 仅[点击]触发，[点击->拖动->松开]不触发
    prop.onClick();
  }
  emit('pressChange', false);
}

function onMouseMove(event: MouseEvent): void {
  if (!isDragging.value) {
    return;
  }
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
  }
  animationFrameId = requestAnimationFrame(() => {
    // 使用 requestAnimationFrame 优化性能
    updatePosition(event.clientX);
  });
}

function updatePosition(x: number): void {
  let data = window.innerWidth - x - offsetX;
  if (data < minRight) {
    data = minRight;
  }
  if (data > maxRight) {
    data = maxRight;
  }
  if (data !== right.value) {
    right.value = data;
    moved = true;
  }
}

// 避免拖动选中页面文字
function disableTextSelection(): void {
  const style = document.body.style as unknown as DragBallStyle;
  style.userSelect = 'none';
  style.webkitUserSelect = 'none';
  style.msUserSelect = 'none';
  style.mozUserSelect = 'none';
}

// 恢复页面文字可选择性
function enableTextSelection(): void {
  const style = document.body.style as unknown as DragBallStyle;
  style.userSelect = '';
  style.webkitUserSelect = '';
  style.msUserSelect = '';
  style.mozUserSelect = '';
}
</script>

<template>
  <div
    :style="{ right: `${right}px`, width: `${width}px`, top: '0px' }"
    class="drag-ball"
    @mousedown="startDrag"
  >
    <slot></slot>
  </div>
</template>

<style scoped>
.drag-ball {
  height: fit-content;
  position: absolute;
  z-index: 100;
}
</style>
