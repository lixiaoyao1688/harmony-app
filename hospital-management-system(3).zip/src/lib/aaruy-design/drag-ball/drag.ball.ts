export interface DragBallStyle {
	userSelect: string;
	webkitUserSelect: string; // Safari
	msUserSelect: string;  // IE
	mozUserSelect: string; // Firefox
}
