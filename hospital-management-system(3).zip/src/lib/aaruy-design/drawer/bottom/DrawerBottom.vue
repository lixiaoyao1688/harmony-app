<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/drawer/drawer.common.style.css';
import '@/lib/aaruy-design/drawer/bottom/drawer.bottom.style.css';


interface Prop {
  opened: boolean;
}

interface Emit {
  (e: 'close'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function close() {
  emit('close');
}
</script>

<template>
  <a-drawer
    :visible="opened"
    :title="null"
    :mask="true"
    :closable="false"
    :destroy-on-close="true"
    :getContainer="false"
    placement="bottom"
    class="drawer-common drawer-bottom"
    @close="close"
  >
    <slot></slot>
  </a-drawer>
</template>

<style scoped></style>
