<script setup lang="ts">
import { ref } from 'vue';
import type { DropdownMenuInstance } from 'vant';
import '@/lib/aaruy-design/drawer/dropdown-mobile/drawer.dropdown.style.css';


interface Prop {
	title: string;
	height: string;
}

const prop = defineProps<Prop>();
const menuRef = ref<DropdownMenuInstance | null>(null);

// 关闭 drawer
function onClose(): void {
  if (menuRef.value) {
    menuRef.value.close();
  }
}
</script>

<template>
	<van-dropdown-menu ref="menuRef" class="drawer-dropdown-mobile">
		<van-dropdown-item :title="title">
			<div :style="{ height: height }" class="overflow-x-hidden overflow-y-auto bg-0">
				<slot :close="onClose"></slot>
			</div>
		</van-dropdown-item>
	</van-dropdown-menu>
</template>
