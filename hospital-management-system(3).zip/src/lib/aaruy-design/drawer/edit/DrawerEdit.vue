<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/drawer/drawer.common.style.css';
import '@/lib/aaruy-design/drawer/edit/drawer.edit.style.css';


interface Prop {
  opened: boolean;
  width?: string;
  doNotDestroyOnClose?: boolean;  // 是否"关闭时不销毁"
}

interface Emit {
  (e: 'close'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const innerWidth = computed(() => prop.width || (mobile.value ? '100vw' : '50vw'));


function close() {
  emit('close');
}
</script>

<template>
  <span class="drawer-edit-container">
    <a-drawer
      :visible="opened"
      :title="null"
      :mask="true"
      :closable="false"
      :destroy-on-close="!doNotDestroyOnClose"
      :width="innerWidth"
      placement="right"
      class="drawer-common drawer-edit"
      @close="close"
    >
      <slot></slot>
    </a-drawer>
  </span>
</template>

<style scoped>
.drawer-edit-container {
  display: inline-block;
}
</style>
