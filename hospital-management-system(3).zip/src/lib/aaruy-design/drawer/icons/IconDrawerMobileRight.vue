<script setup lang="ts">
interface Emit {
  (e: 'onClick'): void;
}


const emit = defineEmits<Emit>();

function onClick() {
  emit('onClick');
}
</script>

<template>
  <svg id="iconDrawerMobileRight" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" @click="onClick">
    <rect id="iconDrawerMobileRightRect" data-name="矩形 3423" width="24" height="24" fill="rgba(255,255,255,0)"/>
    <path id="iconDrawerMobileRightPath" d="M8.293,12.707a1,1,0,0,1,0-1.414L13.95,5.636A1,1,0,1,1,15.364,7.05L10.414,12l4.95,4.95a1,1,0,1,1-1.414,1.414Z" fill="#fff" fill-rule="evenodd"/>
  </svg>
</template>