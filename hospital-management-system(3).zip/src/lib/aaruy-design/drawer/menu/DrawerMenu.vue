<script setup lang="ts">
import '@/lib/aaruy-design/drawer/menu/drawer.menu.style.css';


interface Prop {
  opened: boolean;
  width?: string;
}

interface Emit {
  (e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function close() {
  emit('close');
}
</script>


<template>
  <a-drawer
    :title="null"
    :mask="true"
    placement="left"
    class="drawer-menu"
    :width="width"
    :closable="false"
    :getContainer="false"
    :visible="opened"
    :style="{ position: 'absolute' }"
    :drawerStyle="{ backgroundColor: 'rgb(21,26,31)' }"
    @close="close"
  >
    <slot name="content"></slot>
  </a-drawer>
</template>
