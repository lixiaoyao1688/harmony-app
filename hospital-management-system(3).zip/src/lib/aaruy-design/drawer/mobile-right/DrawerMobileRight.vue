<script setup lang="ts">
import IconDrawerMobileRight from '@/lib/aaruy-design/drawer/icons/IconDrawerMobileRight.vue';
import '@/lib/aaruy-design/drawer/mobile-right/drawer.mobile.right.style.css';


interface Prop {
  opened: boolean;
}

interface Emit {
  (e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onClose() {
  emit('close');
}
</script>

<template>
  <a-drawer
    :visible="opened"
    :title="null"
    :destroy-on-close="true"
    :closable="false"
    width="100vw"
    height="100vh"
    placement="right"
    class="drawer-mobile-right"
  >
    <div class="drawer-mobile-right-header">
      <IconDrawerMobileRight class="dmr-icon-arrow-right" @onClick="onClose" />
      <div class="drawer-mobile-right-header-content">
        <slot name="header"></slot>
      </div>
    </div>
    <slot></slot>
  </a-drawer>
</template>

<style scoped>
.drawer-mobile-right-header {
  height: 44px;
  background-color: rgb(0, 0, 0);
  display: flex;
  align-items: center;
}

.drawer-mobile-right-header .dmr-icon-arrow-right {
  width: 36px;
  height: 100%;
  padding: 10px 0;
}

.drawer-mobile-right-header-content {
  flex: 1;
  height: 100%;
}
</style>