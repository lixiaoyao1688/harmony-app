<script setup lang="ts">
import { ref } from 'vue';
import '@/lib/aaruy-design/dropdown/dropdown.mobile.style.css';
import DropdownPanel from '@/lib/aaruy-design/dropdown/panel/DropdownPanel.vue';
import type { ItemType } from '@/lib/aaruy-design/select/frame/select.frame.type';
import type { DropdownPanelExposed } from '@/lib/aaruy-design/dropdown/panel/dropdown.panel.type';
import {DropDownExposedType} from '@/lib/aaruy-design/dropdown/type/dropdown.type';


/**
 * 下拉选择器 组件
 *
 * 仅 mobile;
 */
interface Prop {
	item: ItemType;
	items: Array<ItemType>;
	itemMap: Map<number, ItemType>;
  margin?: string;
}

interface Emit {
	(e: 'open'): void;
	(e: 'change', data: ItemType): void;
}

defineExpose<DropDownExposedType>({
  closePanel
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const panelRef = ref<DropdownPanelExposed | null>(null);


function onChange(data: ItemType): void {
  emit('change', data);
  closePanel();
}

function closePanel(): void {
  if (!panelRef.value) {
    return;
  }
  panelRef.value.close();
}

function onOpen(): void {
  emit('open');
}
</script>

<template>
  <DropdownPanel ref="panelRef" @open="onOpen">
    <template #title>
      <span class="mr-8 text-xs" :style="{ margin: margin || '0' }">{{ item.text }}</span>
    </template>
    <div class="bg-0 overflow-hidden-auto p-16">
      <div v-for="it in items"
           :key="it.id"
           :class="{ 'text-primary': it.id === item.id }"
           class="py-8"
           @click="onChange(it)"
      >{{ it.text }}</div>
    </div>
  </DropdownPanel>
</template>
