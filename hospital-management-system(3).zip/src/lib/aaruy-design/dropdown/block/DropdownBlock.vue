<script setup lang="ts">
import {ref, watch} from 'vue';
import '@/lib/aaruy-design/dropdown/block/dropdown.block.style.css';


interface Prop {
  visible?: boolean;   // 是否控制弹出层展示
  destroyPopupOnHide?: boolean;  // 关闭后是否销毁 Dropdown
}

interface Emit {
	(e: 'openChange', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);

watch(() => prop.visible, (data) => {
  isOpened.value = data;
});

function onOpenChange(data: boolean): void {
  emit('openChange', data);
}
</script>

<template>
	<a-dropdown v-model:visible="isOpened" :destroy-popup-on-hide="destroyPopupOnHide" :trigger="['click']" overlayClassName="dropdown-block" @visibleChange="onOpenChange" @click.stop>
		<slot></slot>
		<template #overlay>
			<slot name="dropdown"></slot>
		</template>
	</a-dropdown>
</template>
