<script setup lang="ts">
import { ref } from 'vue';
import IconArrowFill from '@/lib/icon/IconArrowFill.vue';
import '@/lib/aaruy-design/dropdown/panel/dropdown.panel.style.css';
import type { DropdownItemInstance } from 'vant';
import type { DropdownPanelExposed } from '@/lib/aaruy-design/dropdown/panel/dropdown.panel.type';


/**
 * 下拉面板 组件
 *
 * 使用范围
 * 仅mobile;
 */
interface Prop {
  isIconTipShowed?: boolean;  // 是否在默认图标位置处展示提示词;
}

interface Emit {
  (e: 'open'): void;
}

defineExpose<DropdownPanelExposed>({
  close
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const itemRef = ref<DropdownItemInstance>();


function open(): void {
  if (!itemRef.value) {
    return;
  }
  itemRef.value.toggle(true);
}

function close(): void {
  if (!itemRef.value) {
    return;
  }
  itemRef.value.toggle(false);
}

function trigger(): void {
  if (isOpened.value) {
    close();
  }
  else {
    open();
  }
}

function onOpen(): void {
  isOpened.value = true;
  emit('open');
}

function onClose(): void {
  isOpened.value = false;
}
</script>

<template>
  <van-dropdown-menu class="dropdown-panel">
    <van-dropdown-item ref="itemRef" @open="onOpen" @close="onClose">
      <template #title>
        <div class="inline-flex items-center">
          <slot name="title"></slot>
          <div v-if="isIconTipShowed">
            <slot name="tip"></slot>
          </div>
          <IconArrowFill v-else :type="isOpened ? 'up' : 'down'" @click.stop="trigger" />
        </div>
      </template>
      <slot></slot>
    </van-dropdown-item>
  </van-dropdown-menu>
</template>
