export type DropdownPanelExposed = {
  close: () => void;
}