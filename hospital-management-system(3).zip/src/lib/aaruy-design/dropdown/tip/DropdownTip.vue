<script setup lang="ts">
import {computed} from 'vue';
import '@/lib/aaruy-design/dropdown/tip/dropdown.tip.style.css';


interface Prop {
	visible: boolean;
  useBg10?: boolean;
  useSelectTips2Style?: boolean;
  disabled?: boolean;
  destroyTooltipOnHide?: boolean;
}

interface Emit {
	(e: 'openChange', isOpened: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const classNames = computed<string>(() => {
  const result = ['dropdown-tip'];
  if (prop.useBg10) {
    result.push('dropdown-tip-bg-10');
  }
  if (prop.useSelectTips2Style) {
    result.push('dropdown-tip-2');
  }
  return result.join(' ');
});

function visibleChange(visible: boolean): void {
  if (prop.disabled) {
    return;
  }
  emit('openChange', visible);
}
</script>

<template>
	<a-tooltip
		:visible="visible"
    :destroyTooltipOnHide="destroyTooltipOnHide || false"
		trigger="click"
		placement="bottomRight"
    :overlayClassName="classNames"
		@visibleChange="visibleChange"
		@click.stop
	>
		<slot name="content"></slot>
		<template #title>
			<slot name="menu"></slot>
		</template>
	</a-tooltip>
</template>
