export interface DropDownExposedType {
  closePanel: () => void;
}
