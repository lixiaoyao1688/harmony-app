<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';


interface Prop {
	words?: string;
	fontSize?: number;
	itemCenter?: boolean;  // 是否让文字垂直居中
  backgroundColor?: string;
}

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

defineProps<Prop>();
</script>

<template>
  <div class="empty"
    :class="{ 'empty-pc': pc, 'empty-mobile': mobile, 'center': itemCenter }"
    :style="{
      'fontSize': fontSize ? `${fontSize}px` : null,
      'backgroundColor': backgroundColor || null
    }"
  >{{ words || '暂无数据' }}</div>
</template>

<style scoped>
.empty {
	display: flex;
	justify-content: center;
	width: 100%;
	height: 100%;
	color: var(--aaruy-text-color-2);
}

.empty-pc {
	font-size: 36px;
	padding-top: 10%;
}

.empty-mobile {
  font-size: 24px;
  padding-top: 20%;
}

.center {
	align-items: center;
	padding-top: 0;
}
</style>
