<script setup lang="ts">
interface Prop {
  height: string;  // 如: 100%, 200px, ...
  fontSize?: string;  // 字号，默认 20px, 如: 18px, 16px, ...
  tips?: string;  // 提示文本，默认为 "暂无数据";
}

/**
 * 占位 组件
 */
const prop = defineProps<Prop>();
</script>

<template>
  <div class="flex items-center justify-center text-weak-5 font-bold"
       :style="{ height: height, fontSize: fontSize || '20px' }">{{ tips || '暂无数据' }}</div>
</template>
