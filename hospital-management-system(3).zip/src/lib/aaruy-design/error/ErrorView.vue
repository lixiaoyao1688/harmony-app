<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';


/**
 * 错误提示 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  tips: string;  // 错误提示词
  isTextCenter?: boolean;  // 文本是否居中
  isTextLeft?: boolean;  // isTextCenter为非true值时可用: 文本是否居左，默认居右
  width?: string;  // 默认 100%;
  padding?: string;
  useFont18?: boolean;
  useFont16?: boolean;  // 仅PC
  bgColor?: string;  // 背景颜色，仅移动端
  margin?: string;
  color?: string;  // 默认 --aaruy-error-color
  fontWeight?: number;  // 默认700, 仅APP
  lineHeight?: number;  // 默认16px，仅PC
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const pad = computed<boolean>(() => screenStore.isPad);
</script>

<template>
  <div v-if="pc"
       :class="{
         'aaruy-visible': tips, 'aaruy-hidden': !tips,
         'text-center': isTextCenter, 'text-left': !isTextCenter && isTextLeft, 'text-right': !isTextCenter && !isTextLeft,
         'text-lg': useFont18, 'text-s': !useFont18 && useFont16, 'text-xs': !useFont18 && !useFont16
       }"
       :style="{
          width: width || '100%',
          padding: padding,
          margin: margin,
          color: color || 'var(--aaruy-error-color)',
          lineHeight: lineHeight || '16px'
       }"
       style="min-height: 16px;"
       class="font-bold">{{ tips }}</div>
  <div v-else
       :class="{
         'aaruy-visible': tips, 'aaruy-hidden': !tips,
         'text-center': isTextCenter, 'text-left': !isTextCenter && isTextLeft, 'text-right': !isTextCenter && !isTextLeft,
         'text-lg': useFont18, 'text-xs': !useFont18
       }"
       :style="{
          width: width || '100%',
          padding: padding,
          backgroundColor: bgColor,
          color: color || 'var(--aaruy-error-color)',
          fontWeight: fontWeight || 700,
          margin: margin,
       }"
       style="min-height: 16px; line-height: 16px;">{{ tips }}</div>
</template>
