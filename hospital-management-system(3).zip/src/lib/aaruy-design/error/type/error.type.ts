export type ErrorExposedType = {
  hasError: () => boolean;
  checkValueError: () => boolean;
  checkAndGetErrorTips: (data: string) => string;
}