<script setup lang="ts">
import { computed } from 'vue';


/**
 * 双文本字段 组件
 */
interface Prop {
  t1: string;  // 标题1
  v1: string;  // 值1
  t2: string;  // 标题1
  v2: string;  // 值2
  t1Width?: string;  // 标题1宽度
  t2Width?: string;  // 标题2宽度
  isEnd?: boolean;
  item1Width?: string;
  useFont14?: boolean;  // 是否使用字号 14px;
}

const prop = defineProps<Prop>();
const innerT1Width = computed<string>(() => prop.t1Width || '58px');
const innerT2Width = computed<string>(() => prop.t2Width || '58px');
</script>

<template>
  <div class="flex justify-between w-full"
       :class="{ 'mb-16': !isEnd, 'text-xs': useFont14, 'text-s': !useFont14 }">
    <div class="flex" :style="{ width: item1Width || '45%' }">
      <span class="text-weak-2" :style="{ width: innerT1Width }">{{ t1 }}</span>
      <span :style="{ width: 'calc(100% - ' + innerT1Width + ')' }" class="wrap-anywhere pr-16">{{ v1 }}</span>
    </div>
    <div class="flex flex-1">
      <span class="text-weak-2" :style="{ width: innerT2Width }">{{ t2 }}</span>
      <span :style="{ width: 'calc(100% - ' + innerT2Width + ')' }" class="wrap-anywhere">{{ v2 }}</span>
    </div>
  </div>
</template>
