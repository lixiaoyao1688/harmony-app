<script setup lang="ts">
/**
 * 只读字段 组件
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  title: string;
  value: string;
}

const prop = defineProps<Prop>();
</script>

<template>
  <div class="flex items-center justify-between text-white text-s mb-16"
       style="height: 51px; border-bottom: 2px solid rgba(204, 214, 225, 0.2);">
    <span>{{ title }}</span>
    <span>{{ value }}</span>
  </div>
</template>
