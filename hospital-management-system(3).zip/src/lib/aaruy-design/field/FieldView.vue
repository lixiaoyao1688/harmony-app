<script setup lang="ts">
import { computed, ref } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconFieldArrow from '@/lib/aaruy-design/field/IconFieldArrow.vue';
import PickerMobile from '@/lib/aaruy-design/picker/PickerMobile.vue';


interface Prop {
	type: 'single' | 'multiple';
	title: string;
	item: SelectorFormItemVO;
	items: Array<SelectorFormItemVO>;
}

interface Emit {
	(e: 'change', item: SelectorFormItemVO): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const visible = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const single = computed<boolean>(() => prop.type === 'single');
const multiple = computed<boolean>(() => prop.type === 'multiple');


function open(): void {
  visible.value = true;
}

function close(): void {
  visible.value = false;
}

function onSelect(vo: SelectorFormItemVO): void {
  emit('change', vo);
  close();
}
</script>

<template>
	<!-- pc留空	-->
  <div v-if="pc"></div>
	<template v-if="mobile">
		<PickerMobile :title="title" :show-picker="visible" :item="item" :items="items" @close="close" @ok="onSelect" />
		<div
			class="bg-2 flex justify-between items-center text-s"
			:class="{
				'border-6 p-16': single,
				'pt-16 pb-8 border-b-type-1': multiple
			}"
			@click="open"
		>
			<span>{{ title }}</span>
			<span class="inline-flex items-center">
				{{ item.text }}
				<IconFieldArrow class="ml-4" />
			</span>
		</div>
	</template>
</template>
