<script setup lang="ts">
/**
 * 字段 组件
 * 仅mobile
 */
interface Prop {
  // text:纯文本;  double-text:双纯文本;
  // other: 内容自定义，但高度固定为字段高度;  other-complex: 内容自定义，高度自适应;
  type: 'text' | 'double-text' | 'other' | 'other-complex';
  title?: string;  // 字段标题, 目前仅 text;
  value?: string;  // 字段文本值，仅 text;
  isStart?: boolean;  // 是否首字段
  isEnd?: boolean;  // 是否尾字段
  marginTop?: string;
  useStyle2?: boolean;  // 启用样式2 (仅 text/other)
  borderTopColor?: string;  // 仅 text/other;
  hideBorderTop?: boolean;  // 是否隐藏顶部边框, 仅 text/other;
  usePlainStyle?: boolean;  // 是否启用透明样式，仅 text/other;
  padding?: string;  // 默认 px-16, 仅 text/other 或 other-complex
  showBorderBottom?: boolean;  // 仅 text/other 和 double-text;
  height?: string;  // 仅 text/other 和 other-complex;
  showBorderTopBlack?: boolean;  // 仅 other-complex;
}

const prop = defineProps<Prop>();
</script>

<template>
  
  <div v-if="type === 'other-complex'"
       class="bg-4 h-fit text-s text-white relative"
       :style="{ marginTop: marginTop, padding: padding || '16px' }"
       :class="{ 'rounded-t-4': isStart, 'rounded-b-4': isEnd, 'border-t-black': showBorderTopBlack }"
  >
    <slot></slot>
  </div>
  
  <div v-else-if="type === 'double-text'"
       class="bg-4 px-16 pt-16 h-fit"
       :style="{ marginTop: marginTop }"
       :class="{ 'rounded-t-4': isStart, 'rounded-b-4': isEnd }"
  >
    <div :class="{ 'border-t-bg-14': !isStart, 'border-b-bg-16': showBorderBottom }" class="h-fit text-s text-white pb-16">
      <slot></slot>
    </div>
  </div>
  
  <!-- text/other -->
  <div v-else
       :style="{ height: height || '54px', marginTop: marginTop, padding: padding || '0 16px' }"
       :class="{
          'rounded-t-4': isStart,
          'rounded-b-4': isEnd,
          'field-view-style-2': useStyle2,
          'bg-transparent': usePlainStyle, 'bg-4': !usePlainStyle
        }"
  >
    <div :class="{ 'field-view-border-t': !isStart && !hideBorderTop }"
         class="flex items-center justify-between h-full text-s text-white"
         :style="{ borderTopColor: borderTopColor, borderBottom: showBorderBottom ? '1px solid rgb(100, 115, 128)' : null }"
    >
      <template v-if="type === 'text'">
        <span>{{ title }}</span>
        <span>{{ value }}</span>
      </template>
      <template v-else-if="type === 'other'">
        <slot></slot>
      </template>
    </div>
  </div>
  
</template>

<style scoped>
.field-view-border-t {
  border-top: 1px solid var(--aaruy-bg-color-0);
}

.field-view-style-2 {
  background-color: var(--aaruy-bg-color-2);
}

.field-view-style-2 > .field-view-border-t {
  border-top: 1px solid var(--aaruy-bg-color-1);
}
</style>
