<template>
	<svg id="iconFieldArrow" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
		<rect id="iconFieldArrowR" data-name="矩形 3423" width="24" height="24" fill="rgba(255,255,255,0)"/>
		<path id="iconFieldArrowP" d="M15.364,12.706a1,1,0,0,0,0-1.414L9.707,5.636A1,1,0,0,0,8.293,7.05L13.243,12l-4.95,4.949a1,1,0,1,0,1.414,1.414Z" transform="translate(0)" fill="#fff" fill-rule="evenodd"/>
	</svg>
</template>