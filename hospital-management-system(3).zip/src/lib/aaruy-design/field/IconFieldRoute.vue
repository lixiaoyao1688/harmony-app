<template>
  <span class="inline-flex items-center justify-center" style="width: 24px; height: 24px;">
    <svg xmlns="http://www.w3.org/2000/svg" width="7.657" height="13.313" viewBox="0 0 7.657 13.313">
      <path d="M15.364,12.707a1,1,0,0,0,0-1.414L9.707,5.636A1,1,0,1,0,8.293,7.05L13.243,12l-4.95,4.95a1,1,0,1,0,1.414,1.414Z" transform="translate(-8 -5.343)" fill="#fff" fill-rule="evenodd"/>
    </svg>
  </span>
</template>