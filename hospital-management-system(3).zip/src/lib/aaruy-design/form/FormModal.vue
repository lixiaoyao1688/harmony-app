<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import '@/lib/aaruy-design/form/form.modal.style.css';


interface Prop {
	waiting?: boolean;
	disabled?: boolean;
  buttonConfirmText?: string;
  okTextMobile?: string;
  cancelTextMobile?: string;  // 仅APP
  cancelText?: string;  // 仅PC
  isNotPaddingOnMobile?: boolean;
  isPaddingZero?: boolean;
  marginOnBottom?: string;
  isOnlyOneButton?: boolean;
}

interface Emit {
  (e: 'confirm'): void;
  (e: 'cancel'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const innerButtonConfirmText = computed<string>(() => prop.buttonConfirmText || '确 定');

const innerCancelTextMobile = computed<string>(() => prop.cancelTextMobile || '取消');
const innerOkTextMobile = computed<string>(() => prop.okTextMobile || '确定');


function confirm() {
  emit('confirm');
}

function cancel() {
  emit('cancel');
}
</script>


<template>
  <div class="form-modal" :class="{ 'form-modal-mobile': mobile, 'p-0': isPaddingZero || (isNotPaddingOnMobile && mobile) }">
    <slot></slot>
    <div class="form-modal-bottom" :style="{ margin: marginOnBottom }" v-if="pc">
      <ButtonView v-if="isOnlyOneButton"
                  type="primary"
                  :text="innerButtonConfirmText"
                  class="form-modal-btn-pc" :loading="waiting" @click="confirm" />
      <template v-else>
        <ButtonView type="default" :text="cancelText || '取 消'" class="form-modal-btn-pc" @click="cancel" />
        <ButtonView type="primary" :text="innerButtonConfirmText" class="form-modal-btn-pc" :loading="waiting" @click="confirm" />
      </template>
    </div>
  </div>
  <div class="form-modal-bottom-mobile" :style="{ margin: marginOnBottom }" v-if="mobile">
		<ButtonView type="default" :text="innerCancelTextMobile" class="form-modal-btn-mobile form-modal-btn-mobile-left" @click="cancel" />
		<ButtonView type="primary" :text="innerOkTextMobile" :loading="waiting" :disabled="disabled" class="form-modal-btn-mobile form-modal-btn-mobile-right" @click="confirm" />
  </div>
</template>

<style scoped>
.form-modal-mobile {
  padding: 36px 24px;
}

.form-modal-mobile.p-0 {
  padding: 0;
}

.form-modal-bottom-mobile {
	display: flex;
	height: 40px;
}
</style>

<style>
.form-modal-btn-pc {
	height: 32px !important;
	padding: 0 15px !important;
}

.form-modal-btn-mobile {
	width: 50%;
	height: 100% !important;
	font-size: 16px !important;
}

.form-modal-btn-mobile-right {
	border-radius: 0 0 4px 0 !important;
}

.form-modal-btn-mobile-left {
	border-radius: 0 0 0 4px !important;
}
</style>
