<script setup lang="ts">
interface Prop {
  title?: string;  // 标题
  required?: boolean;  // 是否必填项
}

defineProps<Prop>();
</script>

<template>
  <div class="form-item">
    <label><i v-if="required">*</i>{{ title }}</label>
    <slot></slot>
  </div>
</template>

<style scoped>
.form-item {
  font-size: 16px;
  color: rgb(255,255,255);
}
</style>
