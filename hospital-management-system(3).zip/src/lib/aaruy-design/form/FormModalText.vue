<script setup lang="ts">
interface Prop {
  mobile?: boolean;
  padding? :string;
}

defineProps<Prop>();
</script>

<template>
  <div class="form-modal-text" :class="{ 'form-modal-text-mobile': mobile }" :style="{ padding: padding }">
    <slot></slot>
  </div>
</template>

<style scoped>
.form-modal-text {
  font-size: 16px;
  color: rgb(255,255,255);
  padding-bottom: 40px;
}

.form-modal-text-mobile {
  padding-bottom: 0;
}
</style>
