import {printApp} from '@/lib/log/util/log.util';
import { CapacitorHttp } from '@capacitor/core';
import {useStorageStore} from '@/lib/storage/store/storage.store';
import type {UploadFile} from 'ant-design-vue';


/**
 * 获取图片文件类型
 * 主方案：使用文件的 MIME type
 * 副方案：当 MIME type 不是图片或无法确定时，使用文件名的扩展名
 * 只返回图片类型，非图片返回空字符串
 */
export function getImageFileType(file: UploadFile): string {
  // 常见图片扩展名列表
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'tiff', 'heic'];
  
  // 主方案：从 MIME type 获取图片类型
  if (file.type && file.type.startsWith('image/')) {
    const mimeParts = file.type.split('/');
    if (mimeParts.length === 2) {
      const typeFromMime = mimeParts[1].toLowerCase();
      // 验证从 MIME 类型获取的类型是否在图片扩展名列表中
      if (imageExtensions.includes(typeFromMime)) {
        return typeFromMime;
      }
    }
  }
  
  // 副方案：从文件名获取图片扩展名
  const fileName = file.name.toLowerCase();
  const lastDotIndex = fileName.lastIndexOf('.');
  
  if (lastDotIndex !== -1 && lastDotIndex < fileName.length - 1) {
    const extension = fileName.slice(lastDotIndex + 1);
    if (imageExtensions.includes(extension)) {
      return extension;
    }
  }
  
  return ''; // 无法确定图片类型返回空字符串
}

/**
 * 加载重定向图片
 * @param imageUrl 原始地址
 * @param imageElementId 图片元素
 */
export async function loadImageWithRedirect(imageUrl: string, imageElementId: string) {
  try {
    const cookie = await useStorageStore().getMobileCookie();
    // 发起原生HTTP请求，它会自动处理302重定向，并拿到最终图片的二进制数据
    const response = await CapacitorHttp.get({
      url: imageUrl,
      responseType: 'json',
      headers: {
        Cookie: cookie
      }
    });
    printApp('重定向图片响应', response);
    const el = document.getElementById(imageElementId) as HTMLImageElement;
    if (el) {
      el.src = response.url;
    }
  } catch (error) {
    printApp('重定向图片加载失败', error);
  }
}
