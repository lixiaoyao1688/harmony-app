<script setup lang="ts">
import {computed} from 'vue';
import '@/lib/aaruy-design/input/style/input.common.style.css';
import '@/lib/aaruy-design/input/style/input.border.style.css';


/**
 * 文本输入框 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  type: 'text' | 'number';  // 类型
  data: string;  // 输入框的内容
  tips?: string;  // 错值提示词
  height?: string;  // 高度，默认 40px;
  tipHeight?: string;  // 提示词高度，默认 24px;
  maxLength?: number;  // 默认20
  margin?: string;
  placeholder?: string;
  useSuffix?: boolean;  // 是否使用后缀符号
  useThemeBorder?: boolean;  // 是否启用 border 主题
  inputPadding?: string;  //  输入框的 padding
}

interface Emit {
	(e: 'change', data: string): void;
	(e: 'enter'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const innerHeight = computed<string>(() => prop.height || '40px');
const innerTipHeight = computed<string>(() => prop.tipHeight || '24px');
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');
const innerMaxLength = computed<number>(() => prop.maxLength || 20);

function onChange(data: string): void {
  emit('change', data);
}

function onEnter(): void {
  emit('enter');
}
</script>

<template>
  <div class="relative" :style="{ height: innerHeight }">
    <div class="h-full relative">
      <input :type="type"
             :value="data"
             :placeholder="innerPlaceholder"
             :maxlength="innerMaxLength"
             :style="{ padding: inputPadding }"
             :class="{
                'aaruy-input-border-pc': useThemeBorder,
                'aaruy-error': tips
             }"
             class="aaruy-common-pc"
             @input="event => onChange(event.target.value)"
             @keyup.enter="onEnter">
      <div v-if="useSuffix" class="absolute top-0 right-0">
        <slot name="suffix"></slot>
      </div>
    </div>
    <div class="absolute left-0 text-error font-bold"
         :class="{ 'aaruy-hidden': !tips, 'aaruy-visible': tips }"
         :style="{ height: innerTipHeight, bottom: `-${innerTipHeight}` }"
    >{{ tips }}</div>
  </div>
</template>
