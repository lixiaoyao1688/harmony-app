<script setup lang="ts">
import { ref } from 'vue';


interface Prop {
  data: string;
  maxLength: number;
}

interface Emit {
  (e: 'change', v: string): void
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>(prop.data);


function onChange(e) {
  emit('change', e.target.value);
}
</script>

<template>
  <a-input
    v-model:value="value"
    :maxlength="maxLength"
    placeholder="请输入"
    class="input-agree-mobile"
    @change="onChange"
  />
</template>

<style scoped>
.input-agree-mobile {
  width: 100%;
  padding: 0;
  border: none;
  font-size: 12px;
  color: rgb(255,255,255);
  background: transparent;
  border-bottom: 1px solid rgb(91,103,116);
}

.input-agree-mobile:focus {
  box-shadow: none;
}
</style>
