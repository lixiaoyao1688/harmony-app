<script setup lang="ts">
import {ref, watch} from 'vue';
import '@/lib/aaruy-design/input/basic/input.basic.style.css';


interface Prop {
	type?: 'number';
  data: string;  // 初始值
  placeholder: string;
  maxlength: number;
  password?: boolean;  // 是否密码
  tips?: string; // 数值错误提示文本（仅!password）
}

interface Emit {
  (e: 'change', v: string): void
  (e: 'pressEnter'): void
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>(prop.data);


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(e): void {
  emit('change', e.target.value);
}

function pressEnter(): void {
  emit('pressEnter');
}
</script>

<template>
  <a-input-password
    v-if="password"
    v-model:value="value"
    class="input-basic input-basic-password"
    :placeholder="placeholder"
    :visibility-toggle="true"
    :maxlength="maxlength"
    @change="onChange"
		@pressEnter="pressEnter"
  />
  <div v-else class="w-full" style="height: 64px;">
    <a-input v-model:value="value"
             :type="type"
             :placeholder="placeholder"
             :maxlength="maxlength"
             :class="{ 'error': tips }"
             class="input-basic"
             style="height: calc(100% - 24px)"
             @change="onChange"
             @pressEnter="pressEnter"
    />
    <div :class="{ 'aaruy-visible': tips, 'aaruy-hidden': !tips }"
         style="height: 24px; line-height: 30px;"
         class="text-error font-bold text-xs">{{ tips }}</div>
  </div>
</template>

<style scoped>
.input-basic {
	width: 100%;
	font-size: 16px;
  border-radius: 4px;
  padding: 0 0 0 10px;
  color: var(--aaruy-text-color);
	background-color: var(--aaruy-bg-color-1);
	border: 1px solid var(--aaruy-default-color-1);
}

.input-basic::placeholder {
	color: var(--aaruy-default-color-2);
}

.input-basic:focus,
.input-basic:hover {
  border-color: var(--aaruy-primary-color-2);
  box-shadow: none;
}

.input-basic.error,
.input-basic.error:hover {
  border-color: var(--aaruy-error-color);
}
</style>
