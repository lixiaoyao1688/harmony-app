<script setup lang="ts">
import {ref, watch} from 'vue';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/input/basic/input.basic.style.css';


interface Prop {
  title: string;
  data: string;
  maxlength: number;
  isRequired?: boolean;
  height?: string;
  placeholder?: string;
  marginBottom?: string;
  titleWidth?: string;
  errorTips?: string;
}

interface Emit {
  (e: 'change', v: string): void
  (e: 'pressEnter'): void
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const innerData = ref<string>(prop.data);


watch(() => prop.data, (data) => {
  innerData.value = data;
}, { immediate: true });

function onChange(e) {
  emit('change', e.target.value);
}

function pressEnter() {
  emit('pressEnter');
}
</script>

<template>
  <div class="flex items-center" :style="{ height: height || '40px', marginBottom: marginBottom || '16px' }">
    <div :style="{ width: titleWidth || '120px' }" class="pr-12 text-right text-white text-s">
      <i v-if="isRequired" class="text-remove mr-8">*</i><span>{{ title }}</span>
    </div>
    <a-input
      v-model:value="innerData"
      type="text"
      class="input-basic flex-1"
      :class="{ 'border-error': errorTips }"
      :placeholder="placeholder || '请输入'"
      :maxlength="maxlength"
      @change="onChange"
      @pressEnter="pressEnter"
    />
  </div>
  <ErrorView v-if="errorTips" :tips="errorTips" is-text-left padding="4px 0 0 64px" />
</template>

<style scoped>
.input-basic {
  height: 40px;
  color: var(--aaruy-text-color);
  font-size: 16px;
  padding: 0 0 0 10px;
  /* background-color: var(--aaruy-bg-color-1); */
  background-color: transparent;
  border: 1px solid var(--aaruy-default-color-1);
  border-radius: 4px;
}

.input-basic::placeholder {
  color: var(--aaruy-default-color-2);
}

.input-basic:focus {
  box-shadow: none;
}

.input-basic:not(.border-error):hover {
  border-color: var(--aaruy-primary-color-2);
}
</style>
