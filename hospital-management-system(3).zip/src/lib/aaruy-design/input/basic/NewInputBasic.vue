<script setup lang="ts">
import { DEFAULT_INPUT_CONFIG } from '@/lib/aaruy-design/input/config/input.config';
import '@/lib/aaruy-design/input/basic/new.input.basic.style.css';


interface Prop {
	value: string;
	type?: 'number';  // 不传则是任意文本
	maxLength?: number;
	placeholder?: string;
}

interface Emit {
	(e: 'change', v: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(v: string): void {
  emit('change', v);
}
</script>

<template>
	<van-field
		class="new-input-basic"
		label=""
		:model-value="value"
		:type="type"
		:placeholder="placeholder || '请输入'"
		:maxlength="maxLength || DEFAULT_INPUT_CONFIG.MAX_LENGTH"
		autocomplete="off"
		@update:model-value="onChange"
	>
		<template #right-icon>
			<slot></slot>
		</template>
	</van-field>
</template>
