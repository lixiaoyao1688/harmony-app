/**
 * 输入框 默认配置
 */
export const DEFAULT_INPUT_CONFIG = {
  MAX_LENGTH: 20,  // 最大字符数
  PLACEHOLDER: '请输入',  // 占位提示词
  WEIGHT: '200px',
  HEIGHT: '32px',
  MARGIN: '0'
};

export const DEFAULT_INPUT_CONFIG_4K = {
  WEIGHT: '400px',
  HEIGHT: '64px',
};
