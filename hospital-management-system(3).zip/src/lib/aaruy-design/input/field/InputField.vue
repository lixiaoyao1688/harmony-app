<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/input/field/input.field.style.css';
import '@/lib/aaruy-design/input/field/input.field.field.style.css';
import '@/lib/aaruy-design/input/field/input.field.button.like.style.css';
import '@/lib/aaruy-design/input/field/input.field.field2.style.css';


/**
 * 字段输入框 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  titleWidth?: string;
  type?: 'number' | 'text'; // 默认 number;
  unit?: string;  // 仅 isField/isField2;
  unitWidth?: string;   // 仅 isField/isField2;
  data?: number;
  isButtonLike?: boolean;   // 类 button 样式, 仅 mobile;
  isButtonLikeError?: boolean;   // 是否报错，仅 类 button 样式;
  isReadOnly?: boolean;  // 仅 isButtonLike 可用
  isField?: boolean;  // 是否用于 FieldView;
  isRequired?: boolean;
  placeholder?: string;  // 默认"请输入"
  isField2?: boolean;  // 是否用于特殊 Field;
  height?: string;  // 仅 isField2/isButtonLike;
  showBorderBottom?: boolean;  // 仅 isField/isField2;
  useFontSize14?: boolean;  // 仅 isField2;
  useFont16?: boolean;  // 仅 isField/isField2
  padding?: string;  // 仅 isField2
  maxLength?: number;  // 仅 isField2
}

interface Emit {
	(e: 'change', data: string | number): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const value = ref<string>('');
const isFocused = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.data, (data) => {
  if (data !== undefined) {
    value.value = data.toString();
  }
}, { immediate: true });

function onChange(data: string | number): void {
  if (!prop.type) {
    // 默认 type 为 number;
    data = +data;
  }
  emit('change', data);
}

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}
</script>

<template>
  <div v-if="pc"><!--  暂不支持 PC 端  --></div>
  <template v-else>
    <div v-if="isButtonLike"
         :style="{ height: height }"
         :class="{ 'button-like-error': isButtonLikeError, 'button-like-focused': isFocused }"
         class="flex items-center input-field-mobile-button-like w-full"
    >
      <div v-if="isReadOnly" class="flex-1 flex">
        <span class="flex-1">{{ title }}</span>
        <span class="font-bold">{{ value }}</span>
      </div>
      <template v-else>
        <van-field
          v-model="value"
          :type="type || 'number'"
          :label="title"
          :label-width="titleWidth"
          :placeholder="placeholder || '请输入'"
          autocomplete="off"
          @focus="onFocus"
          @blur="onBlur"
          @update:model-value="onChange"
        />
      </template>
      <span class="ml-8">{{ unit || '' }}</span>
      
    </div>
    <div v-else-if="isField"
         class="input-field-field flex items-center"
         :class="{ 'border-b-black': showBorderBottom }"
         :style="{ height: height, borderColor: isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-0)' }"
    >
      <van-field
        v-model="value"
        :type="type || 'number'"
        :label="title"
        :placeholder="placeholder || '请输入'"
        :required="isRequired"
        :style="{ fontSize: useFont16 ? '16px' : '14px' }"
        autocomplete="off"
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
      <span class="ml-8" :class="{ 'inline-block': unitWidth }" :style="{ width: unitWidth }">{{ unit || '' }}</span>
    </div>
    <div v-else-if="isField2"
         class="input-field-field-2 flex items-center"
         :class="{ 'border-b-bg-1': showBorderBottom, 'font-14': useFontSize14 }"
         :style="{
           height: height,
           borderColor: isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-1)',
           padding: padding
         }"
    >
      <van-field
        v-model="value"
        :type="type || 'number'"
        :label="title"
        :placeholder="placeholder || '请输入'"
        :required="isRequired"
        :maxlength="maxLength"
        autocomplete="off"
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
      <span class="ml-8" :class="{ 'inline-block': unitWidth }" :style="{ width: unitWidth }">{{ unit || '' }}</span>
    </div>
    <div v-else class="flex items-center border-b-bg-1 input-field-mobile"
         style="padding: 0 20%;"
         :style="{ borderColor: isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-1)' }"
    >
      <van-field
        v-model="value"
        :type="type || 'number'"
        :label="title"
        :placeholder="placeholder || '请输入'"
        autocomplete="off"
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
      <span class="ml-8">{{ unit || '' }}</span>
    </div>
  </template>
  
</template>
