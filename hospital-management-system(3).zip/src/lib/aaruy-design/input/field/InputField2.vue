<script setup lang="ts">
import {ref, watch} from 'vue';
import {getDigitCount} from '@/lib/math/util/math.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/input/field/input.field2.theme.css';
import '@/lib/aaruy-design/input/field/input.field2.theme1.css';


/**
 * 字段输入框 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  data: string;  // 外部传入的数值
  name: string;  // 没有 name 的话 chrome 会报错
  theme?: 1;  // undefined:'input-field2-theme'，1:'input-field-theme1';
  titleWidth?: string;  // 默认 90px;
  type?: 'text' | 'number';  // 默认 text
  unit?: string;  // 单位
  maxLength?: number;  // 最大字符数，默认无限制
  minLength?: number;  // 最小字符数，默认无限制
  max?: number;  // 最大值，仅 type=number 时可用
  min?: number;  // 最小值，仅 type=number 时可用
  digit?: number;  // 最多小数位数，仅 type=number 时可用
  isRequired?: boolean;
  placeholder?: string;  // 默认"请输入"
  height?: string;
  padding?: string;
  errorFontWeight?: number;  // 默认400
  valueValidFn?: (data: string) => boolean;  // 自定义的检错函数，返回true代表输入数据有效，返回false代表输入数据有误。
}

interface Emit {
	(e: 'change', data: string): void;
	(e: 'error-change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>('');
const errorTips = ref<string>('');
const isFocused = ref<boolean>(false);  // 仅移动端

// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError,
});

watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true } );

function onChange(data: string): void {
  value.value = data;
  errorTips.value = getErrorTips(data);
  emit('change', data);
  emit('error-change', errorTips.value);
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  emit('error-change', tips);
  return tips !== '';
}

function getErrorTips(data: string): string {
  if (prop.isRequired && !data) {
    return '请输入';
  }
  if (!prop.isRequired && !data) {
    return '';
  }
  if (prop.maxLength && data.length > prop.maxLength) {
    return `字符数不可超过${prop.maxLength}位`;
  }
  if (prop.minLength && data.length < prop.minLength) {
    return `字符数不可少于${prop.minLength}`;
  }
  if (prop.valueValidFn && !prop.valueValidFn.call(null, data)) {
    return `请输入有效的${prop.title}`;
  }
  if (prop.max !== undefined && +data > prop.max) {
    return `输入值不可超过${prop.max}${prop.unit || ''}`;
  }
  if (prop.min !== undefined && +data < prop.min) {
    return `输入值不可少于${prop.min}${prop.unit || ''}`;
  }
  if (prop.digit !== undefined) {
    if (getDigitCount(data) > prop.digit) {
      return prop.digit === 0 ? '请输入整数' : `小数位数不得超过${prop.digit}位`;
    }
  }
  return '';
}

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}
</script>

<template>
  <div :class="{
         'has-error': errorTips,
         'input-field2-theme': theme === undefined,
         'input-field2-theme-1': theme === 1,
       }"
       :style="{
         height: height,
         padding: padding,
         borderColor: errorTips ? 'var(--aaruy-error-color-2)' : isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-0)'
       }">
    <van-field v-model="value"
               :type="type"
               :label="title"
               :label-width="titleWidth || '90px'"
               :placeholder="placeholder || '请输入'"
               :required="isRequired"
               :maxlength="maxLength"
               autocomplete="off"
               input-align="right"
               @focus="onFocus"
               @blur="onBlur"
               @update:model-value="onChange">
      <template #right-icon v-if="unit">{{ unit }}</template>
    </van-field>
  </div>
  <ErrorView v-if="errorTips"
             :tips="errorTips" :font-weight="errorFontWeight || 400" :padding="padding"
             color="var(--aaruy-error-color-2)" />
</template>
