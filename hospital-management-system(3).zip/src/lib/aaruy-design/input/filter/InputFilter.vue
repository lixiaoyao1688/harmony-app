<script setup lang="ts">
import { computed } from 'vue';
import type { ChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


interface Prop {
	title: string;
  value: string;
  maxLength: number;
	placeholder?: string;
	inputerWidth?: string;
  titleWidth?: string;
	height?: string;
	fontSize?: string;
}

interface Emit {
  (e: 'change', data: string): void;
  (e: 'pressEnter'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const innerPlaceholder = computed(() => prop.placeholder || '请输入');
const innerInputerWidth = computed(() => prop.inputerWidth || '200px');


function onPressEnter() {
  emit('pressEnter');
}

function onChange(e: ChangeEvent) {
  emit('change', e.target.value || '');
}
</script>


<template>
  <div class="filter-input" :style="{ height: height || '32px' }">
    <label v-if="title"
           class="text"
           :style="{ width: titleWidth || 'fit-content' }">{{ title }}</label>
    <a-input
      :value="value"
			:style="{ width: innerInputerWidth, fontSize: fontSize || '14px' }"
      :placeholder="innerPlaceholder"
      :maxlength="maxLength"
      autocomplete="off"
      class="filter-input-item"
      @change="onChange"
      @pressEnter="onPressEnter"
    />
  </div>
</template>


<style scoped>
.filter-input {
  display: flex;
	align-items: center;
}

.filter-input .text {
  display: inline-block;
  height: 32px;
  line-height: 32px;
  text-align: right;
  padding-right: 12px;
  font-size: 16px;
}

.filter-input .filter-input-item {
  color: rgb(255, 255, 255);
  border-radius: 4px;
  border-color: rgb(91, 103, 116);
	background-color: transparent;
	height: 100%;
}

.filter-input .filter-input-item::placeholder {
	color: var(--aaruy-default-color-2) !important;
}

.filter-input .filter-input-item:-internal-autofill-selected {
  color: rgb(255, 255, 255) !important;
  background-color: transparent !important;
}

.filter-input .filter-input-item:focus,
.filter-input .filter-input-item:hover {
  border-color: rgb(38, 111, 232) !important;
}
</style>
