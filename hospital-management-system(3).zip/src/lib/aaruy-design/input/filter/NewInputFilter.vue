<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {DEFAULT_INPUT_CONFIG, DEFAULT_INPUT_CONFIG_4K} from '@/lib/aaruy-design/input/config/input.config';
import '@/lib/aaruy-design/input/style/input.style.css';


/**
 * 输入框 组件
 *
 * 默认配置
 * ~\src\lib\aaruy-design\input\config\input.config.ts: DEFAULT_INPUT_CONFIG;
 *
 * 使用范围
 * 仅pc;
 */
interface Prop {
  data: string; // 输入值
  maxLength?: number; // 最大字符数
  placeholder?: string;  // 占位提示词
  width?: string;  // 宽度
  height?: string;  // 高度
  margin?: string;  // 外边距
  use4KStyle?: boolean;  // 是否适配4K屏
}

interface Emit {
	(e: 'change', data: string): void;  // 输入值变化时触发
	(e: 'enter'): void;  // 按下回车键
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function getInputValue(e: Event): string {
  const el = e.target as HTMLInputElement;
  return el.value;
}

function onInput(e: InputEvent): void {
  emit('change', getInputValue(e));
}

function onEnter(): void {
  emit('enter');
}
</script>

<template>
  <input
    type="text"
    :value="data"
    :maxlength="maxLength || DEFAULT_INPUT_CONFIG.MAX_LENGTH"
    :placeholder="placeholder"
    :style="{
      width: width || (use4KStyle ? DEFAULT_INPUT_CONFIG_4K.WEIGHT : DEFAULT_INPUT_CONFIG.WEIGHT),
      height: height || (use4KStyle ? DEFAULT_INPUT_CONFIG_4K.HEIGHT : DEFAULT_INPUT_CONFIG.HEIGHT),
      margin: margin || DEFAULT_INPUT_CONFIG.MARGIN
    }"
    :class="{ 'text-s': !use4KStyle, 'text-xxl aaruy-input-placeholder-4k': use4KStyle }"
    class="border-bg-9 rounded-4 px-10 hover-border-primary-2 focus-border-primary-2 aaruy-input-placeholder"
    autocomplete="off"
    @input="onInput"
    @keyup.enter="onEnter"
  />
</template>
