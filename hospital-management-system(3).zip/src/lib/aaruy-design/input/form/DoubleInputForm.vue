<template>
	<div class="flex justify-between">
		<div style="width: 48%;">
			<slot name="left"></slot>
		</div>
		<div style="width: 48%;">
			<slot name="right"></slot>
		</div>
	</div>
</template>
