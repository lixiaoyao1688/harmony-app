<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { TWENTY, TWENTY_FOUR } from '@/lib/math/config/math.config';
import IconPencil from '@/modules/admission/icons/IconPencil.vue';
import '@/lib/aaruy-design/input/form/input.form.style.css';


interface Prop {
  data: string;  // 初始值
  title: string;  // 标题
  placeholder?: string;  // 占位文本
  required?: boolean;  // 是否必填项
  password?: boolean;  // 是否密码
  maxLength?: number;  // 最大长度
  mobile?: boolean;  // 是否移动端
  mobileLarge?: boolean;  // 是否移动端的大尺寸（已废弃）
  isBgTransparent?: boolean;  // 是否使用透明背景
}

interface Emit {
  (e: 'change', v: string): void;
  (e: 'pressEnter'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const innerMaxLength = computed<number>(() => prop.maxLength || 1000);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');
const iconSize = computed<number>(() => prop.mobile ? TWENTY : TWENTY_FOUR);


watch(() => prop.data, (newValue) => {
  value.value = newValue;
});


function onChange(e) {
  emit('change', e.target.value);
}

function onPressEnter() {
  emit('pressEnter');
}
</script>


<template>
  <template v-if="password">
    <a-input-password
      v-model:value="value"
      :placeholder="innerPlaceholder"
      :visibilityToggle="true"
      :maxlength="innerMaxLength"
      class="input-form input-form-password"
      :class="{ 'input-form-mobile': mobile, 'input-form-mobile-large': mobileLarge }"
      autocomplete="off"
      @change="onChange"
    >
      <template #prefix>
        <div class="input-form-title">{{ title }} <i v-if="required">*</i></div>
      </template>
      <template #suffix>
        <IconPencil :size="iconSize" />
      </template>
    </a-input-password>
  </template>
  <template v-if="!password">
    <a-input
      v-model:value="value"
      :placeholder="innerPlaceholder"
      :maxlength="innerMaxLength"
      class="input-form"
      :class="{
        'input-form-mobile': mobile,
        'input-form-mobile-large': mobileLarge,
        'input-form-transparent': isBgTransparent
      }"
      autocomplete="off"
      @change="onChange"
      @pressEnter="onPressEnter"
    >
      <template #prefix>
        <div class="input-form-title">{{ title }} <i v-if="required">*</i></div>
      </template>
      <template #suffix>
        <IconPencil :size="iconSize" />
        <slot name="extra-suffix"></slot>
      </template>
    </a-input>
  </template>
</template>


<style scoped>
.input-form .input-form-title {
  height: 100%;
  display: flex;
  align-items: center;
}

.input-form .input-form-title > i {
  margin-left: 4px;
  color: rgb(255, 36, 42);
}

.input-form.input-form-transparent {
  background-color: transparent !important;
}

/* mobile */
.input-form-mobile {
  font-size: 16px;
  padding-top: 20px !important;
  padding-bottom: 8px !important;
  background-color: transparent !important;
	border-bottom-width: 1px !important;
	border-bottom-color: rgb(91, 103, 116) !important;
}

.input-form-mobile-large {
  padding-top: 26px !important;
  padding-bottom: 11px !important;
}

.input-form-mobile .input-form-title {
  font-size: 16px;
}
</style>
