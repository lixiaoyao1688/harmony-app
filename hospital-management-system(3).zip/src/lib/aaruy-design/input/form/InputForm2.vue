<script setup lang="ts">
import { ref, watch } from 'vue';
import { TWENTY_FOUR } from '@/lib/math/config/math.config';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconPencil from '@/modules/admission/icons/IconPencil.vue';
import '@/lib/aaruy-design/input/form/input.form2.style.css';


interface Prop {
  data: string;  // 初始值
  title: string;  // 标题
  placeholder?: string;  // 占位文本
  required?: boolean;  // 是否必填项
  maxLength?: number;  // 最大长度
  disabledData?: Array<[string,string]>;  // 禁用词数据。索引0为禁用词,索引1为该禁用词的报错提示词。
}

interface Emit {
  (e: 'change', data: string): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const errorTips = ref<string>('');


defineExpose({
  checkValueError
});

watch(() => prop.data, (newValue) => {
  value.value = newValue;
}, { immediate: true });

function getErrorTips(data: string): string {
  if (prop.required && data === '') {
    return `${prop.title}不能为空`;
  }
  if (prop.maxLength && data.length > prop.maxLength) {
    return `${prop.title}不得超过${prop.maxLength}个字符`;
  }
  if (prop.disabledData) {
    const list = prop.disabledData;
    for (let i = 0, len = list.length; i < len; i++) {
      const [disabledText, tips] = list[i];
      if (data === disabledText) {
        return tips;
      }
    }
  }
  return '';
}

function checkValueError(): boolean {
  const tips = getErrorTips(prop.data);
  errorTips.value = tips;
  return tips !== '';
}

function onChange(e) {
  const data = e.target.value;
  errorTips.value = getErrorTips(data);
  emit('change', data);
}
</script>


<template>
  <a-input
      v-model:value="value"
      :placeholder="placeholder || '请输入'"
      class="input-form2"
      :class="{ 'border-b-error': errorTips }"
      autocomplete="off"
      @change="onChange">
      <template #prefix>
        <div class="h-full flex items-center">
          <span>{{ title }}</span>
          <i v-if="required" class="text-error ml-4">*</i>
        </div>
      </template>
      <template #suffix>
        <IconPencil :size="TWENTY_FOUR" />
        <slot name="extra-suffix"></slot>
      </template>
  </a-input>
  <ErrorView :tips="errorTips" />
</template>
