<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import '@/lib/aaruy-design/input/frame/input.frame.style.css';


interface Prop {
  title: string;  // 标题
  data: string;  // 初始值
  type?: string;  // text | number, 默认text;
  width?: string;  // 总体的宽度, 默认 100%;
  titleWidth?: string;
  isRequired?: boolean;  // 是否必填项
  maxLength?: number;  // 最大长度
  placeholder?: string;  // 占位文本
  marginBottom?: string;
}

interface Emit {
  (e: 'change', v: string): void;
  (e: 'pressEnter'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const innerMaxLength = computed<number>(() => prop.maxLength || 100);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');


watch(() => prop.data, (newValue) => {
  value.value = newValue;
}, { immediate: true });

function onChange(e): void {
  emit('change', e.target.value);
}

function onPressEnter(): void {
  emit('pressEnter');
}
</script>

<template>
  <div class="flex items-center text-white text-s" style="height: 40px;" :style="{ width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div v-if="title" :style="{ width: titleWidth || '100px' }"  class="text-right pr-8"><i v-if="isRequired" class="text-red-2 mr-8">*</i>{{ title }}</div>
    <a-input
      v-model:value="value"
      :type="type || 'text'"
      :placeholder="innerPlaceholder"
      :maxlength="innerMaxLength"
      class="input-frame"
      @change="onChange"
      @pressEnter="onPressEnter"
    />
  </div>
</template>
