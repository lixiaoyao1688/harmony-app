<script setup lang="ts">
import {useScreenStore} from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/input/login/input.login.style.css';
import type { ChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


interface Prop {
	data: string;
	maxLength: string;
	placeholder: string;
	isPassword?: boolean;
}

interface Emit {
	(e: 'change', data: string): void;
	(e: 'pressEnter'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();

function onDataChange(e: ChangeEvent) {
  emit('change', e.target.value || '');
}

function onPressEnter() {
  emit('pressEnter');
}
</script>

<template>
	<a-input
		v-if="!isPassword"
		:value="data"
		:maxlength="maxLength"
		:placeholder="placeholder"
    :class="{ 'input-login-4k': screenStore.is4KOrAbove }"
    name="account"
		class="input-login"
		@change="onDataChange"
	/>
	<a-input-password
		v-if="isPassword"
		:value="data"
		:maxlength="maxLength"
		:placeholder="placeholder"
    :class="{ 'input-login-4k': screenStore.is4KOrAbove }"
    name="password"
    class="input-login"
		@change="onDataChange"
		@pressEnter="onPressEnter"
	/>
</template>
