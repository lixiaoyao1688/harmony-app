<script setup lang="ts">
import '@/lib/aaruy-design/input/login/input.login.mobile.style.css';
import type { ChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';


interface Prop {
	data: string;
	maxLength: string;
	placeholder: string;
	isPassword?: boolean;
}

interface Emit {
	(e: 'change', data: string): void;
	(e: 'pressEnter'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onDataChange(e: ChangeEvent) {
  emit('change', e.target.value || '');
}

function onPressEnter() {
  emit('pressEnter');
}
</script>

<template>
	<div>
		<a-input
			v-if="!isPassword"
			:value="data"
			:maxlength="maxLength"
			:placeholder="placeholder"
			class="input-login-mobile"
			@change="onDataChange"
		>
			<template #prefix>
				<slot name="preIcon"></slot>
			</template>
		</a-input>
		<a-input-password
			v-if="isPassword"
			:value="data"
			:maxlength="maxLength"
			:placeholder="placeholder"
			class="input-login-mobile"
			@change="onDataChange"
			@pressEnter="onPressEnter"
		>
			<template #prefix>
				<slot name="preIcon"></slot>
			</template>
		</a-input-password>
	</div>
</template>
