<script setup lang="ts">
import { ref } from 'vue';
import '@/lib/aaruy-design/input/number/input.number.style.css';


interface Prop {
	min: number;
	max: number;
	step: number;
	value: number;
}

interface Emit {
	(e: 'change', data: number): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const innerValue = ref<number>(prop.value);

function onChange(data: number) {
  emit('change', data);
}
</script>

<template>
	<a-input-number v-model:value="innerValue" :min="min" :max="max" :step="step" class="aaruy-input-number" @change="onChange" />
</template>

<style scoped></style>