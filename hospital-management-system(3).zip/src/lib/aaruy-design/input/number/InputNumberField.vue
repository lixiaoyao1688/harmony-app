<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/input/number/input.number.field.style.css';


interface Prop {
  title: string;
  height: string;
  value: number;
  unit?: string;
  fontSize?: number;
  placeholder?: string
  min?: number;
}

interface Emit {
  (e: 'change', data: number): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const innerValue = ref<number | undefined>(undefined);
const pc = computed<boolean>(() => screenStore.isPC);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.value, (data) => {
  innerValue.value = data;
}, { immediate: true } );

function onChange(data: number): void {
  emit('change', data);
}
</script>

<template>
  <div :style="{ height: height }" class="flex items-center justify-between border-b-default border-hover-primary-4 pl-16 pr-24">
    <span class="text-s">{{ title }}</span>
    <div>
      <a-input-number
        v-model:value="innerValue"
        :min="min || 0"
        :controls="false"
        :style="{ fontSize: (fontSize || 16) + 'px' }"
        class="input-number-field text-s font-bold"
        style="width: 100px;"
        :placeholder="placeholder || '请输入'"
        @change="onChange"
      />
      <span class="font-bold ml-4 text-s">{{ unit || 'U/h' }}</span>
    </div>
  </div>
</template>
