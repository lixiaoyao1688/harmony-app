<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getDigitCount, isMultipleStep } from '@/lib/math/util/math.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/input/number/input.number.field.style.css';
import type {InputNumberChangePayload} from '@/lib/aaruy-design/input/number/type/input.number.field2.type';


interface Prop {
  title: string;
  data: number;  // 外部传入的数值
  min: number;
  max: number;
  digit: number;  // 最多小数位数
  name: string;  // 没有 name 的话 chrome 会报错
  unit?: string;  // 默认 U/h;
  step?: number;  // 默认不限制步长
  fontSize?: number;
  placeholder?: string;  // 默认"请输入"
  height?: string;  // 仅移动端
  showBorderBottom?: boolean;  // 仅移动端
  useFontSize14?: boolean;  // 仅移动端
  isRequired?: boolean;  // 仅移动端
  unitWidth?: string;   // 仅移动端
  isUnitRight?: boolean;  //  仅移动端
  titleTips?: string;  // 标题下方的提示词 仅APP
  errorTipWidth?: string;  // 报错提示的宽度 仅 titleTips 存在时可用 仅APP
}

interface Emit {
  (e: 'change', data: InputNumberChangePayload): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const value = ref<string>('');
const errorTips = ref<string>('');
const isFocused = ref<boolean>(false);  // 仅移动端

const unitText = computed<string>(() => prop.unit || 'U/h');

const pc = computed<boolean>(() => screenStore.isPC);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);


// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError,
  checkAndGetErrorTips
});

watch(() => prop.data, (data) => {
  if (data) {
    value.value = data.toString();
  }
}, { immediate: true } );

function onChange(data: string): void {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  value.value = data;
  emit('change', { data: data, errorTips: tips });
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

function checkAndGetErrorTips(data: string): string {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  return tips;
}

function getErrorTips(data: string): string {
  if (!data && data !== '0') {
    return '请输入有效数字';
  }
  if (+data < prop.min) {
    return `不得小于${prop.min}${unitText.value}`;
  }
  if (+data > prop.max) {
    return `不得大于${prop.max}${unitText.value}`;
  }
  if (prop.step && !isMultipleStep(+data, prop.step)) {
    return `必须是${prop.step}的整数倍`;
  }
  if (getDigitCount(data) > prop.digit) {
    return `小数位数不得超过${prop.digit}位`;
  }
  return '';
}

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}
</script>

<template>
  <template v-if="pc">
    <div style="height: 32px;"
         class="flex items-center justify-between border-b-default border-hover-primary-4 pl-16 pb-4 pr-24"
         :class="{ 'border-error-i': errorTips }">
      <span class="text-s">{{ title }}</span>
      <div class="inline-flex items-center">
        <input :value="value"
               :placeholder="placeholder || '请输入'"
               :name="name"
               type="number"
               class="input-placeholder input-arrow-hidden text-right text-s font-bold"
               @input="event => onChange(event.target.value)" />
        <span class="ml-4 text-s" style="height: 24px; line-height: 24px;">{{ unitText }}</span>
      </div>
    </div>
    <ErrorView :tips="errorTips" padding="0 24px 0 0" />
  </template>
  <template v-else>
    <div class="input-field-field-2 flex items-center"
         :class="{ 'border-b-bg-1': showBorderBottom, 'font-14': useFontSize14 }"
         :style="{
            height: height,
            borderColor:  errorTips ? 'var(--aaruy-error-color)' : isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-1)'
        }"
    >
      <van-field
        v-model="value"
        type="number"
        :label="title"
        :placeholder="placeholder || '请输入'"
        :required="isRequired"
        autocomplete="off"
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
      <span class="ml-8"
            :class="{ 'inline-block': unitWidth, 'text-right': isUnitRight }"
            :style="{ width: unitWidth }">{{ unit || '' }}</span>
    </div>
    <div v-if="titleTips" class="flex items-center justify-between">
      <div class="text-weak-2 text-xs">{{ titleTips }}</div>
      <ErrorView v-if="errorTips" :tips="errorTips" :width="errorTipWidth" padding="0 0 0 0" />
    </div>
    <template v-else>
      <ErrorView v-if="errorTips" :tips="errorTips" />
    </template>
  </template>
</template>
