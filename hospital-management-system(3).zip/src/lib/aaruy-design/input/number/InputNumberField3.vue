<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import {INVALID_ID} from '@/utils/global.vo.help';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getDigitCount, isMultipleStep } from '@/lib/math/util/math.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/input/number/input.number.field.style.css';
import type {InputNumberChangePayload} from '@/lib/aaruy-design/input/number/type/input.number.field2.type';


/**
 * 数字输入框 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  title: string;
  data: string;  // 外部传入的数值
  min: number;
  max?: number;
  maxName?: string;  // 最大值的标题
  showMaxNameInError?: boolean;  // 是否在报错中显示最大值的标题，仅 maxName 和 max 具备时可用
  digit: number;  // 最多小数位数
  name: string;  // 没有 name 的话 chrome 会报错
  unit?: string;  // 默认 U/h;
  step?: number;  // 默认不限制步长
  fontSize?: number;
  placeholder?: string;  // 默认"请输入"
  inputWidth?: string;  // 仅PC
  height?: string;  // 仅APP
  showBorderBottom?: boolean;  // 仅APP
  showBorderBottomBlack?: boolean;  // 仅APP
  useFontSize14?: boolean;  // 仅APP
  isRequired?: boolean;  // 仅APP
  unitWidth?: string;   // 仅APP
  isUnitRight?: boolean;  //  仅APP
  padding?: string;
  titleTips?: string;  // 标题右侧的提示词 仅PC
}

interface Emit {
  (e: 'change', data: InputNumberChangePayload): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const value = ref<string>('');
const errorTips = ref<string>('');
const isFocused = ref<boolean>(false);  // 仅移动端

const unitText = computed<string>(() => prop.unit || 'U/h');

// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError,
  checkAndGetErrorTips
});

watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true } );

function onChange(data: string): void {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  value.value = data;
  emit('change', { data: data, errorTips: tips });
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

function checkAndGetErrorTips(data: string): string {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  return tips;
}

function getErrorTips(data: string): string {
  if (!data && data !== '0') {
    return '请输入有效数字';
  }
  if (+data < prop.min) {
    return `不得小于${prop.min}${unitText.value}`;
  }
  if (prop.max !== undefined && +data > prop.max) {
    if (prop.max === INVALID_ID) {
      return `请先设置${prop.maxName || '最大值'}`;
    }
    if (prop.maxName && prop.showMaxNameInError) {
      return `不得大于${prop.maxName}: ${prop.max}${unitText.value}`;
    }
    return `不得大于${prop.max}${unitText.value}`;
  }
  if (prop.step && !isMultipleStep(+data, prop.step)) {
    return `必须是${prop.step}的整数倍`;
  }
  if (getDigitCount(data) > prop.digit) {
    return `小数位数不得超过${prop.digit}位`;
  }
  return '';
}

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}
</script>

<template>
  <template v-if="screenStore.isPC">
    <div style="height: 32px;"
         class="flex items-center justify-between border-b-default border-hover-primary-4 pl-16 pb-4 pr-24"
         :class="{ 'border-error-i': errorTips }">
      <div v-if="titleTips" class="inline-flex items-end">
        <span class="text-s">{{ title }}</span>
        <span class="pl-8 text-weak-real-3 text-xs font-bold">{{ titleTips }}</span>
      </div>
      <span v-else class="text-s">{{ title }}</span>
      <div class="inline-flex items-center">
        <input v-disable-wheel
               :value="value"
               :placeholder="placeholder || '请输入'"
               :name="name"
               :style="{ width: inputWidth }"
               type="number"
               class="input-placeholder input-arrow-hidden text-right text-s font-bold"
               @input="event => onChange((event.target as HTMLInputElement).value)" />
        <span class="ml-4 text-s" style="height: 24px; line-height: 24px;">{{ unitText }}</span>
      </div>
    </div>
    <ErrorView :tips="errorTips" padding="0 24px 0 0" />
  </template>
  <template v-else>
    <div class="input-field-field-2 flex items-center"
         :class="{
            'border-b-bg-0': showBorderBottom && showBorderBottomBlack,
            'border-b-bg-1': showBorderBottom && !showBorderBottomBlack,
            'font-14': useFontSize14,
            'padding': padding,
         }"
         :style="{
            height: height,
            borderColor: errorTips ? 'var(--aaruy-error-color)' : isFocused ? 'var(--aaruy-primary-color-2)' : (showBorderBottomBlack ? 'var(--aaruy-bg-color-0)' : 'var(--aaruy-bg-color-1)')
        }"
    >
      <van-field
        v-model="value"
        type="number"
        :label="title"
        :placeholder="placeholder || '请输入'"
        :required="isRequired"
        autocomplete="off"
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
      <span class="ml-8"
            :class="{ 'inline-block': unitWidth, 'text-right': isUnitRight }"
            :style="{ width: unitWidth }">{{ unit || '' }}</span>
    </div>
    <ErrorView v-if="errorTips" :tips="errorTips" />
  </template>
</template>
