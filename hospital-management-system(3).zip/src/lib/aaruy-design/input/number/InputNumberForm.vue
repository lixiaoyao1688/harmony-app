<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import IconPencil from '@/modules/admission/icons/IconPencil.vue';
import '@/lib/aaruy-design/input/number/input.number.form.style.css';


interface Prop {
  data: number;
  min: number;
  max: number;
  step: number;
  precision: number;  // 保留几位小数
  placeholder?: string;  // 占位文本
}

interface Emit {
  (e: 'change', v: number): void;
  (e: 'pressEnter', v: number): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const innerData = ref<number>(prop.data);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');


watch(() => prop.data, (newValue) => {
  innerData.value = newValue;
}, { immediate: true });

function onChange(v: number): void {
  innerData.value = v;
  emit('change', v);
}

function onPressEnter(): void {
  emit('pressEnter', innerData.value);
}
</script>


<template>
  
  <a-input-number
    v-model:value="innerData"
    :placeholder="innerPlaceholder"
    :min="min"
    :max="max"
    :step="step"
    :controls="false"
    :precision="precision"
    class="input-number-form"
    @change="onChange"
    @pressEnter="onPressEnter"
  >
    <template #addonAfter>
      <IconPencil :size="24" />
    </template>
  </a-input-number>

</template>
