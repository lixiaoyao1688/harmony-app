<script setup lang="ts">
import {ref, watch} from 'vue';
import {debounce} from '@/utils/global.tool';
import '@/lib/aaruy-design/input/number/input.number.label.style.css';


/**
 * 前后都有文本的输入框
 * 仅pc
 */
interface Prop {
  data: number;  // 数据来源
  startText: string;  // 前置文本
  endText: string;  // 后置文本
  placeholder?: string;  // 提示词
  max?: number;  // 最大值
  min?: number;  // 最小值
  precision?: number;  // 数值精度 (保留的小数点位数)
}

interface Emit {
  (e: 'change', data: number | undefined): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<number>(100);
const onDebounceChange = debounce(onChange, 500);


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: number): void {
  onEmit(data);
}

function onEnter(): void {
  onEmit(value.value);
}

function onEmit(data: number | null): void {
  if (data === null) {
    emit('change', undefined);
    return;
  }
  emit('change', data);
}
</script>

<template>
  <div class="inline-flex items-center">
    <span>{{ startText }}</span>
    <a-input-number
      v-model:value="value"
      :placeholder="placeholder || '请输入'"
      :max="max"
      :min="min"
      :controls="false"
      :precision="precision"
      class="input-number-label"
      @change="onDebounceChange"
      @pressEnter="onEnter"
    />
    <span>{{ endText }}</span>
  </div>
</template>
