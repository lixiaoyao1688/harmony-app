<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getDigitCount, isMultipleStep } from '@/lib/math/util/math.util';
import '@/lib/aaruy-design/input/number/input.number.field.style.css';
import type {InputNumberChangePayload} from '@/lib/aaruy-design/input/number/type/input.number.field2.type';


interface Prop {
  title: string;
  data: number;  // 外部传入的数值
  min: number;
  max: number;
  maxTitle?: string;  // 最大值的含义
  digit: number;  // 最多小数位数
  name: string;  // 没有 name 的话 chrome 会报错
  unit?: string;  // 默认 U/h;
  step?: number;  // 默认不限制步长
  fontSize?: number;
  placeholder?: string
  inputWidth?: string;  // 默认 100px;
}

interface Emit {
  (e: 'change', data: InputNumberChangePayload): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const value = ref<string>('');
const errorTips = ref<string>('');
const unitText = computed<string>(() => prop.unit || 'U/h');

const pc = computed<boolean>(() => screenStore.isPC);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);

defineExpose({
  checkAndGetErrorTips
});

watch(() => prop.data, (data) => {
  if (data) {
    value.value = data.toString();
  }
}, { immediate: true } );

function onChange(data: string): void {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  value.value = data;
  emit('change', { data: data, errorTips: tips });
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips !== '';
}

function checkAndGetErrorTips(data: string): string {
  const tips = getErrorTips(data);
  errorTips.value = tips;
  return tips;
}

function getErrorTips(data: string): string {
  if (!data && data !== '0') {
    return `${prop.title}需输入有效数字`;
  }
  if (+data < prop.min) {
    return `${prop.title}不得小于${prop.min}${unitText.value}`;
  }
  if (+data > prop.max) {
    return `${prop.title}不得大于${ prop.maxTitle ? prop.maxTitle + ': ' : '' }${prop.max}${unitText.value}`;
  }
  if (prop.step && !isMultipleStep(+data, prop.step)) {
    return `${prop.title}必须是${prop.step}的整数倍`;
  }
  if (getDigitCount(data) > prop.digit) {
    return `${prop.title}小数位数不得超过${prop.digit}位`;
  }
  return '';
}

</script>

<template>
  <div style="height: 32px;" class="flex items-center justify-between">
      <span class="text-s">{{ title }}</span>
      <div class="inline-flex items-center">
        <input :value="value"
               :placeholder="placeholder || '请输入'"
               :name="name"
               type="number"
               class="input-placeholder input-arrow-hidden text-center text-s font-bold border-b-bg-7 border-hover-primary border-focus-primary border-active-primary"
               :class="{ 'border-error-i': errorTips }"
               :style="{ width: inputWidth || '100px' }"
               @input="event => onChange(event.target.value)" />
        <span class="ml-4 text-s" style="height: 24px; line-height: 24px;">{{ unitText }}</span>
      </div>
    </div>
</template>
