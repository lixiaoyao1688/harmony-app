<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/input/number/input.number.raw.style.css';


interface Prop {
	value: string;
	placeholder?: string;
}

interface Emit {
	(e: 'change', data: string): void;
}

const screenStore = useScreenStore();
const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

function onChange(v: string): void {
  emit('change', v);
}
</script>

<template>
	<van-field
		v-if="mobile"
		class="input-raw"
		type="number"
		:placeholder="placeholder || '请输入'"
		:model-value="value"
		@update:model-value="onChange"
	/>
</template>
