export interface InputNumberChangePayload {
  data: string;
  errorTips: string;
}

export type InputNumberExpose = {
  checkValueError: () => boolean,
}
