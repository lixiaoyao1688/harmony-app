export interface InputNumberLabel2NewExposedType {
  checkAndGetErrorTips: (data: string) => string;
}