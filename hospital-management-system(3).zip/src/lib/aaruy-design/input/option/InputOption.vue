<script setup lang="ts">
import {ref, watch} from 'vue';
import {getDigitCount} from '@/lib/math/util/math.util';
import {useScreenStore} from '@/lib/screen/store/screen.store';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import '@/lib/aaruy-design/input/option/input.option.theme1.style.css';


/**
 * 输入框 下拉项样式 组件
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  data: string;
  placeholder: string;
  min: number;
  max: number;
  digit: number;
  unit: string;
  isSelected?: boolean;  // 仅PC
}

interface Emit {
	(e: 'change', data: string): void;
  (e: 'select'): void;
	(e: 'enter', data: string): void;
}

defineExpose({
  hasError,
  getError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>('');
const errorTips = ref<string>('');
const errorColor = 'rgb(255,58,58)';
const screenStore = useScreenStore();

watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: string): void {
  value.value = data;
  errorTips.value = getErrorTips(data);
  if (errorTips.value == '') {
    emit('change', data);
  }
}

function onEnter(): void {
  if (errorTips.value !== '') {
    return;
  }
  emit('enter', value.value);
}

function hasError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getError(): string {
  const tips = getErrorTips(value.value);
  errorTips.value = tips;
  return tips;
}

function getErrorTips(data: string): string {
  if (!data || isNaN(+data)) {
    return '请输入有效数字';
  }
  if (getDigitCount(data) > prop.digit) {
    return `小数位数不得超过${prop.digit}位`;
  }
  if (+data < prop.min) {
    return `不得小于${prop.min}${prop.unit}`;
  }
  if (+data > prop.max) {
    return `不得大于${prop.max}${prop.unit}`;
  }
  return '';
}

function onSelect(): void {
  errorTips.value = getErrorTips(value.value);
  emit('select');
  // if (errorTips.value !== '') {
  //   return;
  // }
}
</script>

<template>
  <div v-if="screenStore.isPC"
       class="input-option rounded-4 cursor-default mt-8 pt-4 pb-8 text-s text-white"
       :class="{ 'bg-default-1': isSelected }"
       @click="onSelect"
  >
    <div class="text-center pb-4 border-b-bg-1">自定义</div>
    <input type="text" :value="value"
           class="font-bold tex-lg text-center mt-4"
           :maxlength="4"
           :style="{ color: errorTips ? errorColor : 'rgb(255,255,255)' }"
           :placeholder="placeholder"
           @click.stop
           @input="event => onChange(event.target.value)"
           @keyup.enter="onEnter"
    />
    <div class="text-center">{{ unit }}</div>
    <ErrorView v-if="errorTips" :tips="errorTips" :color="errorColor" padding="4px 0 0 0" is-text-center />
  </div>
  <template v-else>
    <input :value="value"
           v-disable-wheel
           type="number"
           name="rage-value"
           :class="{ 'border-error': errorTips }"
           class="input-placeholder input-arrow-hidden focus-border-primary-1 w-full bg-16 border-bg-16 text-s text-white px-8 rounded-4"
           style="height: 32px; line-height: 32px; padding-right: 120px;"
           :placeholder="placeholder"
           @input="event => onChange(event.target.value)"
    />
    <span class="absolute" style="right: 20px; top: 6px;">{{ unit }}</span>
    <ErrorView v-if="errorTips" :tips="errorTips" is-text-left />
  </template>
</template>
