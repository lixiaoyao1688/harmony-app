export type InputOptionExpose = {
  hasError: () => boolean;
  getError: () => string;
}
