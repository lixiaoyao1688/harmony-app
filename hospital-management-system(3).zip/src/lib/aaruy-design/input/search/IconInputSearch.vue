<template>
	<svg id="iconInputSearch" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
		<rect id="iconInputSearchRect" data-name="矩形 1688" width="24" height="24" fill="none"/>
		<g id="iconInputSearchG" data-name="组 6693" transform="translate(-1 -1)">
			<path id="iconInputSearchGPath1" data-name="路径 1969" d="M12.115,20.23A8.115,8.115,0,1,0,4,12.115,8.115,8.115,0,0,0,12.115,20.23Z" fill="none" stroke="#fff" stroke-linejoin="round" stroke-width="1.5"/>
			<path id="iconInputSearchGPath2" data-name="路径 1971" d="M33.222,33.222l4.051,4.051" transform="translate(-15.272 -15.272)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
		</g>
	</svg>
</template>