<script setup lang="ts">
import { computed, ref } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import type { ChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';
import '@/lib/aaruy-design/input/search/styles/input.search.style.css';
import IconInputSearch from '@/lib/aaruy-design/input/search/IconInputSearch.vue';


interface Prop {
	value: string;
	icon?: boolean;  // 是否展示icon
	width?: number | string;  // 输入框宽度
  maxLength?: number; // 字符最大长度
	placeholder?: string; // 输入框提示信息
	hideBorder?: boolean;  // 是否隐藏边框
	bgColor?: string;
}

interface Emit {
	(e: 'change', data: string): void;
	(e: 'search'): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const focus = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const innerWidth = computed<string | null>(() => {
  if (!prop.width) {
    return null;
  }
  if (typeof prop.width === 'number') {
    return prop.width + 'px';
  }
  return prop.width;
});


function onSearch() {
  emit('search');
}

function onChange(e: ChangeEvent) {
  emit('change', e.target.value as string);
}

function onIconValueChange(val: string): void {
  emit('change', val);
}

function onCancel(): void {
  emit('change', '');
}

function onFocus(): void {
  focus.value = true;
}

function onBlur(): void {
  focus.value = false;
}
</script>

<template>
	
	<template v-if="icon">
		<van-search
			v-if="mobile"
			:model-value="value"
			:placeholder="placeholder || '请输入'"
			:class="{ focus: focus }"
			class="icon-input-search"
			@update:model-value="onIconValueChange"
			@cancel="onCancel"
			@focus="onFocus"
			@blur="onBlur"
			@search="onSearch"
		>
			<template #left-icon>
				<IconInputSearch />
			</template>
		</van-search>
	</template>
	<template v-else>
		<div class="input-search" :style="{ width: innerWidth }">
			<a-input
				:value="value"
				:maxlength="maxLength"
				:placeholder="placeholder ? placeholder: '请输入'"
				:class="{ 'border-none': hideBorder }"
				:style="{ backgroundColor: bgColor || null }"
				@change="onChange"
				@press-enter="onSearch"
			/>
			<ButtonView
				type="primary"
				text="搜索"
				class="input-search-btn ml-8"
				:class="{
				'input-search-btn-pc': pc,
				'input-search-btn-mobile': mobile,
			}"
				@click="onSearch"
			/>
		</div>
	</template>
	
</template>

<style>
.input-search-btn {
	display: inline-block !important;
	position: absolute !important;
	right: 0 !important;
	height: 100%;
}

.input-search-btn-mobile {
	width: 56px;
	font-size: 16px;
}

.input-search-btn-pc {
	width: 80px;
}
</style>
