<script setup lang="ts">
import { ref, watch } from 'vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import IconRemoveMobile from '@/lib/aaruy-design/input/search/icons/IconRemoveMobile.vue';
import { DEFAULT_INPUT_CONFIG } from '@/lib/aaruy-design/input/config/input.config';
import '@/lib/aaruy-design/input/search/styles/new.input.search.style.css';


interface Prop {
	value: string;
	maxLength?: number;
	placeholder?: string;
  isDisabled?: boolean;
}

interface Emit {
	(e: 'change', v: string): void;
	(e: 'search'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isClearShowed = ref<boolean>(true);


watch(() => prop.value, (newVal) => {
  isClearShowed.value = !!newVal;
}, { immediate: true });

function onChange(v: string): void {
  emit('change', v);
}

function onSearch(): void {
  emit('search');
}

function onClear(): void {
  emit('change', '');
  onSearch();
}
</script>

<template>
	<div class="new-input-search-mobile flex border-4">
		<van-field
			:model-value="value"
			label=""
			:placeholder="placeholder || '请输入'"
			:maxlength="maxLength || DEFAULT_INPUT_CONFIG.MAX_LENGTH"
			autocomplete="off"
			@update:model-value="onChange"
		>
			<template #right-icon>
				<IconRemoveMobile v-show="isClearShowed" @click="onClear" />
			</template>
		</van-field>
		<ButtonView type="primary"
                text="搜索"
                style="width: 80px; height: 100%; font-size: 16px;"
                :disabled="isDisabled"
                @click="onSearch" />
	</div>
</template>
