<script setup lang="ts">
import type { ChangeEvent } from 'ant-design-vue/lib/_util/EventInterface';
import '@/lib/aaruy-design/input/tiny/input.tiny.style.css';


interface Prop {
	value: string;
}

interface Emit {
	(e: 'change', data: string): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onChange(e: ChangeEvent) {
  emit('change', e.target.value as string);
}
</script>

<template>
	<a-input
		:value="value"
		class="aaruy-input-tiny"
		placeholder="请输入"
		@change="onChange"
	/>
</template>

<style scoped></style>