<script setup lang="ts">
import VueJsonPretty from 'vue-json-pretty';
import 'vue-json-pretty/lib/styles.css';
import '@/lib/aaruy-design/json-view/json.view.style.css';


interface Prop {
  json: Object;
}

defineProps<Prop>();
</script>

<template>
  <vue-json-pretty
    :data="json"
    :showIcon="true"
    :showLength="true"
    :showDoubleQuotes="true"
    :showKeyValueSpace="true"
  />
</template>