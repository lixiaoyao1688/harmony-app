<script setup lang="ts">
interface Prop {
	hideCol1?: boolean;
	hideCol2?: boolean;
	hideCol3?: boolean;
}

defineProps<Prop>();
</script>

<template>
	<div class="pr-16 pl-32">
		<slot name="all"></slot>
		<div class="flex justify-between px-24" v-if="!hideCol1 || !hideCol2 || !hideCol3">
			<div class="flex flex-col flex-1" v-if="!hideCol1">
				<slot name="col1"></slot>
			</div>
			<div class="flex flex-col flex-1" v-if="!hideCol2">
				<slot name="col2"></slot>
			</div>
			<div class="flex flex-col flex-1" v-if="!hideCol3">
				<slot name="col3"></slot>
			</div>
		</div>
	</div>
</template>
