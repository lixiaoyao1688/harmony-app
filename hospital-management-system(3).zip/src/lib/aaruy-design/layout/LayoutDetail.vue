<script setup lang="ts">
import IconLayoutBack from '@/lib/aaruy-design/layout/icons/IconLayoutBack.vue';


interface Prop {
	height: string;
	showBack: boolean;  // 是否展示返回箭头
}

interface Emit {
	(e: 'back'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function back() {
  emit('back');
}
</script>

<template>
  <div class="layout-detail" :style="{ height: height }">
		<div class="header">
			<IconLayoutBack v-if="showBack" @back="back" />
			<div class="flex-1 h-100 flex items-center justify-end">
				<slot name="header"></slot>
			</div>
		</div>
		<div class="content">
			<slot></slot>
		</div>
	</div>
</template>

<style scoped>
.layout-detail {
	height: 100%;
	background-color: var(--aaruy-bg-color-2);
	--layout-detail-height: 54px;
}

.layout-detail > .header {
  height: var(--layout-detail-height);
	display: flex;
	align-items: center;
	padding: 0 16px;
}

.layout-detail > .content {
	overflow: hidden auto;
	height: calc(100% - var(--layout-detail-height));
}
</style>
