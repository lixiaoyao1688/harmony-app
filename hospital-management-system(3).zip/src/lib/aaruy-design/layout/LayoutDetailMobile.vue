<script setup lang="ts">
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


interface Prop {
  height: string;
	waiting?: boolean;  // 是否等待服务返回结果中
	isBlack?: boolean;  // 是否使用黑色背景
  isPlainBlack?: boolean;  // 是否使用纯黑背景
	isBgTransparent?: boolean;  // 是否背景透明
	showButtonGroup?: boolean;  // 是否展示底部按钮组
	showPaddingTopAndBottom?: boolean;  // 是否展示 padding-top 和 padding-bottom
	showReset?: boolean;
}

interface Emit {
  (e: 'reset'): void;
  (e: 'cancel'): void;
  (e: 'save'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function reset(): void {
  emit('reset');
}

function cancel(): void {
  emit('cancel');
}

function save(): void {
  emit('save');
}
</script>

<template>
  <div class="layout-detail-mobile"
       :class="{ 'bg-plain-black': isPlainBlack, 'bg-black': isBlack, 'bg-transparent': isBgTransparent }"
       :style="{ height: height }">
		<div
			class="layout-detail-mobile-content"
			:class="{ 'p-t-b': showPaddingTopAndBottom }"
			:style="{ height: showButtonGroup ? 'calc(100% - var(--bottom-height))' : '100%' }">
			<slot></slot>
		</div>
		<div v-if="showButtonGroup" class="flex items-center layout-detail-mobile-bottom">
			<ButtonView v-if="!showReset" type="default" text="取消" class="w-50 mr-8 text-s-important" @click="cancel" />
			<ButtonView v-if="showReset" type="default" text="重置" class="w-50 mr-8 text-s-important" @click="reset" />
			<ButtonView :loading="waiting" type="primary" text="保存" class="w-50 ml-8 text-s-important" @click="save" />
		</div>
  </div>
</template>

<style scoped>
.layout-detail-mobile {
	background-color: rgb(67,80,91);
	--bottom-height: calc(var(--van-button-default-height) + 32px);
}

.layout-detail-mobile.bg-plain-black {
  background-color: rgb(0,0,0);
}

.bg-black {
	background-color: rgb(21,26,30);
}

.bg-transparent {
	background-color: transparent;
}

.layout-detail-mobile-content {
	overflow: hidden auto;
}

.layout-detail-mobile-bottom {
	padding: 0 16px;
	height: var(--bottom-height);
	border-top: 1px solid rgb(255,255,255,0.1);
}

.p-t-b {
	padding-top: 16px;
	padding-bottom: 16px;
}
</style>
