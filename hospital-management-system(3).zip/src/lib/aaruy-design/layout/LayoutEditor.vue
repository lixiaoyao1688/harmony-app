<script setup lang="ts">
import { computed } from 'vue';
import IconCloseHover from '@/lib/aaruy-design/modal/icons/IconModalClose.vue';


interface Prop {
  titlePosition: 'left' | 'center';  // 标题是否左对齐
  title?: string;  // center 时有效
}

interface Emit {
  (e: 'close'): void
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isLeft = computed<boolean>(() => prop.titlePosition === 'left');
const isCenter = computed<boolean>(() => prop.titlePosition === 'center');

function close() {
  emit('close');
}
</script>

<template>
  <div class="lf">
    <!--  Header  -->
    <div class="lf-header lf-header-left" v-if="isLeft">
      <slot name="header"></slot>
			<IconCloseHover @close="close" />
    </div>
    <div class="lf-header lf-header-center" v-if="isCenter">
      <span class="title">{{ title }}</span>
			<IconCloseHover @close="close" />
    </div>
    <!--  Body  -->
    <div class="lf-body">
      <slot name="body"></slot>
    </div>
  </div>
</template>

<style scoped>
.lf {
  --lf-height: 44px;
  width: 100%;
  height: 100vh;
  background-color: rgb(37, 43, 48);
}

.lf-header {
  display: flex;
  align-items: center;
  padding: 0 15px;
  background-color: rgb(91, 103, 116);
  height: var(--lf-height);
}

.lf-header-left {
  justify-content: space-between;
}

.lf-header-center > .title {
  height: 100%;
  display: flex;
  align-items: center;
  font-size: 16px;
  font-weight: 700;
  flex: 1;
  justify-content: center;
  color: rgb(255, 255, 255);
}

.lf-body {
  overflow: auto;
  height: calc(100% - var(--lf-height));
}
</style>
