<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


interface Prop {
  isFullHeight?: boolean;
  isCenterHeight?: boolean;
  isSplitLineHidden?: boolean;  // 是否隐藏中间的分割线
	waiting?: boolean;  // 是否正在等待返回结果
	cancelText?: string;  // 取消文本
	confirmText?: string;  // 确定文本
	showReset?: boolean;
  hideBottom?: boolean;  // 是否隐藏底部工具栏
  isDisabled?: boolean;
}

interface Emit {
  (e: 'save'): void;
  (e: 'cancel'): void;
  (e: 'reset'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

const innerCancelText = computed<string>(() => prop.cancelText || '取消');
const innerConfirmText = computed<string>(() => prop.confirmText || '保存');

function save() {
  emit('save');
}

function cancel() {
  emit('cancel');
}

function reset() {
  emit('reset');
}
</script>

<template>
  <div v-if="pc" class="lf-form" :class="{ 'full-height': isFullHeight, 'center-height': isCenterHeight }">
    <div class="lf-form-top">
      <div class="lf-form-top-left" :class="{ 'split-line-hidden': isSplitLineHidden }">
        <slot name="formContent"></slot>
      </div>
      <div class="lf-form-top-right">
        <slot name="formContentRight"></slot>
      </div>
    </div>
    <div v-if="!hideBottom" class="lf-form-bottom">
			<ButtonView v-if="showReset" :disabled="isDisabled" type="default" text="重置" class="layout-form-btn mr-8" @click="reset" />
			<ButtonView v-else :disabled="isDisabled" type="default" :text="innerCancelText" class="layout-form-btn mr-8" @click="cancel" />
			<ButtonView :disabled="isDisabled" type="primary" :text="innerConfirmText" class="layout-form-btn ml-8" :loading="waiting" @click="save" />
    </div>
  </div>
	
	<div
		v-if="mobile"
		v-bind="$attrs"
		class="lf-mobile"
	>
		<div class="lf-mobile-content">
			<slot></slot>
		</div>
		<div class="lf-mobile-bottom">
			<ButtonView type="default" :text="innerCancelText" class="layout-form-btn-mobile mr-8" @click="cancel" />
			<ButtonView type="primary" :text="innerConfirmText" :loading="waiting" class="layout-form-btn-mobile ml-8" @click="save" />
		</div>
	</div>
</template>

<style scoped>
.lf-form {
  width: 100%;
	height: 100%;
  /* .ad-content-form-tool 的高度 height: calc(100% - 50px); */
  overflow-y: auto;
  background-color: rgb(67, 80, 91);
  display: flex;
  flex-direction: column;
  padding: 7px 10px 12px 15px;
  --ad-form-item-height: 51px;
}

.full-height {
  height: 100% !important;
}

.center-height {
  height: 70vh !important;
}

.lf-form .lf-form-top {
  display: flex;
  height: calc(100% - 70px);
  overflow: hidden auto;
}

.lf-form > .lf-form-top > .lf-form-top-left {
  width: 50%;
  min-height: 100%;
  height: fit-content;
  padding-right: 10px;
  border-right: 1px solid rgba(204, 214, 225, 0.2);
}

.lf-form > .lf-form-top > .lf-form-top-left.split-line-hidden {
	border-right: none;
}

.lf-form > .lf-form-top > .lf-form-top-right {
  width: 50%;
  padding: 5px 10px;
}

.lf-form .lf-form-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 20px;
}

.lf-mobile {
	width: 100%;
	height: 100%;
	background-color: transparent;
	display: flex;
	flex-direction: column;
}

.lf-mobile-content {
	flex: 1;
	overflow: hidden auto;
}

.lf-mobile-bottom {
	height: 44px;
	display: flex;
	margin-top: 16px;
}
</style>

<style>
.layout-form-btn {
	width: 50%;
	height: 50px !important;
	font-size: 18px !important;
}

.layout-form-btn-mobile {
	width: 50%;
	height: 100% !important;
	font-size: 16px !important;
}
</style>
