<script setup lang="ts">
interface Emit {
	(e: 'back'): void;
}

const emit = defineEmits<Emit>();

function back() {
  emit('back');
}
</script>


<template>
	<svg id="iconLayoutBack" data-name="组件 220 – 4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" @click="back">
		<rect id="iconLayoutBackRect" data-name="矩形 3503" width="24" height="24" rx="4" fill="rgba(255,255,255,0)"/>
		<path id="iconLayoutBackPath" data-name="路径 2882" d="M-964.861,370.883l-7.071-7.071,7.071-7.071" transform="translate(979.397 -351.812)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
	</svg>
</template>

<style scoped>
#iconLayoutBack {
	cursor: pointer;
}

#iconLayoutBackRect:hover {
	fill: var(--aaruy-primary-color-2);
}
</style>
