<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import type { LegendChartType } from '@/lib/aaruy-design/legend/types/legend.chart.type';


interface Prop {
	items: Array<LegendChartType>;
	isAgp?: boolean;
	agpHeight?: number;
  useReportStyle?: boolean;  // 是否使用报告样式，仅 pc 且 !isAgp 可用;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  
  <template v-if="pc">
    <div v-if="isAgp" class="flex justify-between">
      <div v-for="(it,i) in items" :key="it.id" class="flex items-center item-agp" :class="{ 'ml-24': i > 0 }">
        <span :style="{ backgroundColor: it.color }" style="width: 16px; height: 12px;"></span>
        <span class="text-xs leading-xs ml-4">{{ it.text }}</span>
      </div>
    </div>
    <template v-else>
      <div v-if="useReportStyle" style="display: flex; height: 25px;">
        <div v-for="(it,i) in items" :key="it.id" style="display: flex; flex-direction: column; justify-content: space-between"
             :style="{ marginLeft: i > 0 ? '15px' : '0' }">
          <span style="font-size: 14px; line-height: 19px; color: rgb(0,0,0);">{{ it.text }}</span>
          <span :style="{ backgroundColor: it.color }" style="height: 4px; border-radius: 3px; width: 100%;"></span>
        </div>
      </div>
      <div v-else class="flex" style="height: 25px;">
        <div v-for="it in items" :key="it.id" class="flex flex-col justify-between item">
          <span class="text-xs leading-xs">{{ it.text }}</span>
          <span :style="{ backgroundColor: it.color }" style="height: 2px; border-radius: 3px" class="w-100"></span>
        </div>
      </div>
    </template>
  </template>
  <template v-else>
    <div v-if="isAgp" class="mt-24">
      <div v-for="it in items" :key="it.id" class="inline-block w-50">
        <div class="inline-block" :style="{ backgroundColor: it.color }" style="width: 56px; height: 12px;"></div>
        <div class="inline-block text-xs leading-xs ml-12">{{ it.text }}</div>
      </div>
    </div>
    <div v-else class="flex justify-end" style="height: 25px;">
      <div v-for="it in items" :key="it.id" class="flex flex-col justify-between item">
        <span class="text-xs leading-xs text-xxs-impl">{{ it.text }}</span>
        <span :style="{ backgroundColor: it.color }" style="height: 2px; border-radius: 3px" class="w-100"></span>
      </div>
    </div>
  </template>
	
</template>

<style scoped>
.item:not(:last-child) {
	margin-right: 15px;
}
</style>
