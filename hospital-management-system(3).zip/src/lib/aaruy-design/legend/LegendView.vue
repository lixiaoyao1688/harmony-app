<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';


interface Prop {
	title: string;
	color: string;
	myClass?: string;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <div :class="myClass">
		<div :class="{ 'text-xs leading-xs': pc, 'text-xxs leading-xxs font-normal': mobile }">{{ title }}</div>
		<div class="legend-bar mt-4" :style="{ backgroundColor: color }"></div>
	</div>
</template>

<style scoped>
.legend-bar {
	height: 2px;
	border-radius: 3px;
}
</style>