export interface LegendChartType {
	id: number;
	text: string;
	color: string;
}