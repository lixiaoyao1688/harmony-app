/**
 * 列表项 VO
 */
export class ListItemVO {
  
  public id: number;  // 唯一标识
  public key: string;  // 键 文本
  public value: string;  // 值 文本
  public isValid: boolean;  // 值是否有效
  public unit: string;  // 值的单位
  
  constructor(id: number, k: string, v: string, isValid?: boolean, u?: string) {
    this.id = id;
    this.key = k;
    this.value = v;
    this.isValid = isValid === undefined ? true : isValid;
    this.unit = u || '';
  }
  
}
