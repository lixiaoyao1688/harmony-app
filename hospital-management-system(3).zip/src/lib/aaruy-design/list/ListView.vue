<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { ListItemVO } from '@/lib/aaruy-design/list/ListItem.vo';


interface Prop {
  list: Array<ListItemVO>;
}

/**
 * 列表 组件
 */
const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <ul v-if="pc">
    <li v-for="(it,i) in list" :key="it.id" class="flex justify-between items-center p-8 bg-1 rounded-4" :class="{ 'mb-4': i < list.length-1 }">
      <span class="text-s leading-l">{{ it.key }}</span>
      <div v-if="it.isValid" class="leading-l text-right" style="min-width: 70px;">
        <span class="text-lg font-bold">{{ it.value }}</span>
        <span v-if="it.unit" class="text-lg ml-4">{{ it.unit }}</span>
      </div>
      <span v-else class="text-weak text-lg leading-l font-bold">----</span>
    </li>
  </ul>
  <ul v-if="mobile" class="rounded-4 bg-2" style="padding: 4px 0 !important;">
    <li v-for="(it,i) in list" :key="it.id" class="flex justify-between items-center py-12 mx-16" :class="{ 'border-b-1-bg-4' : i < list.length-1 }">
      <span class="text-s leading-s">{{ it.key }}</span>
      <div v-if="it.isValid" class="leading-l">
        <span class="text-s font-bold">{{ it.value }}</span>
        <span v-if="it.unit" class="text-xxs ml-4">{{ it.unit }}</span>
      </div>
      <span v-else class="text-weak text-s leading-l font-bold">----</span>
    </li>
  </ul>
</template>
