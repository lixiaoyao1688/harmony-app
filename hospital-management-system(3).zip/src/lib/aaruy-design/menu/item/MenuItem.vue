<script setup lang="ts">
interface Prop {
  text: string;
}

interface Emit {
  (e: 'open'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function open() {
  emit('open');
}
</script>

<template>
  <div class="hms-menu-item" @click="open">
    <slot name="icon"></slot>
    <span class="ml-6">{{ text }}</span>
  </div>
</template>


<style scoped>
.hms-menu-item {
  display: flex;
  align-items: center;
  justify-content: flex-start;
	height: 100%;
	padding-left: 15px;
}

.hms-menu-item > span {
	display: inline-flex;
	align-items: center;
	height: 100%;
}
</style>
