<script setup lang="ts">
import { MenuRoutePayload } from '@/lib/aaruy-design/menu/route/menu.route';
import '@/lib/aaruy-design/menu/route/menu.route.style.css';


interface Prop {
  selectedKeys: any[];
}

interface Emit {
  (e: 'change', p: MenuRoutePayload<any>): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onSelect({ key, selectedKeys }) {
  emit('change', { key: key, selectedKeys: selectedKeys });
}
</script>

<template>
  <a-menu
    :selected-keys="selectedKeys"
    :inlineCollapsed="false"
    @select="onSelect"
    class="home-menu"
    theme="dark"
    mode="inline"
  >
    <slot name="content"></slot>
  </a-menu>
</template>
