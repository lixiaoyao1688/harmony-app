export interface MenuRoutePayload<T> {
	selectedKeys: T[];   // 当前选中的菜单项 key 数组
	key: T;  // menu item 的唯一标志
}