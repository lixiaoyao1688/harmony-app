<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import IconCloseHover from '@/lib/aaruy-design/modal/icons/IconModalClose.vue';
import {
  MODAL_WIDTH_PC,
  MODAL_WIDTH_PC_MAX,
  MODAL_WIDTH_MOBILE,
  MODAL_WIDTH_MOBILE_MAX,
  MODAL_WIDTH_PC_MIN,
  MODAL_WIDTH_MOBILE_MIN
} from '@/lib/aaruy-design/modal/config/modal.config';
import '@/lib/aaruy-design/modal/styles/modal.style.css';


interface Prop {
  title: string;  // 标题
  visible: boolean;  // 是否显示
	isTitleLeft?: boolean;  // 标题是否居左展示
	isFullscreen?: boolean;  // 是否全屏
  width?: string;  // 宽度
  maxWidth?: string;  // 最大宽度
  minWidth?: string;  // 最小宽度
  isMobileDialog?: boolean;  // 是否启用 移动端对话框 模式
  disableIconClose?: boolean;   // 仅 PC
  disableEsc?: boolean;  // 是否禁用 ESC 关闭
  disableMaskClose?: boolean;  // 是否禁用"点击蒙层关闭"
  useThemeWhiteOnMobile?: boolean;   // 是否使用白色主题，仅mobile;
  destroyOnClose?: boolean;
  isBgColor3?: boolean;  // 是否使用 bg-3，仅pc;
  useNewMobile?: boolean;  // 是否启用新的移动端对话框
  top?: string;  //  对话框距离顶部的高度，默认 100px;
}

interface Emit {
  (e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const v = ref<boolean>(prop.visible);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const wrapClassName = computed<string>(() => prop.isMobileDialog ? 'ar-modal-mobile' : 'ar-modal');
const styleObject = computed(() => {

  // 默认 PC端 样式
  let w = MODAL_WIDTH_PC;
  let wmin = MODAL_WIDTH_PC_MIN;
  let wmax = MODAL_WIDTH_PC_MAX;

  // 启动移动端样式
  if (prop.isMobileDialog) {
    w = MODAL_WIDTH_MOBILE;
    wmin = MODAL_WIDTH_MOBILE_MIN;
    wmax = MODAL_WIDTH_MOBILE_MAX;
  }

  // 如果显式指定了样式，就用指定的
  if (prop.width) {
    w = prop.width;
  }
  if (prop.minWidth) {
    wmin = prop.minWidth;
  }
  if (prop.maxWidth) {
    wmax = prop.maxWidth;
  }

  return { width: w, maxWidth: wmax, minWidth: wmin, top: prop.top || (screenStore.isLaptop ? '20px' : null) };
});

const innerDisableEsc = computed<boolean>(() => {
  if (!screenStore.isPC) {
    return prop.disableEsc || false;
  }
  // http://192.168.1.236:81/redmine/issues/6760
  return true;
});

const innerDisableMaskClose = computed<boolean>(() => {
  if (!screenStore.isPC) {
    return prop.disableMaskClose || false;
  }
  // http://192.168.1.236:81/redmine/issues/6760
  return true;
});


watch(() => prop.visible, (newVal) => {
  v.value = newVal;
});

function onAfterClose(): void {
  emit('close');
}
</script>

<template>
  <a-modal
    v-model:visible="v"
    :title="title"
    :footer="null"
    :style="styleObject"
    :afterClose="onAfterClose"
    :destroyOnClose="destroyOnClose === undefined ? true : destroyOnClose"
    :closable="!isMobileDialog && !disableIconClose"
    :centered="isMobileDialog"
    :wrapClassName="wrapClassName"
    :keyboard="!innerDisableEsc"
    :maskClosable="!innerDisableMaskClose"
    :class="{
        'modal-title-left': isTitleLeft,
        'ar-modal-full': isFullscreen,
        'ar-white-modal': useThemeWhiteOnMobile,
        'ar-modal-bg-3': isBgColor3
      }"
  >
    <template #closeIcon>
      <IconCloseHover />
    </template>
    <slot></slot>
  </a-modal>
</template>
