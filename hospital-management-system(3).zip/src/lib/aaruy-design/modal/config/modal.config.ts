export const MODAL_WIDTH_PC = '30vw';
export const MODAL_WIDTH_PC_MIN = '400px';
export const MODAL_WIDTH_PC_MAX = '800px';


export const MODAL_WIDTH_MOBILE = '75vw';
export const MODAL_WIDTH_MOBILE_MIN = '320px';
export const MODAL_WIDTH_MOBILE_MAX = '600px';
