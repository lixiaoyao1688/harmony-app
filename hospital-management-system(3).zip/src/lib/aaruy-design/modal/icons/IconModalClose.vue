<script setup lang="ts">
interface Emit {
  (e: 'ok'): void;
	(e: 'close'): void;
}


const emit = defineEmits<Emit>();

function close() {
  emit('close');
}
</script>

<template>
  <div class="icon-modal-home-close" @click="close">
    <svg xmlns="http://www.w3.org/2000/svg" width="13.824" height="14.033" viewBox="0 0 13.824 14.033">
      <path id="iconModalHomeClose" data-name="路径 2508" d="M171.318,157.989l.045.042,5.605,5.608,5.4-5.4a.825.825,0,0,1,1.209,1.122l-.041.045-5.4,5.4,5.4,5.4a.825.825,0,0,1-1.121,1.21l-.045-.042-5.4-5.4-5.605,5.609a.825.825,0,0,1-1.209-1.122l.042-.045,5.606-5.609L170.2,159.2a.825.825,0,0,1,1.121-1.209Z" transform="translate(-169.955 -157.792)" fill="#fff"/>
    </svg>
  </div>
</template>

<style scoped>
.icon-modal-home-close {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  cursor: pointer;
}

.icon-modal-home-close:hover {
  background-color: rgb(67,80,91);
}
</style>
