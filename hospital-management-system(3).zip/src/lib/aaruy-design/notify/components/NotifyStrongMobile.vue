<script setup lang="ts">
import '@/lib/aaruy-design/notify/components/notify.strong.mobile.style.css';


interface Prop {
	visible: boolean;
	bgColor: string;
	borderColor: string;
	title1?: string;
	title2?: string;
	message?: string;
}

interface Emit {
	(e: 'close'): void;  // 关闭弹窗
	(e: 'closed'): void;  // 关闭弹窗且动画结束后
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClose(): void {
  emit('close');
}

function onClosed(): void {
  emit('closed');
}
</script>

<template>
	<van-dialog :show="visible" class="aaruy-notify-strong-mobile" @closed="onClosed">
		<div class="aaruy-notify-strong-mobile-content text-white relative p-16" :style="{ backgroundColor: bgColor, borderColor: borderColor }">
			<svg id="iconNotifyStrongMobile" class="absolute" style="top: 12px; right: 16px;" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" @click="onClose">
				<path id="iconNotifyStrongMobileP1" data-name="路径 2507" d="M0,0H20V20H0Z" fill="rgba(255,0,51,0)"/>
				<path id="iconNotifyStrongMobileP2" data-name="路径 2508" d="M171.318,157.989l.045.042,5.605,5.608,5.4-5.4a.825.825,0,0,1,1.209,1.122l-.041.045-5.4,5.4,5.4,5.4a.825.825,0,0,1-1.121,1.21l-.045-.042-5.4-5.4-5.605,5.609a.825.825,0,0,1-1.209-1.122l.042-.045,5.606-5.609L170.2,159.2a.825.825,0,0,1,1.121-1.209Z" transform="translate(-166.558 -154.638)" fill="#fff"/>
			</svg>
			<div class="text-lg leading-l text-center mt-24">
				<span class="mr-8" v-if="title1">{{ title1 }}</span>
				<span v-if="title2">{{ title2 }}</span>
			</div>
			<div class="text-xl-1 leading-xl-1 text-center mt-16 mb-24" v-if="message">{{ message }}</div>
		</div>
	</van-dialog>
</template>
