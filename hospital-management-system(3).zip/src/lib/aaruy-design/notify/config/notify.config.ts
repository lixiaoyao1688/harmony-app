export const NOTIFY_DURING = 3000;  // 展示时长，单位ms
export const NOTIFY_LONG_DURING = 6000;
export const NOTIFY_NEVER_CLOSE_DURING = 0;   // 永久展示
export const NOTIFY_SUCCESS_TEXT = '成功';
export const NOTIFY_ERROR_TEXT = '失败';
