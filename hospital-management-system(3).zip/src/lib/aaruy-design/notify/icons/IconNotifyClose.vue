<script setup lang="ts">
interface Prop {
  useBlack?: boolean;
}

interface Emit {
	(e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClose() {
  emit('close');
}
</script>

<template>
  <div class="icon-notify-close" :class="{ 'icon-notify-close-black': useBlack }" @click="onClose">
		<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
			<path d="M0,0H20V20H0Z"
            fill="rgba(255,0,51,0)"/>
			<path d="M171.318,157.989l.045.042,5.605,5.608,5.4-5.4a.825.825,0,0,1,1.209,1.122l-.041.045-5.4,5.4,5.4,5.4a.825.825,0,0,1-1.121,1.21l-.045-.042-5.4-5.4-5.605,5.609a.825.825,0,0,1-1.209-1.122l.042-.045,5.606-5.609L170.2,159.2a.825.825,0,0,1,1.121-1.209Z"
            transform="translate(-166.867 -154.808)"
            :fill="useBlack ? 'var(--aaruy-bg-color-2)' : 'rgb(255,255,255)'"/>
		</svg>
	</div>
</template>

<style scoped>
.icon-notify-close {
	cursor: pointer;
	display: flex;
	width: 28px;
	height: 28px;
	align-items: center;
	justify-content: center;
	border-radius: 4px;
}

.icon-notify-close:hover {
	background-color: var(--aaruy-bg-color-3);
}

.icon-notify-close.icon-notify-close-black:hover {
  background-color: var(--aaruy-weak-text-color);
}
</style>
