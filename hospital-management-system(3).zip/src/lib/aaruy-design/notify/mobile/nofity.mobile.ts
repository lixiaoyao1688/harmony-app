import { showToast } from 'vant';
import {
  NOTIFY_DURING,
  NOTIFY_LONG_DURING,
} from '@/lib/aaruy-design/notify/config/notify.config';


export function notifyErrorMobile(msg: string, desc?: string) {
  showToast({
    type: 'fail',
    icon: 'cross',
    message: getMessage(msg, desc),
    duration: NOTIFY_DURING,
    className: 'notify-mobile',
    closeOnClick: true,
  });
}

export function notifySuccessMobile(msg: string, desc?: string) {
  showToast({
    type: 'success',
    icon: 'success',
    message: getMessage(msg, desc),
    duration: NOTIFY_DURING,
    className: 'notify-mobile',
    closeOnClick: true,
  });
}

export function notifyInfoMobile(msg: string, desc?: string, long?: boolean) {
  showToast({
    type: 'text',
    icon: 'info-o',
    message: getMessage(msg, desc),
    duration: long ? NOTIFY_LONG_DURING : NOTIFY_DURING,
    className: 'notify-mobile',
    closeOnClick: true,
  });
}

function getMessage(msg: string, desc?: string): string {
  return desc ? (msg + ': ' + desc) : msg;
}
