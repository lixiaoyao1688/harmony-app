import { useScreenStore } from '@/lib/screen/store/screen.store';
import { notifyErrorPC, notifyInfoPC, notifySuccessPC } from '@/lib/aaruy-design/notify/pc/notify.pc';
import { NOTIFY_ERROR_TEXT, NOTIFY_SUCCESS_TEXT } from '@/lib/aaruy-design/notify/config/notify.config';
import { notifyErrorMobile, notifyInfoMobile, notifySuccessMobile } from '@/lib/aaruy-design/notify/mobile/nofity.mobile';


export function notifyErrorRangeTitle(title: string, min: number, max: number, field: string) {
  notifyError(title, `请输入 ${min} 到 ${max} 位【${field}】`);
}

export function notifyErrorRange(min: number, max: number, field: string) {
  notifyErrorFormat(`请输入 ${min} 到 ${max} 位【${field}】`);
}
export function notifyErrorInvalid(field: string, more?: string) {
  notifyErrorFormat(`【${field}】格式不规范` + (more ? `, ${more}` : ''));
}
export function notifyErrorFormat(desc: string) {
  notifyError('格式有误', desc);
}
export function notifyErrorLackInputer(field: string) {
  notifyError('信息缺失', `请输入【${field}】`);
}
export function notifyErrorLackSelector(field: string) {
  notifyError('信息缺失', `请选择【${field}】`);
}
export function notifyErrorNormal(desc: string) {
  notifyError(NOTIFY_ERROR_TEXT, desc);
}
export function notifyError(msg?: string, desc?: string) {
  const m = msg || NOTIFY_ERROR_TEXT;
  
  if (useScreenStore().isPC) {
    notifyErrorPC(m, desc);
  }
  else {
    notifyErrorMobile(m, desc);
  }
}


export function notifySuccessNormal(desc?: string) {
  notifySuccess(NOTIFY_SUCCESS_TEXT, desc || '');
}
export function notifySuccess(msg?: string, desc?: string) {
  const m = msg || NOTIFY_SUCCESS_TEXT;
  
  if (useScreenStore().isPC) {
    notifySuccessPC(m, desc);
  }
  else {
    notifySuccessMobile(m, desc);
  }
}


export function notifyInfo(msg: string, desc?: string, long?: boolean) {
  if (useScreenStore().isPC) {
    notifyInfoPC(msg, desc);
  }
  else {
    notifyInfoMobile(msg, desc, long);
  }
}
