import { h } from 'vue';
import { notification } from 'ant-design-vue';
import { MS_PER_SECOND } from '@/lib/time/config/time.config';
import { NOTIFY_DURING } from '@/lib/aaruy-design/notify/config/notify.config';
import IconNotifyClose from '@/lib/aaruy-design/notify/icons/IconNotifyClose.vue';
import { CheckCircleFilled, CloseCircleFilled, ExclamationCircleFilled } from '@ant-design/icons-vue';
import type { Component } from '@vue/runtime-core';


const DURING = NOTIFY_DURING / MS_PER_SECOND;


export function notifyConfig() {
  notification.config({
    closeIcon: h(IconNotifyClose as unknown as Component, {}),
  });
}


export function notifyErrorPC(msg: string, desc?: string) {
  notification.error({
    message: msg,
    description: desc || '',
    icon: () => h(CloseCircleFilled, { style: 'color: rgb(255,36,42)' }),
    duration: DURING,
  });
}

export function notifySuccessPC(msg: string, desc?: string) {
  notification.success({
    message: msg,
    description: desc || '',
    icon: () => h(CheckCircleFilled, { style: 'color: rgb(15,177,9)' }),
    duration: DURING
  });
}

export function notifyInfoPC(msg: string, desc?: string, during?: number) {
  notification.info({
    message: msg,
    description: desc || '',
    icon: () => h(ExclamationCircleFilled, { style: 'color: rgb(235,166,48)' }),
    duration: during || DURING
  });
}
