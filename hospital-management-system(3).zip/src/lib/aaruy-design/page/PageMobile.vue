<script setup lang="ts">
import {onMounted, onUnmounted, ref} from 'vue';
import {App} from '@capacitor/app';
import IconBack from '@/lib/icon/IconBack.vue';
import '@/lib/aaruy-design/page/style/page.style.css';
import type { PluginListenerHandle } from '@capacitor/core';


/**
 * 页面 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  visible: boolean;
  hideBorderBottom?: boolean;
  useWhiteTheme?: boolean;
  topBgColor?: string;  // 顶部标题栏的背景颜色，默认透明;
}

interface Emit {
  (e: 'goBack'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const handler = ref<PluginListenerHandle | null>(null);

onMounted(async () => {
  // 手指在 APP 左边缘向右滑动时触发
  handler.value = await App.addListener('backButton', onClose);
});

onUnmounted(() => {
  if (handler.value) {
    // 移除手指滑动监听
    handler.value.remove();
  }
});

function onClose(): void {
  emit('goBack');
}
</script>

<template>
  <van-popup :show="visible" :z-index="2" :lock-scroll="false"
             :overlay="false"
             teleport="body" position="right" duration="0.2"
             style="overflow-y: hidden;"
             destroy-on-close>
    <div class="aaruy-page"
         :class="{ 'aaruy-page-white': useWhiteTheme }"
         @click.stop>
      <div class="top"
           :style="{ backgroundColor: topBgColor }"
           :class="{ 'hide-border-bottom': hideBorderBottom }">
        <IconBack @click="onClose" class="top-back-icon"/>
        <div class="top-title">
          <slot name="title"></slot>
        </div>
        <div class="top-other">
          <slot name="other"></slot>
        </div>
      </div>
      <div class="content">
        <slot name="content"></slot>
      </div>
    </div>
  </van-popup>
</template>

<style scoped>
.hide-border-bottom {
  border-bottom: none;
}
</style>
