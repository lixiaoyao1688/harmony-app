<script setup lang="ts">
import {computed} from 'vue';


/**
 * 页面内容区 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  bottomHeight?: string;  // 默认 56px;
}

const prop = defineProps<Prop>();
const innerBottomHeight = computed<string>(() => prop.bottomHeight === undefined ? '56px' : prop.bottomHeight);
</script>

<template>
  <div class="h-full">
    <div :style="{ height: 'calc(100% - ' + innerBottomHeight + ')' }" class="overflow-hidden-auto p-16">
      <slot></slot>
    </div>
    <div :style="{ height: innerBottomHeight  }">
      <slot name="bottom"></slot>
    </div>
  </div>
</template>
