export type PageExposeType = {
  onOpen: () => void;
  onClose: () => void;
}
