<script setup lang="ts">
import { ref } from 'vue';
import { FIRST_PAGE } from '@/lib/aaruy-design/table/table';
import '@/lib/aaruy-design/pagination/pagination.mobile.style.css';


interface Prop {
  total: number;  // 总记录数
  pageSize: number;  // 每页记录数
}

interface Emit {
  (e: 'change', page: number): void;  // page: 页码
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const currentPage = ref<number>(FIRST_PAGE);


function change(page: number) {
  emit('change', page);
}
</script>

<template>
  <van-pagination
    v-model="currentPage"
    :total-items="total"
    :items-per-page="pageSize"
    class="pagination-mobile"
    mode="simple"
		@change="change"
  />
</template>

<style scoped>
.pagination-mobile {
  height: 100%;
}
</style>
