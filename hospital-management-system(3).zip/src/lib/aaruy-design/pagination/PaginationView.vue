<script setup lang="ts">
import { ref } from 'vue';
import { FIRST_PAGE } from '@/lib/aaruy-design/table/table';
import { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconSelectUp from '@/lib/aaruy-design/selector/icons/IconSelectUp.vue';
import IconSelectDown from '@/lib/aaruy-design/selector/icons/IconSelectDown.vue';
import '@/lib/aaruy-design/pagination/pagination.style.css';
import '@/lib/aaruy-design/selector/filter/select.filter.dropdown.style.css';


interface Prop {
	total: number;
	options: Array<SelectorFormItemVO>;  // 每页条数切换列表
	page: number;  // 当前页码
	pageSize: number;  // 每页条数
	showTotal?: (total: number) => string;  // 数据总量的显示方式，缺省则不展示总量
	hidePageSizeChanger?: boolean;   // 是否隐藏每页条数切换器
  useTransparentTheme?: boolean;  // 是否使用透明主题
  isSimple?: boolean;  // 是否使用"简单分页"界面
}

interface Emit {
  (e: 'change', data: PaginationData): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);


function onOpenChange(opened: boolean) {
  isOpened.value = opened;
}

function onChange(page: number, pageSize: number) {
  emit('change', { page, pageSize });
}

function onPageSizeChange(v: number) {
  emit('change', { page: FIRST_PAGE, pageSize: v });
}
</script>

<template>
  <div class="pagination-view" :class="{ 'pagination-view-transparent': useTransparentTheme }">
    <a-pagination
      :current="page"
      :total="total"
      :show-total="showTotal"
      :page-size="pageSize"
      :show-size-changer="false"
      :simple="isSimple"
      @change="onChange"
    />
    <a-select
			v-if="!hidePageSizeChanger"
      :value="pageSize"
      class="pagination-select"
      dropdown-class-name="select-filter-dropdown"
      @change="onPageSizeChange"
			@dropdownVisibleChange="onOpenChange"
    >
			<template #suffixIcon>
				<IconSelectUp v-if="isOpened" />
				<IconSelectDown v-else />
			</template>
      <a-select-option v-for="o in options" :key="o.id" :value="o.payload">{{ o.text }}</a-select-option>
    </a-select>
  </div>
</template>
