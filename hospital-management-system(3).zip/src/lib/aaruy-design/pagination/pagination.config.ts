/**
 * 分页 配置
 */
export const PAGINATION_DEFAULT_PAGE = 1;  // 默认页码
export const PAGINATION_DEFAULT_LIMIT = 20;  // 默认每页条数
export const PAGINATION_MIN_LIMIT = 5;  // 最小每页条数
export const PAGINATION_MAX_LIMIT = 100;  // 最大每页条数
