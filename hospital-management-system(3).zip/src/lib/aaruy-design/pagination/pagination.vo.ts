export interface PaginationData {
	page: number;    // 当前页码
	pageSize: number;  // 每页条数
}