<template>
  <span class="inline-flex items-center justify-end" style="width: 24px; height: 24px;">
    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="6" viewBox="0 0 10 6" style="transform: rotate(270deg);">
      <path d="M0,0,5,6l5-6Z" fill="#a2adb8"/>
    </svg>
  </span>
</template>
