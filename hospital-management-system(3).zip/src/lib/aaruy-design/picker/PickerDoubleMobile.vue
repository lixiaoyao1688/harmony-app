<script setup lang="ts">
import {ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {CGM_WARN_TIME_MAP} from '@/modules/cgm/config/cgm.warn.time';
import '@/lib/aaruy-design/picker/style/picker.double.style.css';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


type ValueType = { value: number, text: string };
type DataType = { selectedValues: [number, number] };

/**
 * 双列选择器 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  items1: Array<ItemType2>;
  items2: Array<ItemType2>;
  selectedItems: [ItemType2, ItemType2];
  title: string;
  width?: string;
}

interface Emit {
	(e: 'change', data: [ItemType2, ItemType2]): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const columns: [Array<ValueType>, Array<ValueType>] = [
  prop.items1.map(it => ({ value: it.id, text: it.text })),
  prop.items2.map(it => ({ value: it.id, text: it.text }))
];
const ids = ref<[number, number]>([0,0]);

watch(() => prop.selectedItems, (data) => {
  ids.value = [data[0].id, data[1].id];
}, { immediate: true });

function onChange(data: DataType): void {
  const ids = data.selectedValues;
  const item1 = SelectItemVO.getItem(CGM_WARN_TIME_MAP, ids[0]);
  const item2 = SelectItemVO.getItem(CGM_WARN_TIME_MAP, ids[1]);
  emit('change', [item1, item2]);
}
</script>

<template>
  <van-picker v-model="ids"
              :columns="columns"
              :title="title"
              :style="{ width: width || '100%' }"
              :option-height="32"
              class="picker-double"
              confirm-button-text=""
              cancel-button-text=""
              @change="onChange" />
</template>
