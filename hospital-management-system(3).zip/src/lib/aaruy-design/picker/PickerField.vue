<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {PICKER_SWIPE_DURATION} from '@/lib/aaruy-design/picker/picker.config';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import type {SelectItem} from '@/lib/aaruy-design/selector/types/selector.type';
import type {PickerItemType} from '@/lib/aaruy-design/picker/picker.type';


type DataType = SelectItemVO<any>;

/**
 * 选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  item: DataType;
  items: Array<DataType>;
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题;
  destroyOutSideTitle?: boolean;  // 是否销毁外部标题
  isRequired?: boolean;
  requiredColor?: string;  // 默认 text-required
  height?: string;  // 默认100%;
  showBorderBottom?: boolean;  // 是否展示底部边框;
  borderBottomColor?: string;  // 默认 bg-1
  useFont16?: boolean;  // 是否使用字号 16px;
  placeholderColor?: string;  // 默认 var(--aaruy-weak-text-color)
  usePlaceholderFontBold?: boolean;  // 默认 false
  padding?: string;
  isDisabled?: boolean;  // 是否禁用
}

interface Emit {
	(e: 'change', data: DataType): void;
  (e: 'error-change', data: string): void;
  (e: 'scroll-end'): void;  // 列表滚动到底部时触发
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<DataType>(prop.item);
const isOpened = ref<boolean>(false);
const errorTips = ref<string>('');


const columns = computed<Array<PickerItemType>>(() => prop.items.map(it => it.pickerItem));

// src/lib/aaruy-design/error/type/error.type.ts: ErrorExposedType
defineExpose({
  checkValueError,
});

watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function onOpen(): void {
  if (prop.isDisabled) {
    return;
  }
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function checkValueError(): boolean {
  const tips = getErrorTips(value.value as DataType);
  errorTips.value = tips;
  emit('error-change', tips);
  return tips !== '';
}

function getErrorTips(data: DataType): string {
  if (prop.isRequired && !data.isValid) {
    return '请选择';
  }
  return '';
}

function onConfirm({ selectedOptions }): void {
  const data = selectedOptions[0];
  const id = data.value;
  const item = prop.items.find(it => it.id === id);
  if (!item) {
    return;
  }
  const e: SelectItem<any> = item.payload ? { id: data.value, text: data.text, payload: item.payload } : { id: data.value, text: data.text };
  const d = new SelectItemVO(e);
  value.value = d;
  checkValueError();
  emit('change', d);
  onClose();
}

function onChange({ selectedIndexes }: { selectedIndexes: Array<number> }): void {
  if (selectedIndexes && selectedIndexes[0] === columns.value.length - 1) {
    emit('scroll-end');
  }
}
</script>

<template>
  <van-popup :show="isOpened"
             position="bottom"
             class="picker-mobile"
             @click-overlay="onClose"
  >
    <van-picker
      :title="title"
      :model-value="[item.id]"
      :columns="columns"
      :swipe-duration="PICKER_SWIPE_DURATION"
      @cancel="onClose"
      @confirm="onConfirm"
      @change="onChange"
      confirm-button-text="确定"
    />
  </van-popup>
  <div class="flex items-center justify-between w-full leading-l text-xs"
       :style="{
         height: height || '100%',
         fontSize: useFont16 ? '16px' : '14px',
         borderBottomWidth: showBorderBottom ? '1px' : '0',
         borderBottomStyle: 'solid',
         borderBottomColor: errorTips ? 'var(--aaruy-error-color-2)' : (borderBottomColor || 'var(--aaruy-bg-color-1)')
       }"
       @click="onOpen">
    <span v-if="!destroyOutSideTitle" :class="{ hidden: hideOutSideTitle }">
      <i v-if="isRequired" class="mr-2 text-required" style="font-style: normal;">*</i>
      <span :class="{
        'text-error-2': errorTips,
        'text-weak': isDisabled, 'text-white': !isDisabled,
      }">{{ title }}</span>
    </span>
    <div class="inline-flex items-center">
      <span v-if="item.isValid" class="mr-4">{{ item.text }}</span>
      <span v-else class="mr-4"
            :style="{ fontWeight: usePlaceholderFontBold ? 700 : 400, color: placeholderColor || 'var(--aaruy-weak-text-color)' }">请选择</span>
      <IconPickerField />
    </div>
  </div>
  <ErrorView v-if="errorTips"
             :tips="errorTips" :font-weight="400" :padding="padding"
             color="var(--aaruy-error-color-2)" />
</template>
