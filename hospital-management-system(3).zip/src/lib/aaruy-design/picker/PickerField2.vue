<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {PICKER_SWIPE_DURATION} from '@/lib/aaruy-design/picker/picker.config';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import type {PickerItemType} from '@/lib/aaruy-design/picker/picker.type';


type SelectItemType = SelectItemVO<any>;

/**
 * 选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  item: SelectItemType;
  items: Array<SelectItemVO<any>>;
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题;
  destroyOutSideTitle?: boolean;  // 是否销毁外部标题
  isRequired?: boolean;
  height?: string;  // 默认100%;
  showBorderBottom?: boolean;  // 是否展示底部边框;
  useFont16?: boolean;  // 是否使用字号 16px，默认 14px;
}

interface Emit {
  (e: 'change', data: SelectItemType): void;
}

defineExpose({
  hasError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const errorTips = ref<string>('');  // 报错文本
const value = ref<SelectItemType>(new SelectItemVO<unknown>());
const columns = computed<Array<PickerItemType>>(() => prop.items.map(it => it.pickerItem));


watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function hasError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value as SelectItemType);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getErrorTips(data: SelectItemType): string {
  if (!data.isValid) {
    return '请选择一项';
  }
  return '';
}

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onConfirm({ selectedOptions }): void {
  const data = selectedOptions[0];
  const id = data.value;
  const item = prop.items.find(it => it.id === id);
  value.value = item || new SelectItemVO();
  hasError();
  if (!item) {
    return;
  }
  if (item.payload) {
    emit('change', new SelectItemVO({ id: data.value, text: data.text, payload: item.payload }));
  }
  else {
    emit('change', new SelectItemVO({ id: data.value, text: data.text }));
  }
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" @click-overlay="onClose" position="bottom" class="picker-mobile">
    <van-picker
      :title="title"
      :model-value="[item.id]"
      :columns="columns"
      :swipe-duration="PICKER_SWIPE_DURATION"
      @cancel="onClose"
      @confirm="onConfirm"
      confirm-button-text="确定"
    />
  </van-popup>
  <div :class="{ 'border-b-bg-1': showBorderBottom }"
       :style="{
         height: height || '100%',
         fontSize: useFont16 ? '16px' : '14px',
         borderColor:  errorTips ? 'var(--aaruy-error-color)' : 'var(--aaruy-bg-color-1)'
       }"
       class="flex items-center justify-between w-full leading-l text-xs"
       @click="onOpen">
    <span v-if="!destroyOutSideTitle" :class="{ hidden: hideOutSideTitle }"><i v-if="isRequired" class="mr-2 text-required" style="font-style: normal;">*</i>{{ title }}</span>
    <div class="inline-flex items-center">
      <span v-if="item.isValid" class="mr-4">{{ item.text }}</span>
      <span v-else class="mr-4 text-weak-2">请选择</span>
      <IconPickerField />
    </div>
  </div>
  <ErrorView v-if="errorTips" :tips="errorTips" />
</template>
