<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {PICKER_SWIPE_DURATION} from '@/lib/aaruy-design/picker/picker.config';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import type {PickerItemType} from '@/lib/aaruy-design/picker/picker.type';


type SelectItemType = SelectItemVO<any>;

/**
 * 选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  item: SelectItemType;
  items: Array<SelectItemType>;
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题;
  destroyOutSideTitle?: boolean;  // 是否销毁外部标题
  isRequired?: boolean;
  height?: string;  // 默认100%;
  margin?: string;
  showBorderBottom?: boolean;  // 是否展示底部边框;
  useFont16?: boolean;  // 是否使用字号 16px;
  tips?: string;  // 报错文本
}

interface Emit {
  (e: 'change', data: SelectItemType): void;
}

defineExpose({
  checkValueError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const errorTips = ref<string>('');  // 报错文本
const value = ref<SelectItemType>(new SelectItemVO());
const columns = computed<Array<PickerItemType>>(() => prop.items.map(it => it.pickerItem));


watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function checkValueError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getErrorTips(data: SelectorFormItemVO): string {
  if (!data.isValid) {
    return prop.tips || '请选择一项';
  }
  return '';
}

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onConfirm({ selectedOptions }): void {
  const data = selectedOptions[0];
  const id = data.value;
  const item = prop.items.find(it => it.id === id);
  if (!item) {
    return;
  }
  value.value = item;
  checkValueError();
  if (item.payload) {
    emit('change', new SelectItemVO<any>({ id: data.value, text: data.text, payload: item.payload }));
  }
  else {
    emit('change', new SelectItemVO<any>({ id: data.value, text: data.text }));
  }
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" @click-overlay="onClose" position="bottom" class="picker-mobile">
    <van-picker
      :title="title"
      :model-value="[item.id]"
      :columns="columns"
      :swipe-duration="PICKER_SWIPE_DURATION"
      @cancel="onClose"
      @confirm="onConfirm"
      confirm-button-text="确定"
    />
  </van-popup>
  <div>
    <div :style="{ height: height || '100%', margin: margin, fontSize: useFont16 ? '16px' : '14px' }"
         :class="{ 'border-b-bg-1': showBorderBottom, 'border-bottom-error-i': errorTips }"
         class="h-full flex items-center justify-between w-full leading-l text-xs"
         @click="onOpen">
      <span v-if="!destroyOutSideTitle" :class="{ hidden: hideOutSideTitle }"><i v-if="isRequired" class="mr-2 text-required" style="font-style: normal;">*</i>{{ title }}</span>
      <div class="inline-flex items-center">
        <span v-if="item.isValid" class="mr-2">{{ item.text }}</span>
        <span v-else class="mr-2 text-weak-2 text-s">选择分段</span>
        <IconPickerField />
      </div>
    </div>
    <ErrorView v-if="errorTips" :tips="errorTips" bg-color="var(--aaruy-bg-color-12)" />
  </div>
</template>
