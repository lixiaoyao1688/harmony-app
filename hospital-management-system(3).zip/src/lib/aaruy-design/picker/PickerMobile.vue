<script setup lang="ts">
import {computed, watch} from 'vue';
import { PICKER_SWIPE_DURATION } from '@/lib/aaruy-design/picker/picker.config';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';


interface Prop {
  title: string;
  showPicker: boolean;
	item?: SelectorFormItemVO;
  items?: Array<SelectorFormItemVO>;
	multiItem?: Array<SelectorFormItemVO>;  // 多列选择 选中项
	multiItems?: Array<Array<SelectorFormItemVO>>;  // 多列选择
}

interface Emit {
  (e: 'multi-ok', items: Array<SelectorFormItemVO>): void;  // 多列选择
  (e: 'ok', item: SelectorFormItemVO): void;
  (e: 'close'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = computed<Array<number>>(() => {
  if (prop.multiItem) {
    return prop.multiItem.map(it => it.id);
  }
  return [(prop.item as SelectorFormItemVO).id];
});
const columns = computed(() => {
  if (prop.multiItems) {
    return prop.multiItems.map(items => {
      return items.map(it => ({ value: it.id, text: it.text }));
    });
  }
  return (prop.items as Array<SelectorFormItemVO>).map(it => ({ value: it.id, text: it.text }));
});

function onConfirm({ selectedOptions }): void {
  if (prop.multiItem) {
    const d1 = selectedOptions[0];
    const d2 = selectedOptions[1];
    emit('multi-ok', [ new SelectorFormItemVO(d1.value, d1.text), new SelectorFormItemVO(d2.value, d2.text) ]);
  }
  else {
    const data = selectedOptions[0];
    emit('ok', new SelectorFormItemVO(data.value, data.text));
  }
}

function onClose(): void {
  emit('close');
}
</script>

<template>
  <van-popup :show="showPicker" @click-overlay="onClose" position="bottom" class="picker-mobile">
    <van-picker
			:title="title"
      :model-value="value"
			:columns="columns"
			:swipe-duration="PICKER_SWIPE_DURATION"
			@cancel="onClose"
			@confirm="onConfirm"
			confirm-button-text="确定"
    />
  </van-popup>
</template>
