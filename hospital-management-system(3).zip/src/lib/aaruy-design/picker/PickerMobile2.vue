<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {PICKER_SWIPE_DURATION} from '@/lib/aaruy-design/picker/picker.config';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import type {PickerItemType} from '@/lib/aaruy-design/picker/picker.type';


type SelectItemType = SelectItemVO<any>;

/**
 * 选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  item: SelectItemType;
  items: Array<SelectItemType>;
}

interface Emit {
  (e: 'change', data: SelectItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const value = ref<SelectItemType>(new SelectItemVO());
const columns = computed<Array<PickerItemType>>(() => prop.items.map(it => it.pickerItem));


watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onConfirm({ selectedOptions }): void {
  const data = selectedOptions[0];
  const id = data.value;
  const item = prop.items.find(it => it.id === id);
  if (!item) {
    return;
  }
  value.value = item;
  if (item.payload) {
    emit('change', new SelectItemVO<any>({ id: data.value, text: data.text, payload: item.payload }));
  }
  else {
    emit('change', new SelectItemVO<any>({ id: data.value, text: data.text }));
  }
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" @click-overlay="onClose" position="bottom" class="picker-mobile">
    <van-picker
      :title="title"
      :model-value="[item.id]"
      :columns="columns"
      :swipe-duration="PICKER_SWIPE_DURATION"
      @cancel="onClose"
      @confirm="onConfirm"
      confirm-button-text="确定"
    />
  </van-popup>
  <div @click="onOpen">
    <slot></slot>
  </div>
</template>
