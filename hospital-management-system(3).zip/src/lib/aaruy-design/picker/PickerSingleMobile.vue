<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import {CGM_WARN_HIGH_VALUE_MAP} from '@/modules/cgm/config/cgm.warn.high.value';
import '@/lib/aaruy-design/picker/style/picker.double.style.css';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


type ValueType = { value: number, text: string };
type DataType = { selectedValues: [number, number] };

/**
 * 双列选择器 组件
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  items: Array<ItemType2>;
  item: ItemType2
  title: string;
  width?: string;
}

interface Emit {
  (e: 'change', data: ItemType2): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const columns = computed<Array<ValueType>>(() => prop.items.map(it => ({ value: it.id, text: it.text })));
const ids = ref<[number]>([0]);

watch(() => prop.item, (data) => {
  ids.value = [data.id];
}, { immediate: true });

function onChange(data: DataType): void {
  emit('change', SelectItemVO.getItem(CGM_WARN_HIGH_VALUE_MAP, data.selectedValues[0]));
}
</script>

<template>
  <van-picker v-model="ids"
              :columns="columns"
              :title="title"
              :option-height="32"
              class="picker-double"
              confirm-button-text=""
              cancel-button-text=""
              :style="{ width: width || '100%' }"
              @change="onChange" />
</template>
