export interface PickerItemType {
  value: number;
  text: string;
  className?: string;
}
