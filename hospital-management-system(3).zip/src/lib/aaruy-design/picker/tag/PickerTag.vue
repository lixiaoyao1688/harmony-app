<script setup lang="ts">
import { ref } from 'vue';
import { DownOutlined, UpOutlined } from '@ant-design/icons-vue';
import type { ItemType } from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 标签选择器 UI
 *
 * 限制
 * 每行最多 3 个标签;
 *
 * 使用范围
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  item: ItemType;
  items: Array<ItemType>;
  marginTop?: string;
  useSelectedStyleBorder?: boolean;  // "已选中的样式" 是否使用 "边框样式"
  useFont16?: boolean;  // 字号是否使用 16px;
  isRequired?: boolean;
}

interface Emit {
  (e: 'change', data: ItemType): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const COLLAPSE_IF_EXCEEDING_THIS_COUNT = 6;  // 超过此数量则折叠
const isCollapsed = ref<boolean>(true);  // 是否已折叠

function onCollapsedChange(): void {
  isCollapsed.value = !isCollapsed.value;
}

function onChange(data: ItemType): void {
  emit('change', data);
}
</script>

<template>
  <div class="flex items-center justify-between mb-8"
       :class="{ 'text-s': useFont16, 'text-xs': !useFont16 }"
       :style="{ marginTop: marginTop || '0' }">
    <div v-if="isRequired">
      <span class="text-error-2 mr-2">*</span>
      <span>{{ title }}</span>
    </div>
    <span v-else>{{ title }}</span>
    <div v-if="items.length > COLLAPSE_IF_EXCEEDING_THIS_COUNT" @click="onCollapsedChange">
      <div v-show="isCollapsed">
        <span class="mr-8">展开</span>
        <DownOutlined />
      </div>
      <div v-show="!isCollapsed">
        <span class="mr-8">收起</span>
        <UpOutlined />
      </div>
    </div>
  </div>
  <div class="flex flex-wrap" :class="{ 'text-s': useFont16, 'text-xs': !useFont16 }">
    <!--  width参数含义: 100%(父级宽度), 16px(2个mr-8), 4px(滚动条宽度), 3(一行3个标签) -->
    <div v-for="(it,i) in items" :key="it.id"
         class="inline-flex items-center justify-center bg-12 border-bg-12 rounded-4 py-6 px-8 mb-8"
         style="width: calc((100% - 16px - 4px) / 3);"
         :class="{
           'd-hidden': isCollapsed && i > (COLLAPSE_IF_EXCEEDING_THIS_COUNT-1),
           'selected': it.id === item.id && !useSelectedStyleBorder,
           'selected-border-style': it.id === item.id && useSelectedStyleBorder,
           'mr-8': i % 3 !== 2
         }"
         @click="onChange(it)">{{ it.text }}</div>
  </div>
</template>

<style scoped>
.selected {
  color: var(--aaruy-primary-color-6);
  background-color: var(--aaruy-primary-color-1-alpha);
}

.selected-border-style {
  font-weight: 700;
  color: var(--aaruy-primary-color-6);
  background-color: var(--aaruy-primary-color-1-alpha);
  border-color: var(--aaruy-primary-color-6);
}
</style>
