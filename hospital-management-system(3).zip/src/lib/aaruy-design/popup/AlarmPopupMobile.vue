<script setup lang="ts">
import { ref, watch } from 'vue';
import IconClose1 from '@/lib/icon/IconClose1.vue';


interface Props {
  color: string;//警报背景颜色
  bedNum: number;//床号
  name: string;//姓名
  info: string;//警报提示信息
  show: Boolean;//是否显示警报弹框
}

const props = defineProps<Props>();
const emits = defineEmits<{
  (e: 'close'): void
}>();

const show = ref<Boolean>(props.show);

watch(() => props.show, (val) => {
  show.value = val;
});

const clickChangeShow = () => {
  show.value = false;
  emits('close');
};

</script>

<template>
  <div class="alarm-popup-mobile" v-if="show">
    <div class="alarm-center-content" :style="{backgroundColor:color}">
      <IconClose1 class="alarm-icon" @click="clickChangeShow"/>
      <span class="alarm-detail">
        {{ bedNum }}床  {{ name }}
      </span>
      <span class="alarm-info">
        {{ info }}
      </span>
    </div>
  </div>
</template>
<style scoped>
.alarm-popup-mobile {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 998;
  width: 100%;
  height: 100%;
  background-color: rgb(0, 0, 0, 60%);
  display: flex;
  justify-content: center;
  align-items: center;
}

.alarm-center-content {
  position: relative;
  padding: 20px;
  width: 320px;
  min-height: 120px;
  max-height: max-content;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  color: var(--color);
}

.alarm-icon {
  position: absolute;
  right: 15px;
  top: 10px;
  width: 20px;
  height: 20px;
}

.alarm-detail {
  font-size: var(--fs-large);
}

.alarm-info {
  font-size: var(--fs-large-more);
}
</style>