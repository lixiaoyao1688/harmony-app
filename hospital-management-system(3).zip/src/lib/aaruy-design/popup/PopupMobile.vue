<script setup lang="ts">
import { ref } from 'vue';


interface Prop {
	visible: boolean;
}

interface Emit {
	(e: 'close'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const show = ref<boolean>(false);

function close(): void {
  emit('close');
}
</script>

<template>
	<van-popup
		:show="visible"
		position="bottom"
		@close="close"
		:style="{
			height: 'calc(100vh - var(--board-top) - var(--admission-detail-mobile-tab-header-height))',
			backgroundColor: 'var(--aaruy-bg-color-4)'
		}"
	>
		<slot></slot>
	</van-popup>
</template>
