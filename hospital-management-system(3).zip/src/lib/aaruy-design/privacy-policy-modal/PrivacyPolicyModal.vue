<script setup lang="ts">
import { ref, onMounted } from 'vue';
import {useUserStore} from '@/modules/user/store/user.store';
import {agreePolicy, isPolicyAgreed} from '@/lib/aaruy-design/privacy-policy-modal/util/policy.util';
import FormModal from '@/lib/aaruy-design/form/FormModal.vue';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import PrivacyPolicy from '@/modules/about/component/PrivacyPolicy.vue';
import ServiceAgreement from '@/modules/about/component/ServiceAgreement.vue';


/**
 * 用户协议与隐私政策 弹窗
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  url: string;  // 隐私政策网址;
}

const store = useUserStore();
const prop = defineProps<Prop>();
const showModal = ref<boolean>(false);

onMounted(() => {
  checkFirstRun();
});

async function checkFirstRun() {
  isPolicyAgreed()
    .then(isAgreed => {
      if (!isAgreed) {
        open();
      }
      store.toggleAgreed(isAgreed);
    });
}

async function onAgree() {
  agreePolicy()
    .then(() => {
      close();
      store.toggleAgreed(true);
    });
}

function onRefuse(): void {
  close();
  store.toggleAgreed(false);
}

function close(): void {
  showModal.value = false;
}

function open(): void {
  showModal.value = true;
}

function onPageOpen(): void {
  if (store.isAgreed) {
    return;
  }
  close();
}

function onPageClose(): void {
  if (store.isAgreed) {
    return;
  }
  open();
}
</script>

<template>
  <ModalView :visible="showModal"
             is-mobile-dialog
             use-theme-white-on-mobile
             width="90vw"
             max-width="90vw"
             min-width="90vw"
             disable-esc
             disable-mask-close
             title="用户协议和隐私政策">
    <FormModal :waiting="false" is-not-padding-on-mobile cancel-text-mobile="拒绝" ok-text-mobile="同意"
               @cancel="onRefuse"
               @confirm="onAgree">
      <div class="pt-16 pb-24 px-24 text-black text-s">
        <div class="pb-8">
          <span>欢迎您使用阿瑞查房软件，请充分阅读</span>
          <ServiceAgreement width="fit-content" height="24px" display="inline-block"
                            @open="onPageOpen" @close="onPageClose">
            <span class="text-primary font-bold inline-block w-full text-center text-s">《用户协议》</span>
          </ServiceAgreement>
          <span>和</span>
          <PrivacyPolicy width="fit-content" height="24px" display="inline-block"
                         @open="onPageOpen" @close="onPageClose">
            <span class="text-primary font-bold inline-block w-full text-center text-s">《隐私政策》</span>
          </PrivacyPolicy>
          <span>，点击“同意”按钮代表您已同意上述协议。</span>
        </div>
      </div>
    </FormModal>
  </ModalView>
</template>
