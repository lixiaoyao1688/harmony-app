/**
 * 用户是否同意协议 配置
 *
 * 适用设备
 * 平板 && 手机;
 */
export const POLICY_AGREE_KEY = 'hospital_policy_agree';
export const POLICY_AGREE_VALUE = 'true';

