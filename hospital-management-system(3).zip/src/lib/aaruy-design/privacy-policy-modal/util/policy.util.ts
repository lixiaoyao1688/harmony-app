import {Preferences} from '@capacitor/preferences';
import {POLICY_AGREE_KEY, POLICY_AGREE_VALUE} from '@/lib/aaruy-design/privacy-policy-modal/config/policy.config';


export async function agreePolicy(): Promise<void> {
  await Preferences.set({ key: POLICY_AGREE_KEY, value: POLICY_AGREE_VALUE });
}

export async function isPolicyAgreed(): Promise<boolean> {
  const { value } = await Preferences.get({ key: POLICY_AGREE_KEY });
  return value === POLICY_AGREE_VALUE;
}
