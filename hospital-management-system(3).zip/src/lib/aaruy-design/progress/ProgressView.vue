<script setup lang="ts">
import '@/lib/aaruy-design/progress/progress.style.css';


interface Prop {
	percent: number;  // 0~100
	color: string;  // 进度条颜色
	backgroundColor: string;  // 背景颜色
}

defineProps<Prop>();
</script>

<template>
	<a-progress :percent="percent" :show-info="false" :stroke-color="color" :trail-color="backgroundColor" style="height: 4px;"
              class="progress-view" />
</template>
