<script setup lang="ts">
import '@/lib/aaruy-design/pull-refresh/pull.refresh.style.css';


interface Prop {
  isLoading: boolean;
  minHeight: string;
  loadingText?: string;  // 加载中提示文案
  pullingText?: string;  // 下拉过程提示文案
  loosingText?: string;  // 释放过程提示文案
}

interface Emit {
	(e: 'refresh'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onRefresh(): void {
  emit('refresh');
}
</script>

<template>
  <van-pull-refresh
    class="aaruy-pull-refresh"
    :model-value="isLoading"
    :style="{ minHeight: minHeight }"
    :loading-text="loadingText || '加载中...'"
    :pulling-text="pullingText || '下拉即可刷新...'"
    :loosing-text="loosingText || '释放即可刷新...'"
    @refresh="onRefresh"
  >
    <slot></slot>
  </van-pull-refresh>
</template>
