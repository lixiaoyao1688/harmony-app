<script setup lang="ts">
import { ref, watch } from 'vue';
import { RadioButtonOptionDTO } from '@/lib/aaruy-design/radio-button/radio.button.dto';
import '@/lib/aaruy-design/radio-button/radio.style.css';


interface Prop {
  data: unknown;
  options: RadioButtonOptionDTO[];
}

interface Emit {
  (e: 'change', value: unknown): void
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const special = ref<unknown>(prop.data);


watch(() => prop.data, () => {
  special.value = prop.data;
});


function onChange(e) {
  emit('change', e.target.value);
}
</script>


<template>
  <a-radio-group v-model:value="special" button-style="solid" class="radio-group" @change="onChange">
    <a-radio-button v-for="b in options" :key="b.id" :value="b.id" class="radio-btn">{{ b.text }}</a-radio-button>
  </a-radio-group>
</template>


<style scoped>
.radio-btn {
  width: 80px;
  height: 32px;
  line-height: 32px;
  text-align: center;
}
</style>
