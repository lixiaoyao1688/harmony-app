<script setup lang="ts">
import {ref, watch,computed} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import '@/lib/aaruy-design/radio-button/new/style/radio.button.new.white.style.css';
import type {RadioGroupItem} from '@/lib/aaruy-design/radio-group/radio.group.type';


/**
 * 单选按钮 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  item: RadioGroupItem;
  items: Array<RadioGroupItem>;
  height?: string;
}

interface Emit {
  (e: 'change', data: RadioGroupItem): void;
}

const screenStore = useScreenStore();
const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const selectedItem = ref<RadioGroupItem>(new SelectItemVO<unknown>());
const pc = computed<boolean>(() => screenStore.isPC);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.item, (data) => {
  selectedItem.value = data;
}, { immediate: true });

function onChange(data: RadioGroupItem): void {
  selectedItem.value = data;
  emit('change', data);
}
</script>

<template>
  <div v-if="pc" :style="{ height: height || '32px', lineHeight: height || '32px' }"
       class="aaruy-radio-button-new-white">
    <div v-for="it in items" :key="it.id"
         :class="{ 'aaruy-selected': it.id === item.id }"
         @click="onChange(it)">{{ it.text }}</div>
  </div>
  <div><!--  暂不支持移动端  --></div>
</template>
