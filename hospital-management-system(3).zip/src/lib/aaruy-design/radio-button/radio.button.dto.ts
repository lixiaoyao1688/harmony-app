export interface RadioButtonOptionDTO {
	id: number;
	text: string;
}