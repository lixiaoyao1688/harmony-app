<script setup lang="ts">
import {ref, watch,computed} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import '@/lib/aaruy-design/radio-group/radio.group.list.style.css';
import type {RadioGroupItem} from '@/lib/aaruy-design/radio-group/radio.group.type';
import type {RadioChangeEvent} from 'ant-design-vue/lib/radio/interface';


/**
 * 单选 组件
 *
 * 适用项目
 * 闭环
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  item: RadioGroupItem;
  items: Array<RadioGroupItem>;
  type?: 'switch' | 'list';  // 默认 switch; 仅 pc;
  height?: string;  // 仅 switch 且 pc下需!use4KStyle;
  bgColor?: string;  // 背景颜色, 默认 bg-3, 仅 switch; 仅 pc;
  useColorPrimary6?: boolean;  // 是否使用 --aaruy-primary-color-6
  isCompactMode?: boolean;  // 是否启用紧凑模式 仅 "pc 的 switch 类型" 或 "mobile";
  margin?: string;  // 仅移动端;
  use4KStyle?: boolean;  // 是否适配4K屏，仅PC
}

interface Emit {
	(e: 'change', data: RadioGroupItem): void;
}

const screenStore = useScreenStore();
const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const selectedItem = ref<RadioGroupItem>(new SelectItemVO<unknown>());
const pc = computed<boolean>(() => screenStore.isPC);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.item, (data) => {
  selectedItem.value = data;
}, { immediate: true });

function onChange(data: RadioGroupItem): void {
  // selectedItem.value = data;
  emit('change', data);
}

function onListChange(e: RadioChangeEvent): void {
  const item = prop.items.find(it => it.id === e.target.value) || new SelectItemVO();
  emit('change', item);
}
</script>

<template>
  
  <template v-if="pc">
    <a-radio-group v-if="type === 'list'" :value="selectedItem.id"
                   class="radio-group-list"
                   @change="onListChange">
      <a-radio v-for="(it,i) in items" :key="it.id" :value="it.id"
               :class="{ 'border-b-default': i < items.length - 1 }"
               style="height: 48px; line-height: 48px;"
      >{{ it.text }}</a-radio>
    </a-radio-group>
    <!-- switch 类型 -->
    <div v-else class="flex rounded-4"
         :class="{ 'radio-group-switch-4k': use4KStyle }"
         :style="{
            height: height || (use4KStyle ? '64px' : '32px'),
            lineHeight: height || (use4KStyle ? '64px' : '32px'),
            backgroundColor: bgColor || 'var(--aaruy-bg-color-3)'
          }"
    >
      <div v-for="it in items" :key="it.id"
           class="cursor-pointer rounded-4 text-weak hover-text-white"
           :class="{
             'radio-item-selected': it.id === selectedItem.id,
             'px-32': use4KStyle, 'px-8': !use4KStyle && isCompactMode, 'px-16': !use4KStyle && !isCompactMode,
             'text-s': !use4KStyle, 'text-xxl': use4KStyle
           }"
           @click="onChange(it)">{{ it.text }}</div>
    </div>
  </template>
  <div v-else
       class="inline-block rounded-4 text-weak-8"
       :class="{ 'bg-4': useColorPrimary6, 'bg-12': !useColorPrimary6 }"
       :style="{ height: height, lineHeight: height, margin: margin }">
    <div v-for="it in items" :key="it.id"
         class="h-full inline-flex items-center justify-center rounded-4 border-c-12 font-bold"
         :class="{
           'px-4 text-xs': isCompactMode,
           'px-16 text-s': !isCompactMode,
           'radio-item-selected-mobile': it.id === item.id && !useColorPrimary6,
           'radio-item-selected-mobile-primary-6': it.id === item.id && useColorPrimary6,
         }"
         @click="onChange(it)"
    >{{ it.text }}</div>
  </div>
  
</template>

<style scoped>
.radio-item-selected {
  color: rgb(255,255,255);
  background-color: rgb(103,149,238);
  cursor: default;
}

.radio-item-selected-mobile {
  color: var(--aaruy-primary-color-1);
  border-color: var(--aaruy-primary-color-1);
}

.radio-item-selected-mobile-primary-6 {
  color: var(--aaruy-primary-color-6);
  border-color: var(--aaruy-primary-color-6);
}
</style>
