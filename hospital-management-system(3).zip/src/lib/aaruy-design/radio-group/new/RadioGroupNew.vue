<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import { INVALID_ID } from '@/utils/global.vo.help';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import '@/lib/aaruy-design/radio-group/radio.group.list.style.css';
import '@/lib/aaruy-design/radio-group/new/radio.group.mobile.tab.style.css';
import '@/lib/aaruy-design/radio-group/new/radio.group.new.mobile.style.css';
import '@/lib/aaruy-design/radio-group/new/radio.group.new.vertical.style.css';
import type { RadioGroupItem } from '@/lib/aaruy-design/radio-group/radio.group.type';


/**
 * 单选框 基础UI
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
  item: RadioGroupItem;
  items: Array<RadioGroupItem>;
  isRadioGroupStyle?: boolean;  // 是否使用 a-radio-group 样式;
  isVerticalMode?: boolean; // 是否竖直模式，仅 pc 且 a-radio-group 样式 可用;
  isTabStyle?: boolean;  // 是否使用 tab 样式，仅 mobile 可用;
  margin?: string;  // 仅 isTabStyle 为 true 且 mobile 时可用;
  useHeight32?: boolean;
}

interface Emit {
  (e: 'change', data: RadioGroupItem): void;
}


const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const selectedItem = ref<RadioGroupItem>(new SelectItemVO<unknown>());
const selectedIdOnMobile = ref<number>(INVALID_ID);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.item, (data) => {
  selectedItem.value = data;
  selectedIdOnMobile.value = data.id;
}, { immediate: true });

function onChange(data: RadioGroupItem): void {
  selectedItem.value = data;
  emit('change', data);
}

function onMobileChange(data: number | string): void {
  const id = +data;
  selectedIdOnMobile.value = id;
  const item = prop.items.find(it => it.id === id);
  if (item) {
    emit('change', item);
  }
}

function onTabChange(name: number): void {
  onMobileChange(name);
}

function onRadioGroupChange(e): void {
  const item = prop.items.find(it => it.id === e.target.value);
  if (item) {
    emit('change', item);
  }
}
</script>

<template>
  <template v-if="pc">
    <a-radio-group v-if="isRadioGroupStyle && isVerticalMode"
                   :value="item.id"
                   class="radio-group-new-vertical"
                   @change="onRadioGroupChange">
      <a-radio v-for="it in items" :key="it.id" :value="it.id"
               class="text-white"
      >{{ it.text }}</a-radio>
    </a-radio-group>
    <div v-else class="flex rounded-4 bg-3 text-white text-s h-full">
      <div v-for="it in items" :key="it.id"
           class="inline-flex items-center justify-center flex-1 cursor-pointer"
           :class="{
             'rounded-4 bg-20 text-bg-12 cursor-default': it.id === selectedItem.id,
             'hover-text-primary-1': it.id !== selectedItem.id,
           }"
           @click="onChange(it)">{{ it.text }}</div>
    </div>
  </template>

  <template v-else>
    <template v-if="isTabStyle">
      <van-radio-group v-model="selectedIdOnMobile"
                       direction="horizontal" class="aaruy-radio-group-new-mobile" shape="dot"
                       @change="onMobileChange">
        <van-radio v-for="it in items" :key="it.id" :name="it.id">{{ it.text }}</van-radio>
      </van-radio-group>
    </template>
    <template v-else>
      <van-tabs v-model:active="selectedIdOnMobile" class="radio-group-mobile-tab" :class="{ 'use-height-32': useHeight32 }"
                :style="{ margin: margin }" @change="onTabChange">
        <van-tab v-for="it in items" :key="it.id" :name="it.id">
          <template #title>
            <div>{{ it.text }}</div>
          </template>
        </van-tab>
      </van-tabs>
    </template>
  </template>
  
</template>
