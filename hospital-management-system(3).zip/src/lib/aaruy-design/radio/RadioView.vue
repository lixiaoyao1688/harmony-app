<script setup lang="ts">
import { ref, watch, computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/radio/radio.style.css';


interface Prop {
	name?: string;
	width?: string;
	isVertical?: boolean;
  isForm?: boolean;
	item: SelectorFormItemVO;
	items: Array<SelectorFormItemVO>;
}

interface Emit {
	(e: 'change', item: SelectorFormItemVO): void;
}

const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const checked = ref(prop.item.id);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.item.id, (newId) => {
  checked.value = newId;
});

function onItemChange(it: SelectorFormItemVO) {
  emit('change', it);
}
</script>

<template>
	
	<template v-if="pc">
		<a-radio-group v-model:value="checked" :name="name" class="aaruy-radio-pc" :class="{ 'aaruy-radio-pc-form': isForm }" :style="{ width: width || null }">
			<a-radio v-for="it in items" :key="it.id" :value="it.id" @click="onItemChange(it)">
				{{ it.text }}
				<slot :item="it"></slot>
			</a-radio>
		</a-radio-group>
	</template>
	
	<template v-if="mobile">
		<van-radio-group v-model="checked" class="flex aaruy-radio" :class="{ 'aaruy-radio-vertical': isVertical }">
			<van-radio v-for="it in items" :key="it.id" :name="it.id" @click="onItemChange(it)">{{ it.text }}</van-radio>
		</van-radio-group>
	</template>

</template>

<style scoped></style>