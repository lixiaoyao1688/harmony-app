<script setup lang="ts">
import RadioGroupNew from '@/lib/aaruy-design/radio-group/new/RadioGroupNew.vue';
import '@/lib/aaruy-design/select/frame/select.frame.style.css';
import '@/lib/aaruy-design/select/frame/select.dropdown.frame.style.css';
import type { RadioGroupItem } from '@/lib/aaruy-design/radio-group/radio.group.type';


/**
 * 单选框 组件
 *
 * 样式
 * Frame
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
  title: string;  // 标题
  item: RadioGroupItem;  // 选中项
  items: Array<RadioGroupItem>;  // 供给列表
  width?: string;  // 总体的宽度, 默认 100%;
  titleWidth?: string;  // 标题的宽度，默认 100px;
  isRequired?: boolean;  // 是否必填项
  marginBottom?: string;  // 外下边距
}

interface Emit {
  (e: 'change', item: RadioGroupItem): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onChange(data: RadioGroupItem): void {
  emit('change', data);
}
</script>

<template>
  <div class="flex items-center text-white text-s" style="height: 40px;"
       :style="{ width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div :style="{ width: titleWidth || '100px' }"
         class="text-right pr-8"><i v-if="isRequired" class="text-red-2 mr-8">*</i>{{ title }}</div>
    <div class="flex-1 h-full">
      <RadioGroupNew :item="item" :items="items" @change="onChange" />
    </div>
  </div>
</template>
