<script setup lang="ts">
import {Html5QrcodeSupportedFormats} from 'html5-qrcode';
import {CapacitorBarcodeScanner} from '@capacitor/barcode-scanner';


/**
 * 扫描条形码 组件
 * 仅mobile;
 */
interface Prop {
  margin?: string;
}

interface Emit {
  (e: 'finished', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

async function onScan() {
  try {
    // 对于 ios app:
    // 确保在 ~ios/App/App/Info.plist 中有:
    // <key>NSCameraUsageDescription</key>
    // <string>需要相机权限来扫描二维码</string>
    
    // 开始扫描
    const scanResult = await CapacitorBarcodeScanner.scanBarcode({
      hint: Html5QrcodeSupportedFormats.CODABAR
    });
    
    if (scanResult.ScanResult) {
      emit('finished', scanResult.ScanResult);
    }
  } catch (error) {
    console.error('扫描错误:', error);
  }
  
  // 注意：这里没有直接提供停止扫描的钩子，但可以在适当时候调用 stopScan 方法
  // BarcodeScanner.stopScan();
}
</script>

<template>
  <div class="inline-flex" :style="{ margin: margin }" @click="onScan">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
      <path d="M152.986,181.457a.77.77,0,1,0,1.539,0v-4.8a1.642,1.642,0,0,1,1.641-1.642h4.808a.77.77,0,0,0,0-1.54h-4.8a3.192,3.192,0,0,0-3.187,3.188v4.8Zm18.415,3.236H158.57a.77.77,0,0,0,0,1.54h12.824a.77.77,0,0,0,.007-1.54Zm4.808-2.466a.747.747,0,0,0,.77-.77v-4.8a3.192,3.192,0,0,0-3.187-3.188h-4.8a.77.77,0,0,0,0,1.54h4.8a1.642,1.642,0,0,1,1.641,1.642v4.81A.754.754,0,0,0,176.209,182.226ZM153.755,188.7a.747.747,0,0,0-.77.77v4.8a3.192,3.192,0,0,0,3.187,3.188h4.8a.77.77,0,0,0,0-1.54h-4.8a1.642,1.642,0,0,1-1.641-1.642v-4.8A.756.756,0,0,0,153.755,188.7Zm23.224.77a.77.77,0,1,0-1.539,0v4.8a1.642,1.642,0,0,1-1.641,1.642H169a.77.77,0,0,0,0,1.54h4.8a3.192,3.192,0,0,0,3.187-3.188v-4.8Zm0,0" transform="translate(-152.986 -173.466)" fill="#898a95"/>
    </svg>
  </div>
</template>
