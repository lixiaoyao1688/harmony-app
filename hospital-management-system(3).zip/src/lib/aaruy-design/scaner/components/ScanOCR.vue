<script setup lang="ts">
import {ref} from 'vue';
import Tesseract from 'tesseract.js';
// @ts-ignore
import { Camera, CameraResultType } from '@capacitor/camera';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


/**
 * 扫描-文本识别 组件
 * 仅mobile;
 */
interface Prop {}

interface Emit {
  (e: 'click'): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const result = ref<string | null>('尚未开始');

function onClick(): void {
  getImageAndRecognizeText();
}

const getImageAndRecognizeText = async () => {
  const image = await Camera.getPhoto({
    quality: 90,
    allowEditing: false,
    resultType: CameraResultType.Uri
  });

  Tesseract.recognize(
    image.webPath, // 图像路径
    'eng', // 语言
    {}
  ).then(({ data: { text } }) => {
    console.log('识别出的文字:', text);
    result.value = text;
  }).catch(err => console.error(err));
};
</script>

<template>
  <div class="login-button-mobile">
    <div style="word-break: break-all; margin-bottom: 12px;">
      <div>扫描结果:</div>
      <div style="border: 1px solid gray; padding: 16px;">{{ result }}</div>
    </div>
    <ButtonView type="primary" text="扫描" class="login-button-mobile" @click="onClick" />
  </div>
</template>

<style scoped>
.login-button-mobile {
  width: 81%;
  max-width: 400px;
  min-width: 250px;
  font-size: 16px !important;
}
</style>