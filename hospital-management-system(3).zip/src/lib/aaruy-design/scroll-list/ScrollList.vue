<script setup lang="ts">
import { onMounted, onUnmounted, watch } from 'vue';
import SpinMobile from '@/lib/aaruy-design/spin/SpinMobile.vue';
import EmptyMobile from '@/lib/aaruy-design/empty/EmptyMobile.vue';
import PullRefresh from '@/lib/aaruy-design/pull-refresh/PullRefresh.vue';
import IconLoadMore from '@/lib/aaruy-design/scroll-list/icons/IconLoadMore.vue';


/**
 * 滚动列表 组件
 *
 * 使用范围
 * 仅 mobile;
 */
interface Prop {
  id: string;  // 列表容器的 HTML 元素id
  isLoading: boolean;  // 是否加载中
  isEmpty: boolean;    // 数据是否为空
  isTotalLoaded: boolean;  // 整个长列表是否加载完毕
  isMoreLoading: boolean;  // 是否正在加载更多
  isPullRefreshing: boolean;  // 是否正在下拉加载更多
  height?: string;  // 列表高度，不传则为 100%
  loadingText?: string;  // 加载中提示文案
  pullingText?: string;  // 下拉过程提示文案
  loosingText?: string;  // 释放过程提示文案
}

interface Emit {
  (e: 'pullRefresh'): void;
  (e: 'scroll', top: number): void;
  (e: 'arrivedBottom', top: number): void;
}

type Listener = () => void;

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

let listener: Listener | null = null;
let el: HTMLDivElement | null  = null;
let lastScrollTop: number = 0;  // 上次滚动的距离

watch(() => prop.isMoreLoading, (isMoreLoading) => {
  if (el && !isMoreLoading) {
    // 2025-05-06 当加载更多后，维持上次的滚动条位置不变;
    el.scrollTop = lastScrollTop;
  }
}, {
  immediate: false,
  flush: 'post',  // https://cn.vuejs.org/guide/essentials/watchers#post-watchers
});

onMounted(() => {
  el = document.getElementById(prop.id) as HTMLDivElement;
  if (el) {
    listen(el);
  }
});

onUnmounted(() => {
  if (el) {
    stopListen(el);
  }
});

function onPullRefresh(): void {
  emit('pullRefresh');
}

function onBottomClick(): void {
  el = document.getElementById(prop.id) as HTMLDivElement;
  if (el) {
    emit('arrivedBottom', el.scrollTop);
  }
}

function listen(el: HTMLDivElement): void {
  listener = () => {
    if (Math.abs(el.scrollHeight - el.clientHeight - el.scrollTop) < 1) {
      lastScrollTop = el.scrollTop;
      emit('arrivedBottom', lastScrollTop);
    }
    else {
      emit('scroll', el.scrollTop);
    }
  };
  el.addEventListener('scroll', listener);
}

function stopListen(el: HTMLDivElement): void {
  el.removeEventListener('scroll', listener as Listener);
}
</script>

<template>
  
  <div :id="id" class="overflow-hidden-auto" :style="{ height: height || '100%' }">
    <PullRefresh class="scroll-list" :is-loading="isPullRefreshing" :min-height="height || '100%'"
                 :loosing-text="loosingText" :pulling-text="pullingText" :loading-text="loadingText"
                 @refresh="onPullRefresh">
<!--      <SpinMobile v-if="isLoading" tip="加载中..." :loading="isLoading" height="200px" />-->
      <SpinMobile v-if="isLoading" :loading="isLoading" tip="加载患者..." icon-size="24px" :text-size="20" height="224px" />
      <template v-else>
        <EmptyMobile v-if="isEmpty" tips="暂无患者" height="320px" />
        <template v-else>
          <slot></slot>
          <!--  下拉加载更多  -->
          <div class="flex items-center justify-center text-weak text-s pb-16" style="height: 60px;" @click="onBottomClick">
            <van-loading v-if="isMoreLoading" size="24px" :text-size="16" color="rgb(255,255,255,0.6)">加载中...</van-loading>
            <template v-else>
              <span v-if="isTotalLoaded">-- 已展示全部患者 --</span>
              <template v-else><span class="mr-4">加载更多</span><IconLoadMore /></template>
            </template>
          </div>
        </template>
      </template>
    </PullRefresh>
  </div>

</template>
