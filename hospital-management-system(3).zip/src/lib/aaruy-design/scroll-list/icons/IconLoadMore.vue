<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <g id="组_9268" data-name="组 9268" transform="translate(-380 -865)">
      <rect id="矩形_3425" data-name="矩形 3425" width="20" height="20" transform="translate(380 865)" fill="rgba(255,255,255,0)"/>
      <path id="路径_1858" data-name="路径 1858" d="M929.141,774.141H921V766" transform="translate(-808.646 982.258) rotate(-45)" fill="none" stroke="#848787" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="1.5"/>
    </g>
  </svg>
</template>