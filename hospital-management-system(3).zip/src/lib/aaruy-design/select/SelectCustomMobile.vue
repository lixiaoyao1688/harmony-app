<script setup lang="ts">
import { ref } from 'vue';
import { isBoolean } from 'ant-design-vue/es/_util/hooks/_vueuse/is';
import { EnumMaskType } from '@/lib/aaruy-design/select/select.custom.mobile.config';
import IconDownArrow from '@/lib/icon/IconDownArrow.vue';
import IconUpArrow from '@/lib/icon/IconUpArrow.vue';
import '@/lib/aaruy-design/select/select.mobile.style.css';


interface Prop {
  id: string,
  selectName?: string,
  mask?: Boolean,//是否显示遮罩
  maskClosable?: Boolean,//点击遮罩是否可以关闭
  customContent?: Boolean, //是否自定义点击的内容
  maskType?: EnumMaskType,// 遮罩遮挡区域,默认只遮挡下半部分
}

const prop = defineProps<Prop>();

const visible = ref<Boolean>(false);
let listPlaceTop: number = 0;
// 当前选择框位置
let selectPlace: DOMRect | undefined = undefined;

const getDomPlace = (): void => {
  let dom: HTMLElement | null = document.getElementById(prop.id);
  let param: DOMRect | undefined = dom?.getBoundingClientRect();
  selectPlace = param;
  if (param) {
    listPlaceTop = param?.top + param?.height;
  }
};

const click = (val:boolean): void => {
  if (!visible.value) {
    getDomPlace();
  }

  if (isBoolean(val)){
    visible.value = val;
  }else{
    visible.value = !visible.value;
  }
};

const maskClick = (): void => {
  if (prop.maskClosable) {
    visible.value = false;
  }
};

window.addEventListener('click',it=>{
  if (visible.value && selectPlace){
    if (it.pageY < selectPlace?.top
        || ((it.pageY > selectPlace.top && it.pageY < selectPlace.top + selectPlace.height)
            && (it.pageX < selectPlace.left  || it.pageX > selectPlace.left + selectPlace.width))
    ){
      visible.value = false;
    }
  }
});

defineExpose({click});

</script>

<template>
  <div class="select-mobile">
    <div class="select-mobile-content"
         v-bind="$attrs"
         :id="id"
         @click="click"
         v-if="!customContent">
      <span class="select-mobile-content-title"
            :style="{color: `${visible ? 'var(--fs-pop-color-confirm)'  : `var(--color)`}`}">
        {{ selectName }}
      </span>
      <IconDownArrow class="select-mobile-icon" v-if="!visible"/>
      <IconUpArrow class="select-mobile-icon" v-else-if="visible"/>
    </div>
    <div :id="id" @click="click" v-else>
      <slot name="customContent"></slot>
    </div>
    <div
			v-if="visible"
			class="select-mobile-list"
      :style="{top:`${listPlaceTop}px`,maxHeight:`calc(100vh - ${listPlaceTop }px)`}"
		>
      <slot name="selectContent"></slot>
    </div>
    <div
			v-if="visible && mask"
			class="select-mobile-mask"
      @click.prevent.self
      @click.self="maskClick"
      :style="{ top: maskType === EnumMaskType.all ?  0 : listPlaceTop + 'px' }"
    ></div>
  </div>
</template>