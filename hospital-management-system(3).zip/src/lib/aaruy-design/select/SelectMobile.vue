<script setup lang="ts">
import { computed, ref } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconUpArrow from '@/lib/icon/IconUpArrow.vue';
import IconDownArrow from '@/lib/icon/IconDownArrow.vue';
import '@/lib/aaruy-design/select/select.mobile.style.css';


interface Prop {
  id: string;
  placeholder: string;
	selectedItem: SelectorFormItemVO;
  items: Array<SelectorFormItemVO>;
}

interface Emit {
  (e: 'itemChange', item: SelectorFormItemVO);
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

let listPlaceTop: number = 0;  // 下拉框 top
let selectPlace: DOMRect | undefined = undefined;  // 当前选择框位置

const visible = ref<Boolean>(false);
const selectText = computed<string>(() => prop.selectedItem.isValid ? prop.selectedItem.text : prop.placeholder);


function getDomPlace() {
  const dom: HTMLElement | null = document.getElementById(prop.id);
  const param: DOMRect | undefined = dom?.getBoundingClientRect();
  selectPlace = param;
  if (param) {
    listPlaceTop = param.top + param.height;
  }
}

function click() {
  if (!visible.value) {
    getDomPlace();
  }
  visible.value = !visible.value;
}

function itemClick(item: SelectorFormItemVO) {
  visible.value = false;
  emit('itemChange', item);
}

function maskClick() {
  visible.value = false;
}

window.addEventListener('click', it => {
  if (visible.value && selectPlace) {
    if (
      it.pageY < selectPlace?.top ||
			(
			  (it.pageY > selectPlace.top && it.pageY < selectPlace.top + selectPlace.height)
        &&
				(it.pageX < selectPlace.left || it.pageX > selectPlace.left + selectPlace.width)
			)
    ) {
      visible.value = false;
    }
  }
});
</script>

<template>
  <div class="select-mobile">
    <div class="select-mobile-content" :id="id" @click="click">
      <div class="select-mobile-content-title"
           :style="{color: `${visible ? 'var(--fs-pop-color-confirm)'  : `var(--color)`}`}">
        {{ selectText }}
      </div>
      <IconDownArrow class="select-mobile-icon" v-if="!visible"/>
      <IconUpArrow class="select-mobile-icon" v-else-if="visible"/>
    </div>
    <div class="select-mobile-list" v-if="visible" :style="{top:`${listPlaceTop}px`}">
      <div class="select-mobile-list-item"
           v-for="it in items"
           :key="it.id"
           @click="itemClick(it)"
           :style="{color: `${it.id === selectedItemId ? 'var(--fs-pop-color-confirm)'  : `var(--color)`}`}"
      >
        {{ it.text }}
      </div>
    </div>
    <div class="select-mobile-mask"
			 v-if="visible"
			 :style="{ top: listPlaceTop + 'px' }"
			 @click.prevent.self
			 @click.self="maskClick"></div>
  </div>
</template>
