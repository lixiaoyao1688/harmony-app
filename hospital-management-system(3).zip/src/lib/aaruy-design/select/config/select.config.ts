/**
 * 下拉选择器 默认配置
 */
export const DEFAULT_SELECT_CONFIG = {
  WIDTH: '160px',
  HEIGHT: '32px',
  MARGIN: '0',
};

export const DEFAULT_SELECT_CONFIG_4K = {
  WIDTH: '320px',
  HEIGHT: '64px',
  MARGIN: '0',
};
