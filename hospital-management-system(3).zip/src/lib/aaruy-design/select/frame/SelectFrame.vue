<script setup lang="ts">
import { computed, ref } from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import IconSelectFrameUp from '@/lib/aaruy-design/select/frame/IconSelectFrameUp.vue';
import IconSelectFrameDown from '@/lib/aaruy-design/select/frame/IconSelectFrameDown.vue';
import '@/lib/aaruy-design/select/frame/select.frame.style.css';
import '@/lib/aaruy-design/select/frame/select.dropdown.frame.style.css';
import type {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';


interface Prop {
  title: string;
  item: ItemType;
  items: Array<ItemType>;
  width?: string;  // 总体的宽度, 默认 100%;
  titleWidth?: string;  // 标题的宽度，默认 100px;
  isRequired?: boolean;  // 是否必填项
  placeholder?: string;  // 输入框占位文本
  marginBottom?: string;
  useEmphaticTitleStyle?: boolean;  // 是否使用强调性的标题样式
  isDisabled?: boolean;  // 是否禁用
}

interface Emit {
  (e: 'change', item: ItemType): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const innerPlaceholder = computed(() => prop.placeholder || '请选择');
const innerValue = computed(() => prop.item.isValid ? prop.item.id : null);
const itemMap = computed<Map<number, ItemType>>(() => new Map(prop.items.map(it => ([it.id, it]))));

function onOpenChange(opened: boolean): void {
  isOpened.value = opened;
}

function onChange(id: number): void {
  emit('change', itemMap.value.get(id) || new SelectItemVO());
}
</script>

<template>
  <div class="flex items-center text-white text-s" style="height: 40px;" :style="{ width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div :style="{ width: titleWidth || '100px' }" class="text-right pr-8">
      <i v-if="isRequired" class="text-red-2 mr-8">*</i><span :class="{ 'text-lg font-bold': useEmphaticTitleStyle }">{{ title }}</span>
    </div>
    <!--  :virtual="false" 解决下拉项不能到底的问题 -->
    <a-select
      :open="isOpened"
      :value="innerValue"
      :placeholder="innerPlaceholder"
      :virtual="false"
      :disabled="isDisabled"
      class="select-frame"
      dropdownClassName="select-frame-dropdown"
      @change="onChange"
      @dropdownVisibleChange="onOpenChange"
    >
      <template #suffixIcon>
        <IconSelectFrameUp v-if="isOpened" />
        <IconSelectFrameDown v-else />
      </template>
      <a-select-option v-for="it in items" :value="it.id" :key="it.id">{{ it.text }}</a-select-option>
    </a-select>
  </div>
</template>
