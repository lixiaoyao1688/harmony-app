import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export type ItemType = SelectItemVO<undefined>;
export type ItemType2 = SelectItemVO<unknown>;

