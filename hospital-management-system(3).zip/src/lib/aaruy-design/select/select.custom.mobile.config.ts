export enum EnumMaskType{
    all = 0,
    bottom = 1
}