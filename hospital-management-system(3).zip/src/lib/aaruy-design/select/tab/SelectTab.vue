<script setup lang="ts">
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/select/tab/select.tab.style.css';
import type {ItemType} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 标签选择器 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  item: ItemType;
  items: Array<ItemType>;
  tabMinWidth?: string;  // 选择块的最小宽度，默认 80px;
  fontSize?: string;  // 默认16px
  margin?: string;
}

interface Emit {
	(e: 'change', data: ItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();

function onChange(data: ItemType): void {
  emit('change', data);
}
</script>

<template>
  <div v-if="screenStore.isPC" class="flex flex-wrap justify-between">
    <span v-for="it in items" :key="it.id"
          :style="{ margin: margin }"
          style="width: 56px;"
          :class="{ 'bg-primary-2 cursor-default': it.id === item.id, 'bg-10 cursor-pointer bg-hover-primary-2': it.id !== item.id }"
          class="py-2 text-white text-s text-center rounded-4"
          @click="onChange(it)"
    >{{ it.text }}</span>
  </div>
  <div v-else class="flex flex-wrap justify-between">
    <div v-for="it in items"
         :key="it.id"
         class="rounded-4 px-12 leading-s text-center"
         style="height: 32px; line-height: 30px;"
         :style="{ minWidth: tabMinWidth || '80px', fontSize: fontSize || '16px' }"
         :class="{
           'bg-primary-alpha text-primary border-primary': it.id === item.id,
           'border-c-12 bg-12 text-weak': it.id !== item.id
         }"
         @click="onChange(it)"
    >{{ it.text }}</div>
  </div>
</template>
