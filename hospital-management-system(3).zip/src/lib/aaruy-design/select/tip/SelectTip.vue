<script setup lang="ts">
import {ref, watch} from 'vue';
import {INVALID_ID} from '@/utils/global.vo.help';
import {DEFAULT_SELECT_CONFIG, DEFAULT_SELECT_CONFIG_4K} from '@/lib/aaruy-design/select/config/select.config';
import IconLoading from '@/lib/icon/IconLoading.vue';
import DropdownTip from '@/lib/aaruy-design/dropdown/tip/DropdownTip.vue';
import IconSelectSort from '@/lib/aaruy-design/selector/icons/IconSelectSort.vue';
import IconSelectUp from '@/lib/aaruy-design/selector/icons/IconSelectUp.vue';
import IconSelectDown from '@/lib/aaruy-design/selector/icons/IconSelectDown.vue';
import IconSelectTipArrowDown from '@/lib/aaruy-design/select/tip/icon/IconSelectTipArrowDown.vue';
import IconSelectTipArrowUp from '@/lib/aaruy-design/select/tip/icon/IconSelectTipArrowUp.vue';
import type { ItemType } from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 下拉选择器 组件
 *
 * 风格
 * 提示框
 *
 * 默认配置
 * ~\src\lib\aaruy-design\select\config\select.config.ts: DEFAULT_SELECT_CONFIG;
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
  item: ItemType;  // 已选中的项目
  items: Array<ItemType>;  // 项目列表
  width?: string;  // 宽度
  height?: string;  // 高度
  margin?: string;  // 外边距
  isSortStyle?: boolean;  // 是否使用"排序"样式
  isFillStyle?: boolean;  // 是否使用"填充"样式
  itemMaxWidth?: string;  // 已选中文本的最大宽度，默认 80px，仅 isFillStyle;
  isLoading?: boolean;  // 是否加载中，仅 isSortStyle 为 true 时可用;
  placeholder?: string;  // 未选中任意项时的占位文本
  useDropdownBg10?: boolean;  // 下拉框的颜色是否使用 bg-10，默认 bg-1;
  disabled?: boolean;  // 仅 isFillStyle;
  use4KStyle?: boolean;  // 是否适配4K屏，仅isSortStyle或默认style
}

interface Emit {
	(e: 'change', data: ItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);


watch(() => prop.disabled, (data) => {
  if (data) {
    onOpenChange(false);
  }
}, { immediate: true });

function onOpenChange(data: boolean): void {
  isOpened.value = data;
}

function onChange(data: ItemType): void {
  emit('change', data);
  onOpenChange(false);
}
</script>

<template>
  <DropdownTip :visible="isOpened" :use-bg10="useDropdownBg10" :disabled="disabled" @openChange="onOpenChange">
    <template #content>
      <div v-if="isSortStyle"
           :style="{
              width: width || (use4KStyle ? DEFAULT_SELECT_CONFIG_4K.WIDTH : DEFAULT_SELECT_CONFIG.WIDTH),
              height: height || (use4KStyle ? DEFAULT_SELECT_CONFIG_4K.HEIGHT : DEFAULT_SELECT_CONFIG.HEIGHT),
              margin: margin || DEFAULT_SELECT_CONFIG.MARGIN,
           }"
           class="bg-10 hover-primary flex justify-between items-center px-16 rounded-4 cursor-pointer"
      >
        <span :class="{ 'text-xxl': use4KStyle, 'text-s': !use4KStyle }" class="text-white">{{ item.text }}</span>
        <IconLoading v-if="isLoading" :use4-k-style="use4KStyle" color="rgb(103, 149, 238)" />
        <IconSelectSort v-else :scale="use4KStyle ? 1.8 : 1" />
      </div>
      <div v-else-if="isFillStyle"
           :style="{
              width: width || DEFAULT_SELECT_CONFIG.WIDTH,
              height: height || DEFAULT_SELECT_CONFIG.HEIGHT,
              margin: margin || DEFAULT_SELECT_CONFIG.MARGIN,
           }"
           class=" flex justify-between items-center px-8 rounded-4 "
           :class="{ 'bg-10 cursor-not-allowed': disabled, 'bg-10 hover-primary cursor-pointer': !disabled }"
      >
        <span v-if="item.id === INVALID_ID" class="text-s text-weak-2 no-select">{{ placeholder || '请选择' }}</span>
        <span v-else
              :class="{ 'text-weak-2': disabled, 'text-white': !disabled }"
              class="text-s ellipsis no-select"
              :style="{ maxWidth: itemMaxWidth || '80px' }">{{ item.text }}</span>
        <IconSelectTipArrowUp v-if="isOpened" />
        <IconSelectTipArrowDown v-else />
      </div>
      <div v-else
           :style="{
              width: width || (use4KStyle ? DEFAULT_SELECT_CONFIG_4K.WIDTH : DEFAULT_SELECT_CONFIG.WIDTH),
              height: height || (use4KStyle ? DEFAULT_SELECT_CONFIG_4K.HEIGHT : DEFAULT_SELECT_CONFIG.HEIGHT),
              margin: margin || DEFAULT_SELECT_CONFIG.MARGIN,
           }"
           class="bg-11 border-bg-9 hover-border-primary-2 rounded-4 flex justify-between items-center px-10 cursor-pointer"
           :class="{ 'border-primary-2': isOpened }"
      >
        <span :class="{ 'text-xxl': use4KStyle, 'text-s': !use4KStyle }" class="text-white">{{ item.text }}</span>
        <IconSelectUp v-if="isOpened" :scale="use4KStyle ? 1.8 : 1" />
        <IconSelectDown v-else :scale="use4KStyle ? 1.8 : 1" />
      </div>
    </template>
    <template #menu>
      <div :style="{
              width: width || (use4KStyle ? DEFAULT_SELECT_CONFIG_4K.WIDTH : DEFAULT_SELECT_CONFIG.WIDTH),
              backgroundColor: useDropdownBg10 ? 'var(--aaruy-bg-color-10)' : 'var(--aaruy-bg-color-1)'
           }"
           class="py-16 px-8 rounded-4"
      >
        <div v-if="items.length === 0" class="text-s text-weak-2 text-center">暂无数据</div>
        <ul v-else
            style="padding: 0 4px !important; max-height: 280px;"
            class="overflow-hidden-auto">
          <li v-for="(it,i) in items" :key="it.id"
              style="height: 34px; line-height: 34px;"
              class="text-s text-white px-8 rounded-4 cursor-pointer hover-bg-9"
              :class="{ 'bg-9' : it.id === item.id, 'mt-8': i > 0 }"
              @click="onChange(it)"
          >{{ it.text }}</li>
        </ul>
      </div>
    </template>
  </DropdownTip>
</template>
