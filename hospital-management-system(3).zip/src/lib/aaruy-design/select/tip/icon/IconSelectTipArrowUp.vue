<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <g transform="translate(20 20) rotate(180)">
      <rect width="20" height="20" fill="none"/>
      <path d="M5.931,226.017a.86.86,0,0,1-.611-.25L.157,220.6a.864.864,0,0,1,1.222-1.222l4.552,4.561,4.552-4.552A.861.861,0,0,1,11.7,220.6l-5.163,5.163A.861.861,0,0,1,5.931,226.017Z" transform="translate(4.096 -212.129)" fill="#dce9f5"/>
    </g>
  </svg>
</template>