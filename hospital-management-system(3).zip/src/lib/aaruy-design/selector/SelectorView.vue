<script setup lang="ts">
import '@/lib/aaruy-design/selector/selector.style.css';


interface IProp {
  options: unknown[]
  value: unknown
  valueField?: string
  textField?: string
  style?: string
}

interface IEmit {
  (e: 'change', value: unknown): void
}


const prop = defineProps<IProp>();
const emit = defineEmits<IEmit>();

const vf = prop.valueField || 'id';
const tf = prop.textField || 'text';


function onChange(v) {
  emit('change', v);
}
</script>

<template>
  <div class="my-selector">
    <a-select :value="value" @change="onChange" :style="style" dropdownClassName="my-selector-dropdown">
      <a-select-option v-for="o in options" :value="o[vf]" :key="o[vf]">{{ o[tf] }}</a-select-option>
    </a-select>
  </div>
</template>
