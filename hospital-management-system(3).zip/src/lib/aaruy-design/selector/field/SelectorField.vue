<script setup lang="ts">
import { ref } from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import SelectorNormalIconUp from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconUp.vue';
import SelectorNormalIconDown from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconDown.vue';
import '@/lib/aaruy-design/selector/field/selector.field.style.css';



type SelectItemType = SelectItemVO<unknown>;

interface Prop {
  title: string;
  height: string;
  item: SelectItemType;
  items: Array<SelectItemType>;
  map: Map<number, SelectItemType>;
  width?: string;  // 下拉框的宽度，默认 70px;
  isDark?: boolean;
  useFont16?: boolean;
}

interface Emit {
  (e: 'change', item: SelectItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const open = ref<boolean>(false);


function openChange(v: boolean): void {
  open.value = v;
}

function change(id: number): void {
  emit('change', prop.map.get(id) as SelectItemType);
}
</script>


<template>
  <div :style="{ height: height }" class="flex items-center justify-between border-b-default border-hover-primary-4 pl-16 pr-16">
    <span class="text-s">{{ title }}</span>
    <a-select
      :open="open"
      :value="item.id"
      :style="{ width: width || '70px' }"
      :dropdownClassName="'selector-field-dropdown' + (useFont16 ? ' selector-field-dropdown-font-16' : '')"
      :class="{ 'selector-field-dark': isDark, 'selector-field-font-16': useFont16 }"
      :virtual="false"
      class="selector-field"
      @change="change"
      @dropdownVisibleChange="openChange"
    >
      <a-select-option v-for="it in items" :key="it.id" :value="it.id">{{ it.text }}</a-select-option>
      <template #suffixIcon>
        <SelectorNormalIconUp v-show="open" />
        <SelectorNormalIconDown v-show="!open" />
      </template>
    </a-select>
  </div>
</template>
