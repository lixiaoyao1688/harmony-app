<script setup lang="ts">
import {ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import SelectorNormalIconUp from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconUp.vue';
import SelectorNormalIconDown from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconDown.vue';
import '@/lib/aaruy-design/selector/field/selector.field2.style.css';


type SelectItemType = SelectItemVO<unknown>;

interface Prop {
  title: string;
  item: SelectItemType;
  items: Array<SelectItemType>;
  map: Map<number, SelectItemType>;
  width?: string;  // 下拉框的宽度，默认 70px;
  isDark?: boolean;
  useFont16?: boolean;
  margin?: string;
}

interface Emit {
  (e: 'change', item: SelectItemType): void;
}

defineExpose({
  hasError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const open = ref<boolean>(false);
const errorTips = ref<string>('');  // 报错文本
const value = ref<SelectItemType>(new SelectItemVO<unknown>());


watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function hasError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value as SelectItemType);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getErrorTips(data: SelectItemType): string {
  if (!data.isValid) {
    return '请选择一项';
  }
  return '';
}

function openChange(v: boolean): void {
  open.value = v;
}

function change(id: number): void {
  const data = prop.map.get(id) as SelectItemType;
  value.value = data;
  hasError();
  emit('change', data);
}
</script>


<template>
  <div :style="{ margin: margin }"
       :class="{ 'border-error': errorTips }"
       class="flex items-end justify-between border-b-default border-hover-primary-4 pl-16 pb-4 pr-16">
    <span class="text-s" style="line-height: 22px;">{{ title }}</span>
    <a-select
      :open="open"
      :value="item.isValid ? item.id : undefined"
      :style="{ width: width || '70px' }"
      :dropdownClassName="'selector-field-dropdown' + (useFont16 ? ' selector-field-dropdown-font-16' : '')"
      :class="{ 'selector-field-dark': isDark, 'selector-field-font-16': useFont16 }"
      :virtual="false"
      placeholder="请选择"
      class="selector-field"
      @change="change"
      @dropdownVisibleChange="openChange"
    >
      <a-select-option v-for="it in items" :key="it.id" :value="it.id">{{ it.text }}</a-select-option>
      <template #suffixIcon>
        <SelectorNormalIconUp v-show="open" />
        <SelectorNormalIconDown v-show="!open" />
      </template>
    </a-select>
  </div>
  <ErrorView :tips="errorTips" bg-color="var(--aaruy-bg-color-12)" padding="0 24px 0 0" />
</template>
