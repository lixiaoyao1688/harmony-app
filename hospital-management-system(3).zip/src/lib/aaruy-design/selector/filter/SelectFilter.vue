<script setup lang="ts">
import { computed, ref } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconSelectUp from '@/lib/aaruy-design/selector/icons/IconSelectUp.vue';
import IconSelectDown from '@/lib/aaruy-design/selector/icons/IconSelectDown.vue';
import IconSelectSort from '@/lib/aaruy-design/selector/icons/IconSelectSort.vue';
import '@/lib/aaruy-design/selector/filter/select.filter.style.css';
import '@/lib/aaruy-design/selector/filter/select.filter.sort.style.css';
import '@/lib/aaruy-design/selector/filter/select.filter.dropdown.style.css';
import '@/lib/aaruy-design/selector/filter/select.filter.disabled.style.css';


interface Prop {
	title: string;
	items: SelectorFormItemVO[];
	itemMap: Map<number, SelectorFormItemVO>;
	selectedItem: SelectorFormItemVO;
	placeholder?: string;
  selectorWidth?: string;
	isDefault?: boolean;
  height?: string;
  disabled?: boolean;
  isSort?: boolean;  // 是否启用排序样式
  useBgTransparent?: boolean;
  useBg10?: boolean;
  useDisabledStyle?: boolean;  // 仅  disabled 为 true 时可用
  useTempDropdownDisabledStyle?: boolean;  // 是否置灰第2项及以后的项(临时)
}

interface Emit {
  (e: 'itemChange', item: SelectorFormItemVO): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const innerPlaceholder = computed(() => prop.placeholder || '请选择');
const innerSelectorWidth = computed(() => prop.selectorWidth || '200px');
const innerValue = computed(() => prop.selectedItem.isValid ? prop.selectedItem.id : null);


function onOpenChange(opened: boolean) {
  isOpened.value = opened;
}

function onChange(id: number) {
  emit('itemChange', prop.itemMap.get(id) || SelectorFormItemVO.empty());
}
</script>

<template>
  
  <div class="select-filter flex"
       :style="{ height: height || '32px' }"
       :class="{
          'select-filter-default': isDefault,
          'select-filter-sort': isSort,
          'select-filter-bg-transparent': useBgTransparent,
          'select-filter-bg-10': useBg10,
          'select-filter-new-disabled': useDisabledStyle
       }">
    <label v-if="title"
           class="inline-block text-right text-s"
           style="height: 32px; line-height: 32px;"
           :class="{ 'text-weak-2': disabled }"
           :style="{ paddingRight: title ? '12px' : '0' }">{{ title }}</label>
    <a-select
      :open="isOpened"
      :value="innerValue"
      :style="{ width: innerSelectorWidth, height: height || '32px' }"
      :placeholder="innerPlaceholder"
      :disabled="disabled"
      @change="onChange"
      @dropdownVisibleChange="onOpenChange"
      :dropdownClassName="useTempDropdownDisabledStyle ? 'select-filter-dropdown select-filter-dropdown-temp-disable' : 'select-filter-dropdown'"
    >
      <template #suffixIcon>
        
        <template v-if="isSort">
          <IconSelectSort />
        </template>
        <template v-else>
          <IconSelectUp v-if="isOpened" />
          <IconSelectDown v-else />
        </template>
      </template>
      <a-select-option v-for="it in items" :value="it.id" :key="it.id">{{ it.text }}</a-select-option>
    </a-select>
  </div>
  
</template>
