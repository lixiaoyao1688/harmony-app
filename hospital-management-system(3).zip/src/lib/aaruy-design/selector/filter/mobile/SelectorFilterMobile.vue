<script setup lang="ts">
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/selector/filter/mobile/selector.filter.mobile.style.css';


interface Prop {
	items: SelectorFormItemVO[];
	itemMap: Map<number, SelectorFormItemVO>;
	selectedItem: SelectorFormItemVO;
	itemWidth?: string;
	itemMarginRight?: string;
}

interface Emit {
	(e: 'itemChange', item: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function onSelect(item: SelectorFormItemVO): void {
  emit('itemChange', item);
}
</script>

<template>
  <div class="multiple-choice-mobile">
    <div
			v-for="(it,i) in items"
			:key="it.id"
			class="item ellipsis"
			:class="{ actived: it.id === selectedItem.id }"
			:style="{ width: itemWidth, marginRight: (i === items.length-1) ? 0 : itemMarginRight }"
		  @click="onSelect(it)"
		>
      {{ it.text }}
    </div>
  </div>
</template>

<style scoped>
.actived {
	background-color: var(--bg-list-item-select);
}
</style>
