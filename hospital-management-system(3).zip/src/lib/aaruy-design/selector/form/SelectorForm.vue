<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import PickerMobile from '@/lib/aaruy-design/picker/PickerMobile.vue';
import IconArrowRight from '@/modules/admission/icons/IconArrowRight.vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import { TWENTY, TWENTY_FOUR } from '@/lib/math/config/math.config';
import '@/lib/aaruy-design/selector/form/selector.form.style.css';


interface Prop {
  title: string;
  items: Array<SelectorFormItemVO>;
  data: SelectorFormItemVO;
  skin?: 'underline' | 'plain'; // 皮肤, 默认 underline;
  required?: boolean;
  placeholder?: string;
  mobile?: boolean;  // 是否移动端
  mobileLarge?: boolean;  // 是否移动端的大尺寸（已废弃）
}

interface Emit {
  (e: 'change', id: number): void;
  (e: 'change-item', data: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<SelectorFormItemVO>(prop.data);
const opened = ref<boolean>(false);
const haveValue = computed<boolean>(() => (value.value.text !== ''));
const text = computed<string>(() => value.value.text || prop.placeholder || '未指定');
const iconSize = computed<number>(() => prop.mobile ? TWENTY : TWENTY_FOUR);


watch(() => prop.data, (newValue) => {
  value.value = newValue;
}, { immediate: true });

function select(item: SelectorFormItemVO) {
  value.value = item;
  opened.value = false;
  emit('change', item.id);
  emit('change-item', item);
}

function openMobile() {
  opened.value = true;
}

function closeMobile() {
  opened.value = false;
}
</script>

<template>
  
  <div v-if="mobile" class="selector-form selector-form-mobile" :class="{'selector-form-actived': opened, 'selector-form-mobile-large': mobileLarge }">
    <div class="selector-form-title">{{ title }} <i v-if="required">*</i></div>
    <div class="selector-form-placeholder" @click="openMobile">
      <span class="text-s" :class="{ 'valued': haveValue }">{{ text }}</span>
      <IconArrowRight :size="iconSize" />
    </div>
    <PickerMobile :title="title" :show-picker="opened" :item="data" :items="items" @close="closeMobile" @ok="select" />
  </div>
  <!-- pc -->
  <template v-else>
    <div v-if="skin === 'plain'"
         class="selector-form"
         style="border-bottom: none; width: 100%;"
         :class="{ 'selector-form-actived': opened }"
    >
      <div class="selector-form-title">{{ title }} <i v-if="required">*</i></div>
      <a-tooltip
        v-model:visible="opened"
        trigger="click"
        placement="rightTop"
        overlayClassName="selector-form-tooltip"
      >
        <template #title>
          <div v-if="items.length === 0" class="selector-form-empty">暂无数据</div>
          <ul v-else>
            <li v-for="it in items" :key="it.id" :class="{ selected: it.id === data.id }" @click="select(it)">
              {{ it.text }}
            </li>
          </ul>
        </template>
        <div class="selector-form-placeholder">
          <span :class="{ 'valued': haveValue }">{{ text }}</span>
          <IconArrowRight :size="iconSize" />
        </div>
      </a-tooltip>
    </div>
    <!--  skin === underline  -->
    <div v-else class="selector-form" :class="{ 'selector-form-actived': opened }">
      <div class="selector-form-title">{{ title }} <i v-if="required">*</i></div>
      <a-tooltip
        v-model:visible="opened"
        trigger="click"
        placement="rightTop"
        overlayClassName="selector-form-tooltip"
      >
        <template #title>
          <div v-if="items.length === 0" class="selector-form-empty">暂无数据</div>
          <ul v-else>
            <li v-for="it in items" :key="it.id" :class="{ selected: it.id === data.id }" @click="select(it)">
              {{ it.text }}
            </li>
          </ul>
        </template>
        <div class="selector-form-placeholder">
          <span :class="{ 'valued': haveValue }">{{ text }}</span>
          <IconArrowRight :size="iconSize" />
        </div>
      </a-tooltip>
    </div>
  </template>
  
</template>

<style scoped>
.selector-form {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: var(--ad-form-item-height);
  border-bottom: 2px solid rgba(204, 214, 225, 0.2);
}

.selector-form-actived,
.selector-form:hover {
  border-bottom-color: rgb(38, 111, 232);
}

.selector-form .selector-form-title {
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.selector-form .selector-form-title > i {
  color: rgb(255, 36, 42);
}

.selector-form-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.selector-form-placeholder > span {
  color: rgb(163, 175, 188);
  font-size: 16px;
}

.selector-form-placeholder > span.valued {
  color: rgb(255, 255, 255);
}

ul {
  --radius: 2px;
  border-radius: var(--radius);
  background-color: rgb(91, 103, 116);
  padding: 4px 6px;
}

ul li {
  cursor: pointer;
  font-size: 16px;
  min-width: 100px;
  text-align: center;
  padding: 12px 20px;
}

ul li.selected,
ul li:hover {
  color: var(--aaruy-primary-color-1);
}

ul li:first-child {
  border-radius: var(--radius) var(--radius) 0 0;
}

ul li:last-child {
  border-radius: 0 0 var(--radius) var(--radius);
}

.selector-form-empty {
	display: inline-flex;
	width: 100%;
	height: 100%;
	min-height: 60px;
	min-width: 120px;
	align-items: center;
	justify-content: center;
	font-size: 16px;
	color: rgb(204, 204, 204);
	cursor: default;
}

/* mobile */
.selector-form-mobile {
  padding-top: 20px;
  padding-bottom: 8px;
	border-bottom-width: 1px !important;
	border-bottom-color: rgb(91, 103, 116) !important;
}

.selector-form-mobile .selector-form-title {
  font-size: 16px;
}

.selector-form-mobile-large {
  padding-top: 26px;
  padding-bottom: 11px;
}

.selector-form-mobile-large .selector-form-title {
  font-size: 16px;
}
</style>
