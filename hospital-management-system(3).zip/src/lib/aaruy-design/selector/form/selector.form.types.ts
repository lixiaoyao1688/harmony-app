import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


export type SelectorMap = Map<number, SelectorFormItemVO>;
