import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorMap } from '@/lib/aaruy-design/selector/form/selector.form.types';


// todo: payload 用 T 表示
export class SelectorFormItemVO {
	public static INVALID_ID = -1;
	
	public id: number;
	public text: string;
	public payload?: any;
	
	constructor(id: number, text: string, p?: any) {
	  this.id = id;
	  this.text = text;

	  if (p !== undefined) {
	    this.payload = p;
	  }
	}
	
	public get isValid() {
	  return this.id !== INVALID_ID;
	}
	
	public static empty() {
	  return new SelectorFormItemVO(INVALID_ID, '');
	}
	
	public static getItem(map: Map<number, SelectorFormItemVO>, id: number) {
	  const item = map.get(id);
	  return item ? item : SelectorFormItemVO.empty();
	}
	
	public static getMap(list: Array<SelectorFormItemVO>): SelectorMap {
	  return new Map<number, SelectorFormItemVO>(list.map(item => ([item.id, item])));
	}
	
	public static getText(map: Map<number, SelectorFormItemVO>, id: number): string {
	  const item = map.get(id);
	  return item ? item.text : '';
	}

}
