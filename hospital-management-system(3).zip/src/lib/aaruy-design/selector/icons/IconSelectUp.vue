<script setup lang="ts">
interface Prop {
  scale?: number;
}

defineProps<Prop>();
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg"
       :width="16 * (scale || 1)"
       :height="16 * (scale || 1)"
       viewBox="0 0 16 16">
    <g id="iconSelectFilterUp" transform="translate(16 16) rotate(180)">
      <rect id="iconSelectFilterUpRect" data-name="矩形 2682" width="16" height="16" fill="rgba(255,255,255,0)"/>
      <path id="iconSelectFilterUpPath" data-name="多边形 4" d="M5.646.354a.5.5,0,0,1,.707,0l4.793,4.793A.5.5,0,0,1,10.793,6H1.207a.5.5,0,0,1-.354-.854Z" transform="translate(14 12) rotate(180)" fill="#999"/>
    </g>
  </svg>
</template>