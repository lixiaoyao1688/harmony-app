<script setup lang="ts">
import { ref } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import SelectorNormalIconUp from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconUp.vue';
import SelectorNormalIconDown from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconDown.vue';
import '@/lib/aaruy-design/selector/normal/selector.normal.style.css';


interface Prop {
  item: SelectorFormItemVO;
  items: Array<SelectorFormItemVO>;
  map: Map<number, SelectorFormItemVO>;
	isDark?: boolean;
  useFont16?: boolean;
}

interface Emit {
  (e: 'change', item: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const open = ref<boolean>(false);


function openChange(v: boolean): void {
  open.value = v;
}

function change(id: number): void {
  emit('change', prop.map.get(id) as SelectorFormItemVO);
}
</script>


<template>
  <a-select
    :open="open"
    :value="item.id"
    class="selector-normal"
    :dropdownClassName="'selector-normal-dropdown' + (useFont16 ? ' selector-normal-dropdown-font-16' : '')"
		:class="{ 'selector-normal-dark': isDark, 'selector-normal-font-16': useFont16 }"
    @change="change"
    @dropdownVisibleChange="openChange"
  >
    <a-select-option v-for="it in items" :key="it.id" :value="it.id">{{ it.text }}</a-select-option>
    <template #suffixIcon>
      <SelectorNormalIconUp v-show="open" />
      <SelectorNormalIconDown v-show="!open" />
    </template>
  </a-select>
</template>
