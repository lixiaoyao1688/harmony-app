<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <g transform="translate(-1010 929) rotate(-90)">
      <rect width="16" height="16" transform="translate(929 1010) rotate(90)" fill="rgba(255,255,255,0)"/>
      <path d="M6.027,6.888a.86.86,0,0,1-.611-.25L.253,1.475A.864.864,0,0,1,1.475.253L6.027,4.814,10.58.262a.861.861,0,0,1,1.213,1.213L6.63,6.638A.86.86,0,0,1,6.027,6.888Z" transform="translate(924.444 1012) rotate(90)" fill="#fff"/>
    </g>
  </svg>
</template>