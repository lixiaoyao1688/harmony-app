<script setup lang="ts">
import {ref} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import PageMobile from '@/lib/aaruy-design/page/PageMobile.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import FieldView2 from '@/lib/aaruy-design/field/FieldView2.vue';
import '@/lib/aaruy-design/selector/page/style/selector.page.style.css';
import type {SelectorPageExpose, SelectorPageItemPayload} from '@/lib/aaruy-design/selector/page/type/selector.page.type';


/**
 * 页面选择器 组件
 *
 * 适用场景
 * 需要新开一个页面，在页面中既有单项选择，又有选择后自定义输入的场景。
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  id: number;
  title: string;
  items: Array<SelectItemVO<SelectorPageItemPayload>>;
  customId: number;  // 自定义项的id
  customTips?: string;  // 自定义项的提示词
}

interface Emit {
	(e: 'confirm'): void;
  (e: 'id-change', data: number): void;
}

defineExpose<SelectorPageExpose>({
  onClose
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onIdChange(data: number): void {
  emit('id-change', data);
}

function onConfirm(): void {
  emit('confirm');
}
</script>

<template>
  <PageMobile :visible="isOpened" @goBack="onClose">
    <template #title>{{ title }}</template>
    <template #content>
      <van-radio-group :modelValue="id" shape="dot" class="selector-page-radio">
        <FieldView2 v-for="it in items" :key="it.id" type="other-complex" padding="0">
          <div v-if="it.id !== customId" class="flex items-center justify-between p-12" @click="onIdChange(it.id)">
            <div v-if="it.payload && it.payload.icon" class="inline-flex items-center">
              <span v-html="it.payload.icon" class="inline-flex items-center" style="width: 36px;"></span>
              <span class="text-white text-s">{{ it.text }}</span>
            </div>
            <span v-else>{{ it.text }}</span>
            <van-radio :name="it.id"></van-radio>
          </div>
          <template v-else>
            <div class="flex items-center justify-between p-12" @click="onIdChange(it.id)">
              <span>{{ it.text }}{{ customTips }}</span>
              <van-radio :name="it.id"></van-radio>
            </div>
            <slot name="custom"></slot>
          </template>
        </FieldView2>
      </van-radio-group>
      <div class="flex items-center justify-between px-16">
        <ButtonView type="default" text="取消" style="width: 49%; height: 36px; line-height: 36px;"
                    @click="onClose" />
        <ButtonView type="primary" text="确定" style="width: 49%; height: 36px; line-height: 36px;"
                    @click="onConfirm" />
      </div>
    </template>
  </PageMobile>
  <div @click="onOpen"><slot name="head"></slot></div>
</template>
