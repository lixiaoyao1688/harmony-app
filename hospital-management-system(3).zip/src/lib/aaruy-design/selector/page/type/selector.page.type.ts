export interface SelectorPageItemPayload {
  icon: string;
}

export type SelectorPageExpose = {
  onClose: () => void;
}
