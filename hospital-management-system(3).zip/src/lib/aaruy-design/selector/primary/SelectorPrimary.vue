<script setup lang="ts">
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/selector/primary/selector.primary.style.css';


interface Prop {
  isOpen: boolean;
  items: Array<SelectorFormItemVO>;
  item: SelectorFormItemVO;
  itemMap: Map<number, SelectorFormItemVO>;
}

interface Emit {
	(e: 'change', it: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(id: number): void {
  emit('change', SelectorFormItemVO.getItem(prop.itemMap, id));
}
</script>

<template>
  <a-select :value="item.id" :open="isOpen" dropdown-class-name="selector-primary-dropdown" @change="onChange">
    <a-select-option v-for="it in items" :key="it.id" :value="it.id">{{ it.text }}</a-select-option>
  </a-select>
</template>
