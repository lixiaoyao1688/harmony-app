<script setup lang="ts">
import { computed, ref } from 'vue';
import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconSelectorReportUp from '@/lib/aaruy-design/selector/report/icons/IconSelectorReportUp.vue';
import IconSelectorReportDown from '@/lib/aaruy-design/selector/report/icons/IconSelectorReportDown.vue';
import '@/lib/aaruy-design/selector/report/selector.report.style.css';


interface Prop {
	items: Array<SelectorFormItemVO>;
	item: SelectorFormItemVO;
	map: Map<number, SelectorFormItemVO>;
}

interface Emit {
	(e: 'change', item: SelectorFormItemVO): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const id = computed<number | undefined>(() => prop.item.id === INVALID_ID ? undefined : prop.item.id);


function onOpenChange(opened: boolean): void {
  isOpened.value = opened;
}

function onChange(v: number): void {
  const item = prop.map.get(v);
  emit('change', item || SelectorFormItemVO.empty());
}
</script>

<template>
	<a-select
		:open="isOpened"
		:value="id"
		class="selector-report"
		@change="onChange"
		@dropdownVisibleChange="onOpenChange"
		dropdownClassName="selector-report-dropdown"
	>
		<template #suffixIcon>
			<IconSelectorReportUp v-if="isOpened" />
			<IconSelectorReportDown v-else />
		</template>
		<a-select-option v-for="o in items" :value="o.id" :key="o.id">{{ o.text }}</a-select-option>
	</a-select>
</template>
