<script setup lang="ts">
import { ref } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconSelectorDetailUp from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailUp.vue';
import IconSelectorDetailDown from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailDown.vue';
import '@/lib/aaruy-design/selector/table/styles/selector.table2.style.css';


interface Prop {
  items: Array<SelectorFormItemVO>;
  item: SelectorFormItemVO;
  map: Map<number, SelectorFormItemVO>;
  width: string;
  listHeight?: number;  // 下拉列表最大高度
  borderBottom?: string;
}

interface Emit {
  (e: 'change', item: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);


function onOpenChange(opened: boolean): void {
  isOpened.value = opened;
}

function onChange(v: number): void {
  const item = prop.map.get(v);
  emit('change', item || SelectorFormItemVO.empty());
}
</script>

<template>
  <div class="selector-table2" :style="{ width: width, borderBottom: borderBottom }">
    <a-select
      :open="isOpened"
      :value="item.id"
      :list-height="listHeight || 256"
      @change="onChange"
      @dropdownVisibleChange="onOpenChange"
      dropdownClassName="selector-table2-dropdown"
    >
      <template #suffixIcon>
        <IconSelectorDetailUp v-if="isOpened" />
        <IconSelectorDetailDown v-else />
      </template>
      <a-select-option v-for="o in items" :value="o.id" :key="o.id">{{ o.text }}</a-select-option>
    </a-select>
  </div>
</template>
