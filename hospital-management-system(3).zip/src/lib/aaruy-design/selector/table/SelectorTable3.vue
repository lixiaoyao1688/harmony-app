<script setup lang="ts">
import {ref, watch} from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import IconSelectorDetailUp from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailUp.vue';
import IconSelectorDetailDown from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailDown.vue';
import '@/lib/aaruy-design/selector/table/styles/selector.table2.style.css';


interface Prop {
  items: Array<SelectorFormItemVO>;
  item: SelectorFormItemVO;
  map: Map<number, SelectorFormItemVO>;
  width: string;
  listHeight?: number;  // 下拉列表最大高度
  borderBottom?: string;
  placeholder?: string;
  tips?: string;  // 报错文本
  useBg1?: boolean;  // 是否使用 bg-1
  useLineHeight32px?: boolean;  // 是否使用 line-height: 32px;
}

interface Emit {
  (e: 'change', item: SelectorFormItemVO): void;
}

defineExpose({
  checkValueError
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const errorTips = ref<string>('');  // 报错文本
const value = ref<SelectorFormItemVO>(SelectorFormItemVO.empty());


watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function checkValueError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getErrorTips(data: SelectorFormItemVO): string {
  if (!data.isValid) {
    return prop.tips || '请选择一项';
  }
  return '';
}

function onOpenChange(opened: boolean): void {
  isOpened.value = opened;
}

function onChange(v: number): void {
  // const item = prop.map.get(v);
  // emit('change', item || SelectorFormItemVO.empty());
  const data = prop.map.get(v) as SelectorFormItemVO;
  value.value = data;
  checkValueError();
  emit('change', data);
}
</script>

<template>
  <div class="selector-table2 relative"
       :class="{
         'border-error': errorTips,
         'use-bg-1': useBg1,
         'leading-32px': useLineHeight32px
       }"
       :style="{ width: width, borderBottom: borderBottom }">
    <a-select
      :open="isOpened"
      :value="item.isValid ? item.id : undefined"
      :list-height="listHeight || 256"
      :placeholder="placeholder || undefined"
      @change="onChange"
      @dropdownVisibleChange="onOpenChange"
      dropdownClassName="selector-table2-dropdown"
    >
      <template #suffixIcon>
        <IconSelectorDetailUp v-if="isOpened" />
        <IconSelectorDetailDown v-else />
      </template>
      <a-select-option v-for="o in items" :value="o.id" :key="o.id">{{ o.text }}</a-select-option>
    </a-select>
    <div class="absolute" style="left: 2px; top: 36px;">
      <ErrorView :tips="errorTips" bg-color="var(--aaruy-bg-color-12)" />
    </div>
  </div>
</template>
