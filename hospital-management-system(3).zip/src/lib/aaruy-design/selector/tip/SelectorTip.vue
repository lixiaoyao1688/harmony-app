<script setup lang="ts">
import { ref } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import IconSelectorTipDown from '@/lib/aaruy-design/selector/tip/icons/IconSelectorTipDown.vue';
import IconSelectorTipUp from '@/lib/aaruy-design/selector/tip/icons/IconSelectorTipUp.vue';
import '@/lib/aaruy-design/selector/tip/styles/selector.tip.style.css';


interface Prop {
	items: Array<SelectorFormItemVO>;
	item: SelectorFormItemVO;
}

interface Emit {
	(e: 'change', item: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const visible = ref<boolean>(false);


function change(item: SelectorFormItemVO) {
  visible.value = false;
  emit('change', item);
}
</script>

<template>
	<a-tooltip
		v-model:visible="visible"
		trigger="click"
		placement="bottomLeft"
		overlayClassName="selector-tip-dropdown"
		@click.stop
	>
		<div class="flex items-center cursor-pointer">
			<span class="text-s mr-2">{{ item.text }}</span>
			<IconSelectorTipUp v-show="visible" />
			<IconSelectorTipDown v-show="!visible" />
		</div>
		<template #title>
			<a-menu :selectable="false">
				<a-menu-item v-for="it in items" :key="it.id" @click="change(it)" :class="{ selected: it.id === item.id }">
					{{ it.text }}
				</a-menu-item>
			</a-menu>
		</template>
	</a-tooltip>
</template>
