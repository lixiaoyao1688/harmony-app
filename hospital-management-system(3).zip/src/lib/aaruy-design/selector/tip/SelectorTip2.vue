<script setup lang="ts">
import {ref, watch} from 'vue';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import DropdownTip from '@/lib/aaruy-design/dropdown/tip/DropdownTip.vue';
import SelectorNormalIconUp from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconUp.vue';
import SelectorNormalIconDown from '@/lib/aaruy-design/selector/normal/icons/SelectorNormalIconDown.vue';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 下拉框 提示样式 UI
 *
 * 适用设备
 * 台式机 && 笔记本;
 */
interface Prop {
  title: string;
  text: string;
  item: ItemType2;
  items: Array<ItemType2>;
  map: Map<number, ItemType2>;
  margin?: string;
  tips?: string;
}

interface Emit {
	(e: 'change', data: ItemType2): void;
}

defineExpose({
  hasError,
  onClose
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const isOpened = ref<boolean>(false);
const value = ref<ItemType2>(new SelectItemVO());
const errorTips = ref<string>('');


watch(() => prop.tips, (data) => {
  if (data !== undefined) {
    errorTips.value = data;
  }
}, { immediate: true });

watch(() => prop.item, (data) => {
  value.value = data;
}, { immediate: true });

function onOpenChange(data: boolean): void {
  isOpened.value = data;
}

function hasError(): boolean {
  let isValueError = false;
  const tips = getErrorTips(value.value as ItemType2);
  if (tips !== '') {
    isValueError = true;
  }
  errorTips.value = tips;
  return isValueError;
}

function getErrorTips(data: ItemType2): string {
  if (!data.isValid) {
    return '请选择一项';
  }
  return '';
}

function change(id: number): void {
  const data = prop.map.get(id) as ItemType2;
  value.value = data;
  hasError();
  emit('change', data);
  onClose();
}

function onClose(): void {
  isOpened.value = false;
}
</script>

<template>
  <DropdownTip :visible="isOpened" destroy-tooltip-on-hide use-select-tips2-style @openChange="onOpenChange">
    <template #content>
      <div :style="{ margin: margin }"
           :class="{ 'border-error': errorTips }"
           class="flex items-end justify-between border-b-default border-hover-primary-4 pl-16 pb-4 pr-16">
        <span class="text-s" style="line-height: 22px;">{{ title }}</span>
        <div class="inline-flex items-center pr-8">
          <span class="text-white text-s cursor-pointer no-select mr-8">{{ text }}</span>
          <SelectorNormalIconUp v-show="isOpened" />
          <SelectorNormalIconDown v-show="!isOpened" />
        </div>
      </div>
    </template>
    <template #menu>
      <div class="bg-1 p-8 rounded-4">
        <div v-for="(it,i) in items" :key="it.id"
             class="rounded-4 text-center text-s cursor-default bg-default-1-hover"
             style="height: 32px; line-height: 32px;"
             :class="{ 'bg-default-1': it.id === value.id, 'mt-8': i > 0 }"
             @click="change(it.id)">{{ it.text }}</div>
        <slot></slot>
      </div>
    </template>
  </DropdownTip>
  <ErrorView :tips="errorTips" bg-color="var(--aaruy-bg-color-12)" padding="0 24px 0 0" />
</template>
