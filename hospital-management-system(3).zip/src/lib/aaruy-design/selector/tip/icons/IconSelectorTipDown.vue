<script setup lang="ts">
interface Prop {
  isNotYetEnabled: boolean;
  scale?: number;  // 默认1
}

const prop = defineProps<Prop>();
</script>

<template>
	<svg xmlns="http://www.w3.org/2000/svg" :width="20 * (scale || 1)" :height="20 * (scale || 1)" viewBox="0 0 20 20">
		<g id="iconSelectorTipDown" data-name="组 8886" transform="translate(-1716 -384)">
			<rect width="20" height="20" transform="translate(1716 384)" fill="none"/>
			<path d="M5.931,226.017a.86.86,0,0,1-.611-.25L.157,220.6a.864.864,0,0,1,1.222-1.222l4.552,4.561,4.552-4.552A.861.861,0,0,1,11.7,220.6l-5.163,5.163A.861.861,0,0,1,5.931,226.017Z" transform="translate(1720.096 171.871)"
            :fill="isNotYetEnabled ? 'rgba(255,255,255,0.5)' : 'rgb(255,255,255)'" />
		</g>
	</svg>
</template>