<script setup lang="ts">
interface Prop {
  isNotYetEnabled: boolean;
  scale?: number;  // 默认1
}

const prop = defineProps<Prop>();
</script>

<template>
	<svg xmlns="http://www.w3.org/2000/svg" :width="20 * (scale || 1)" :height="20 * (scale || 1)" viewBox="0 0 20 20">
		<g id="iconSelectorTipUp" data-name="组 8886" transform="translate(0)">
			<rect width="20" height="20" transform="translate(0)" fill="none"/>
			<path d="M5.931,219.129a.86.86,0,0,0-.611.25L.157,224.542a.864.864,0,0,0,1.222,1.222L5.931,221.2l4.552,4.552a.861.861,0,0,0,1.213-1.213l-5.163-5.163A.861.861,0,0,0,5.931,219.129Z" transform="translate(4.096 -213.017)"
            :fill="isNotYetEnabled ? 'rgba(255,255,255,0.5)' : 'rgb(255,255,255)'" />
		</g>
	</svg>
</template>
