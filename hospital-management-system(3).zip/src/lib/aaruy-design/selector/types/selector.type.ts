import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {ErrorExposedType} from '@/lib/aaruy-design/error/type/error.type';


export type SelectorInfo = {
	items: Array<SelectorFormItemVO>;
	defaultItem: SelectorFormItemVO;
	itemMap: Map<number, SelectorFormItemVO>;
}

export interface SelectItem<T> {
	id: number;
	text: string;
	payload?: T;
}

export type SelectorTip2ExposedType = ErrorExposedType & {
	onClose: () => void;
}
