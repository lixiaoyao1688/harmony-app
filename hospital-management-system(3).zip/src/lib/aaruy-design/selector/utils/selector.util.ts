import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { SelectorInfo } from '@/lib/aaruy-design/selector/types/selector.type';


export function getSelectorInfo(ids: Array<number>, texts: Array<string>): SelectorInfo {
  const items: Array<SelectorFormItemVO> = [];
	
  for (let i = 0, len = ids.length; i < len; i++) {
    items.push(new SelectorFormItemVO(ids[i], texts[i]));
  }
	
  return {
    items: items,
    defaultItem: items.length > 0 ? items[0] : SelectorFormItemVO.empty(),
    itemMap: new Map<number, SelectorFormItemVO>(items.map(it => ([it.id, it]))),
  };
}
