import { INVALID_ID } from '@/utils/global.vo.help';
import { SelectItem } from '@/lib/aaruy-design/selector/types/selector.type';
import type {PickerItemType} from '@/lib/aaruy-design/picker/picker.type';


/**
 * 选项 VO
 *
 * 用于各种需要列表的组件，如: Select, Dropdown, List, Radio, Checkbox...
 */
export class SelectItemVO<T> {
  private readonly _entity: SelectItem<T>;
  
  constructor(e?: SelectItem<T>) {
    this._entity = e || this._getEmpty();
  }
  
  public get id(): number {
    return this._entity.id;
  }
  
  public get text(): string {
    return this._entity.text;
  }
  public set text(data) {
    this._entity.text = data;
  }
  
  public get payload(): T {
    return this._entity.payload as T;
  }
  
  public get isValid() {
    return this._entity.id !== INVALID_ID;
  }
  
  public get pickerItem(): PickerItemType {
    return { value: this._entity.id, text: this._entity.text };
  }
  
  public static getItem<T>(map: Map<number, SelectItemVO<T>>, id: number): SelectItemVO<T> {
    const item = map.get(id);
    return item ? item : new SelectItemVO<T>();
  }
  
  public static getMap<T>(list: Array<SelectItemVO<T>>): Map<number, SelectItemVO<T>> {
    return new Map<number, SelectItemVO<T>>(list.map(item => ([item.id, item])));
  }
  
  public static getText<T>(map: Map<number, SelectItemVO<T>>, id: number): string {
    const item = map.get(id);
    return item ? item.text : '';
  }
  
  public static isIdValid<T>(list: Array<SelectItemVO<T>>, id: number): boolean {
    return list.findIndex(it => it.id === id) !== -1;
  }
  
  private _getEmpty(): SelectItem<T> {
    return { id: INVALID_ID, text: '' };
  }
  
}
