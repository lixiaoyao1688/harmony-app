<script setup lang="ts">
import '@/lib/aaruy-design/selector/workbench/selector.black.white.style.css';


interface Prop {
  options: unknown[]
  value: unknown
  valueField?: string
  textField?: string
  style?: string
}

interface Emit {
  (e: 'change', value: unknown): void
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const vf = prop.valueField || 'id';
const tf = prop.textField || 'text';


function onChange(v) {
  emit('change', v);
}
</script>

<template>
  <div class="wb-selector">
    <a-select :value="value" @change="onChange" :style="style" dropdownClassName="wb-selector-dropdown">
      <a-select-option v-for="o in options" :value="o[vf]" :key="o[vf]">{{ o[tf] }}</a-select-option>
    </a-select>
  </div>
</template>
