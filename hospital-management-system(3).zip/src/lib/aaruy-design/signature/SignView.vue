<script setup lang="ts">
import { ref } from 'vue';
import { notifyErrorNormal } from '@/lib/aaruy-design/notify/notify';
import { base64ToFile } from '@/lib/aaruy-design/signature/sign.util';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import PageBoardContent from '@/lib/aaruy-design/page/component/PageBoardContent.vue';
import '@/lib/aaruy-design/signature/sign.style.css';
import type { SignatureInstance } from 'vant';
import type { SignData } from '@/lib/aaruy-design/signature/sign.type';


/**
 * 签名 组件
 * 仅 mobile;
 */
interface Prop {
  isLoading?: boolean;
  cancelText?: string;   // 按钮取消文本
  confirmText?: string;   // 按钮确认文本
}

interface Emit {
  (e: 'change', data: File): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const signatureRef = ref<SignatureInstance | null>(null);


function onSubmit(data: SignData): void {
  if (!data.image) {
    notifyErrorNormal('签名不能为空');
    return;
  }
  // // 将绘制出的图片，逆时针旋转 90 度，再导出给外层使用;
  // rotateImageCounterClockwise90(data.image)
  //   .then(newBase64 => {
  //     emit('change', base64ToFile(newBase64));
  //   });
  // 2025-03-27 签名界面方向改为正向;
  emit('change', base64ToFile(data.image));
}

function onClear(): void {
  if (!signatureRef.value) {
    return;
  }
  signatureRef.value.clear();
}

function onConfirm(): void {
  if (!signatureRef.value) {
    return;
  }
  signatureRef.value.submit();
}
</script>

<template>
 
  <PageBoardContent>
    <van-signature ref="signatureRef"
                   pen-color="#fff"
                   background-color="#151A1F"
                   class="sign-view"
                   tips="当前设备不支持签名功能"
                   @submit="onSubmit" />
    <template #bottom>
      <div class="h-full flex items-start justify-between px-16">
        <ButtonView type="default" :text="cancelText || '清空'" style="width: 49%; height: 80%; font-size: 16px;" @click="onClear" />
        <ButtonView type="primary" :text="confirmText || '保存'" style="width: 49%; height: 80%; font-size: 16px;" :loading="isLoading" @click="onConfirm" />
      </div>
    </template>
  </PageBoardContent>
  
  <!-- 签名界面顺时针旋转 90 度 -->
  <!--  <div class="h-full flex">-->
  <!--    <div style="width: 48px;" class="flex h-full justify-between flex-col p-8">-->
  <!--      <ButtonView type="default" :text="cancelText || '清空'" is-text-rotate90 style="width: 100%; height: 49%;" @click="onClear" />-->
  <!--      <ButtonView type="primary" :text="confirmText || '保存'" :loading="isLoading" is-text-rotate90 style="width: 100%; height: 49%;" @click="onConfirm" />-->
  <!--    </div>-->
  <!--    <van-signature ref="signatureRef"-->
  <!--                   pen-color="#fff"-->
  <!--                   background-color="#151A1F"-->
  <!--                   class="sign-view"-->
  <!--                   tips="当前设备不支持签名功能"-->
  <!--                   @submit="onSubmit" />-->
  <!--  </div>-->
  
</template>
