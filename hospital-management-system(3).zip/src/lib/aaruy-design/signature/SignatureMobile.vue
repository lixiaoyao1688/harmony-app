<script setup lang="ts">
import { onMounted, ref } from 'vue';
import IconSignatureTip from '@/lib/icon/IconSignatureTip.vue';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import { SignatureCanvasLineCap, SignatureCanvasLineJoin } from '@/lib/aaruy-design/signature/signature.type';
import '@/lib/aaruy-design/signature/signature.mobile.style.css';


interface ImageInfo {
  image: string | File | null;
}

interface coordinate {
  sx: number,
  sy: number,
  ex: number,
  ey: number,
}

interface Prop {
  id: string,
  padding?: number,
  imageType?:string, //要转换的图片类型-默认”image/png“
}

interface Emit {
  (e: 'submit', data: ImageInfo),

  (e: 'clear'),
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const $ = (name) => document.querySelector(name);
// 配置内容
const config = {
  width: 0, // 宽度
  height: 0, // 高度
  borderWidth: 1,//盒子线宽
  btnWidth: 40,//按钮宽度
  lineWidth: 2, // 线宽
  strokeStyle: 'rgb(255,255,255)', // 绘制线条颜色
  lineCap: 'round', // 设置线条两端圆角
  lineJoin: 'round', // 线条交汇处圆角
  bg: 'transparent'//画布背景
};

// 偏移量
const client = {
  offsetX: 0,
  offsetY: 0
};

let canvas: HTMLCanvasElement;
let ctx: CanvasRenderingContext2D | null;
const isMove = ref<Boolean>(false);

onMounted(() => {
  initSignBoard();
});

const initSignBoard = (): void => {
  const {width, height, left, top} = $('.signature-drawing-mobile').getBoundingClientRect();
  config.width = width;
  config.height = height;
  client.offsetX = left;
  client.offsetY = top;
  // canvas 实例
  canvas = $('#canvas');
  if (!canvas) return;
  // 设置宽高
  canvas.width = config.width - config.borderWidth * 2;
  canvas.height = config.height - config.borderWidth * 2;
  // 创建上下文
  ctx = canvas.getContext('2d') as CanvasRenderingContext2D;
  ctx.lineWidth = config.borderWidth;
  // 设置填充背景色
  ctx.fillStyle = config.bg;
  // 绘制填充矩形
  ctx.fillRect(
    0, // x 轴起始绘制位置
    0, // y 轴起始绘制位置
    config.width, // 宽度
    config.height // 高度
  );
};

// 鼠标按下
const touchStart = (event): void => {
  event.preventDefault();
  // 获取偏移量及坐标
  const {clientX, clientY} = event.changedTouches[0];
  // 清除以上一次 beginPath 之后的所有路径，进行绘制
  if (ctx) {
    isMove.value = true;
    ctx.beginPath();
    // 根据配置文件设置相应配置
    ctx.lineWidth = config.lineWidth;
    ctx.strokeStyle = config.strokeStyle;
    ctx.lineCap = config.lineCap as SignatureCanvasLineCap;
    ctx.lineJoin = config.lineJoin as SignatureCanvasLineJoin;
    // 设置画线起始点位（减去 左边、上方的偏移量很关键）
    ctx.moveTo(clientX - client.offsetX, clientY - client.offsetY);
  }
};

// 绘制
const touchMove = (event): void => {
  if (isMove.value) {
    // 获取当前坐标点位
    const { clientX, clientY } = event.changedTouches[0];
    if (ctx) {
      // 根据坐标点位移动添加线条（减去 左边、上方的偏移量很关键）
      ctx.lineTo(clientX - client.offsetX, clientY - client.offsetY);
      // 绘制
      ctx.stroke();
    }

  }
};

// 结束绘制
const touchEnd = (): void => {
  if (ctx) {
    ctx.closePath();
  }
  isMove.value = false;
};

// 清除
const reset = (): void => {
  if (ctx) {
    // 清空当前画布上的所有绘制内容
    ctx.clearRect(0, 0, config.width, config.height);
    ctx.fillStyle = config.bg;
    ctx.fillRect(
      0, // x 轴起始绘制位置
      0, // y 轴起始绘制位置
      config.width, // 宽度
      config.height // 高度
    );
  }
  emit('clear');
};
// 将画布内容保存为图片
const save = (): void => {
  if (!isCanvasBlank(canvas)) {
    rotateImage(canvas.toDataURL(prop.imageType ? prop.imageType : 'image/png')).then((img: ImageInfo) => {
      emit('submit', img);
    });
  } else {
    emit('submit', {image: null});
  }
};

// 判断canvas对象是否空
const isCanvasBlank = (canvas: HTMLCanvasElement): Boolean => {
  const blank = document.createElement('canvas'); // 系统获取一个空canvas对象
  blank.width = config.width;
  blank.height = config.height;
  return canvas.toDataURL() === blank.toDataURL(); // 比较值相等则为空
};

// 将base64图片旋转90度以后上传
const rotateImage = (imgBase64: string): Promise<ImageInfo> => {
  return new Promise((resolve, reject) => {
    const imgView = new Image();
    imgView.src = imgBase64;
    const canvas: HTMLCanvasElement = document.createElement('canvas');
    const context = canvas.getContext('2d') as CanvasRenderingContext2D;
    if (!context) return reject({image: null});
    let coordinate: coordinate = {
      sx: 0,
      sy: 0,
      ex: 0,
      ey: 0
    };
    // 裁剪坐标
    imgView.onload = () => {
      const imgW: number = imgView.width;
      const imgH: number = imgView.height;
      const size: number = imgH;
      //   常量大小 = imgH;
      canvas.width = size * 2;
      canvas.height = size * 2;
      coordinate.sx = size;
      coordinate.sy = size - imgW;
      coordinate.ex = size + imgH;
      coordinate.ey = size + imgW;
      context.translate(size, size);
      context.rotate((Math.PI / 2) * 3);
      context.drawImage(imgView, 0, 0);
      const imgData: ImageData = context.getImageData(coordinate.sx, coordinate.sy, coordinate.ex, coordinate.ey);
      canvas.width = imgH;
      canvas.height = imgW;
      context.putImageData(imgData, 0, 0);
      canvas.toBlob(async (blob) => {
        if (blob) {
          //   将blob转换为File
          let fileName = new Date().getTime();
          const files = await new window.File([blob], fileName.toString(), {type:  prop.imageType ? prop.imageType : 'image/png'});
          resolve({
            image: files
          });
        } else {
          resolve({
            image: null
          });
        }
      });
    };
  });
};
</script>

<template>
  <div class="signature-drawing-mobile">
    <canvas
			id="canvas"
			@touchstart="touchStart"
			@touchmove="touchMove"
			@touchend="touchEnd"
    ></canvas>
    <IconSignatureTip />
  </div>
  <div class="signature-btn-container">
		<ButtonView type="default" text="清空" class="signature-btn mr-10" @click="reset" />
		<ButtonView type="primary" text="确认" class="signature-btn" @click="save" />
  </div>
</template>
