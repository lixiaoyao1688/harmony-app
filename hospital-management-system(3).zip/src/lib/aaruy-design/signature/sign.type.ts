export interface SignData {
  image: string;  // 签名对应的图片，为 base64 字符串格式。若签名为空，则返回空字符串。
  canvas: HTMLCanvasElement;  // Canvas 元素
}