import { useScreenStore } from '@/lib/screen/store/screen.store';


function loadImageFromBase64(base64String: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = base64String;
  });
}

/**
 * 将图片逆时针旋转 90 度;
 * @param base64String 图片的 Base64 字符串;
 * @return 旋转完成后图片的 Base64 字符串;
 */
export async function rotateImageCounterClockwise90(base64String: string): Promise<string> {
  const img = await loadImageFromBase64(base64String);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('2D context not available');
  }
  
  // 交换宽度和高度，因为我们是逆时针旋转90度
  canvas.width = img.height;
  canvas.height = img.width;
  
  // 原点平移到左下角
  ctx.translate(0, canvas.height);
  // 逆时针旋转90度
  ctx.rotate(-Math.PI / 2);
  
  // 绘制图像
  ctx.drawImage(img, 0, 0);
  
  // 将canvas内容转换为base64字符串
  return canvas.toDataURL('image/png');
}


/**
 * Base64 字符串转 File 对象;
 * @param base64Url 图片的 Base64 字符串;
 * @return File 对象;
 */
export function base64ToFile(base64Url: string): File {
  const isPC = useScreenStore().isPC;
  const type = 'image/png';
  const base64Str = base64Url.split(';base64,').pop() as string;
  const byteString = atob(base64Str);
  const aaruyBuffer = new ArrayBuffer(byteString.length);
  const uint8Array = new Uint8Array(aaruyBuffer);
  
  for (let i = 0; i < byteString.length; i++) {
    uint8Array[i] = byteString.charCodeAt(i);
  }
  const blob = new Blob([uint8Array], { type: type });
  
  
  if (isPC) {
    return new File([blob], 'user_signature', { type: type });
  }
  else {
    // @ts-ignore
    // cordova-plugin-advanced-http 上传文件时，需要原生的 File 对象
    return new NativeFile([blob], 'user_signature', { type: type });
  }
  
}
