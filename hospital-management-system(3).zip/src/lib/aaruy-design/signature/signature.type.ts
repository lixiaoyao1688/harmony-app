export type SignatureCanvasLineCap = 'butt' | 'round' | 'square';
export type SignatureCanvasLineJoin = 'bevel' | 'miter' | 'round';
