<script setup lang="ts">
import { ref, watch } from 'vue';
import { INVALID_ID } from '@/utils/global.vo.help';
import VueSlider, { DotOption } from 'vue-slider-component';
import { GLU_DEFAULT_RANGE } from '@/modules/glucose/config/glu.config';
import 'vue-slider-component/theme/default.css';
import '@/lib/aaruy-design/slider/styles/aaruy.slider.style.css';
import type {SliderData, SliderRangeType} from '@/lib/aaruy-design/slider/types/slider.type';


/**
 * 滑动输入条 基础UI
 *
 * 注意
 * 固定显示 4 个滑块;
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
	min: number;
	max: number;
	step: number;
	value: SliderRangeType;
}

interface Emit {
	(e: 'change', data: SliderData): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const activedIndex = ref<number>(INVALID_ID);  // 激活的滑块索引
const innerValue = ref<SliderRangeType>(GLU_DEFAULT_RANGE);
const slider = ref<InstanceType<typeof VueSlider> | null>(null);
const dotOptions = ref<Array<DotOption>>(Array(prop.value.length).fill(0).map(_ => ({ disabled: false, tooltipStyle: undefined })));


watch(() => prop.value, (data) => {
  innerValue.value = data;
}, { immediate: true });

watch(() => activedIndex.value, (index) => {
  dotOptions.value.forEach(d => { d.tooltipStyle = undefined; });
  resetZIndex();
  if (index === INVALID_ID) {
    return;
  }
  dotOptions.value[index].tooltipStyle = {
    borderColor: 'var(--aaruy-primary-color-1)',
    backgroundColor: 'var(--aaruy-bg-color-2)'
  };
  setZIndex(index, 10);
}, { immediate: true });

function resetZIndex(): void {
  prop.value.forEach((_,i) => setZIndex(i, 5));
}

function setZIndex(index: number, zIndex: number): void {
  // 1.找到激活的 vue-slider-dot
  // 2.设置 z-index: index === INVALID_ID ? 5 : 10
  if (slider.value && slider.value.$el) {
    const dots = slider.value.$el.querySelectorAll('.vue-slider-dot');
    if (dots && dots[index] && dots[index].style) {
      dots[index].style.zIndex = zIndex;
    }
  }
}

function onDragStart(index: number): void {
  activedIndex.value = index;
}

function onDragEnd(): void {
  activedIndex.value = INVALID_ID;
}

function onChange(v: SliderRangeType, index: number): void {
  emit('change', { index: index, data: v });
}

function onInputChange(v: number, i: number): void {
  innerValue.value[i] = v;
}

function onInputEnter(i: number): void {
  onChange(innerValue.value, i);
}
</script>

<template>
	<vue-slider
		ref="slider"
		class="aaruy-slider"
    tooltip="always"
		:model-value="value"
		:enable-cross="false"
		:clickable="false"
		:min="min"
		:max="max"
		:interval="step"
		:min-range="0"
		:drag-on-click="false"
		:dot-options="dotOptions"
		:dot-style="{ color: 'red' }"
    :process="dotsPos => {
      return [
        [0,dotsPos[0],{ backgroundColor: 'rgb(157,0,4)' }],
        [dotsPos[0],dotsPos[1],{ backgroundColor: 'rgb(247,58,63)' }],
        [dotsPos[1],dotsPos[2],{ backgroundColor: 'rgb(123,175,253)' }],
        [dotsPos[2],dotsPos[3],{ backgroundColor: 'rgb(255,180,51)' }],
        [dotsPos[3],100,{ backgroundColor: 'rgb(183,79,0)' }]
      ];
    }"
		@drag-start="onDragStart"
		@drag-end="onDragEnd"
		@change="onChange"
	>
		<template v-slot:dot>
			<div style="width: 12px; height: 15px;" class="cursor-pointer rounded-4 bg-primary border-2-white"></div>
		</template>
    <template v-slot:tooltip="{ index, focus }">
      <div class="inline-block bg-1 rounded-4" style="width: 60px; height: 40px;" @click.stop @keydown.stop>
        <a-input-number title=""
                        :min="min"
                        :max="max"
                        :step="step"
                        :value="innerValue[index]"
                        :controls="false"
                        placeholder="请输入"
                        class="w-full h-full text-center"
                        :class="{ 'slider-input-focus': focus }"
                        @click.stop
                        @change="onInputChange($event, index)"
                        @press-enter.stop="onInputEnter(index)" />
      </div>
    </template>
	</vue-slider>
</template>
