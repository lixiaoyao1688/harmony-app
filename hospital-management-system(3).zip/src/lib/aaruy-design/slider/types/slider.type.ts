export type SliderRangeType = [number, number, number, number];

export type SliderData = {
	index: number;  // 滑块索引
	data: SliderRangeType;
}
