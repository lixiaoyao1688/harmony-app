<script setup lang="ts">
import { computed, ref } from 'vue';
import { MS_PER_SECOND } from '@/lib/time/config/time.config';
import { notifyErrorInvalid } from '@/lib/aaruy-design/notify/notify';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import InputBasic from '@/lib/aaruy-design/input/basic/InputBasic.vue';


interface Prop {
	value: string;
	maxLength: number;
	placeholder: string;
	waiting: boolean;  // 是否等待重试
	field: string;  // 用于报错提示
	interval: number;   // 按下按钮后，等待的时间 (秒)
	isValid: (v: string) => boolean;  // 校验器
}

interface Emit {
	(e: 'send'): void;
	(e: 'stopWaiting'): void;
	(e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const count = ref<number>(prop.interval);
const tips = computed<string>(() => count.value + '秒后重试');

let timer: any = null;


function onChange(v: string): void {
  emit('change', v);
}

function send(): void {
  if (!prop.isValid(prop.value)) {
    return notifyErrorInvalid(prop.field);
  }
  if (prop.waiting) {
    return;
  }
	
  emit('send');
	
  timer = setInterval(() => {
    if (count.value === 0) {
      emit('stopWaiting');
      count.value = prop.interval;
      clearInterval(timer);
      return;
    }
    count.value--;
  }, MS_PER_SECOND);
}
</script>

<template>
	<div class="flex items-center" style="height: 40px;">
		<InputBasic :data="value" :placeholder="placeholder" :maxlength="maxLength" @change="onChange" />
		<ButtonView type="primary" :disabled="waiting" style="width: 128px; height: 40px; margin-left: 10px;" @click="send">
			<template #complexContent>
				{{ waiting ? tips : '发送验证码' }}
			</template>
		</ButtonView>
	</div>
</template>
