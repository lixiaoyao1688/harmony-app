<script setup lang="ts">
interface Prop {
	tip: string;
	loading: boolean;
  height?: string;  // 默认 100%;
  minHeight?: string;  // 默认 200px;
  textSize?: number;
  iconSize?: string;
  margin?: string;
  color?: string;  // 指示器颜色，默认	#c9c9c9
}

const prop = defineProps<Prop>();
</script>

<template>
	<div v-if="loading" class="flex items-center justify-center"
       :style="{
          height: height || '100%',
          minHeight: minHeight || '200px',
          margin: margin
       }">
		<van-loading :size="iconSize || '24px'" :text-size="textSize || 18" :color="color">{{ tip }}</van-loading>
	</div>
</template>
