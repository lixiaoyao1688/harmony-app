<script setup lang="ts">
import '@/lib/aaruy-design/spin/spin.normal.style.css';

interface Prop {
  tip: string;
  loading: boolean;
}


defineProps<Prop>();
</script>

<template>
  <a-spin :tip="tip" :spinning="loading" size="large" wrapper-class-name="spin-normal">
    <slot></slot>
  </a-spin>
</template>
