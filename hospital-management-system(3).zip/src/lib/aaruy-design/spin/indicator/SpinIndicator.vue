<script setup lang="ts">
import { h } from 'vue';
import { LoadingOutlined } from '@ant-design/icons-vue';
import '@/lib/aaruy-design/spin/indicator/spin.indicator.style.css';


interface Prop {
	tip: string;
  color?: string;
  fontSize?: string;
  height?: string;  // 仅PC
}

const DEFAULT_COLOR = 'rgb(255,255,255)';
const DEFAULT_FONT_SIZE = '22px';
const DEFAULT_ICON_FONT_SIZE = '24px';

const prop = defineProps<Prop>();
const indicator = h(LoadingOutlined, {
  style: {
    fontSize: prop.fontSize || DEFAULT_ICON_FONT_SIZE,
    color: prop.color || DEFAULT_COLOR,
  },
  spin: true,
});
</script>

<template>
	<a-spin
    :tip="tip"
    :indicator="indicator"
    :style="{
      color: color || DEFAULT_COLOR,
      fontSize: fontSize || DEFAULT_FONT_SIZE,
      height: height
    }"
    class="aaruy-spin-ind"
  />
</template>
