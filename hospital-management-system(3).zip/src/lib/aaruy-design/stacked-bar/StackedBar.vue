<script setup lang="ts">
import { computed } from 'vue';
import { GLU_ANA_LEVEL } from '@/modules/glucose/dto/agp.dto';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { StackedBarItemVO } from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';
import StackedBarBadge from '@/lib/aaruy-design/stacked-bar/components/StackedBarBadge.vue';


interface Prop {
  items: Array<StackedBarItemVO>;
  isPicVertical?: boolean;
	height?: number | string;
	isVertical?: boolean;
	isFat?: boolean;
	isReport?: boolean;
	isDayMerge?: boolean;  // 是否每日综合使用
  isMobile?: boolean;
}

const screenStore = useScreenStore();
const prop = defineProps<Prop>();

const dataItems = computed<Array<StackedBarItemVO>>(() => prop.items.slice().reverse());
const renderItems = computed<Array<StackedBarItemVO>>(() => dataItems.value.filter(it => it.percentValue > 0));
const okItem = computed<StackedBarItemVO>(() => prop.items.find(it => it.id === GLU_ANA_LEVEL.OK) as StackedBarItemVO);
const otherItems = computed<Array<StackedBarItemVO>>(() => prop.items.filter(it => it.id !== GLU_ANA_LEVEL.OK));

const laptop = computed<boolean>(() => screenStore.isLaptop);
const isSmallPhone = computed<boolean>(() => screenStore.isSmallPhone);
const isPad = computed<boolean>(() => screenStore.isTablet);
const isNewPad = computed<boolean>(() => screenStore.isPad);

const innerHeight = typeof prop.height === 'number' ? (prop.height+'px') : prop.height;
</script>

<template>
	
	<!-- 报告必须写内联样式 -->
	<div v-if="isReport" style="display: flex; justify-content: flex-start; align-items: center;" :style="{ height: innerHeight }">
		<div style="width: 38px; height: 100%; margin-right: 8px;">
			<div
        v-for="(it,i) in renderItems"
        :key="it.id"
        :style="{
          height: it.width.toString(),
          backgroundColor: it.color,
          borderRadius: renderItems.length === 0 ? '4px' : (i === 0 ? '4px 4px 0 0' : (i === renderItems.length-1 ? '0 0 4px 4px' : '0'))
        }"
      ></div>
		</div>
		<div style="display: flex; height: 100%;">
			<div style="height: 100%; display:flex; flex-direction: column; justify-content: flex-start;">
				<div v-for="(it,i) in items.slice(0,3)" :key="it.id" :style="{ marginBottom: i === 2 ? 0 : '6px' }" style="display: flex; align-items: center;">
					<span style="display: inline-block; width: 8px; height: 24px; border-radius: 4px; margin-right: 4px;" :style="{ backgroundColor: it.color }"></span>
					<div>
						<span style="font-size: 12px; line-height: 16px; color: rgb(51,51,51); margin-right: 10px;">{{ it.name }}</span>
						<span style="font-size: 14px; line-height: 16px; color: rgb(51,51,51); font-weight: 700;">{{ it.width }}</span>
						<div style="font-size: 12px; line-height: 16px; color: rgb(102,102,102);">{{ it.desc }}</div>
					</div>
				</div>
			</div>
			<div style="height: 100%; display:flex; flex-direction: column; justify-content: flex-start; margin-left: 12px;">
				<div v-for="it in items.slice(3)" :key="it.id" style="display: flex; align-items: center; margin-bottom: 6px;">
					<span style="display: inline-block; width: 8px; height: 24px; border-radius: 4px; margin-right: 4px;" :style="{ backgroundColor: it.color }"></span>
					<div>
						<span style="font-size: 12px; line-height: 16px; color: rgb(51,51,51); margin-right: 10px;">{{ it.name }}</span>
						<span style="font-size: 14px; line-height: 16px; color: rgb(51,51,51); font-weight: 700;">{{ it.width }}</span>
						<div style="font-size: 12px; line-height: 16px; color: rgb(102,102,102);">{{ it.desc }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  
  <div v-else-if="isPicVertical">
    <div class="flex mb-24" style="height: 100px;">
      <div
        v-for="(it,i) in items"
        :key="it.id"
        :style="{ width: it.width, backgroundColor: it.color }"
        :class="{ 'rounded-l-4': i === 0, 'rounded-r-4': i === items.length-1 }"
      ></div>
    </div>
    <div class="flex justify-between">
      <StackedBarBadge v-for="bg in items" :key="bg.id" :item="bg" :is-vertical="true" />
    </div>
  </div>
	
	<div v-else-if="isDayMerge" class="flex h-full">
		<div style="width: 40%" class="flex h-full">
			<div v-for="it in items" :key="it.id" :style="{ width: it.width, backgroundColor: it.color }"></div>
		</div>
		<div class="flex-1 flex">
			<div class="mx-24">
				<StackedBarBadge :item="okItem" :is-day-merge="true" :is-day-merge-main="true" />
			</div>
			<div class="mr-16" style="flex-basis: 150px;">
				<StackedBarBadge :item="otherItems[0]" :is-day-merge="true" />
				<div class="mt-16">
					<StackedBarBadge :item="otherItems[2]" :is-day-merge="true" />
				</div>
			</div>
			<div>
				<StackedBarBadge :item="otherItems[1]" :is-day-merge="true" />
				<div class="mt-16">
					<StackedBarBadge :item="otherItems[3]" :is-day-merge="true" />
				</div>
			</div>
		</div>
	</div>

  <div v-else-if="isMobile">
    <div class="flex items-center rounded-8 mt-8" style="height: 60px;">
      <div
        v-for="(it,i) in items"
        :key="it.id"
        :style="{ width: it.width, backgroundColor: it.color }"
        :class="{ 'rounded-l-4': i === 0, 'rounded-r-4': i === items.length-1 }"
        class="h-full"
      ></div>
    </div>
    <div class="flex items-center mt-8" :class="{ 'justify-start': isPad, 'justify-between': !isPad }" style="height: 62px;">
      <!-- okItem -->
      <div :class="{ 'pr-24': isNewPad, 'w-80': !isNewPad }">
        <div class="flex items-center">
          <span class="inline-block size-10 rounded-2 mr-4" :style="{ backgroundColor: okItem.color }"></span>
          <span class="text-xs">{{ okItem.name }}</span>
        </div>
        <div class="leading-xxl font-bold" :style="{ fontSize: isSmallPhone ? '20px' : '24px' }">{{ okItem.width }}</div>
      </div>
      <!-- otherItems -->
      <div :class="{ 'pr-24': isPad, 'flex-1': !isPad }" class="flex h-full flex-col justify-between pt-4 pb-4">
        <StackedBarBadge :item="otherItems[1]" :is-mobile="true" />
        <StackedBarBadge :item="otherItems[0]" :is-mobile="true" />
      </div>
      <div :class="{ 'pr-24': isPad, 'flex-1': !isPad }" class="flex h-full flex-col justify-between pt-4 pb-4">
        <StackedBarBadge :item="otherItems[2]" :is-mobile="true" />
        <StackedBarBadge :item="otherItems[3]" :is-mobile="true" />
      </div>
    </div>
  </div>
	
	<div v-else class="flex justify-between" :style="{ height: innerHeight }">
		<div class="flex h-100" :class="{ 'w-35': laptop, 'w-40': !laptop }">
			<div
          v-for="(it,i) in items"
          :key="it.id"
          :style="{ width: it.width, backgroundColor: it.color }"
          :class="{ 'rounded-l-4': i === 0, 'rounded-r-4': i === items.length-1 }"
      ></div>
		</div>
		<div class="flex h-100 justify-evenly" v-if="!isFat" :class="{ 'w-65': laptop, 'w-55': !laptop }">
			<StackedBarBadge v-for="bg in dataItems" :key="bg.id" :item="bg" :is-vertical="isVertical" />
		</div>
		<div class="h-100" v-if="isFat" :class="{ 'w-60': laptop, 'w-55': !laptop }">
			<div class="flex">
				<div style="width: 34%;" class="text-center">
					<StackedBarBadge :item="dataItems[0]" :is-vertical="isVertical" :is-fat="true" />
				</div>
				<div style="width: 33%" class="text-center">
					<StackedBarBadge :item="dataItems[1]" :is-vertical="isVertical" :is-fat="true" />
				</div>
				<div style="width: 33%" class="text-center">
					<StackedBarBadge :item="dataItems[2]" :is-vertical="isVertical" :is-fat="true" />
				</div>
			</div>
			<div class="flex mt-16">
				<div style="width: 34%" class="text-center"></div>
				<div style="width: 33%" class="text-center">
					<StackedBarBadge :item="dataItems[3]" :is-vertical="isVertical" :is-fat="true" />
				</div>
				<div style="width: 33%" class="text-center">
					<StackedBarBadge :item="dataItems[4]" :is-vertical="isVertical" :is-fat="true" />
				</div>
			</div>
		</div>
	</div>
	
</template>
