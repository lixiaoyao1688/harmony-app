<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { StackedBarItemVO } from '@/lib/aaruy-design/stacked-bar/vo/stacked.bar.vo';


interface Prop {
	item: StackedBarItemVO;
	isVertical?: boolean;
	isFat?: boolean;
	isDayMerge?: boolean;
	isDayMergeMain?: boolean;
  isMobile?: boolean;
}

defineProps<Prop>();
const screenStore = useScreenStore();
const isSmallPhone = computed<boolean>(() => screenStore.isSmallPhone);
</script>

<template>

  <template v-if="isMobile">
    <div class="flex items-center text-xs leading-xs">
      <span class="inline-block size-10 rounded-2 mr-4" :style="{ backgroundColor: item.color }"></span>
      <span class="mr-8">{{ item.name }}</span>
      <span class="font-bold">{{ item.width }}</span>
    </div>
  </template>

  <template v-else>
    <template v-if="isDayMerge">
      <div v-if="isDayMergeMain">
        <div class="flex items-center">
          <span class="inline-block rounded-2" :style="{ width: '13px', height: '13px', backgroundColor: item.color }"></span>
          <span class="ml-4 text-s leading-s">{{ item.name }}</span>
        </div>
        <div>
          <span class="text-xxl-2 leading-xxl-2 font-bold">{{ item.percentValue }}</span>
          <span class="text-s leading-s ml-8">%</span>
        </div>
      </div>
      <div v-else>
        <span class="inline-block rounded-2" :style="{ width: '13px', height: '13px', backgroundColor: item.color }"></span>
        <span class="ml-4 text-s leading-s">{{ item.name }}</span>
        <span class="text-xl-1 font-bold mx-8" style="line-height: 8px;">{{ item.percentValue }}</span>
        <span class="text-s leading-s">%</span>
      </div>
    </template>
    <template v-else>
      <div v-if="isVertical" class="inline-flex flex-col justify-between">
        <div style="font-size: 21px; line-height: 14px; margin-bottom: 10px;">{{ item.name }}</div>
        <div style="width: 42px; height: 18px; border-radius: 2px;" :style="{ backgroundColor: item.color }"></div>
        <div style="font-size: 36px; line-height: 48px; font-weight: bold;">{{ item.width }}</div>
      </div>
      <div v-if="!isVertical" class="inline-flex flex-col justify-center">

        <template v-if="!isFat">
          <div class="flex items-center">
            <span class="sign" :style="{ backgroundColor: item.color }"></span>
            <span class="text-xxs leading-xxs">{{ item.name }}</span>
          </div>
          <span class="text-xl leading-l font-bold mt-2">{{ item.width }}</span>
        </template>

        <template v-if="isFat">
          <div class="flex items-center">
            <span class="fat-sign" :style="{ backgroundColor: item.color }"></span>
            <span class="text-s-2 leading-s-2">{{ item.name }}</span>
          </div>
          <span class="text-xl-2 leading-xl-2 font-bold mt-2">{{ item.width }}</span>
        </template>

      </div>
    </template>
  </template>

</template>

<style scoped>
.sign {
	display: inline-block;
	width: 10px;
	height: 10px;
	margin-right: 2px;
	border-radius: 2px;
}

.fat-sign {
	display: inline-block;
	width: 14px;
	height: 14px;
	margin-right: 2px;
	border-radius: 2px;
}
</style>
