import { getPercentDataFromDigit } from '@/lib/math/util/math.util';


export class StackedBarItemVO {
	public id: number;
	public name: string;
	public width: string;
	public color: string;
	public desc: string;
	public percent?: string;   // 占比，如 '97.2%';
	public percentValue: number;  // 如 97.2;
	
	constructor(id: number, n: string, p: number, c: string, digits?: number, desc?: string) {
	  const v = getPercentDataFromDigit(p, digits);
	  this.id = id;
	  this.name = n;
	  this.width = `${v}%`;
	  this.percent = `${v}%`;
	  this.color = c;
	  this.desc = desc || '';
	  this.percentValue = v;
	}
}
