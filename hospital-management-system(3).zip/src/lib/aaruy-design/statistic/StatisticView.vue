<script setup lang="ts">
interface Prop {
	isValid: boolean;
	title: string;
	subTitle?: string;
	value: string;
	desc: string;
	width: string;
}

defineProps<Prop>();
</script>

<template>
  <div :style="{ width: width }" class="statistic h-100 inline-flex flex-col items-center">
		<div class="text-s text-center" style="max-width: 48px;">{{ title }}</div>
		<div v-if="subTitle" class="text-xxs leading-s text-weak-3 inline-flex items-center justify-center text-center" style="max-width: 60px; height: 32px; margin: 7px 0;">{{ subTitle }}</div>
		<template v-if="isValid">
			<div style="font-size: 26px;" class="font-bold">{{ value }}</div>
			<div class="text-xs font-bold text-weak-3">{{ desc }}</div>
		</template>
		<template v-else>
			<div style="font-size: 26px;" class="font-bold text-weak-3">{{ value }}</div>
			<div class="text-xs font-bold text-weak-3" style="visibility: hidden;">placeholder</div>
		</template>
	</div>
</template>

<style scoped>
.statistic:not(:last-child) {
	border-right: 1px solid var(--aaruy-default-color-1);
}
</style>
