<script setup lang="ts">
import {Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import {getNDayAfterDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import IconStepAdd from '@/lib/aaruy-design/stepper/icons/IconStepAdd.vue';
import IconStepSubtract from '@/lib/aaruy-design/stepper/icons/IconStepSubtract.vue';
import '@/lib/aaruy-design/stepper/styles/stepper.style.css';


interface Prop {
  value: Dayjs;
  step: number;  // 单位为h;
}

interface Emit {
	(e: 'change', data: Dayjs): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const innerValue = ref<Dayjs>(getTodayDayjs());
const valueText = computed<string>(() => getValueText(innerValue.value));
const isMax = computed<boolean>(() => innerValue.value.unix() === getNDayAfterDayjs(1).unix());
const isMin = computed<boolean>(() => innerValue.value.unix() === getTodayDayjs().unix());


watch(() => prop.value, (data) => {
  innerValue.value = data;
}, { immediate: true });

function getValueText(data: Dayjs): string {
  if (data.diff(getTodayDayjs(), 'd') === 1) {
    return '24:00';
  }
  return data.format('HH:mm');
}

function add(): void {
  if (isMax.value) {
    return;
  }
  const data = innerValue.value.add(prop.step, 'h');
  innerValue.value = data;
  onChange(data);
}

function subtract(): void {
  if (isMin.value) {
    return;
  }
  const data = innerValue.value.subtract(prop.step, 'h');
  innerValue.value = data;
  onChange(data);
}

function onChange(data: Dayjs): void {
  emit('change', data);
}
</script>

<template>
  <van-button class="stepper-van-button" :disabled="isMax" @click="add"><IconStepAdd /></van-button>
  <div class="text-center bg-2 text-white text-lg"
       style="width: 66px; height: 60px; line-height: 60px;"
  >{{ valueText }}</div>
  <van-button class="stepper-van-button" :disabled="isMin" @click="subtract"><IconStepSubtract /></van-button>
</template>
