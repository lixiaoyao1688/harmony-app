<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="2.182" viewBox="0 0 22 2.182">
    <path id="路径_4002" data-name="路径 4002" d="M213.909,204.322H194.091a1.091,1.091,0,1,1,0-2.182h19.818a1.091,1.091,0,1,1,0,2.182Z" transform="translate(-193 -202.141)" fill="#fff"/>
  </svg>
</template>