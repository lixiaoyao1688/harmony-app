<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import {fill2Zero} from '@/lib/time/util/time.util';
import IconStepAdd from '@/lib/aaruy-design/stepper/icons/IconStepAdd.vue';
import IconStepSubtract from '@/lib/aaruy-design/stepper/icons/IconStepSubtract.vue';
import '@/lib/aaruy-design/stepper/styles/stepper.style.css';


interface Prop {
  value: number;
  step1: number;
  step2: number;
  max1: number;
}

interface Emit {
  (e: 'change', data: number): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const min = 0;
const max2 = 1000;
const v1 = ref<number>(0);  // 整数部分
const v2 = ref<number>(0);  // 小数部分
const d = ref<number>(3); // 小数部分的位数

const t1 = computed<string>(() => v1.value.toString());
const t2 = computed<string>(() => fill2Zero(v2.value));  // 固定保留 3 位小数，所以需补齐前面的 '0';


watch(() => prop.value, (data) => {
  // https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Number/toFixed#%E6%8F%8F%E8%BF%B0
  // toFixed() 方法返回一个表示 numObj 的字符串，但不使用指数计数法，并且小数点后有精确到 digits 位的数字。
  // 如果需要截断，则将数字四舍五入；如果小数位数不足，则小数部分用零填充，以使其具有指定长度。
  const db = data.toFixed(3);
  const [itg, dec] = db.split('.');
  v1.value = +itg;
  v2.value = +dec;
}, { immediate: true });

function add(i: 1 | 2): void {
  const s = i == 1 ? prop.step1 : prop.step2;
  if (i === 1) {
    if (v1.value + s >= prop.max1) {
      return;
    }
    v1.value += s;
  }
  else {
    if (v2.value + s >= max2) {
      return;
    }
    v2.value += s;
  }
  onChange();
}

function subtract(i: 1 | 2): void {
  const s = i == 1 ? prop.step1 : prop.step2;
  if (i === 1) {
    if (v1.value - s < min) {
      return;
    }
    v1.value -= s;
  }
  else {
    if (v2.value - s < min) {
      return;
    }
    v2.value -= s;
  }
  onChange();
}

function onChange(): void {
  emit('change', +(t1.value + '.' + fill2Zero(+t2.value)));
}
</script>

<template>
  <div>
    <div class="flex justify-between">
      <van-button class="stepper-van-button" @click="add(1)"><IconStepAdd /></van-button>
      <van-button class="stepper-van-button" @click="add(2)"><IconStepAdd /></van-button>
    </div>
    <div class="bg-2 text-white text-lg w-full flex" style="height: 60px; line-height: 60px;">
      <span class="inline-block text-center" style="width: 66px;">{{ t1 }}</span>
      <span>.</span>
      <span class="inline-block text-center" style="width: 66px;">{{ t2 }}</span>
    </div>
    <div class="flex justify-between">
      <van-button class="stepper-van-button" @click="subtract(1)"><IconStepSubtract /></van-button>
      <van-button class="stepper-van-button" @click="subtract(2)"><IconStepSubtract /></van-button>
    </div>
  </div>
</template>
