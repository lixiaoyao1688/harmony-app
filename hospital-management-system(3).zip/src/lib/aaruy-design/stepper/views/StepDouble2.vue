<script setup lang="ts">
import {ref, watch} from 'vue';
import {fillPreZero} from '@/lib/time/util/time.util';
import IconStepAdd from '@/lib/aaruy-design/stepper/icons/IconStepAdd.vue';
import IconStepSubtract from '@/lib/aaruy-design/stepper/icons/IconStepSubtract.vue';
import '@/lib/aaruy-design/stepper/styles/stepper.style.css';


/**
 * 双值步进器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  value: string;  // 输入值，保留完整的小数位数，如 '2.05', '6.80' 等;
  digit: number;  // 保留的小数位数
  step0: number;  // 整数步长
  step1: number;  // 小数步长
  name0: string;  // 整数输入框名称
  name1: string;  // 小数输入框名称
}

interface Emit {
  (e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const v0 = ref<string>('');  // 整数部分
const v1 = ref<string>('');  // 小数部分

watch(() => prop.value, (data) => {
  // https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Number/toFixed#%E6%8F%8F%E8%BF%B0
  // toFixed() 方法返回一个表示 numObj 的字符串，但不使用指数计数法，并且小数点后有精确到 digits 位的数字。
  // 如果需要截断，则将数字四舍五入；如果小数位数不足，则小数部分用零填充，以使其具有指定长度。
  const [itg, dec] = data.split('.');
  v0.value = itg;
  v1.value = dec;
}, { immediate: true });

function onInputChange(i: 0 | 1, dataText: string): void {
  if (i === 0) {
    v0.value = dataText;
  }
  else {
    v1.value = dataText;
  }
  onChange();
}

function add(i: 0 | 1): void {
  const step = i === 0 ? prop.step0 : prop.step1;
  const data = i === 0 ? (+v0.value) : (+v1.value);
  const result = data + step;
  
  if (i === 0) {
    v0.value = result.toString();
  }
  else {
    v1.value = fillPreZero(result, prop.digit);
  }
  onChange();
}

function subtract(i: 0 | 1): void {
  const step = i === 0 ? prop.step0 : prop.step1;
  const data = i === 0 ? (+v0.value) : (+v1.value);
  const result = data - step;
  
  if (result < 0) {
    return;
  }
  if (i === 0) {
    v0.value = result.toString();
  }
  else {
    v1.value = fillPreZero(result, prop.digit);
  }
  onChange();
}

function onChange(): void {
  emit('change',v0.value + '.' + v1.value);
}
</script>

<template>
  <div>
    <div class="flex justify-between">
      <van-button class="stepper-van-button" @click="add(0)"><IconStepAdd /></van-button>
      <van-button class="stepper-van-button" @click="add(1)"><IconStepAdd /></van-button>
    </div>
    <div class="bg-2 text-white text-lg w-full flex" style="height: 60px; line-height: 60px;">
      <input :value="v0"
             :name="name0"
             placeholder="请输入"
             type="number"
             class="w-full text-center input-placeholder input-arrow-hidden text-lg"
             @input="event => onInputChange(0, event.target.value)" />
      <span>.</span>
      <input :value="v1"
             :name="name1"
             placeholder="请输入"
             type="number"
             class="w-full text-center input-placeholder input-arrow-hidden text-lg"
             @input="event => onInputChange(1, event.target.value)" />
    </div>
    <div class="flex justify-between">
      <van-button class="stepper-van-button" @click="subtract(0)"><IconStepSubtract /></van-button>
      <van-button class="stepper-van-button" @click="subtract(1)"><IconStepSubtract /></van-button>
    </div>
  </div>
</template>
