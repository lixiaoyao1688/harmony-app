<script setup lang="ts">
import {ref, watch} from 'vue';
import IconStepAdd from '@/lib/aaruy-design/stepper/icons/IconStepAdd.vue';
import IconStepSubtract from '@/lib/aaruy-design/stepper/icons/IconStepSubtract.vue';
import '@/lib/aaruy-design/stepper/styles/stepper.style.css';


/**
 * 单值步进器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: string;  // 输入值
  step: number;  // 步长
  digit: number;  // 保留的小数位数
  name: string;  // 输入框的 name
  width?: string;  // 默认 100%;
}

interface Emit {
  (e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<string>('');

watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function add(): void {
  const s = prop.step;
  const d = +value.value;
  value.value = (d + s).toFixed(prop.digit);
  onChange();
}

function subtract(): void {
  const s = prop.step;
  const d = +value.value;
  value.value = (d - s).toFixed(prop.digit);
  onChange();
}

function onChange(): void {
  emit('change', value.value);
}

function onInputChange(dataText: string): void {
  value.value = dataText;
  onChange();
}
</script>

<template>
  <div class="w-full">
    <van-button class="stepper-van-button" @click="add"><IconStepAdd /></van-button>
    <div class="bg-2 text-white text-lg" style="height: 60px; line-height: 60px;">
      <input :value="value"
             :name="name"
             placeholder="请输入"
             type="number"
             class="w-full text-center input-placeholder input-arrow-hidden text-lg"
             @input="event => onInputChange(event.target.value)" />
    </div>
    <van-button class="stepper-van-button" @click="subtract"><IconStepSubtract /></van-button>
  </div>
</template>
