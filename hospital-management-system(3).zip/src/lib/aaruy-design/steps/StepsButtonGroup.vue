<script setup lang="ts">
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


/**
 * 步骤条按钮组 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  isFirst: boolean;
  isLast: boolean;
  height: string;
  padding?: string;
}

interface Emit {
	(e: 'prev'): void;
	(e: 'next'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onPrev(): void {
  emit('prev');
}

function onNext(): void {
  emit('next');
}
</script>

<template>
  <div class="flex items-center justify-between" :style="{ height: height, padding: padding }">
    <ButtonView v-if="!isFirst" type="default" style="width: 49%; font-size: 16px;" text="上一步" @click="onPrev" />
    <ButtonView type="primary" style="font-size: 16px;" :style="{ width: isFirst ? '100%' : '49%' }" :text="isLast ? '确定' : '继续'"
                @click="onNext" />
  </div>
</template>
