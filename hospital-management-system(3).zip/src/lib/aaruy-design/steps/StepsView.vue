<script setup lang="ts">
import {computed} from 'vue';
import StepItem from '@/lib/aaruy-design/steps/component/StepItem.vue';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 步骤条 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  items: Array<ItemType2>;
  item: ItemType2;
  height: string;
  padding?: string;
}

const prop = defineProps<Prop>();
const index = computed<number>(() => getIndex(prop.item, prop.items));

function getIndex(data: ItemType2, list: Array<ItemType2>): number {
  return list.findIndex(it => it.id === data.id);
}
</script>

<template>
  <div class="flex items-center" :style="{ height: height, padding: padding }">
    <StepItem v-for="(it,i) in items" :key="it.id"
              :id="getIndex(it, items) + 1"
              :item="it"
              :is-current="it.id === item.id"
              :is-completed="i < index"
              :is-last="i === items.length - 1" />
  </div>
</template>
