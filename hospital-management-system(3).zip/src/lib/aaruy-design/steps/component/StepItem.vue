<script setup lang="ts">
import StepItemId from '@/lib/aaruy-design/steps/component/StepItemId.vue';
import type {ItemType2} from '@/lib/aaruy-design/select/frame/select.frame.type';


/**
 * 步骤条 项
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  id: number;  // 序号，从1开始
  item: ItemType2;  // 步骤项
  isCurrent?: boolean;  // 是否为当前步骤
  isCompleted?: boolean;  // 是否已完成
  isLast?: boolean;  // 是否是最后一个步骤
}

const prop = defineProps<Prop>();
</script>

<template>
  <div v-if="isLast" style="width: 56px; height: 100%;">
    <div style="width: 100%;" class="inline-flex justify-center">
      <StepItemId :id="id" :is-current="isCurrent" :is-completed="isCompleted" />
    </div>
    <div style="width: 100%; height: 28px;" class="pt-4 text-center text-white font-bold text-xs">{{ item.text }}</div>
  </div>
  <div v-else style="height: 100%;" class="flex-1">
    <div style="width: 100%; height: 32px;" class="inline-flex">
      <div style="width: 56px;" class="inline-flex justify-center">
        <StepItemId :id="id" :is-current="isCurrent" :is-completed="isCompleted" />
      </div>
      <div style="width: calc(100% - 56px); height: 50%; border-bottom-width: 1px;"
           :style="{
               'border-bottom-style': isCompleted ? 'solid' : 'dashed',
               'border-bottom-color': isCompleted ? 'var(--aaruy-primary-color-1)' : 'var(--aaruy-default-color-3)',
             }"
      ></div>
    </div>
    <div style="width: 56px; height: 28px;" class="pt-4 text-center text-white font-bold text-xs">{{ item.text }}</div>
  </div>
</template>
