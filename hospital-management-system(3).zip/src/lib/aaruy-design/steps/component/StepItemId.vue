<script setup lang="ts">
import {computed} from 'vue';
import IconCompleted from '@/lib/aaruy-design/steps/icon/IconCompleted.vue';


/**
 * 步骤条 项 序号
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  id: number;  // 序号，从1开始
  isCurrent?: boolean;  // 是否为当前步骤
  isCompleted?: boolean;  // 是否已完成
}

const prop = defineProps<Prop>();
const isActived = computed<boolean>(() => prop.isCurrent || prop.isCompleted);
</script>

<template>
  <div style="width: 32px; height: 32px; line-height: 32px;" :class="{ 'bg-primary': isActived, 'bg-default-3': !isActived }"
       class="rounded-full text-white font-bold text-s inline-flex items-center justify-center">
    <IconCompleted v-if="isCompleted" /><template v-else>{{ id }}</template>
  </div>
</template>
