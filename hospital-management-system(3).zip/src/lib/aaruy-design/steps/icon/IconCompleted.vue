<script setup lang="ts">
/**
 * 已完成 图标
 *
 * 适用设备
 * 平板 && 手机;
 */
</script>

<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="14.083" viewBox="0 0 18 14.083">
    <path d="M112.517,184.541l-8.861,10.036-4.171-4.464a1.419,1.419,0,1,0-2.073,1.937l5.235,5.61a1.419,1.419,0,0,0,2.1-.03l9.9-11.21a1.419,1.419,0,1,0-2.126-1.876Z"
          transform="translate(-97.03 -184.026)"
          fill="#fff" />
  </svg>
</template>
