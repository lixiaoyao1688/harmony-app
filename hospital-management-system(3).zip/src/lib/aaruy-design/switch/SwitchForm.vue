<script setup lang="ts">
import '@/lib/aaruy-design/switch/switch.form.style.css';


interface Prop {
	title: string;
	data: boolean;
	hideBorder?: boolean;
}

interface Emit {
	(e: 'change', data: boolean): void
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function change(data: boolean) {
  emit('change', data);
}
</script>

<template>
	<div class="flex justify-between items-center switch-form" :class="{ 'hide-border': hideBorder }">
		<span class="text-s">{{ title }}</span>
		<a-switch :checked="data" @change="change"></a-switch>
	</div>
</template>

<style scoped>
.switch-form {
	height: 51px;
	border-bottom: 2px solid var(--aaruy-border-color-1);
}
.switch-form:hover {
	border-bottom-color: var(--aaruy-primary-color-2) !important;
}

.hide-border {
	border-bottom: none;
}
</style>
