<script setup lang="ts">
import '@/lib/aaruy-design/switch/switch.table.style.css';


interface Prop {
  data: boolean;
}

interface Emit {
  (e: 'change', data: boolean): void
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function change(data: boolean) {
  emit('change', data);
}

</script>

<template>
  <a-switch :checked="data" class="switch-table" @change="change"></a-switch>
</template>
