<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/switch/switch.style.css';
import '@/lib/aaruy-design/switch/switch.mobile.style.css';


/**
 * 开关 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  checked: boolean;
}

interface Emit {
	(e: 'change', data: boolean): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const value = ref<boolean>(false);

const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.checked, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: boolean): void {
  value.value = data;
  emit('change', data);
}
</script>

<template>
  <div v-if="pc" class="switch-view">
    <a-switch v-model:checked="value" @change="onChange"></a-switch>
  </div>
  <template v-else>
    <van-switch v-model="value" class="switch-view-mobile" @change="onChange" />
  </template>
</template>
