<script setup lang="ts">
import { computed } from 'vue';
import { ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/switch/field/switch.field.style.css';


/**
 * 字段开关 组件
 * pc && mobile;
 */
interface Prop {
  title: string;
  height: string;
  value: boolean;
  width?: string;  // 仅APP
  fontSize?: string;  // 默认16px, 仅APP
  showBorderBottom?: boolean;  // 仅APP
  isDisabled?: boolean;  // 仅APP
}

interface Emit {
  (e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const isChecked = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.value, (data) => {
  isChecked.value = data;
}, { immediate: true });

function onCheckedChange(v: boolean): void {
  isChecked.value = v;
  emit('change', v);
}
</script>

<template>
  <div v-if="pc"
       :style="{ height: height }"
       class="flex items-center justify-between border-b-default border-hover-primary-4 pl-16 pr-24">
    <span class="text-s">{{ title }}</span>
    <a-switch :checked="isChecked" class="switch-field-pc" @change="onCheckedChange"></a-switch>
  </div>
  <div v-if="mobile"
       :style="{ height: height, width: width }"
       :class="{ 'border-b-bg-1': showBorderBottom }"
       class="flex items-center justify-between">
    <span :style="{ fontSize: fontSize || '16px' }">{{ title }}</span>
    <a-switch :checked="isChecked" :disabled="isDisabled" class="switch-field-mobile" @change="onCheckedChange"></a-switch>
  </div>
</template>
