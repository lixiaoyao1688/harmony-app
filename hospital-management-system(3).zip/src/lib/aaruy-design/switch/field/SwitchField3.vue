<script setup lang="ts">
/**
 * 开关 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  data: boolean;
  isRequired?: boolean;
  height?: string;
  padding?: string;  // 默认 "0 0 4px";
  fontSize?: string;  // 默认 16px;
}

interface Emit {
	(e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(data: boolean): void {
  emit('change', data);
}
</script>

<template>
  <div :style="{ height: height, padding: padding || '0 0 4px', fontSize: fontSize || '16px' }"
       class="flex items-center justify-between text-white border-b-bg-0"
  >
    <div v-if="isRequired">
      <span class="text-error-2">*</span>
      <span>{{ title }}</span>
    </div>
    <div v-else>{{ title }}</div>
    <van-switch :model-value="data" :size="fontSize || '16px'" class="switch-field-3"
                active-color="rgb(105,158,245)" inactive-color="rgb(153,153,153)"
                @update:model-value="onChange" />
  </div>
</template>

<style scoped>
.switch-field-3 {
  --van-switch-width: 40px;
}
</style>
