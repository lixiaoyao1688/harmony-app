export class TabVO {
	public key: any;  // 对应 activeKey
	public tab: string;   // 选项卡头显示文字
	public icon: string;  // 图标HTML
	public children: TabVO[];  // 子结点
	
	constructor(k: any, t: string, icon?: string, c?: TabVO[]) {
	  this.key = k;
	  this.tab = t;
	  this.icon = icon || '';
	  this.children = c || [];
	}
	
	public static emptyVO(): TabVO {
	  return new TabVO(1,'');
	}
}
