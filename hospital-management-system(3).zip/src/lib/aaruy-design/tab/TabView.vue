<script setup lang="ts">
import { computed } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import type { TabType } from '@/lib/aaruy-design/tab/types/tab.type';


interface Prop {
	type: TabType;
	items: Array<SelectorFormItemVO>;
	item: SelectorFormItemVO;
}

interface Emit {
	(e: 'itemChange', item: SelectorFormItemVO): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isDefault = computed<boolean>(() => prop.type === 'default');
const isVertical = computed<boolean>(() => prop.type === 'vertical');


function select(data: SelectorFormItemVO) {
  emit('itemChange', data);
}
</script>

<template>
	<div
		v-bind="$attrs"
		class="ar-tab"
		:class="{
			'ar-tab-default': isDefault,
			'ar-tab-vertical': isVertical,
		}"
	>
		<span
			v-for="it in items"
			:key="it.id"
			class="ar-tab-item"
			:class="{ actived: it.id === item.id }"
			@click="select(it)">
			{{ it.text }}
		</span>
	</div>
</template>

<style scoped>
/* 通用 */
.ar-tab > .ar-tab-item:not(.actived):hover {
	background-color: rgb(38,111,232);
}


/* vertical */
.ar-tab-vertical {
	display: flex;
	flex-direction: column;
	width: 100px;
	height: 100%;
	background-color: rgb(37,43,48);
}
.ar-tab-vertical > .ar-tab-item {
	height: 50px;
	line-height: 50px;
	text-align: center;
	cursor: default;
	font-size: 16px;
}
.ar-tab-vertical > .ar-tab-item.actived {
	background-color: rgb(67,80,91);
}


/* default */
.ar-tab-default {
	display: flex;
	color: rgb(0,0,0);
	font-size: 18px;
	background-color: rgb(163,175,188);
}
.ar-tab-default > .ar-tab-item {
	width: 100%;
	height: 100%;
	display: inline-block;
	cursor: pointer;
	padding: 10px 15px;
	text-align: center;
	border-right: 1px solid rgba(112,112,112,0.5);
}
.ar-tab-default > .ar-tab-item.actived {
	background-color: rgb(204,214,225);
}
</style>
