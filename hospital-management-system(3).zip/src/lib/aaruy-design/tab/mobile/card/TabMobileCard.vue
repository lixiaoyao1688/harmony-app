<script setup lang="ts">
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';

/**
 * 标签选择 组件
 * mobile;
 */
type TabItem = SelectItemVO<unknown>;

interface Prop {
  items: Array<TabItem>;
  item: TabItem;
  height?: string;  // 默认 100%;
}

interface Emit {
	(e: 'change', data: TabItem): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(data: TabItem): void {
  emit('change', data);
}
</script>

<template>
  <div :style="{ height: height || '100%' }">
  
  </div>
</template>
