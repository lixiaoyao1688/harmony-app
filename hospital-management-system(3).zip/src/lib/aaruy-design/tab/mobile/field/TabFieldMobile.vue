<script setup lang="ts">
import {useScreenStore} from '@/lib/screen/store/screen.store';
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';

/**
 * 标签选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
type ItemType = SelectItemVO<unknown>;

interface Prop {
  items: Array<ItemType>;
  item: ItemType;
}

interface Emit {
	(e: 'change', data: ItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();

function onChange(data: ItemType): void {
  emit('change', data);
}
</script>

<template>
  <div class="flex items-center rounded-4">
    <div v-for="(it,i) in items" :key="it.id"
         style="height: 32px; line-height: 30px;"
         class="item rounded-4 font-bold text-center px-4"
         :class="{
             'selected-item': it.id === item.id,
             'text-xs': screenStore.isNewPhone,
             'text-s': !screenStore.isNewPhone,
             'ml-4': i > 0 && screenStore.isNewPhone,
             'ml-16': i > 0 && !screenStore.isNewPhone,
           }"
         @click="onChange(it)">{{ it.text }}</div>
  </div>
</template>

<style scoped>
.item {
  color: rgb(162,173,184);
  border-width: 1px;
  border-style: solid;
  border-color: rgb(36,44,51);
  background-color: rgb(36,44,51);
}

.selected-item {
  color: rgb(245,245,245);
  border-color: rgb(105,158,245);
  background-color: rgba(105,158,245,0.2);
}
</style>
