<script setup lang="ts">
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';


interface Prop {
  item: SelectorFormItemVO;
  items: SelectorFormItemVO[];
  isAdmissionDetail?: boolean;  // 是否用于患者详情页
	isPrimary?: boolean;
  useBlockStyle?: boolean;
  isCompactMode?: boolean;  // 是否使用紧凑模式，仅 useBlockStyle 为 true 时可用;
  isRedPointShowed?: boolean;  // 是否在末尾的 item 右上角展示小红点，仅 useBlockStyle 为 true 时可用;
  enabledWarp?: boolean; // 是否允许换行。仅 useBlockStyle 为 true 可用;
  itemHeight?: string; // 仅 useBlockStyle 为 true 可用; 默认 28px;
  itemMinHeight?: string; // 仅 useBlockStyle 为 true 可用;
  itemWidth?: string;  // 仅 useBlockStyle 为 true 可用;
}

interface Emit {
  (e: 'change', item: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();


function change(item: SelectorFormItemVO): void {
  emit('change', item);
}
</script>

<template>
  
  <div v-if="useBlockStyle" class="flex items-center justify-center">
    <div>
      <div v-for="(it,i) in items" :key="it.id"
            :class="{
              'ml-6': i > 0 && isCompactMode,
              'ml-12': i > 0 && !isCompactMode,
              'px-6': isCompactMode,
              'px-12': !isCompactMode,
              'text-weak-8 border-bg-15': it.id !== item.id,
              'text-primary-6 border-primary font-bold': it.id === item.id,
            }"
            class="inline-flex items-center text-center rounded-4 bg-15 relative"
            :style="{ width: itemWidth, height: itemHeight || '28px', minHeight: itemMinHeight }"
            @click="change(it)">
        <span>{{ it.text }}</span>
        <span v-if="i === items.length - 1 && isRedPointShowed" class="absolute rounded-full bg-not-resolved inline-block"
              style="width: 8px; height: 8px; right: 2px; top: 2px;"></span>
      </div>
    </div>
  </div>
  <div v-else class="tab-form-mobile"
      :class="{
			'tab-form-mobile-admission-detail': isAdmissionDetail,
			'tab-form-primary': isPrimary,
		}"
    >
    <span
      v-for="(it,i) in items"
      :key="it.id"
      :class="{
				selected: it.id === item.id,
				'border-radius': items.length === 1,
				'last-border-radius': items.length > 1 && i === items.length,
			}"
      @click="change(it)"
    >
      {{ it.text }}
    </span>
    </div>
  
</template>


<style scoped>
.tab-form-mobile.tab-form-primary {
	display: inline-block;
	width: fit-content;
	background-color: transparent;
}

.tab-form-mobile.tab-form-primary > span {
	display: inline-block;
	height: 100%;
	padding: 0 16px;
	background-color: var(--aaruy-bg-color-2);
}

.border-radius {
	border-radius: 4px;
}

.last-border-radius {
	border-radius: 0 4px 4px 0;
}

.first-border-radius {
	border-radius: 4px 0 0 4px;
}

.tab-form-mobile.tab-form-primary > span.selected {
	background-color: var(--aaruy-primary-color-1);
}

.tab-form-mobile {
  width: 100%;
  display: flex;
}

.tab-form-mobile-admission-detail {
  height: var(--admission-detail-mobile-tab-form-height);
}

.tab-form-mobile > span {
  flex-grow: 1;
  text-align: center;
  color: rgb(255,255,255);
  background-color: rgb(37,43,48);
  font-size: 14px;
  height: var(--tab-form-height);
  line-height: var(--tab-form-height);
	border-bottom: 2px solid transparent;
}

.tab-form-mobile > span:hover {
	background-color: rgb(67,80,91);
}

.tab-form-mobile > span.selected {
	background-color: rgb(67,80,91);
	border-bottom-color: var(--aaruy-primary-color-1);
}
</style>
