<script setup lang="ts">
import { ref, computed } from 'vue';
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/tab/mobile/normal/tab.normal.mobile.style.css';
import type {TabNormalExposedType} from '@/lib/aaruy-design/tab/mobile/normal/tab.normal.type';


interface Prop {
  item: SelectorFormItemVO;
  items: Array<SelectorFormItemVO>;
  map: Map<number, SelectorFormItemVO>;
  lineWidth?: number;  // 下划线宽度
  useWhite?: boolean;  // 激活颜色是否使用白色
  useWhiteOnUnSelected?: boolean;  //  未选中颜色是否使用白色
  isMarginRight0?: boolean;  // 是否让每个项的 margin-right 置为 0
  margin?: string;
}

interface Emit {
  (e: 'change', item: SelectorFormItemVO): void;
}

defineExpose<TabNormalExposedType>({
  rerender
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const tabsRef = ref(null);
const activedId = computed<number>(() => prop.item.id);

function rerender(): void {
  if (tabsRef.value) {
    // 重新渲染UI
    tabsRef.value.resize();
  }
}

function change(e): void {
  const id = e.name;
  emit('change', prop.map.get(id) as SelectorFormItemVO);
}
</script>

<template>
  <van-tabs ref="tabsRef"
            class="tab-normal-mobile"
            :line-width="lineWidth || 40" :active="activedId"
            :class="{
              'tab-normal-mobile-white': useWhite,
              'tab-normal-mobile-unselected-white': useWhiteOnUnSelected,
              'tab-normal-mobile-margin-right-0': isMarginRight0,
            }"
            :style="{ margin: margin }"
            @click-tab="change">
    <van-tab v-for="it in items" :key="it.id" :name="it.id" :title="it.text" />
  </van-tabs>
</template>
