export interface TabNormalExposedType {
  rerender: () => void;
}
