<script setup lang="ts">
import { ref, watch } from 'vue';
import { TabVO } from '@/lib/aaruy-design/tab/Tab.vo';
import '@/lib/aaruy-design/tab/tab-body/tab.body.style.css';


interface Prop {
  activeKey: any
  options: TabVO[]
}

interface Emit {
  (e: 'change', key: any): void
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const activedName = ref<any>(prop.activeKey);


watch(() => prop.activeKey, (newValue) => {
  activedName.value = newValue;
});

function onChange(key) {
  emit('change', key);
}
</script>

<template>
  <a-tabs v-model:activeKey="activedName" @change="onChange" class="tab-body">
    <a-tab-pane v-for="o in options" :key="o.key" :tab="o.tab"></a-tab-pane>
  </a-tabs>
</template>
