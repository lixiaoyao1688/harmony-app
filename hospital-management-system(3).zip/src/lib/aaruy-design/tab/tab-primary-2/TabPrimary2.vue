<script setup lang="ts">
import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import type {TabItemType} from '@/lib/aaruy-design/tab/tab-primary-2/type/tab.primary2.type';
import '@/lib/aaruy-design/tab/tab-primary-2/tab.primary2.style.css';


/**
 * 标签页 组件
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
  items: Array<TabItemType>;
  item: TabItemType;
  itemMap: Map<number, TabItemType>;
  isBorderBottomNone?: boolean;
}

interface Emit {
  (e: 'change', data: TabItemType): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(id: number): void {
  emit('change', SelectItemVO.getItem(prop.itemMap, id));
}
</script>

<template>
  <a-tabs :activeKey="item.id" class="tab-primary-2" :class="{ 'tab-primary-2-border-bottom-none': isBorderBottomNone }"
          @tabClick="onChange">
    <a-tab-pane v-for="it in items" :key="it.id">
      <template #tab>{{ it.text }}</template>
    </a-tab-pane>
  </a-tabs>
</template>
