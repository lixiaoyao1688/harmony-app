import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export type TabItemType = SelectItemVO<any>;
