<script setup lang="ts">
interface Prop {
  isDown: boolean;
}

interface Emit {
  (e: 'click'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onClick(): void {
  emit('click');
}
</script>

<template>
  <div class="inline-flex" :style="{ transform: `rotate(${isDown ? '0' : '180deg'})` }" @click="onClick">
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="6.888" viewBox="0 0 12 6.888">
      <path id="路径_2506" data-name="路径 2506" d="M5.931,226.017a.86.86,0,0,1-.611-.25L.157,220.6a.864.864,0,0,1,1.222-1.222l4.552,4.561,4.552-4.552A.861.861,0,0,1,11.7,220.6l-5.163,5.163A.861.861,0,0,1,5.931,226.017Z" transform="translate(0.096 -219.129)" fill="#fff"/>
    </svg>
  </div>
</template>
