<script setup lang="ts">
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import '@/lib/aaruy-design/tab/tab-primary/tab.primary.style.css';


/**
 * 标签页 UI
 */
interface Prop {
  items: Array<SelectorFormItemVO>;
  item: SelectorFormItemVO;
  itemMap: Map<number, SelectorFormItemVO>;
  height?: string;
  useFontSize18?: boolean;
  useFontActivedColor?: boolean;
  gap?: number;  // 标签之间的间隙(px)
}

interface Emit {
	(e: 'change', it: SelectorFormItemVO): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(id: number): void {
  emit('change', SelectorFormItemVO.getItem(prop.itemMap, id));
}
</script>

<template>
  <a-tabs :activeKey="item.id" class="tab-primary"
          :class="{ 'tab-primary-font-18': useFontSize18, 'use-font-actived-color': useFontActivedColor }"
          :style="{ height: height || 'fit-content' }"
          :tab-bar-gutter="gap"
          @tabClick="onChange">
    <a-tab-pane v-for="it in items" :key="it.id">
      <template #tab>{{ it.text }}</template>
    </a-tab-pane>
  </a-tabs>
</template>
