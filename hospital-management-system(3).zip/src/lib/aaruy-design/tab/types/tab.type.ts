export type TabType = 'default' | 'vertical';
