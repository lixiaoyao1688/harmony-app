export interface TableDetailKey {
	id: number;
	key: string;  // 键
	text: string;  // 中文
	extraText?: string;  // 额外的中文
	width: string;  // 宽度百分比
	color?: string;  // 字体颜色
}