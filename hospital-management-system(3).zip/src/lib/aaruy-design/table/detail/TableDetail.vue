<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { TableDetailKey } from '@/lib/aaruy-design/table/detail/Table.Detail.vo';
import EmptyView from '@/lib/aaruy-design/empty/EmptyView.vue';


interface Prop {
  keys: TableDetailKey[];
  data: Array<Object>;
  maxHeight?: number | string;  // 表格体的最大高度，仅 mobile;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <template v-if="pc">
    <div class="table-detail table-detail-clinic">
      <div class="table-detail-header flex bg-default-2 text-black">
      <span
        v-for="h in keys"
        :key="h.id"
        :style="{ width: h.width }"
        class="cell"
      >
        <template v-if="h.extraText">
          <span class="block leading-m">{{ h.text }}</span>
          <span class="block leading-m">{{ h.extraText }}</span>
        </template>
        <template v-else>{{ h.text }}</template>
      </span>
      </div>
      <div class="table-detail-body bg-2" :style="{ height: 'calc(100% - 50px)' }" style="border-radius: 0 0 5px 5px;">
        <div v-if="data.length === 0" class="text-weak-8 text-xl font-bold text-center pt-100">暂无数据</div>
        <div v-for="(d,i) in data"
             :key="i"
             :style="{ borderBottom: i < data.length-1 ? '1px solid var(--aaruy-bg-color-3)' : null }"
             class="flex py-4"
        >
          <span
            v-for="k in keys"
            :key="k.id"
            :style="{ width: k.width, color: k.color }"
            class="inline-flex items-center justify-center text-s text-white"
            :class="{ 'flex-col': d[k.key][1] }"
            style="min-height: 45px; padding: 8px 10px; overflow-wrap: break-word;"
          >
            <!--  "操作信息"列单独处理 -->
            <template v-if="k.key === 'info'">
              <!--  有两行数据时，展示两行  -->
              <template v-if="d[k.key][1]">
                <i class="extra" :title="d[k.key][0]">{{ d[k.key][0] }}</i>
                <i class="extra" :title="d[k.key][1]">{{ d[k.key][1] }}</i>
              </template>
              <!--  只有一行数据时，展示一行  -->
              <template v-else>{{ d[k.key][0] }}</template>
            </template>
            <!--  其他列只展示一行   -->
            <template v-else>{{ d[k.key] }}</template>
          </span>
        </div>
      </div>
    </div>
  </template>
  <template v-if="mobile">
    <div class="table-detail table-detail-mobile bg-2">
      <div class="table-detail-header flex bg-1 text-white">
        <span
        v-for="h in keys"
        :key="h.id"
        :style="{ width: h.width }"
        class="cell"
      >
        <template v-if="h.extraText">
          <span class="block leading-m">{{ h.text }}</span>
          <span class="block leading-m">{{ h.extraText }}</span>
        </template>
        <template v-else>{{ h.text }}</template>
      </span>
      </div>
      <div v-if="!data || data.length === 0" style="height: 240px;">
        <EmptyView words="暂无数据" item-center />
      </div>
      <div v-else class="table-detail-body" :style="{ height: null, maxHeight: mobile && maxHeight ? (typeof maxHeight === 'number' ? maxHeight + 'px' : maxHeight) : null }">
        <div v-for="(d,i) in data" :key="i" class="table-detail-body-row bg-2 flex items-center py-8">
          <span
            v-for="k in keys"
            :key="k.id"
            :style="{ width: k.width, color: k.color }"
            class="cell ellipsis"
          >
            <!--  "操作信息"列单独处理 -->
            <template v-if="k.key === 'info'">
              <!--  有两行数据时，展示两行  -->
              <template v-if="d[k.key][1]">
                <i class="extra" :title="d[k.key][0]">{{ d[k.key][0] }}</i>
                <i class="extra" :title="d[k.key][1]">{{ d[k.key][1] }}</i>
              </template>
              <!--  只有一行数据时，展示一行  -->
              <template v-else>
                <span class="ellipsis single-span" :title="d[k.key][0]">{{ d[k.key][0] }}</span>
              </template>
            </template>
            <!--  其他列只展示一行   -->
            <template v-else>
              <span class="ellipsis single-span" :title="d[k.key]">{{ d[k.key] }}</span>
            </template>
          </span>
        </div>
      </div>
    </div>
  </template>
</template>

<style scoped>
.table-detail {
  width: 100%;
  height: 100%;
}

.table-detail-clinic .table-detail-header {
  color: var(--aaruy-text-color);
  background-color: var(--aaruy-bg-color-3);
  font-size: 16px;
  line-height: 21px;
}

.table-detail-clinic .table-detail-body-row {
  background-color: var(--aaruy-bg-color-2);
}

.table-detail-header {
  height: 50px;
  border-radius: 5px 5px 0 0;
}

.table-detail-body {
  overflow-y: auto;
}

.table-detail-body-row {
  box-sizing: border-box;
  margin-bottom: 1px;
}

.table-detail-body-row:not(:last-child) {
  border-bottom: 1px solid rgb(0, 0, 0);
}

.table-detail-body-row:last-child {
  border-radius: 0 0 5px 5px;
}

.table-detail-body-row .cell {
	color: var(--aaruy-text-color);
  padding: 0 10px;
  height: 45px;
  line-height: 45px;
}

.cell {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  height: 100%;
  font-size: 16px;
}

.extra {
  display: block;
  height: 24px;
  line-height: 26px;
  font-size: 15px;
  font-style: normal !important;
}

.single-span {
  display: block;
}

/* mobile */
.table-detail-mobile {
  height: fit-content;
  margin-bottom: 16px;
}
</style>
