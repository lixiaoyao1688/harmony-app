<script setup lang="ts">
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/table/device-record/table.device.record.style.css';
import type { TableColumnType } from 'ant-design-vue';


interface Prop {
  columns: TableColumnType[];
  data: unknown[];
  loading: boolean;
}

const prop = defineProps<Prop>();

const screenStore = useScreenStore();
</script>

<template>
  <a-table
    :columns="columns"
    :data-source="data"
    :loading="loading"
    :pagination="false"
    :bordered="false"
    class="table-device-record"
    :class="{ 'table-device-record-mobile': screenStore.isMobile }"
  >

    <template #bodyCell="{ column, record }">
      <!--  操作 单元格   -->
      <template v-if="column.dataIndex === 'operator'">
        <slot name="operator" :column="column" :record="record"></slot>
      </template>
      <!--  基本信息 单元格 -->
      <template v-else>
        <slot name="cell" :column="column" :record="record"></slot>
      </template>
    </template>

  </a-table>
</template>
