<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue';


const height = ref<number>(window.innerHeight);
const listener = () => {
  height.value = window.innerHeight;
};

onMounted(() => {
  window.addEventListener('resize', listener);
});

onUnmounted(() => {
  window.removeEventListener('resize', listener);
});
</script>

<template>
	<div>
		<slot :height="height"></slot>
	</div>
</template>
