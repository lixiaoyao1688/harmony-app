<script setup lang="ts">
import { TableModalOption } from '@/lib/aaruy-design/table/modal/table.modal';


interface Prop {
  options: Array<TableModalOption>;
  mobile?: boolean;
}

const prop = defineProps<Prop>();

</script>


<template>
  <div class="table-modal" :class="{ 'table-modal-mobile': mobile }">

    <template v-if="!mobile">
      <div class="table-modal-option" v-for="o in options" :key="o.id">
        <div class="table-modal-option-title">{{ o.title }}</div>
        <div class="table-modal-option-content">{{ o.content }}</div>
      </div>
    </template>

    <template v-if="mobile">
      <div class="table-modal-option-mobile" v-for="o in options" :key="o.id">
        <div class="mobile-text mobile-text-1">{{ o.title }}</div>
        <div class="mobile-text mobile-text-2">{{ o.content }}</div>
      </div>
    </template>

  </div>
</template>


<style scoped>
.table-modal {
  color: rgb(255, 255, 255);
  padding: 30px 24px;
}

.table-modal-option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 45px;
  font-size: 16px;
}

/* mobile */
.table-modal-mobile {
  padding: 36px 24px;
}

.table-modal-option-mobile {
  display: flex;
  justify-content: space-between;
  font-size: 16px;
}

.table-modal-option-mobile:not(:last-of-type) {
  margin-bottom: 17px;
}

.table-modal-option-mobile .mobile-text {
  display: flex;
  align-items: flex-start;
  height: 100%;
}

.table-modal-option-mobile .mobile-text-1 {
  width: 100px;
}

.table-modal-option-mobile .mobile-text-2 {
  flex: 1;
  word-break: break-all;
  display: flex;
  justify-content: flex-end;
  text-align: right;
}
</style>
