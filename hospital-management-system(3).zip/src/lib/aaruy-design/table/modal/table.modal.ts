export class TableModalOption {
	
	public id: number;
	public title: string;
	public content: string;
	
	constructor(id: number, t: string, c: string) {
	  this.id = id;
	  this.title = t;
	  this.content = c;
	}
}