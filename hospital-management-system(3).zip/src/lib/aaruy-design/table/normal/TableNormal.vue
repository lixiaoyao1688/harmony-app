<script setup lang="ts">
import {computed, watch} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { DEFAULT_PAGE_SIZE, FIRST_PAGE } from '@/lib/aaruy-design/table/table';
import { TABLE_PAGE_SIZE_OPTIONS } from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import PaginationView from '@/lib/aaruy-design/pagination/PaginationView.vue';
import '@/lib/aaruy-design/table/normal/style/table.normal.style.css';
import '@/lib/aaruy-design/selector/filter/select.filter.dropdown.style.css';
import type { SorterResult } from 'ant-design-vue/lib/table/interface';
import type { TableColumnsType, TablePaginationConfig, TableProps } from 'ant-design-vue';
import type { TableColumnVO, TableVO } from '@/lib/aaruy-design/table/normal/vo/Table.vo';
import type { PaginationData } from '@/lib/aaruy-design/pagination/pagination.vo';
import type {TableNormalSortData} from '@/lib/aaruy-design/table/normal/type/table.normal.type';


interface Prop {
  loading: boolean;  // 是否处于加载状态
  columns: TableColumnsType<TableColumnVO>;  // 列
  dataSource: TableVO<unknown>[];  // 数据源
  pagination: TablePaginationConfig;  // 分页配置
  rowSelection?: TableProps['rowSelection'];  // 可选择行时的配置
	isTotalHidden?: boolean;  // 是否隐藏 total 展示
  scroll?: { x?: string | number | true, y?: string | number, scrollToFirstRowOnChange?: boolean };  // 表格滚动配置
  isMinHeightEnabled?: boolean;  // 是否用 scroll.y 设置表格的最小高度
}

interface Emit {
  (e: 'onChange', p: PaginationData): void;  // 表格变化时触发
  (e: 'onSortChange', data: TableNormalSortData): void;  // 表格变化时触发
}

const emit = defineEmits<Emit>();
const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.scroll, (data) => {
  if (!data || !prop.isMinHeightEnabled) {
    return;
  }
  const el = document.getElementsByClassName('ant-table-body')[0] as HTMLElement;
  if (el && el.style && prop.scroll) {
    el.style.minHeight = prop.scroll.y + 'px';
  }
}, { immediate: true });

function onChange(data: TablePaginationConfig, _, sorterData: SorterResult) {
  if (sorterData) {
    if (sorterData.order) {
      emit('onSortChange', { field: sorterData.field as string, order: sorterData.order });
    }
    else {
      emit('onSortChange', { field: sorterData.field as string, order: null });
    }
    return;
  }
  onPaginationChange({ page: data.current || FIRST_PAGE, pageSize: data.pageSize || DEFAULT_PAGE_SIZE });
}

function onPaginationChange(data: PaginationData) {
  emit('onChange', data);
}
</script>

<template>
  <a-table
		class="table-normal"
		:class="{ 'table-normal-mobile': mobile }"
		:loading="{ spinning: loading, tip: '加载中...' }"
		:columns="columns"
		:dataSource="dataSource"
		:pagination="pc ? false : pagination"
		:bordered="false"
		:scroll="scroll"
		:showSorterTooltip="false"
		:locale="{ items_per_page: '条/页' }"
    :row-selection="rowSelection"
		@change="onChange"
  >
    <!--
      TABLE 表头
      column {ITableColumnVO}:      Antd 规定的列结构
      record {ITableDateSourceVO}:  VO 实例处理成的 Table DataSource 结构
    -->
    <template #headerCell="{ column, record }">
      <slot name="header" :column="column" :record="record"></slot>
    </template>
    <!--
      TABLE 单元格
      column {ITableColumnVO}:      Antd 规定的列结构
      record {ITableDateSourceVO}:  VO 实例处理成的 Table DataSource 结构
    -->
    <template #bodyCell="{ column, record }">
      <!--  操作 单元格   -->
      <template v-if="column.dataIndex === 'operator'">
        <slot name="operator" :column="column" :record="record"></slot>
      </template>
      <!--  基本信息 单元格 -->
      <template v-else>
        <slot name="cell" :column="column" :record="record"></slot>
      </template>
    </template>
  </a-table>
  <slot name="pagination"
        :show-total="isTotalHidden ? null : (total) => `共 ${total} 条`"
        :options="TABLE_PAGE_SIZE_OPTIONS"
        :total="pagination.total"
        :page-size="pagination.pageSize"
        :page="pagination.current"
  >
    <div class="border-t-default-alpha table-normal-pagination" style="height: 60px;">
      <PaginationView :show-total="isTotalHidden ? null : (total) => `共 ${total} 条`"
                      :options="TABLE_PAGE_SIZE_OPTIONS"
                      :total="pagination.total"
                      :page-size="pagination.pageSize"
                      :page="pagination.current"
                      :is-simple="pagination.simple"
                      @change="onPaginationChange" />
    </div>
  </slot>
</template>
