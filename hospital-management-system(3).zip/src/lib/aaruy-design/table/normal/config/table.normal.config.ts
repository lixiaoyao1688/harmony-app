// 当前页码
import { SelectorFormItemVO } from '@/lib/aaruy-design/selector/form/selector.form.vo';

export const TABLE_CURRENT = 1;

// 每页条数
export const TABLE_PAGE_SIZE = 10;
export const TABLE_DEFAULT_PAGE_SIZE_PC = 20;
export const TABLE_PAGE_SIZE_MOBILE = 5;

// 初始数据条数
export const TABLE_DEFAULT_TOTAL_SIZE = 0;

// 服务端限制的最大条数 暂时用于请求所有数据
export const TABLE_MAX_PAGE_SIZE = 100;

// 每页条数选项
export const TABLE_PAGE_SIZE_OPTIONS = [
  new SelectorFormItemVO(10, '10 条/页'),
  new SelectorFormItemVO(20, '20 条/页'),
  new SelectorFormItemVO(50, '50 条/页'),
  new SelectorFormItemVO(100, '100 条/页'),
];
