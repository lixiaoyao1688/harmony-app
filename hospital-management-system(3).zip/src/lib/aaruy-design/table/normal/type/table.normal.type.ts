import type {SortOrder} from 'ant-design-vue/lib/table/interface';

export interface TableNormalSortData {
  field: string;
  order: SortOrder
}
