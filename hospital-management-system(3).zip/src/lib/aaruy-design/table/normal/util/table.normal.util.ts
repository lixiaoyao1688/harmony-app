import { ONE, ZERO } from '@/lib/math/config/math.config';
import {
  TABLE_CURRENT, TABLE_DEFAULT_PAGE_SIZE_PC,
  TABLE_DEFAULT_TOTAL_SIZE,
  TABLE_PAGE_SIZE_MOBILE
} from '@/lib/aaruy-design/table/normal/config/table.normal.config';
import type { TableColumnType, TablePaginationConfig } from 'ant-design-vue';
import type { VO, TableVO } from '@/lib/aaruy-design/table/normal/vo/Table.vo';


/**
 * 返回 TABLE 分页器配置
 *
 * @param page 页码
 * @param pageSize 每页条数
 * @param total 总条数
 * @param isMobile 是否处于移动端
 * @param isSimple 是否使用"简单分页"界面
 */
export function getPagination(page: number, pageSize: number, total: number, isMobile?: boolean, isSimple?: boolean): TablePaginationConfig {
  return {
    position: ['bottomCenter'],
    current: page,
    pageSize: pageSize,
    total: total,
    size: isMobile ? 'small' : 'default',
    showSizeChanger: !isMobile,
    simple: !!isSimple,
    buildOptionText: ({value}) => `${value} 条/页`,
    showTotal: (total) => `共 ${total} 条`
  };
}

/**
 * 返回数据接受后的 分页器配置
 */
export function getPaginationAfterFetching(p: TablePaginationConfig, current: number, pageSize: number, total: number): TablePaginationConfig {
  return {
    ...p,
    current: current,
    pageSize: pageSize,
    total: total,
  };
}

/**
 * 返回 PC端 TABLE 分页器配置
 */
export function getPaginationOnPC(): TablePaginationConfig {
  return getPagination(TABLE_CURRENT, TABLE_DEFAULT_PAGE_SIZE_PC, TABLE_DEFAULT_TOTAL_SIZE);
}

/**
 * 返回移动端 TABLE 分页器配置
 */
export function getPaginationOnMobile(): TablePaginationConfig {
  return getPagination(TABLE_CURRENT, TABLE_PAGE_SIZE_MOBILE, TABLE_DEFAULT_TOTAL_SIZE, true);
}

/**
 * 返回移动端 COLUMNS
 */
export function getColumnForMobile(columns: TableColumnType[], mobileWidths: number[]): TableColumnType[] {
  for (let i = 0, len = columns.length; i < len; i++) {
    if (i < 2) {
      columns[i].fixed = 'left';
    }
    columns[i].width = mobileWidths[i];
  }
  return columns;
}

/**
 * 返回 TABLE 每行所需的数据
 *
 * @param vos VO 实例数组
 * @param keys TableVO 字段名数组
 * @param page 页码
 * @param pageSize 每页条数
 */
export function getDataSource<V extends VO, VT extends TableVO<V>>(vos: V[], keys: string[], page: number, pageSize: number): VT[] {
  const dataSource = [] as VT[];
  const passedIndex = (page - 1) * pageSize;
  
  for (let i = 0, len = vos.length; i < len; i++) {
    // VO实例
    const vo = vos[i];
    // 表格所需的基础字段
    const d = {key: vo.id.toString(), index: passedIndex + i + 1, relatedVO: vo} as VT;
    
    // 填充其余待展示字段
    keys.filter(k => k !== 'index' && k !== 'key' && k !== 'relatedVO').forEach(k => {
      d[k] = vo[k];
    });
    dataSource.push(d);
  }
  
  return dataSource;
}


/**
 * 返回 add 之后，应该请求的页码
 * @param total  总条数
 * @param pageSize  每页条数
 */
export function getAddSearchPage(total: number, pageSize: number): number {
  // add 完成，应该请求最后一页的数据
  let lastPage = Math.ceil(total / pageSize);
  if (total % pageSize === ZERO) {
    lastPage = lastPage + ONE;
  }
  return lastPage;
}


/**
 * 返回 remove 之后，应该请求的页码
 * @param page  当前页码
 * @param pageCount 当前页的条数
 */
export function getRemoveSearchPage(page: number, pageCount: number): number {
  // remove 完成，若当前页为空，应该请求前一页的数据
  if (pageCount === ONE) {
    page = (page === ONE) ? ONE : (page - ONE);
  }
  return page;
}
