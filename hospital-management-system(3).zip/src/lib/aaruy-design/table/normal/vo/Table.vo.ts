import { FixedType } from 'ant-design-vue/lib/vc-table/interface';
import { CompareFn, SortOrder } from 'ant-design-vue/es/table/interface';


// VO 实例处理成的 Table 数据结构
export interface TableVO<V> {
	key: string;  // 每行key
	index: number;  // 每行编号
	relatedVO: V;  // 归属VO实例
}

// Table 列结构
export interface TableColumnVO {
	title: string;  // 列标题
	dataIndex: string;  // 字段
	width: string | number;  // 列宽
	ellipsis?: boolean;  // 是否打点，默认true
	fixed?: FixedType;  // 是否固定列头
	sorter?: CompareFn<any> | boolean;  // 排序方法
	sortOrder?: SortOrder;  // 排序的受控属性，外界可用此控制列的排序
	children?: TableColumnVO[];
}

// 基础 VO
export interface VO {
	id: number | string;
}
