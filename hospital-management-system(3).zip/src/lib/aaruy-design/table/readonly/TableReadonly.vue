<script setup lang="ts">
import { computed } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/table/readonly/table.readonly.style.css';
import type { ColumnType } from 'ant-design-vue/lib/table/interface';


interface Prop {
  columns: ColumnType[];
  data: unknown[];
  loading?: boolean;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
</script>

<template>
  <a-table
    :columns="columns"
    :data-source="data"
    :loading="loading || false"
    :pagination="false"
    :bordered="true"
    class="table-readonly"
  >
    <template #bodyCell="{ column, record }">
      <!--  操作 单元格   -->
      <template v-if="column.isImage">
        <slot name="image" :column="column" :record="record"></slot>
      </template>
    </template>
  </a-table>
</template>
