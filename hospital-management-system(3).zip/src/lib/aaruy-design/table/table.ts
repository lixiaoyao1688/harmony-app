export interface TableScrollType {
	scrollToFirstRowOnChange?: boolean;
	x?: string | number | true;
	y?: string;
}

export const FIRST_PAGE = 1;
export const DEFAULT_PAGE_SIZE = 10;
export const DEFAULT_MAX_LIMIT = 100;
