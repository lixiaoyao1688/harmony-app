<script setup lang="ts">
import {computed, ref, watch} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/textarea/style/textarea.bg1.style.css';
import '@/lib/aaruy-design/textarea/style/textarea.bg18.style.css';


/**
 * 多行文本输入 UI
 *
 * 适用设备
 * 台式机 && 笔记本 && 平板 && 手机;
 */
interface Prop {
  data: string;  // 初始值/更新值
  name: string;  // 控件的 name，防止 chrome 报错
  maxLength: number;  // 最大字数
  placeholder?: string;  // 占位提示词
  height?: string;  // 高度，默认 100%;
  bgColor?: string;  // 背景颜色，默认透明; 仅 PC端;
  useThemeBg1?: boolean;  //  是否使用主题 bg-1; 仅 PC端;
  useThemeBg18?: boolean;  //  是否使用主题 bg-18; 仅 移动端;
}

interface Emit {
	(e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const screenStore = useScreenStore();
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);
const laptop = computed<boolean>(() => screenStore.isLaptop);
const pad = computed<boolean>(() => screenStore.isPad);

const value = ref<string>('');  // 已输入的内容
const valueLength = computed<number>(() => value.value.length);  // 已输入内容的长度


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: string): void {
  value.value = data;
  emit('change', data);
}
</script>

<template>
  <div v-if="pc" class="relative" :class="{ 'textarea-bg-1': useThemeBg1 }">
    <textarea :value="value"
              :maxlength="maxLength"
              :placeholder="placeholder || '请输入'"
              :style="{ height: height || '100%' }"
              :name="name"
              class="w-full border-bg-5 text-s"
              style="resize: none; padding: 12px 16px 48px;"
              @input="event => onChange(event.target.value)" />
    <div class="absolute text-weak-2 font-bold text-s"
         style="right: 16px; bottom: 32px;">{{ valueLength }}/{{ maxLength }}</div>
  </div>
  <div v-else class="relative text-s" :class="{ 'textarea-bg-18': useThemeBg18 }">
    <textarea :value="value"
              :maxlength="maxLength"
              :placeholder="placeholder || '请输入'"
              :style="{ height: height || '100%' }"
              :name="name"
              class="w-full text-xs"
              style="resize: none; padding: 8px;"
              @input="event => onChange(event.target.value)" />
    <div class="absolute text-weak font-bold text-xxs"
         style="right: 8px; bottom: 12px;">{{ valueLength }}/{{ maxLength }}</div>
  </div>
</template>
