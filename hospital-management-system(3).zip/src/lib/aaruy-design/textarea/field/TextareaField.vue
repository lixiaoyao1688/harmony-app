<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/textarea/field/textarea.field.style.css';


/**
 * 段落输入框 组件
 * 仅 mobile;
 */
interface Prop {
  title: string;
  data: string;
  maxLength?: number;
  isRequired?: boolean;
  placeholder?: string;
  useFont16?: boolean;  // 默认 14px，开启时为 16px;
}

interface Emit {
  (e: 'change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const value = ref<string>('');
const isFocused = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}

function onChange(data: string): void {
  emit('change', data);
}
</script>

<template>
  <div v-if="pc"><!--  暂不支持 PC 端  --></div>
  <template v-if="mobile">
    <div class="textarea-field border-b-black pb-16"
         :style="{ borderColor: isFocused ? 'var(--aaruy-primary-color-2)' : 'var(--aaruy-bg-color-0)' }"
    >
      <van-field
        v-model="value"
        :label="title"
        :placeholder="placeholder || '请输入'"
        :required="isRequired"
        type="textarea"
        autosize
        :maxlength="maxLength || 50"
        :class="{ 'font16': useFont16, 'font14': !useFont16 }"
        show-word-limit
        @focus="onFocus"
        @blur="onBlur"
        @update:model-value="onChange"
      />
    </div>
  </template>
</template>
