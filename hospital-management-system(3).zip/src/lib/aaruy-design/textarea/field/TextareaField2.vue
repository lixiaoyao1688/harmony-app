<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/textarea/field/textarea.field2.style.css';
import type {FieldAutosizeConfig} from 'vant';


/**
 * 段落输入框 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  title: string;
  data: string;
  maxLength?: number;
  isRequired?: boolean;
  placeholder?: string;
  useTheme1?: boolean;  // textarea-field-2 主题，若要适配其他样式，参考本方法自行编写 css;
  autoSize?: boolean | FieldAutosizeConfig;  // 自适应内容高度，参考: https://vant-ui.github.io/vant/#/zh-CN/field:autosize
}

interface Emit {
  (e: 'change', data: string): void;
  (e: 'error-change', data: string): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();
const value = ref<string>('');
const isFocused = ref<boolean>(false);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


watch(() => prop.data, (data) => {
  value.value = data;
}, { immediate: true });

function onFocus(): void {
  isFocused.value = true;
}

function onBlur(): void {
  isFocused.value = false;
}

function onChange(data: string): void {
  emit('change', data);
}
</script>

<template>
  <div v-if="pc"><!--  暂不支持 PC 端  --></div>
  <div v-else
       :class="{
         'textarea-field-2': useTheme1,
         'textarea-field-2-focus': isFocused
       }"
  >
    <van-field
      v-model="value"
      type="textarea"
      :label="title"
      :placeholder="placeholder || '请输入'"
      :required="isRequired"
      :autosize="autoSize"
      :maxlength="maxLength || 50"
      show-word-limit
      @focus="onFocus"
      @blur="onBlur"
      @update:model-value="onChange"
    />
  </div>
</template>
