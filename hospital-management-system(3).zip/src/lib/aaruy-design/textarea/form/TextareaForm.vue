<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { MAX_TEXTAREA_LENGTH } from '@/lib/aaruy-design/textarea/form/textarea.form';
import '@/lib/aaruy-design/input/form/input.form.style.css';


interface Prop {
  data: string;  // 初始值
  title: string;  // 标题
  height: string;  // 高度
  placeholder?: string;  // 占位文本
  required?: boolean;  // 是否必填项
  maxLength?: number;  // 最大长度
  mobile?: boolean;  // 是否移动端
  mobileTransparent?: boolean;  // 是否移动端透明样式
  bgColor?: string;  // 背景颜色
  padding?: string;  // 内边距
}

interface Emit {
  (e: 'change', v: string): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const innerMaxLength = computed<number>(() => prop.maxLength || MAX_TEXTAREA_LENGTH);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');


watch(() => prop.data, (newValue) => {
  value.value = newValue;
});


function change(e) {
  emit('change', e.target.value);
}
</script>


<template>
  <div
    class="textarea-form"
    :class="{
      'textarea-form-mobile': mobile,
      'textarea-form-mobile-transparent': mobileTransparent,
    }"
  >
    <p class="textarea-form-title">{{ title }}<i v-if="required" class="required">*</i></p>
    <a-textarea
      v-model:value="value"
       class="textarea-form-instance"
      :style="{ height: height, backgroundColor: bgColor, padding: padding }"
      :placeholder="innerPlaceholder"
      :maxlength="innerMaxLength"
      @change="change"
    />
  </div>
</template>


<style scoped>
.textarea-form {
  padding-bottom: 20px;
  text-align: left !important;
}

.textarea-form > .textarea-form-title {
  font-size: 16px;
  color: rgb(255,255,255);
  margin-bottom: 10px !important;
}

.textarea-form > .textarea-form-title > .required {
  margin-left: 4px;
  color: rgb(255,0,0);
}

.textarea-form .textarea-form-instance {
  font-size: 14px;
  color: rgb(255,255,255);
  border-color: rgb(58,68,77);
  background-color: rgb(58,68,77);
}

.textarea-form .textarea-form-instance:focus {
  border-color: rgb(38,111,232);
}

/* mobile */
.textarea-form-mobile {
  padding-bottom: 0;
}

.textarea-form-mobile > .textarea-form-title {
  font-size: 16px;
  color: rgb(255,255,255);
}

.textarea-form-mobile > .textarea-form-instance {
  border-radius: 4px;
  border: 1px solid rgb(91, 103, 116);
}

.textarea-form-mobile-transparent > .textarea-form-instance {
  background-color: transparent;
}
</style>
