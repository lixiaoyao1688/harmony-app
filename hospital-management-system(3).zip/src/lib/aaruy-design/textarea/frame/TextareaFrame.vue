<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import '@/lib/aaruy-design/textarea/frame/textarea.frame.style.css';


interface Prop {
  data: string;  // 初始值
  title: string;  // 标题
  height: string;  // 高度
  maxLength: number;  // 最大长度
  placeholder?: string;  // 占位文本
  isRequired?: boolean;  // 是否必填项
  width?: string;  // 总体的宽度, 默认 100%;
  titleWidth?: string;  // 标题的宽度，默认 100px;
  marginBottom?: string;
}

interface Emit {
  (e: 'change', v: string): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');
const count = computed<number>(() => prop.data.length);

watch(() => prop.data, (newValue) => {
  value.value = newValue;
}, { immediate: true });


function change(e): void {
  emit('change', e.target.value);
}
</script>


<template>
  <div class="flex items-start text-white text-s relative" :style="{ height: height || '100px', width: width || '100%', marginBottom: marginBottom || '0px' }">
    <div :style="{ width: titleWidth || '100px' }" class="text-right pr-8"><i v-if="isRequired" class="text-red-2 mr-8">*</i>{{ title }}</div>
    <a-textarea
      v-model:value="value"
      class="textarea-frame"
      :style="{ height: height }"
      :placeholder="innerPlaceholder"
      :maxlength="maxLength"
      @change="change"
    />
    <div class="absolute text-weak text-xs" style="bottom: 8px; right: 12px;">{{count}}/{{maxLength}}</div>
  </div>
</template>
