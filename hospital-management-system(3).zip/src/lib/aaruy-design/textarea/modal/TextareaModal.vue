<script setup lang="ts">
import { computed, ref, watch } from 'vue';


interface Prop {
  data: string;  // 初始值
  height: string;  // 高度
  maxLength?: number;  // 最大长度
  placeholder?: string;  // 占位文本
}

interface Emit {
  (e: 'change', v: string): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<string>(prop.data);
const innerPlaceholder = computed<string>(() => prop.placeholder || '请输入');


watch(() => prop.data, (newValue) => {
  value.value = newValue;
});

function change(e) {
  emit('change', e.target.value);
}

</script>

<template>
  <a-textarea
    v-model:value="value"
    class="textarea-modal-instance"
    :style="{ height: height }"
    :placeholder="innerPlaceholder"
    :maxlength="maxLength"
    @change="change"
  />
</template>

<style scoped>
.textarea-modal-instance {
  color: rgb(255, 255, 255);
  font-size: 14px;
  border-color: rgb(58, 68, 77);
  background-color: rgb(58, 68, 77);
  padding: 6px 8px !important;
}

.textarea-modal-instance:hover {
	border-color: rgb(38, 111, 232);
}
</style>
