<script setup lang="ts">
import dayjs,{ Dayjs } from 'dayjs';
import { ref, watch } from 'vue';
import { ClockCircleOutlined, CloseCircleFilled } from '@ant-design/icons-vue';
import '@/lib/aaruy-design/time-picker/time.range.picker2.style.css';


/**
 * 时间范围选择器 基础组件
 * 仅pc;
 */
interface Prop {
  day: Dayjs;
}

interface Emit {
  (e: 'change', data: Dayjs): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const value = ref<Dayjs>(dayjs());

watch(() => prop.day, (data) => {
  value.value = data;
}, { immediate: true });

function onChange(data: Dayjs): void {
  value.value = data;
  emit('change', data);
}
</script>

<template>
  
  <a-time-picker v-model:value="value"
                 :show-now="false"
                 :class="{ 'range-not-empty': value !== null }"
                 size="large"
                 format="HH:mm"
                 placeholder="请选择"
                 class="time-range-picker2"
                 popup-class-name="time-range-picker2-popup"
                 style="width: 120px;"
                 @change="onChange"
  >
    <template #suffixIcon>
      <ClockCircleOutlined style="color: var(--aaruy-text-color); font-size: 16px;" />
    </template>
    <template #clearIcon>
      <CloseCircleFilled style="color: var(--aaruy-text-color); font-size: 16px;" />
    </template>
  </a-time-picker>
  
</template>
