<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { ref, watch, computed } from 'vue';
import { fillZero } from '@/lib/time/util/time.util';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import '@/lib/aaruy-design/time-picker/style/time.picker.theme1.style.css';
import type {VanTimePickerChangePayload} from '@/lib/aaruy-design/time-picker/type/time.picker.type';


/**
 * 时间选择器 UI
 *
 * 适用设备
 * 平板 && 手机;
 */
interface Prop {
  data: Dayjs;
  useTheme1?: boolean;
}

const prop = defineProps<Prop>();
const screenStore = useScreenStore();
const value = ref<Array<string>>(['12','00']);

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);

defineExpose({
  getData
});

watch(() => prop.data, (data) => {
  value.value = [fillZero(data.hour()), fillZero(data.minute())];
}, { immediate: true });

function getData(): Dayjs {
  const [hourText, minuteText] = value.value;
  return dayjs().hour(+hourText).minute(+minuteText).second(0).millisecond(0);
}

function onChange(data: VanTimePickerChangePayload): void {
  value.value = data.selectedValues;
}
</script>

<template>
  <div v-if="pc"><!--  暂不支持PC端  --></div>
  <template v-else>
    <van-time-picker v-model="value"
                     :show-toolbar="false"
                     :visible-option-num="4"
                     :class="{
                       'time-picker-theme1': useTheme1
                     }"
                     title="选择时间"
                     @change="onChange" />
  </template>
</template>
