<script setup lang="ts">
import dayjs,{Dayjs} from 'dayjs';
import {computed, ref, watch} from 'vue';
import {fillZero} from '@/lib/time/util/time.util';
import {getTodayDayjs} from '@/lib/time/util/dayjs.util';
import DropdownTip from '@/lib/aaruy-design/dropdown/tip/DropdownTip.vue';
import DropdownBlock from '@/lib/aaruy-design/dropdown/block/DropdownBlock.vue';
import TimeRangeList from '@/lib/aaruy-design/time-picker/components/TimeRangeList.vue';
import IconSelectorDetailUp from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailUp.vue';
import IconSelectorDetailDown from '@/lib/aaruy-design/selector/detail/icons/IconSelectorDetailDown.vue';
import '@/lib/aaruy-design/time-picker/time.range.picker.style.css';


/**
 * 分钟选择器 UI
 */
interface Prop {
  range: [Dayjs, Dayjs];
  padding?: string;
  isThemeTips?: boolean;  // 是否使用 tip 主题
  tipsText?: string;  // 仅 isThemeTips 为 true 可用
}

interface Emit {
	(e: 'change', r: [Dayjs, Dayjs]): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const innerRange = ref<[Dayjs,Dayjs]>([dayjs().startOf('h'), dayjs().startOf('h').add(1,'h')]);
const rangeText = computed<string>(() => getTextFromRange(innerRange.value));


watch(() => prop.range, (data) => {
  innerRange.value = data;
}, { immediate: true });

function getTextFromRange(r: [Dayjs, Dayjs]): string {
  const g = getTextFromDayjs;
  const s = r[0];
  const e = r[1];
  if (e.diff(getTodayDayjs(), 'd') === 1) {
    return `${g(s)}-24:00`;
  }
  return `${g(s)}-${g(e)}`;
}

function getTextFromDayjs(d: Dayjs): string {
  const f = fillZero;
  return `${f(d.hour())}:${f(d.minute())}`;
}

function onOpenChange(opened: boolean): void {
  isOpened.value = opened;
}

function onClose(): void {
  isOpened.value = false;
}

function onChange(r: [Dayjs,Dayjs]): void {
  innerRange.value = r;
  emit('change',r);
  onClose();
}
</script>

<template>
  
  <DropdownTip v-if="isThemeTips" :visible="isOpened" @openChange="onOpenChange">
    <template #content>
      <span style="height: 24px; line-height: 24px;"
            class="text-xs font-bold text-white text-hover-primary-1 cursor-pointer no-select">{{ tipsText }}</span>
    </template>
    <template #menu>
      <TimeRangeList :range="innerRange" use-bg1 @change="onChange" />
    </template>
  </DropdownTip>
  <DropdownBlock v-else :visible="isOpened" :destroy-popup-on-hide="true" @open-change="onOpenChange">
    <div class="cursor-default bg-transparent rounded-4 flex items-center hover-text-primary-1" :style="{ padding: padding }">
      <span class="mr-8">{{ rangeText }}</span>
      <IconSelectorDetailUp v-if="isOpened" />
      <IconSelectorDetailDown v-else />
    </div>
    <template #dropdown>
      <TimeRangeList :range="innerRange" @change="onChange" />
    </template>
  </DropdownBlock>
  
</template>
