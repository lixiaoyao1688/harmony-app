<script setup lang="ts">
import {Dayjs} from 'dayjs';
import {onMounted, ref} from 'vue';
import {notifyErrorNormal} from '@/lib/aaruy-design/notify/notify';
import {getNDayAfterDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';
import {
  TIME_RANGE_ALL_MINUTES,
  TIME_RANGE_END_HOURS,
  TIME_RANGE_ONE_MINUTES,
  TIME_RANGE_ONE_MINUTES_HALF,
  TIME_RANGE_START_HOURS
} from '@/lib/aaruy-design/time-picker/config/time.range.config';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';


/**
 * 分钟列表
 */
interface Prop {
  range: [Dayjs, Dayjs];
  useBg1?: boolean;
}

interface Emit {
	(e: 'change', data: [Dayjs,Dayjs]): void;
}

onMounted(() => {
  initIndex(prop.range);
});

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const ul1 = ref<HTMLUListElement | null>(null);
const ul2 = ref<HTMLUListElement | null>(null);
const ul3 = ref<HTMLUListElement | null>(null);
const ul4 = ref<HTMLUListElement | null>(null);

const h1 = ref<Array<SelectorFormItemVO>>(TIME_RANGE_START_HOURS);
const m1 = ref<Array<SelectorFormItemVO>>(TIME_RANGE_ALL_MINUTES);
const h2 = ref<Array<SelectorFormItemVO>>(TIME_RANGE_END_HOURS);
const m2 = ref<Array<SelectorFormItemVO>>(TIME_RANGE_ALL_MINUTES);


function initIndex(data: [Dayjs,Dayjs]): void {
  const [shi,smi] = getIndexFromDayjs(data[0]);
  const [ehi,emi] = getIndexFromDayjs(data[1]);
  onSelect(shi, 0, true);
  onSelect(smi, 1, true);
  onSelect(ehi, 2, true);
  onSelect(emi, 3, true);
}

function getIndexFromDayjs(d: Dayjs): [number, number] {
  const hourIndex = d.diff(getTodayDayjs(), 'd') === 1 ? 24 : d.hour();
  const minuteIndex = d.minute() > 29 ? 1 : 0;
  return [hourIndex, minuteIndex];
}

function onConfirm(): void {
  if (!ul1.value || !ul2.value || !ul3.value || !ul4.value) {
    return;
  }
  const start = getDayjsFromEl(ul1.value, ul2.value, h1.value, m1.value);
  let end = getDayjsFromEl(ul3.value, ul4.value, h2.value, m2.value);
  
  const today = getTodayDayjs();
  if (end.diff(today, 'd') === 0 && end.hour() === 0) {
    m2.value = TIME_RANGE_ONE_MINUTES_HALF;
    end = end.minute(30);
  }
  else if (end.diff(today, 'd') === 1) {
    m2.value = TIME_RANGE_ONE_MINUTES;
    end = end.minute(0);
  }
  else {
    m2.value = TIME_RANGE_ALL_MINUTES;
  }
  
  if (end.unix() <= start.unix()) {
    notifyErrorNormal('结束时间必须晚于开始时间');
    return;
  }
  emit('change', [start, end]);
}

function getDayjsFromEl(e1: HTMLUListElement, e2: HTMLUListElement, hourList: Array<SelectorFormItemVO>, minuteList: Array<SelectorFormItemVO>): Dayjs {
  const hi = Math.round(e1.scrollTop / 35);
  const mi = Math.round(e2.scrollTop / 35);
  const h = +hourList[hi].text;
  const m = +minuteList[mi].text;
  if (h === 24) {
    return getNDayAfterDayjs(1);
  }
  return getTodayDayjs().hour(h).minute(m);
}

function onSelect(dataIndex: number, colIndex: number, isInit?: boolean): void {
  let e: HTMLUListElement | null = null;
  
  if (colIndex === 0) {
    e = ul1.value;
  }
  else if (colIndex === 1) {
    e = ul2.value;
  }
  else if (colIndex === 2) {
    e = ul3.value;
    m2.value = dataIndex === 24 ? TIME_RANGE_ONE_MINUTES : (dataIndex === 0 ? TIME_RANGE_ONE_MINUTES_HALF : TIME_RANGE_ALL_MINUTES);
  }
  else if (colIndex === 3) {
    e = ul4.value;
  }
  
  if (isInit) {
    setTimeout(() => {
      e && e.scrollTo({ top: 35 * dataIndex, behavior: 'auto' });
    }, 0);
  }
  else {
    e && e.scrollTo({ top: 35 * dataIndex, behavior: 'smooth' });
  }
}
</script>

<template>
  <div :class="{ 'bg-1': useBg1, 'bg-3': !useBg1 }" class="rounded-4">
    <div class="text-white flex px-4 time-range-list relative z-0" @click.stop>
      <div class="absolute bg-default-1 z-1 rounded-4 text-center" style="top: 35px; width: 68px; height: 35px; line-height: 35px; left: 4px;">:</div>
      <div class="absolute bg-default-1 z-1 rounded-4 text-center" style="top: 35px; width: 68px; height: 35px; line-height: 35px; left: 76px;">:</div>
      <ul ref="ul1" class="z-2 h-ul"><li v-for="(h,i) in h1" :key="h.id" class="no-select" @click.stop="onSelect(i, 0)">{{ h.text }}</li></ul>
      <ul ref="ul2" class="z-2 h-ul-2 mr-4" @click.stop><li v-for="(m,i) in m1" :key="m.id" class="no-select" @click.stop="onSelect(i, 1)">{{ m.text }}</li></ul>
      <ul ref="ul3" class="z-2 h-ul" @click.stop><li v-for="(h,i) in h2" :key="h.id" class="no-select" @click.stop="onSelect(i, 2)">{{ h.text }}</li></ul>
      <ul ref="ul4" class="z-2 h-ul-2" @click.stop><li v-for="(m,i) in m2" :key="m.id" class="no-select" @click.stop="onSelect(i, 3)">{{ m.text }}</li></ul>
    </div>
    <div class="flex items-center justify-end p-12 border-t-default">
      <ButtonView type="primary" text="确定" style="width: 100%; height: 32px;" @click="onConfirm" />
    </div>
  </div>
</template>

<style scoped>
.time-range-list > ul {
  overflow: hidden auto;
  cursor: default;
  width: 34px;
  text-align: center;
  height: 210px;
}

.time-range-list > ul.h-ul {
  padding-top: 35px !important;
  padding-bottom: 140px !important;
}

.time-range-list > ul.h-ul-2 {
  padding-top: 35px !important;
  padding-bottom: 140px !important;
}

.time-range-list > ul > li {
  height: 35px;
  line-height: 35px;
  cursor: pointer;
  text-align: center;
}

.time-range-list > ul > li:hover {
  color: var(--aaruy-primary-color-1);
}

.time-range-list > ul::-webkit-scrollbar,
.time-range-list > ul::-webkit-scrollbar-thumb {
  display: none;
}
</style>
