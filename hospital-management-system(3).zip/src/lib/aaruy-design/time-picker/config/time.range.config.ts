import {Dayjs} from 'dayjs';
import {getNDayAfterDayjs, getTodayDayjs} from '@/lib/time/util/dayjs.util';
import {SelectorFormItemVO} from '@/lib/aaruy-design/selector/form/selector.form.vo';


export const TIME_RANGE_START_HOURS = [
  new SelectorFormItemVO(1, '00'),
  new SelectorFormItemVO(2, '01'),
  new SelectorFormItemVO(3, '02'),
  new SelectorFormItemVO(4, '03'),
  new SelectorFormItemVO(5, '04'),
  new SelectorFormItemVO(6, '05'),
  new SelectorFormItemVO(7, '06'),
  new SelectorFormItemVO(8, '07'),
  new SelectorFormItemVO(9, '08'),
  new SelectorFormItemVO(10, '09'),
  new SelectorFormItemVO(11, '10'),
  new SelectorFormItemVO(12, '11'),
  new SelectorFormItemVO(13, '12'),
  new SelectorFormItemVO(14, '13'),
  new SelectorFormItemVO(15, '14'),
  new SelectorFormItemVO(16, '15'),
  new SelectorFormItemVO(17, '16'),
  new SelectorFormItemVO(18, '17'),
  new SelectorFormItemVO(19, '18'),
  new SelectorFormItemVO(20, '19'),
  new SelectorFormItemVO(21, '20'),
  new SelectorFormItemVO(22, '21'),
  new SelectorFormItemVO(23, '22'),
  new SelectorFormItemVO(24, '23'),
];

export const TIME_RANGE_END_HOURS = [
  new SelectorFormItemVO(1, '00'),
  new SelectorFormItemVO(2, '01'),
  new SelectorFormItemVO(3, '02'),
  new SelectorFormItemVO(4, '03'),
  new SelectorFormItemVO(5, '04'),
  new SelectorFormItemVO(6, '05'),
  new SelectorFormItemVO(7, '06'),
  new SelectorFormItemVO(8, '07'),
  new SelectorFormItemVO(9, '08'),
  new SelectorFormItemVO(10, '09'),
  new SelectorFormItemVO(11, '10'),
  new SelectorFormItemVO(12, '11'),
  new SelectorFormItemVO(13, '12'),
  new SelectorFormItemVO(14, '13'),
  new SelectorFormItemVO(15, '14'),
  new SelectorFormItemVO(16, '15'),
  new SelectorFormItemVO(17, '16'),
  new SelectorFormItemVO(18, '17'),
  new SelectorFormItemVO(19, '18'),
  new SelectorFormItemVO(20, '19'),
  new SelectorFormItemVO(21, '20'),
  new SelectorFormItemVO(22, '21'),
  new SelectorFormItemVO(23, '22'),
  new SelectorFormItemVO(24, '23'),
  new SelectorFormItemVO(25, '24'),
];

const TIME_RANGE_MINUTE_0O = new SelectorFormItemVO(1,'00');
const TIME_RANGE_MINUTE_30 = new SelectorFormItemVO(2,'30');

export const TIME_RANGE_ONE_MINUTES = [TIME_RANGE_MINUTE_0O];
export const TIME_RANGE_ONE_MINUTES_HALF = [TIME_RANGE_MINUTE_30];
export const TIME_RANGE_ALL_MINUTES = [TIME_RANGE_MINUTE_0O, TIME_RANGE_MINUTE_30];

export const TIME_RANGE_MINUTES = [new SelectorFormItemVO(1,'00'), new SelectorFormItemVO(2,'30')];
export const DEFAULT_TIME_RANGE: [Dayjs, Dayjs] = [getTodayDayjs(), getNDayAfterDayjs(1)];
