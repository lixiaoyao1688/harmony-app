<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { computed, ref, watch } from 'vue';
import { fillZero as f } from '@/lib/time/util/time.util';
import IconPickerField from '@/lib/aaruy-design/picker/IconPickerField.vue';
import '@/lib/aaruy-design/picker/picker.mobile.style.css';
import '@/lib/aaruy-design/date-range-picker/field/date.time.picker.mobile.css';


/**
 * 时间选择器 组件
 * 仅 mobile;
 */
interface Prop {
  title: string;
  data: Dayjs | undefined;
  hideOutSideTitle?: boolean;  // 是否隐藏外部标题
  isRequired?: boolean;
}

interface Emit {
  (e: 'change', data: Dayjs): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const isOpened = ref<boolean>(false);
const currentTime = ref<[string, string]>(['08', '00']);
const dataText = computed<string>(() => prop.data ? prop.data.format('HH:mm') : '');


watch(() => prop.data,  (d) => {
  if (d) {
    currentTime.value = [f(d.hour()), f(d.minute())];
  }
}, { immediate: true });

function onOpen(): void {
  isOpened.value = true;
}

function onClose(): void {
  isOpened.value = false;
}

function onCancel(): void {
  onClose();
}

function onConfirm(): void {
  const ts = currentTime.value;
  const hr = +ts[0];
  const mi = +ts[1];
  emit('change', dayjs().hour(hr).minute(mi).second(0).millisecond(0));
  onClose();
}
</script>

<template>
  <van-popup :show="isOpened" @click-overlay="onClose" position="bottom"
             class="picker-mobile time-picker-mobile">
    <van-time-picker v-model="currentTime" :columns-type="['hour','minute']" :title="title" @confirm="onConfirm" @cancel="onCancel" />
  </van-popup>
  <div class="flex items-center justify-between h-full w-full leading-l text-xs" @click="onOpen">
    <span :class="{ hidden: hideOutSideTitle }">
      <i v-if="isRequired" class="mr-2 text-required" style="font-style: normal;">*</i>{{ title }}
    </span>
    <div class="inline-flex items-center">
      <span v-if="data" class="mr-4">{{ dataText }}</span>
      <span v-else class="mr-4 text-weak-2">请选择</span>
      <IconPickerField />
    </div>
  </div>
</template>
