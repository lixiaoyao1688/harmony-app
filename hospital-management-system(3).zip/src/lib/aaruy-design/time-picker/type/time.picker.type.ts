import {Dayjs} from 'dayjs';


export interface VanTimePickerChangePayload {
  selectedIndexes: [number, number];  // [时,分]，如 '20:30' 返回 [20,30];
  selectedValues: [string, string];  // [时,分]，如 '20:30' 返回 ['20','30'];
}

export interface TimePickerRef {
  getData: () => Dayjs;
}
