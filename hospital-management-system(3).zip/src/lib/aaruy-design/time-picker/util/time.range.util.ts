import {Dayjs} from 'dayjs';


export function getTimeRangeText(data: [Dayjs, Dayjs]): string {
  const T = 'HH:mm';
  const s = data[0];
  const e = data[1];
  return `${s.format(T)} - ${e.date() !== s.date() && e.hour() === 0 && e.minute() === 0 ? '24:00' : e.format(T)}`;
}
