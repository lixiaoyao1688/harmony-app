<script setup lang="ts">
import '@/lib/aaruy-design/tooltip/card/tooltip.card.style.css';


interface Prop {
  title: string;
  placement: string;
}

defineProps<Prop>();
</script>

<template>
  <a-tooltip
    :title="title"
    :placement="placement"
    overlay-class-name="tooltip-card"
  >
    <slot></slot>
  </a-tooltip>
</template>
