<script setup lang="ts">
import '@/lib/aaruy-design/tooltip/complex/tooltip.complex.style.css';
import '@/lib/aaruy-design/tooltip/complex/tooltip.complex.style.theme1.css';


interface Prop {
  trigger?: 'hover' | 'click';  // 浮窗触发方式，默认 hover
  useTheme1?: boolean;
}

interface Emit {
  (e: 'change', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onVisibleChange(v: boolean): void {
  emit('change', v);
}
</script>

<template>
  <a-tooltip
    :trigger="trigger || 'hover'"
    placement="bottom"
    :overlay-class-name="'tooltip-complex' + (useTheme1 ? ' tooltip-complex-theme1' : '')"
    @visibleChange="onVisibleChange"
  >
    <template #title>
      <slot name="title"></slot>
    </template>
    <slot></slot>
  </a-tooltip>
</template>
