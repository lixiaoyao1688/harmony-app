<script setup lang="ts">
import '@/lib/aaruy-design/tooltip/dark/tooltip.dark.style.css';


interface Prop {
  title: string;
  placement: string;
}

const prop = defineProps<Prop>();
</script>

<template>
  <a-tooltip
    :title="title"
    :placement="placement"
    overlay-class-name="tooltip-dark"
  >
    <slot></slot>
  </a-tooltip>
</template>
