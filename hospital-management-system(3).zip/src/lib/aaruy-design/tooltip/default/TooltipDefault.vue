<script setup lang="ts">
import '@/lib/aaruy-design/tooltip/default/tooltip.default.style.css';


interface Prop {
  title: string;
	visible: boolean;
  placement: string;
}

interface Emit {
	(e: 'visibleChange', data: boolean): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onVisibleChange(data: boolean) {
  emit('visibleChange', data);
}
</script>

<template>
  <a-tooltip
		:visible="visible"
    :title="title"
    :placement="placement"
		@visible-change="onVisibleChange"
    overlay-class-name="tooltip-default"
  >
    <slot></slot>
  </a-tooltip>
</template>
