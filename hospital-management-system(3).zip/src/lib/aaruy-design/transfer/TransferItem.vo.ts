export type TransferMap = Map<number, TransferItemVO>;


export class TransferItemVO {
	public key: number;
	public title: string;
	
	constructor(k: number, t: string) {
	  this.key = k;
	  this.title = t;
	}
	
	public static getMap(items: Array<TransferItemVO>): TransferMap {
	  return new Map(items.map(it => ([it.key, it])));
	}
}

