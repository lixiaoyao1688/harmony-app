<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { TransferItemVO, TransferMap } from '@/lib/aaruy-design/transfer/TransferItem.vo';
import '@/lib/aaruy-design/transfer/aaruy.transfer.style.css';


interface Prop {
	vos: Array<TransferItemVO>;  // 源
	targetVos: Array<TransferItemVO>;  // 已转移到选中区
  t1?: string;  // 左侧标题
  t2?: string;  // 右侧标题
  isLoading?: boolean;
}

interface Emit {
	(e: 'change', targetVos: Array<TransferItemVO>): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const disabled = ref<boolean>(false);
const targetKeys = ref<number[]>([]);
const map = computed<TransferMap>(() => TransferItemVO.getMap(prop.vos));


watch(() => prop.targetVos, (vos) => {
  targetKeys.value = vos.map(vo => vo.key);
}, { immediate: true });

function onRender(data: TransferItemVO): string {
  return data.title;
}

function onChange(keys: number[]): void {
  const data: Array<TransferItemVO> = [];
  targetKeys.value = keys.sort((k1,k2) => k1-k2);
  targetKeys.value.forEach(k => {
    const vo = map.value.get(k);
    if (vo) {
      data.push(vo);
    }
  });
  emit('change', data);
}
</script>

<template>
	<a-transfer
		v-model:target-keys="targetKeys"
		:data-source="vos"
		:titles="[t1 || '所有信息', t2 || '模板信息']"
		:render="onRender"
		:disabled="disabled"
		:locale="{ notFoundContent: isLoading ? '加载中，请稍候...' : '无数据' }"
		class="aaruy-transfer"
		@change="onChange"
	/>
</template>
