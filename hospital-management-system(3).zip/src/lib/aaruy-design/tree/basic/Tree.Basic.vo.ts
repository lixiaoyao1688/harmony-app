import type { AntTreeNodeCheckedEvent } from 'ant-design-vue/es/tree';


export interface TreeBasicVO {
	checkedKeys: number[];  // 已选中的结点 (不包括父结点)
	event: AntTreeNodeCheckedEvent;
}
