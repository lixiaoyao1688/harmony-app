<script setup lang="ts">
import { TreeNodeVO } from '@/lib/aaruy-design/tree/vo/TreeNode.vo';
import IconReadonly from '@/lib/aaruy-design/tree/icon/IconReadonly.vue';
import '@/lib/aaruy-design/tree/basic/tree.basic.style.css';


interface Prop {
	data: Array<TreeNodeVO>;
	checkedKeys: Array<number>;
}

interface Emit {
	(e: 'change', selectedKeys: Array<number>): void;  // 仅叶子结点
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

function onChange(keys: Array<number>): void {
  emit('change', keys.map(k => +k).filter(k => !isNaN(k)));
}
</script>

<template>
	<a-tree
		:tree-data="data"
		:checked-keys="checkedKeys"
		:checkable="true"
		:default-expand-all="true"
    show-icon
		class="tree-basic"
		@check="onChange"
	>
    <template #icon="{ checkable }">
      <IconReadonly v-if="!checkable" />
    </template>
	</a-tree>
</template>
