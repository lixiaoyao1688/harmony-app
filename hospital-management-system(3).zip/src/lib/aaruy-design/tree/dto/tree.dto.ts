// 从根到叶子的 id 都要写进来，如: "父模块1id,子模块11id,子模块12id,父模块2id,子模块21id,子模块22id"
export type TreeNodeDTO = string;
// 分隔符
export const TREE_NODE_SPLIT = ',';
