<script setup lang="ts">
import {computed, ref} from 'vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { TreeNodeVO } from '@/lib/aaruy-design/tree/vo/TreeNode.vo';
import { NEW_AUTHORITY } from '@/modules/auth/config/auth.config';
import { getPathIdFromLeafKeys } from '@/modules/auth/utils/auth.util';
import ErrorView from '@/lib/aaruy-design/error/ErrorView.vue';
import TreeBasic from '@/lib/aaruy-design/tree/basic/TreeBasic.vue';


interface Prop {
  title: string;  // 标题
	data: Array<TreeNodeVO>;  // 所有结点（已选/未选）
  checkedKeys: number[];   // 已选中的结点
  required?: boolean;  // 是否必填项
}

interface Emit {
  (e: 'change', leafKeys: Array<number>): void;  // 仅叶子结点
}


const screenStore = useScreenStore();

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const errorTips = ref<string>('');  // 报错文本

const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


defineExpose({
  checkValueError
});

function checkValueError(): boolean {
  const tips = getErrorTips(prop.checkedKeys);
  errorTips.value = tips;
  return tips !== '';
}

function getErrorTips(leafKeys: Array<number>): string {
  // 所有选中结点和它的祖先结点
  const ids = getPathIdFromLeafKeys(leafKeys);
  if (ids.length === 0) {
    return '权限不能为空';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADD) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"患者建档"后需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"患者医嘱"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_DATA) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"数据分析"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_NURSING_RECORD_ADD) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"录入护理记录"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_TESTING_RECORD_ADD) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"录入检测记录"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_TRANSFER_PART_OR_BED) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"转科/换床"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_REPLACE_CONSUMABLES) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_GET)) {
    return '患者管理中，选取"换耗材"后，需选取"查看患者"中的任一权限。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_ADD_CANCEL) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_GET)) {
    return '患者医嘱中，选取"创建/取消医嘱"后需选取"查看医嘱"。';
  }
  if (ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_RECEIVE_RETURN_SEND) && !ids.includes(NEW_AUTHORITY.PATIENT_MANAGEMENT_ADVICE_GET)) {
    return '患者医嘱中，选取"接收/退回/发送医嘱（含大剂量）"后需选取"查看医嘱"。';
  }
  // if (ids.includes(NEW_AUTHORITY.HISTORY_PATIENT_UPDATE) && !ids.includes(NEW_AUTHORITY.HISTORY_PATIENT_GET)) {
  //   return '历史患者中，选取"修改患者"后需选取"查询/查看患者"。';
  // }
  if (ids.includes(NEW_AUTHORITY.HISTORY_PATIENT_REMOVE) && !ids.includes(NEW_AUTHORITY.HISTORY_PATIENT_GET)) {
    return '历史患者中，选取"删除患者"后需选取"查询/查看患者"。';
  }
  if (ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_ADD) && !ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_GET)) {
    return '设备管理中，选取"添加设备"后需选取"查看设备"。';
  }
  if (ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_ASSIGN) && !ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_GET)) {
    return '设备管理中，选取"分配设备（上下泵及绑CGM）"后需选取"查看设备"。';
  }
  if (ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_UPDATE_REMOVE) && !ids.includes(NEW_AUTHORITY.DEVICE_MANAGEMENT_GET)) {
    return '设备管理中，选取"编辑/删除设备"后需选取"查看设备"。';
  }
  return '';
}

function onChange(leafKeys: Array<number>): void {
  errorTips.value = getErrorTips(leafKeys);
  emit('change', leafKeys);
}
</script>

<template>
  <div :class="{ 'border-b-error': errorTips }"
       class="pb-8 border-b-2-color-2 border-b-hover-primary">
    <div class="text-s text-left mb-12 text-white">
      <span>{{ title }}</span>
      <i v-if="required" class="text-error ml-4">*</i>
    </div>
		<TreeBasic :data="data" :checked-keys="checkedKeys" @change="onChange" />
  </div>
  <ErrorView :tips="errorTips" is-text-left />
</template>
