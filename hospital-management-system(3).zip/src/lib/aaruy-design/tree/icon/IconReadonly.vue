<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="11.998" viewBox="0 0 12.033 9.001"
       style="margin-top: 4px; margin-right: 12px;">
    <path d="M5.794,13.079l3.4,2.813,3.263-3.7.091-.1L15.008,9.3" transform="translate(-4.387 -7.891)"
          fill="none" stroke="var(--aaruy-primary-color-1)"
          stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </svg>
</template>
