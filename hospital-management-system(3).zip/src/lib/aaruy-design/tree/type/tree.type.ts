export type TreeExposedType = {
  checkValueError: () => boolean;
}