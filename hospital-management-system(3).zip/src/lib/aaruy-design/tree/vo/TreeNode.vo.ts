/**
 * 树 VO
 *
 * 参考:
 * https://3x.antdv.com/components/tree-cn#TreeNode
 */
export class TreeNodeVO {
	
	public key: number;
	public title: string;
	public children: Array<TreeNodeVO>;
	public checkable: boolean;  // true:可选中/取消，false:只读;

	constructor(k: number, t: string, c?: Array<TreeNodeVO>, isCheckable?: boolean) {
	  this.key = k;
	  this.title = t;
	  this.children = c || [];
	  this.checkable = isCheckable === undefined ? true : isCheckable;
	}
	
}
