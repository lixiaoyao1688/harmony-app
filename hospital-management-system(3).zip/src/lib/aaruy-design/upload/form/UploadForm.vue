<script setup lang="ts">
import { ref, watch } from 'vue';
import { printError } from '@/lib/log/util/log.util';
import { notifyError } from '@/lib/aaruy-design/notify/notify';
import { getBase64 } from '@/lib/aaruy-design/upload/util/upload.util';
import { httpUserSignDelete } from '@/modules/user/requests/user.http';
import ButtonView from '@/lib/aaruy-design/button/ButtonView.vue';
import IconUploadClose from '@/lib/aaruy-design/upload/icons/IconUploadClose.vue';
import IconUploadUpdate from '@/lib/aaruy-design/upload/icons/IconUploadUpdate.vue';
import '@/lib/aaruy-design/upload/form/upload.form.style.css';
import type { UploadFile } from 'ant-design-vue';


interface Prop {
  url: string;
  title: string;
  buttonText: string;
  minHeight?: string;
  required?: boolean;
}

interface Emit {
  (e: 'change', file: UploadFile): void;
  (e: 'removed'): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const imgUrl = ref<string>(prop.url);


watch(() => prop.url, (newUrl) => {
  imgUrl.value = newUrl;
});

function remove(): void {
  httpUserSignDelete()
    .then(() => {
      imgUrl.value = '';
      emit('removed');
    })
    .catch(reason => {
      notifyError(reason);
    });
}

function onBeforeUpload(file: File) {
  getBase64(file)
    .then(url => {
      imgUrl.value = url;
    })
    .catch(reason => printError('[onBeforeUpload]', reason));

  emit('change', file as unknown as UploadFile);
  return false;
}
</script>

<template>
  <div class="upload-form" :style="{ minHeight: minHeight || '50px' }" :class="{ 'has-img': imgUrl }">
    <div class="upload-form-title">{{ title }} <i v-if="required">*</i></div>
    <div v-if="imgUrl" class="upload-img">
      <a-image :src="imgUrl" :height="'40px'" alt="签名图" />
      <a-tooltip title="移除签名，重新上传">
        <IconUploadClose @click="remove" title="删除" />
      </a-tooltip>
    </div>
    <a-upload v-if="!imgUrl" list-type="picture" :before-upload="onBeforeUpload" class="upload-form-instance">
			<ButtonView type="primary" :text="buttonText" class="upload-form-btn">
				<template #icon><IconUploadUpdate class="mr-7" /></template>
			</ButtonView>
    </a-upload>
  </div>
</template>

<style>
.upload-form-btn {
	width: 77px;
	height: 32px;
}
</style>

<style scoped>
.upload-form {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 2px solid rgba(204, 214, 225, 0.2);
}

.upload-form:hover {
  border-bottom-color: rgb(38, 111, 232);
}

.upload-form .upload-form-title {
  color: rgb(255, 255, 255);
  font-size: 16px;
}

.upload-form .upload-form-title > i {
  color: rgb(255, 36, 42);
}

.upload-form.has-img {
  display: block;
  height: fit-content;
  padding: 13px 0;
}
.upload-form.has-img .upload-form-title {
  margin-bottom: 10px;
}
.upload-form.has-img .upload-img {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-right: 5px;
}

.upload-form-placeholder > span {
  color: rgb(163, 175, 188);
  font-size: 16px;
}
</style>
