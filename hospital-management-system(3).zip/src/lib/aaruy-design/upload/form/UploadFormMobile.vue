<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { KB } from '@/lib/computer/computer.config';
import { getBase64 } from '@/lib/aaruy-design/upload/util/upload.util';
import { UploadMobileFile } from '@/lib/aaruy-design/upload/upload.mobile';
import { DEFAULT_MAX_UPLOAD_FILE_SIZE } from '@/lib/aaruy-design/upload/upload';
import { notifyErrorMobile } from '@/lib/aaruy-design/notify/mobile/nofity.mobile';
import { printError } from '@/lib/log/util/log.util';
import IconUploadClose from '@/lib/aaruy-design/upload/icons/IconUploadClose.vue';
import IconUploadMobile from '@/lib/aaruy-design/upload/icons/IconUploadMobile.vue';
import ButtonPlain from '@/lib/aaruy-design/button/plain/ButtonPlain.vue';
import '@/lib/aaruy-design/upload/form/upload.form.style.css';


interface Prop {
  url: string;
  title: string;
  buttonText: string;
  altText: string;
  maxSize?: number;  // 最大文件大小 (单位: Byte)
  required?: boolean;
}

interface Emit {
  (e: 'change', file: File | undefined): void;
}



const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const imgUrl = ref<string>(prop.url);
const innerMaxSize = computed<number>(() => prop.maxSize || DEFAULT_MAX_UPLOAD_FILE_SIZE);


watch(() => prop.url, (newUrl) => {
  imgUrl.value = newUrl;
});

function remove() {
  imgUrl.value = '';
  emit('change', undefined);
}

function afterRead(data: UploadMobileFile) {
  if (!data) {
    return;
  }
  if (data.content) {
    imgUrl.value = data.content;
  }
  else {
    getBase64(data.file)
      .then(url => {
        imgUrl.value = url;
      })
      .catch(reason => printError('[afterRead]', reason));
  }

  emit('change', data.file);
}

function onOversize(data: UploadMobileFile) {
  notifyErrorMobile(`文件大小不能超过 ${Math.floor(innerMaxSize.value / KB)} KB`);
}
</script>

<template>
  <div class="upload-form-mobile" :class="{ 'has-img': imgUrl }">
    <div class="upload-form-title">{{ title }} <i v-if="required">*</i></div>
    <div v-if="imgUrl" class="upload-img">
      <a-image :src="imgUrl" :height="'40px'" :alt="altText" />
      <a-tooltip>
        <IconUploadClose @click="remove" />
      </a-tooltip>
    </div>
    <van-uploader v-if="!imgUrl" :after-read="afterRead" :max-size="innerMaxSize" @oversize="onOversize" >
			<ButtonPlain :text="buttonText" class="upload-form-button-plain">
				<template #icon><IconUploadMobile class="flex mr-4" /></template>
			</ButtonPlain>
    </van-uploader>
  </div>
</template>

<style scoped>
.upload-form-mobile {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: var(--ad-form-item-height);
  border-bottom: 1px solid rgb(91, 103, 116);
  padding-top: 20px;
  padding-bottom: 8px;
}

.upload-form-mobile:hover {
  border-bottom-color: rgb(38, 111, 232);
}

.upload-form-mobile .upload-form-title {
  font-size: 16px;
  color: rgb(255, 255, 255);
}

.upload-form-mobile .upload-form-title > i {
  color: rgb(255, 36, 42);
}

.upload-form-mobile.has-img {
  display: block;
  height: fit-content;
  padding: 13px 0;
}

.upload-form-mobile.has-img .upload-form-title {
  margin-bottom: 10px;
}

.upload-form-mobile.has-img .upload-img {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.upload-form-placeholder > span {
  font-size: 16px;
  color: rgb(163, 175, 188);
}
</style>

<style>
.upload-form-button-plain {
	width: 62px;
	height: 28px !important;
	font-size: 12px !important;
	border-radius: 12px !important;
}
</style>
