<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" style="cursor: pointer;">
    <g id="iconUploadCloseG" data-name="组 8092" transform="translate(-98 -12)">
      <rect id="iconUploadCloseGRect" width="16" height="16" transform="translate(98 12)" fill="rgba(255,255,255,0)"/>
      <g id="iconUploadCloseGG" data-name="组 7990" transform="translate(99 13)">
        <circle id="iconUploadCloseGGCircle" data-name="椭圆 43" cx="6" cy="6" r="6" transform="translate(1 1)" fill="none" stroke="#c3d8fb" stroke-width="1"/>
        <path id="iconUploadCloseGGPath1" data-name="路径 2877" d="M7,3.246v6" transform="translate(-2.366 7.533) rotate(-45)" fill="none" stroke="#c3d8fb" stroke-linecap="round" stroke-width="1"/>
        <path id="iconUploadCloseGGPath2" data-name="路径 2878" d="M7,3.246v6" transform="translate(6.466 -2.366) rotate(45)" fill="none" stroke="#c3d8fb" stroke-linecap="round" stroke-width="1"/>
      </g>
    </g>
  </svg>
</template>