<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
    <g id="iconUploadMobileG" data-name="组 8541" transform="translate(-335 -809)">
      <rect id="iconUploadMobileGRect" data-name="矩形 3840" width="12" height="12" transform="translate(335 809)" fill="rgba(255,255,255,0)"/>
      <g id="iconUploadMobileGG" data-name="组 8542" transform="translate(0.5 0.5)">
        <path id="iconUploadMobileGGPath1" data-name="路径 2304" d="M-11084.32,6909.012v9" transform="translate(11424.782 -6099.012)" fill="none" stroke="#699ef5" stroke-linecap="round" stroke-width="1.5"/>
        <path id="iconUploadMobileGGPath2" data-name="路径 2305" d="M0,0V9" transform="translate(345 814.461) rotate(90)" fill="none" stroke="#699ef5" stroke-linecap="round" stroke-width="1.5"/>
      </g>
    </g>
  </svg>
</template>