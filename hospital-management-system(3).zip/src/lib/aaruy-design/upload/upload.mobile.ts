export type UploadMobileFile = {
	content: string;  // base64
	file: File;
	message: string;
	objectUrl: string;
	status: string;
}