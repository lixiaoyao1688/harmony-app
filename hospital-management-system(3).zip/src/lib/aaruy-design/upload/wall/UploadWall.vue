<script setup lang="ts">
import {ref, computed} from 'vue';
import { PlusOutlined } from '@ant-design/icons-vue';
import ModalView from '@/lib/aaruy-design/modal/ModalView.vue';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { getBase64 } from '@/lib/aaruy-design/upload/util/upload.util';
import '@/lib/aaruy-design/upload/wall/upload.wall.style.css';
import type { UploadProps } from 'ant-design-vue';


interface Prop {
  maxCount: number;  // 最多上传图片数量
}

interface Emit {
  (e: 'change', files: File[]): void;
}


const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();

const screenStore = useScreenStore();

const modalImage = ref('');
const modalTitle = ref('');
const modalVisible = ref(false);
const fileList = ref<UploadProps['fileList']>([]);
const pc = computed<boolean>(() => screenStore.isPC);
const mobile = computed<boolean>(() => screenStore.isMobile);


function onResetForParent() {
  fileList.value = [];
}

function change(e) {
  let files = [];
  if (e && e.fileList) {
    files = e.fileList.map(f => f.originFileObj);
  }
  emit('change', files);
}

function closeModal() {
  modalVisible.value = false;
  modalTitle.value = '';
}

async function preview(file: any) {
  if (!file.url && !file.preview) {
    file.preview = (await getBase64(file.originFileObj)) as string;
  }
  modalImage.value = file.url || file.preview;
  modalVisible.value = true;
  modalTitle.value = file.name || file.url.substring(file.url.lastIndexOf('/') + 1);
}

function beforeUpload() {
  return false;
}

defineExpose({
  onResetForParent
});
</script>

<template>
  <div class="clearfix">
    <a-upload
      v-model:file-list="fileList"
      accept="image/*"
      list-type="picture-card"
      class="upload-wall"
      :class="{ 'upload-wall-mobile': mobile }"
      :beforeUpload="beforeUpload"
      @change="change"
      @preview="preview"
    >
      <div v-if="fileList.length < maxCount" class="upload-wall-add">
        <plus-outlined class="upload-wall-add-icon" />
      </div>
    </a-upload>
    <ModalView :visible="modalVisible" :title="modalTitle" width="80vw" @close="closeModal">
			<img :alt="modalTitle" :src="modalImage" style="width: 100%;" />
    </ModalView>
  </div>
</template>

<style scoped>
.upload-wall-add {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.upload-wall-add-icon {
  font-size: 24px;
}
</style>
