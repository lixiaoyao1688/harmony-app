<script setup lang="ts">
import { ref } from 'vue';
import { PlusOutlined } from '@ant-design/icons-vue';
import { UploadMobileFile } from '@/lib/aaruy-design/upload/upload.mobile';


interface Prop {
  title: string;
  maxCount: number;  // 最多上传图片数量
  useFont16?: boolean;
}

interface Emit {
  (e: 'change', files: File[]): void;
}

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
const fileList = ref<UploadMobileFile[]>([]);

function onResetForParent() {
  fileList.value = [];
}

function afterRead() {
  if (!fileList.value) {
    return;
  }
  emit('change', fileList.value.map(d => d.file));
}

defineExpose({
  onResetForParent
});
</script>

<template>
  <div class="upload-wall-mobile">
    <div class="pb-16 text-white flex justify-between"
         :style="{ fontSize: useFont16 ? '16px' : '14px' }">{{ title }}</div>
    <van-uploader v-model="fileList" :after-read="afterRead" :max-count="maxCount" preview-size="100" multiple>
      <div class="upload-wall-mobile-add">
        <PlusOutlined class="add-icon" />
      </div>
    </van-uploader>
    <div class="text-right text-weak pt-4">{{ fileList.length }}/{{ maxCount }}</div>
  </div>
</template>

<style scoped>
.upload-wall-mobile {
  --upload-wall-mobile-color: rgb(91, 103, 116);
}

.upload-wall-mobile-add {
  width: 100px;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  background-color: rgba(255,255,255,0.05);
  border: 1px dashed var(--upload-wall-mobile-color);
}

.upload-wall-mobile-add .add-icon {
  font-size: 24px;
  color: var(--upload-wall-mobile-color);
}
</style>
