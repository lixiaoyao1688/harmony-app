export interface UploadWallComponent {
  onResetForParent: () => void;
}