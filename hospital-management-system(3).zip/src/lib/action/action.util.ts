/**
 * 用于 click 事件处理，点击元素 3 次后，执行 callback 函数。
 */
export function getHandleTripleClickFn(callback: Function): () => void {
  let touchCount = 0;
  let lastTouchTime = 0;
  
  return function () {
    const now = Date.now();
    
    // 如果两次触摸间隔超过 1s，则重置计数
    if (now - lastTouchTime > 1000) {
      touchCount = 0;
    }
    
    lastTouchTime = now;
    touchCount += 1;
    
    if (touchCount === 3) {
      // 已点击元素 3 次
      callback.call(null);
      touchCount = 0;
    }
  };
}
