import { SelectItemVO } from '@/lib/aaruy-design/selector/vo/SelectItem.vo';
import type { AppKindType } from '@/lib/app/type/app.type';


/**
 * APP 部署的网络类型
 */
export enum APP_KIND {
  IN = 0,
  OUT,
}

export const APP_KIND_IN_ITEM: AppKindType = new SelectItemVO({ id: APP_KIND.IN, text: '内网登录' });
export const APP_KIND_OUT_ITEM: AppKindType = new SelectItemVO({ id: APP_KIND.OUT, text: '公网登录' });

export const DEFAULT_APP_KIND_ITEM = APP_KIND_IN_ITEM;
export const APP_KIND_ITEMS: Array<AppKindType> = [APP_KIND_IN_ITEM, APP_KIND_OUT_ITEM];

export const APP_KIND_MAP: Map<number, AppKindType> = new Map(APP_KIND_ITEMS.map(it => ([it.id, it])));
