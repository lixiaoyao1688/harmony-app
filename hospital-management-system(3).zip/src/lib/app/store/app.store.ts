import { defineStore, Store } from 'pinia';
import { APP_KIND_OUT_ITEM } from '@/lib/app/config/app.kind';
import { OUT_APP_SERVER_DOMAIN } from '@/lib/app/config/app.config';
import { HTTP_PROTOCOL_PREFIX, HTTPS_PROTOCOL_PREFIX } from '@/lib/http/config/http.protocol';
import type { AppKindType } from '@/lib/app/type/app.type';


interface State {
  /**
   * APP端登录的网络类型
   * 注意:
   * 见 ~src/lib/app/config/app.kind.ts
   */
  kindItem: AppKindType;
  /**
   * App端的"WS/HTTP"服务地址
   * 注意:
   * 1. 公网：固定地址（测试服/正式服），始终处于线上模式（HTTPS）
   * 2. 内网：需要用户输入ip，始终处于线上模式（HTTPS）
   * 3. 和 PC端的服务地址: @src\lib\request\util\request.util.ts:getRequestUrl 同步修改
   * 2(已废弃 20251127). 内网版需要用户输入ip，处于本地模式（HTTP）
   *
   * 示例
   * 1. 公网: https://server.aaruy.com
   * 2. 内网: https://192.168.0.67
   * 2(已废弃 20251127). 内网: http://192.168.0.67 已废弃 20251127
   */
  domain: string;
}

interface Action {
  setKindItem: (data: AppKindType) => void;
  setDomain: (data: string) => void;
  resetDomain: () => void;
  getIP: () => string;
}

type Getter = {
}


export type AppStoreType = Store<string, State, Getter, Action>;

/**
 * APP 配置库
 // */
export const useAppStore = defineStore<string, State, Getter, Action>('app-store', {
  
  state: () => ({
    kindItem: APP_KIND_OUT_ITEM,
    domain: OUT_APP_SERVER_DOMAIN,
  }),
  
  actions: {
    setKindItem(data) {
      this.kindItem = data;
    },
    setDomain(data) {
      this.domain = data;
    },
    resetDomain() {
      this.domain = OUT_APP_SERVER_DOMAIN;
    },
    getIP() {
      const data = this.domain;
      if (data.includes(HTTPS_PROTOCOL_PREFIX)) {
        return data.replace(HTTPS_PROTOCOL_PREFIX, '');
      }
      if (data.includes(HTTP_PROTOCOL_PREFIX)) {
        return data.replace(HTTP_PROTOCOL_PREFIX, '');
      }
      return data;
    }
  },
  
  getters: {
  }
  
});
