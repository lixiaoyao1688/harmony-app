import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export type AppKindType = SelectItemVO<unknown>;
