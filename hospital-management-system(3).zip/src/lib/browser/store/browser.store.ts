import { defineStore } from 'pinia';
import {LOG_COLOR} from '@/lib/log/dto/log.dto';
import {printGroup} from '@/lib/log/util/log.util';
import { isBrowserFirefox } from '@/lib/browser/util/browser.util';


/**
 * 浏览器 库
 */
interface State {
  isFirefox: boolean;
}

interface Action {
  init: () => void;
}

type Getter = {
}

export const useBrowserStore = defineStore<string, State, Getter, Action>('browser-store', {
  
  state: () => ({
    isFirefox: false,
  }),
  
  actions: {
    init() {
      this.isFirefox = isBrowserFirefox();
      printGroup('browser', { isFirefox: this.isFirefox }, LOG_COLOR.NORMAL);
    }
  },
  
  getters: {
  }
  
});
