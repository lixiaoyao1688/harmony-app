export function isBrowserFirefox(): boolean {
  return /firefox/i.test(navigator.userAgent);
}
