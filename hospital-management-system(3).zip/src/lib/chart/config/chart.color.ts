export const COLOR_WHITE_0 = 'rgb(255,255,255)';
export const COLOR_BLACK_0 = 'rgb(0,0,0)';
export const COLOR_RED_0 = 'rgb(247,58,63)';
export const COLOR_GRAY_0 = 'rgb(100,115,128)';
export const COLOR_GRAY_1 = 'rgb(184,210,232)';
