export type HideTooltipCallbackType = (e: TouchEvent | MouseEvent) => void;
export type StopPropagationType = (e: TouchEvent | MouseEvent) => void;
