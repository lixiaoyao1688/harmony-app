import type { EChartsType } from 'echarts';
import type {HideTooltipCallbackType, StopPropagationType} from '@/lib/chart/type/chart.type';


// 隐藏图形的浮窗
export function getHideTooltipCallback(chart: EChartsType | null): HideTooltipCallbackType {
  return (e) => {
    if (!chart) {
      return;
    }
    if (e && !chart.getDom().contains(e.target as Node)) {
      chart.dispatchAction({ type: 'hideTip' });
      chart.dispatchAction({ type: 'downplay' });
    }
  };
}

// 防止在图表内部触摸时意外隐藏（注意: 需要在 renderChart 之后调用才会生效）
export function stopChartPropagation(chart: EChartsType | null): StopPropagationType {
  return (e) => {
    if (!chart) {
      return;
    }
    e.stopPropagation();
  };
}
