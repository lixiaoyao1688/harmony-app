export const KB = 1024;  // 1KB = 1024Byte
