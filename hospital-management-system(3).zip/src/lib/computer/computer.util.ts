export function isBlob(obj: Object): boolean {
  return obj instanceof Blob;
}