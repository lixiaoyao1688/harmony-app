export const DOM_HEADER_ID = 'header';
export const DOM_RECORD_HEADER_ID = 'recordHeader';
export const DOM_RECORD_ID = 'record';
