import { defineStore } from 'pinia';
import { scrollToTop } from '@/lib/dom/utils/dom.util';
import { DOM_HEADER_ID, DOM_RECORD_HEADER_ID, DOM_RECORD_ID } from '@/lib/dom/config/dom.config';


interface State {
	header1: HTMLElement | null;
	header2: HTMLElement | null;
	container: HTMLElement | null;
}

interface Action {
	init: () => void;  // 初始化各个 dom 引用
	scroll: (target: HTMLElement) => void;  // 滚动 container， 直到 target 刚好贴在顶部，如果滚动条到底了，那么到底即可。
}

export type Getter = {
	headerHeight: () => number;  // "header" 的高度 ("container顶部" 到 "screen顶部" 的距离)
}


export const useDomStore = defineStore<string, State, Getter, Action>('dom', {
	
  state: () => ({
    header1: null,
    header2: null,
    container: null,
  }),
	
  actions: {
    init() {
      this.header1 = document.getElementById(DOM_HEADER_ID);
      this.header2 = document.getElementById(DOM_RECORD_HEADER_ID);
      this.container = document.getElementById(DOM_RECORD_ID);
    },
    scroll(target) {
      scrollToTop(target, this.container, this.headerHeight);
    }
  },
	
  getters: {
    headerHeight() {
      const h1 = this.header1 ? this.header1.offsetHeight : 0;
      const h2 = this.header2 ? this.header2.offsetHeight : 0;
      const h3 = this.container ? +window.getComputedStyle(this.container, null)['paddingTop'].slice(0,-2) : 0;
      return h1+h2+h3;
    },
  }
	
});
