/**
 * 让 target 滚动到它的上边距和 container 的上边距重合。
 * @param target 待滚动的元素
 * @param container 容器元素
 * @param containerTop container顶部到屏幕顶部的距离
 */
export function scrollToTop(target: HTMLElement, container: HTMLElement | null, containerTop: number): void {
  if (!container || !target) {
    return;
  }
  // 步骤1：求 "target顶部" 到 "header底部" 的偏移
  //    "getBoundingClientRect().top" 是 "target顶部" 到 "screen顶部" 的距离，
  // "this.headerHeight" 是 "header的高度"。
  //    两者相减求出 "target顶部" 到 "header底部" 的偏移，这个偏移值可能为负，说明
  // target 已经向上滚动到和 header 重合；也可能为正，说明 target 和 header 还有
  // 一些距离。
  const offsetTop = target.getBoundingClientRect().top - containerTop;
  
  // 步骤2: 求本次滚动需要的距离
  //    "container.scrollTop" 是 "container已经滚动的距离"，加上 offsetTop 即可
  // 让容器滚动到刚好让 "target顶部" 和 "header顶部" 重合。
  const nextScrollTop = container.scrollTop + offsetTop;
  
  // 步骤3: 执行容器滚动
  container.scroll({
    left: 0,
    top: nextScrollTop,
    behavior: 'auto',
  });
}

export function isElement(el: unknown): boolean {
  return !!(el && el instanceof HTMLElement);
}

export function getElementClientHeight(selector: string): number {
  const e = document.querySelector(selector);
  if (!e || !e.clientHeight) {
    return 0;
  }
  return e.clientHeight;
}

export function getInlineElementWidth(element: HTMLElement): number {
  return element.getBoundingClientRect().width;
}

/**
 * 水平可滚动元素的左侧是否还有内容
 * @param scrollLeft 元素内容从其左边缘开始，向左水平偏移的像素数
 */
export function isElementLeftOverflow(scrollLeft: number): boolean {
  // 元素从其左边缘开始，向左平移的像素数大于 0px。
  return scrollLeft > 0;
}

/**
 * 水平可滚动元素的右侧是否还有内容
 * @param scrollLeft 元素内容从其左边缘开始，向左水平偏移的像素数
 * @param clientWidth 可见的像素数
 * @param scrollWidth 总像素数，包括由于溢出而在屏幕上不可见的内容
 */
export function isElementRightOverflow(scrollLeft: number, clientWidth: number, scrollWidth: number): boolean {
  // 滚动过去的像素数+可见像素数，仍小于"总像素数"。
  return scrollLeft + clientWidth < scrollWidth;
}

/**
 * 水平可滚动元素的内容是否溢出
 * @param el 水平可滚动元素
 */
export function isElementXOverflow(el: HTMLDivElement): boolean {
  return el.scrollWidth > el.clientWidth;
}
