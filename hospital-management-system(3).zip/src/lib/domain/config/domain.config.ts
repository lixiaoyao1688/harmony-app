export const DOMAIN_SERVER = 'server.aaruy.com';
export const DOMAIN_TEST = 'test.aaruy.com';