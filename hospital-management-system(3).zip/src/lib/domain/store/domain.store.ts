import { defineStore } from 'pinia';
import { isProductionServer } from '@/lib/env/utils/env.domain.util';


/**
 * 域名 库
 */
interface State {
  isServer: boolean;  // 是否正式服
}

interface Action {
}

type Getter = {
}

export const useDomainStore = defineStore<string, State, Getter, Action>('domain-store', {
  
  state: () => ({
    isServer: isProductionServer(),
  }),
  
  actions: {
  },
  
  getters: {
  }
  
});
