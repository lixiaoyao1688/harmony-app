/**
 * 定义各类设备的最小屏幕像素数
 * 单位px
 */
export enum MIN_SCREEN_WIDTH {
  LARGE_4K = 3840,  // 4K (3840*2160)
  LARGE = 1921,  // 大屏
  MID_DESKTOP = 1681,  // 大台式 22英寸
  DESKTOP = 1501,  // 小台式
  PC = 1366, // PC端 (18.5英寸笔记本电脑的屏幕宽度)
  PAD = 835,  // 平板
  NEW_PAD = 600,  // 注意:华为平板竖屏宽度 600px
  LARGE_PHONE = 351,  // 宽屏手机
  MOBILE = 0,  // 窄屏手机 (移动端)
}
