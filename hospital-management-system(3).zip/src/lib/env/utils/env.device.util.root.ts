import { IS_APP } from '@/lib/app/config/app.config';


/**
 * 设备监测库
 *
 * 注意:
 * 1. 为避免循环引用，此文件作为根结点，最多引用定义常量的文件（此时常量文件变为根结点），不可引用其他文件。
 *
 */

/**
 * 监测软件是否运行在移动设备上
 */
export function isDeviceMobile(): boolean {
  return IS_APP;
  // const ua = navigator.userAgent;
  // const reForMobile = /Mobi|Tablet|iPad|iPhone|Android/i;
  //
  // if (ua.includes('Edg/')) {
  //   // 处理 Edge
  //   if (reForMobile.test(ua)) {
  //     // 有这些直接判断为移动端
  //     return true;
  //   }
  //   // 如果包含 Windows 则认为在 PC端，找不到则认为在移动端。
  //   return !/Windows/i.test(ua);
  // }
  //
  // // 处理苹果移动设备
  // if (ua.includes('Apple') || (ua.includes('Safari/') && ua.includes('Mac'))) {
  //   // ua.includes('Apple'): 兼容 iPad;
  //   // ua.includes('Safari/') && ua.includes('Mac'): Chrome 有时候会包含 Safari 字符串，所以再加一个 Mac 判断;
  //   if (reForMobile.test(ua)) {
  //     return true;
  //   }
  //   return window.innerWidth < MIN_SCREEN_WIDTH.PC;
  // }
  //
  // // Mobi: (苹果/安卓/华为) https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Browser_detection_using_the_user_agent
  // // iPad/iPhone: 苹果
  // // Android: 安卓
  // return reForMobile.test(ua);
}
