import { printApp } from '@/lib/log/util/log.util';
import { isValidIP } from '@/lib/env/utils/env.ip.util';
import { isDevelopment } from '@/lib/env/utils/env.util.root';
import { DOMAIN_SERVER } from '@/lib/domain/config/domain.config';
import { AppStoreType, useAppStore } from '@/lib/app/store/app.store';
import { IS_APP, IS_APP_HTTP_USE_WEB } from '@/lib/app/config/app.config';


/**
 * 是否启用 WEB HTTP 交互方式
 */
export function isWebHttpUsing(): boolean {
  return IS_APP_HTTP_USE_WEB || !IS_APP;
}


/**
 * 是否部署在公网 20251028
 *
 * 检测方法
 * IP为内网，域名为公网
 *
 * 适用范围
 * PC端 && APP端
 */
export function isOnline(appStore?: AppStoreType): boolean {
  if (isDevelopment()) {
    return !isValidIP(process.env.VUE_APP_DEV_HOST_NAME as string);
    // return process.env.VUE_APP_DEV_PROTOCOL === 'https';
  }
  if (IS_APP && appStore) {
    // APP端
    const ip = appStore.getIP();
    printApp('域名', ip);
    return !isValidIP(ip);
    // return appStore.domain.includes('server') || appStore.domain.includes('test');
  }
  // PC端
  return location && !isValidIP(location.hostname);
  // return !!(location && location.protocol && location.protocol.includes('https'));
}
/**
 * 是否部署在线上（已废弃）
 * pc && mobile;
 */
// export function isOnline(appStore?: AppStoreType): boolean {
//   if (isDevelopment()) {
//     return process.env.VUE_APP_DEV_PROTOCOL === 'https';
//   }
//   if (IS_APP && appStore) {
//     return appStore.domain.includes('server') || appStore.domain.includes('test');
//   }
//   return !!(location && location.protocol && location.protocol.includes('https'));
// }


/**
 * 是否部署在测试服 20251028
 *
 * 适用范围
 * PC端 && APP端
 */
export function isOnlineTest(): boolean {
  if (isDevelopment()) {
    return (process.env.VUE_APP_DEV_HOST_NAME as string).includes('test.aaruy.com');
  }
  if (IS_APP) {
    return useAppStore().domain.includes('test');
  }
  return isOnline() && location.hostname.includes('test.aaruy.com');
}
/**
 * 是否部署在线上测试版（已废弃）
 * pc && mobile;
 */
// export function isOnlineTest(): boolean {
//   if (isDevelopment()) {
//     return (process.env.VUE_APP_DEV_HOST_NAME as string).includes('test.aaruy.com');
//   }
//   if (IS_APP) {
//     return useAppStore().domain.includes('test');
//   }
//   return isOnline() && !!(location.origin && location.origin.includes('test.aaruy.com'));
// }



/**
 * 是否部署在正式服域名（医院试用）
 *
 * 适用范围
 * PC端 && APP端
 */
export function isProductionServer(): boolean {
  if (isDevelopment()) {
    return (process.env.VUE_APP_DEV_HOST_NAME as string).includes(DOMAIN_SERVER);
  }
  if (IS_APP) {
    return useAppStore().domain.includes(DOMAIN_SERVER);
  }
  return isOnline() && location.hostname.includes(DOMAIN_SERVER);
}
/**
 * 是否部署在正式服
 *
 * 适用范围
 * PC端 && APP端
 */
export function isOnlineServer(): boolean {
  if (isDevelopment()) {
    return (process.env.VUE_APP_DEV_HOST_NAME as string).includes('server.aaruy.com');
  }
  if (IS_APP) {
    return useAppStore().domain.includes('server');
  }
  return isOnline() && !isOnlineTest();
}


/**
 * 是否测试中
 * pc && mobile;
 */
export function isTesting(): boolean {
  return !isOnlineServer();
}
