/**
 * 验证字符串是否为有效的 IPv4 地址
 */
function isValidIPv4(ip: string): boolean {
  const parts = ip.split('.');
  
  // IPv4 必须有 4 个部分
  if (parts.length !== 4) {
    return false;
  }
  
  for (const part of parts) {
    // 每个部分必须是数字
    if (!/^\d+$/.test(part)) {
      return false;
    }
    
    // 不能有前导零（除非就是 0）
    if (part.length > 1 && part.startsWith('0')) {
      return false;
    }
    
    const num = parseInt(part, 10);
    
    // 必须在 0-255 范围内
    if (num < 0 || num > 255) {
      return false;
    }
    
    // 检查解析后的数字转换回字符串是否与原始部分相同（防止如 "01" 这样的情况）
    if (num.toString() !== part) {
      return false;
    }
  }
  
  return true;
}

/**
 * 验证字符串是否为有效的 IPv6 地址
 */
function isValidIPv6(ip: string): boolean {
  const parts = ip.split(':');
  
  // IPv6 必须有 8 个部分，或者包含 :: 缩写
  if (parts.length < 3 || parts.length > 8) {
    return false;
  }
  
  let emptySegmentCount = 0;
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    
    // 空段（:: 缩写）
    if (part === '') {
      emptySegmentCount++;
      // 只能有一个空段（表示连续的 0 被缩写）
      if (emptySegmentCount > 1) {
        return false;
      }
      // 空段不能在开头和结尾同时出现，除非是整个地址都是 ::
      if ((i === 0 || i === parts.length - 1) && parts.length > 3) {
        // 允许 :: 在开头或结尾，但不能同时出现在开头和结尾（除非是 ::1 这样的特殊情况）
        if (!(i === 0 && parts[1] === '') && !(i === parts.length - 1 && parts[parts.length - 2] === '')) {
          // 对于非边界情况，需要进一步检查
          if (parts.length < 8 && !(i === 0 && parts[1] === '') && !(i === parts.length - 1 && parts[parts.length - 2] === '')) {
            return false;
          }
        }
      }
      continue;
    }
    
    // 每段必须是 1-4 个十六进制字符
    if (part.length < 1 || part.length > 4) {
      return false;
    }
    
    // 检查是否为有效的十六进制
    if (!/^[0-9a-fA-F]+$/.test(part)) {
      return false;
    }
  }
  
  // 如果有空段，总段数可以少于 8
  return !(emptySegmentCount === 0 && parts.length !== 8);
}

/**
 * 检查字符串是否是有效的 IP 地址（支持 IPv4 和 IPv6）
 * @param ip 要检查的字符串
 * @returns 如果是有效的 IP 地址则返回 true，否则返回 false
 */
export function isValidIP(ip: string): boolean {
  if (ip.length === 0) {
    return false;
  }
  // 去除首尾空格
  const trimmedIp = ip.trim();
  
  // 检查是否是 IPv4
  if (trimmedIp.includes('.')) {
    return isValidIPv4(trimmedIp);
  }
  
  // 检查是否是 IPv6
  if (trimmedIp.includes(':')) {
    return isValidIPv6(trimmedIp);
  }
  
  return false;
}
