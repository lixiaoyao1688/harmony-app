/**
 * 环境校验库
 *
 * 注意:
 * 1. 为避免循环引用，此文件作为根结点，最多引用定义常量的文件（此时常量文件变为根结点），不可引用其他文件。
 * 2. 不能使用类似 process && process.env && process.env.NODE_ENV 的判空方法，因为单独的 process 无法被替换。
 *
 * vue-cli (@vue/cli-service "~5.0.0") 编译代码后:
 *
 * 在生产环境中
 * 1. process.env.NODE_ENV 会被替换为字符串 'production'。
 *
 * 在开发环境中
 * 1. process.env.NODE_ENV 会被替换为字符串 'development'。
 * 2. .env.development 中的定义的常量会被替换为指定值，如 process.env.VUE_APP_DEV_HOST_NAME 会被替换为 server.aaruy.com。
 *
 */


/**
 * 程序是否处于生产环境
 */
export function isProduction(): boolean {
  return process.env.NODE_ENV === 'production';
}

/**
 * 程序是否处于开发环境
 */
export function isDevelopment(): boolean {
  return process.env.NODE_ENV === 'development';
}

/**
 * 程序是否处于开发环境，且域名使用正式服
 */
export function isServerDevelopment(): boolean {
  return isDevelopment() && (process.env.VUE_APP_DEV_HOST_NAME as string).includes('server');
}
