import ExcelJS from 'exceljs';
import {
  calculateScaledWidth,
  correctImageOrientation,
  getImageDimensionsFromArrayBuffer
} from '@/lib/image/util/image.util';
import type {ImageExtensionType} from '@/lib/image/type/image.type';


/**
 * "像素"(px) 转 "磅"(pt: Excel的单位)
 * @param px 像素值
 */
export function pxToPt(px: number): number {
  return px * 0.75;
}

/**
 *
 * 添加图片到Excel单元格
 *
 * @param worksheet 工作表
 * @param imageUrl 图片的网络地址，如: 'https://static-test.aaruy.com/1.jpg'
 * @param col 列号，从0开始;
 * @param row 行号，从0开始，标题行索引为0;
 * @param imageHeight 图片的高度 px;
 */
export async function addImageToExcelCell(worksheet: ExcelJS.Worksheet, imageUrl: string, col: number, row: number, imageHeight: number): Promise<void> {
  try {
    // 加载网络图片
    const response = await fetch(imageUrl, {
      headers: {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      }
    });
    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();
    
    // 确定图片扩展名
    let mimeType = 'image/jpeg';
    let extension: ImageExtensionType = 'jpeg';
    if (response.headers) {
      mimeType = response.headers.get('content-type') || 'image/jpeg';
      const mimeData = mimeType.split('/');
      extension = (mimeData && mimeData.length > 1 ? mimeData[1] : 'jpeg') as ImageExtensionType;
    }
    
    // 校正图片方向（fetch 得到的 arrayBuffer 图片方向不对）
    const correctedBuffer = await correctImageOrientation(arrayBuffer);
    
    // 图片高度固定为 IMAGE_HEIGHT px，保持宽高比，计算缩放后的宽度。
    const { width, height } = await getImageDimensionsFromArrayBuffer(correctedBuffer, mimeType);
    const resolvedWidth = calculateScaledWidth(width, height, imageHeight);
    
    // 将图片添加到Excel
    const imageId = worksheet.workbook.addImage({
      buffer: correctedBuffer,
      extension: extension,
    });
    
    // 将图片插入到指定单元格
    worksheet.addImage(imageId, {
      tl: { col: col, row: row },
      ext: { width: resolvedWidth, height: imageHeight },
      editAs: 'oneCell'
    });
  }
  catch (error) {
    console.error('Excel Add Image Error: ', error);
    console.error('Image URL: ', imageUrl);
  }
}
