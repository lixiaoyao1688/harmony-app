export function getLogFormData(formData: FormData): Object {
  const obj = {};
  
  // 遍历所有的键值对
  for (const pair of formData.entries()) {
    const k = pair[0];
    const v = pair[1];
    
    obj[k] = typeof v === 'object' ? {} : v;
    if (typeof v === 'object' && v !== null) {
      // 如果是文件类型的数据，打印更多信息
      const file = v as File;
      obj[k] = {
        name: file.name,
        size: file.size,
        type: file.type
      };
    }
  }
  
  return obj;
}


/**
 * 上传文件到指定网络地址
 * @param file 待上传的文件
 * @param uploadUrl 目标地址
 */
export function uploadFileToUrl(file: File, uploadUrl: string): Promise<null> {
  
  return new Promise<null>((resolve, reject) => {
    
    const xhr = new XMLHttpRequest();
    xhr.open('put', uploadUrl, true);
    xhr.setRequestHeader('Accept', '');
    xhr.setRequestHeader('Accept-Language', '');
    xhr.setRequestHeader('Content-Type', '');
    xhr.send(file);
    xhr.onload = () => {
      if (xhr.status === 200) {
        resolve(null);
      }
      else {
        reject(xhr.responseText || '');
      }
    };
    xhr.onerror = () => {
      reject(xhr.responseText || '');
    };
    
  });
  
}
