import { CapacitorHttp } from '@capacitor/core';
import { printApp } from '@/lib/log/util/log.util';
import { getLogFormData } from '@/lib/file/utils/file.util';
import { useStorageStore } from '@/lib/storage/store/storage.store';
import { useAppStore } from '@/lib/app/store/app.store';
import {PROJECT_VERSION, SUB_VERSION} from '@/configs/global.config';
import {APP_CODE, APP_CODE_IOS} from '@/lib/app/config/app.config';
import type { HttpHeaders, HttpOptions, HttpResponse } from '@capacitor/core/types/core-plugins';


/**
 * 移动App HTTP客户端
 */
export class AppHttpClient {
  
  static async postFormData(path: string, formData: FormData, log: string) {
    const cookie = await useStorageStore().getMobileCookie();

    try {
      const url = useAppStore().domain + path;
      // 已废弃，无论正式服测试服，都用 hospital;
      // const url = useAppStore().domain + (isServerPathUsing() ? path.replace(TEST_HOSPITAL_PATH, SERVER_HOSPITAL_PATH) : path);
      // 所有请求都加上 X-App-Version 版本号。by 阿瑞软件群 周益民(zym) 2025-11-12 10:16:31
      const options = {
        method: 'post',
        data: formData,
        headers: {
          Cookie: cookie,
          'X-App-Version': PROJECT_VERSION + SUB_VERSION
        },
        serializer: 'multipart',
        responseType: 'json'
      };

      printApp(`${log} Request`, { options, formData: getLogFormData(formData) });

      const res: HttpResponse = await new Promise((resolve, reject) => {
        // 依赖于 cordova-plugin-advanced-http, cordova-plugin-file;
        // @ts-ignore
        const myHttp = cordova.plugin.http;
        myHttp.sendRequest(
          url,
          options,
          function(res: HttpResponse) {
            resolve(res);
          },
          function(err: unknown) {
            reject(err);
          }
        );
      });

      printApp(`${log} Response`, res);
      return res;
    }
    catch (err) {
      printApp(`${log} Error`, err);
      throw err;
    }

  }
  
  static async post<B>(path: string, body: B, log: string, useCookie?: boolean, headers?: HttpHeaders) {
    let headerConfig: HttpHeaders = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-App-Version': PROJECT_VERSION + SUB_VERSION
    };
    if (useCookie) {
      const cookie = await useStorageStore().getMobileCookie();
      headerConfig = { ...headerConfig, 'Cookie': cookie };
    }
    if (headers) {
      headerConfig = { ...headerConfig, ...headers };
    }
    
    const options: HttpOptions = {
      url: useAppStore().domain + path,
      headers: headerConfig,
    };
    
    if (body) {
      // @ts-ignore
      if (APP_CODE === APP_CODE_IOS) {
        // ios
        // 手动将 body 转换为 application/x-www-form-urlencoded 格式的字符串
        // fix: body中数字全部变成空字符串的问题
        const params = new URLSearchParams();
        Object.entries(body).forEach(([key, value]) => {
          // 将任何值转为字符串，避免数字 0/1 被吞掉
          params.append(key, String(value));
        });
        options.data = params.toString();
      }
      else {
        // android
        options.data = JSON.parse(JSON.stringify(body));
      }
    }
    
    printApp(`${log} Request`, options);
    
    try {
      const res = await CapacitorHttp.post(options);
      printApp(`${log} Response`, res);
      return res;
    } catch (err) {
      printApp(`${log} Error`, err);
      throw err;
    }
  }

}
