export const TEST_HOSPITAL_PATH = 'hospital';
export const SERVER_HOSPITAL_PATH = 'hospital_v2';
