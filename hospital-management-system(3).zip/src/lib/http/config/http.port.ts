export const HTTP_DEFAULT_PORT = 80;
export const HTTPS_DEFAULT_PORT = 443;
