export const HTTP_PROTOCOL_PREFIX = 'http://';
export const HTTPS_PROTOCOL_PREFIX = 'https://';
export const HTTP_PROTOCOL = 'http:';
export const HTTPS_PROTOCOL = 'https:';
