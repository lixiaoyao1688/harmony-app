
export interface IApiPatient {
	kind_list: IApiPatientKind[];
	level_list: IApiPatientLevel[];
}

export interface IApiPatientGender {
	id: number;
	name: string;
	text: string;
}

export interface IApiPatientLevel {
	id: number;
	name: string;
	text: string;
}

export interface IApiPatientKind {
	id: number;
	name: string;
	text: string;
}


export enum DRUG_COLOR {
	RED = 'red',
	GREEN = 'green',
	YELLOW = 'yellow',
	GRAY = 'gray',
}

export interface IDrugColorDTO {
	id: number;
	name: DRUG_COLOR;
	text: string;
}

export interface IUnit {
	id: number;
	name: string;
}

export interface IMode {
	id: number;
	name: string;
	text: string;
	unit_info: IUnit;
}

export interface IPressureUnit {
	id: number;
	name: string;
}

export interface IPressureValue {
	id: number;
	name: string;
}

export interface ISpeedTime {
	id: number;
	name: string;
}

export interface ISupplies {
	id: number;
	name: string;
	text: string;
}

export interface IDrugConfig {
	color_info: IDrugColorDTO[];
	mode_info: IMode[];
	pressure_unit_info: IPressureUnit[];
	pressure_value_info: IPressureValue[];
	speed_time_info: ISpeedTime[];
	supplies_info: ISupplies[];
}
