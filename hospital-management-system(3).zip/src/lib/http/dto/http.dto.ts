/**
 * HTTP 响应码
 */
export enum HTTP_CODE {
	SUCCESS = 0,  // 成功
	NOT_LOGIN = 11700,  // 用户未登录
	
	// 判断 用户未登录/登录过期:
	// 登录后服务器会返回 cookie，浏览器的请求会自动携带上 cookie，以下两种情况说明 "用户未登录/登录过期":
	//  1. 请求 [个人中心-查看账号信息]，返回异常的用户信息
	//  2. 任何请求的响应码为 HTTP_CODE.NOT_LOGIN
	
	// 如何测试？
	// 1. 登录后关闭浏览器/标签页，再次打开主页观察是否保持登录状态。
	// 2. 退出登录，关闭浏览器/标签页，再次打开主页，观察是否保持退出状态。
}

/**
 * HTTP 响应 DTO
*/
export interface HttpResponseDTO<T> {
	code: HTTP_CODE;
	data: T;
	msg: string;
}

/**
 * HTTP 响应 (查询) DTO
*/
export interface HttpGetResponseDTO<T> {
	code: HTTP_CODE;
	data: T;
	msg: string;
	total: number;
}
