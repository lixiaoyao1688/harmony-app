import axios, { AxiosResponse } from 'axios';
import { isBlob } from '@/lib/computer/computer.util';
import { HttpGetResponseVO } from '@/lib/http/vo/http.vo';
import { getBaseURI,  httpNoResponseCatcher,  httpResponseCatcher,  isHttpResponseError } from '@/lib/http/util/http.utils';
import { useStorageStore } from '@/lib/storage/store/storage.store';
import { AppHttpClient } from '@/lib/http/client/AppHttpClient';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import {PROJECT_VERSION, SUB_VERSION} from '@/configs/global.config';
import type { HttpResponse } from '@capacitor/core/types/core-plugins';
import type { HttpGetResponseDTO, HttpResponseDTO } from '@/lib/http/dto/http.dto';
import type {HTTPResponseType, HTTPResponseType2} from '@/lib/http/types/http.type';


/**
 * HTTP 全局请求实例
*/
export const instance = axios.create({
  // 所有请求都加上 X-App-Version 版本号。by 周益民(zym) 2025-11-12 10:16:31
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-App-Version': PROJECT_VERSION + SUB_VERSION
  },
  baseURL: getBaseURI()
});


instance.interceptors.request.use(async (config) => {
  const c = config;
  
  // 已废弃，无论正式服测试服，都用 hospital;
  // if (config && config.url && config.url.includes(TEST_HOSPITAL_PATH) && isServerPathUsing()) {
  //   // 正式服的 "医院接口path前缀" 用 hospital_v2，其他用 hospital;
  //   // 注意:
  //   // 1.仅限于 WEB 的情况，APP 请到 ~src/lib/http/client/AppHttpClient.ts 处维护;
  //   c = { ...config, url: config.url.replace(TEST_HOSPITAL_PATH, SERVER_HOSPITAL_PATH) };
  // }
  
  if (isWebHttpUsing()) {
    return c;
  }
  // 移动端(App) 手动加上 cookie;
  const cookie = await useStorageStore().getMobileCookie();
  return { ...c, headers: { Cookie: cookie } } as any;
});


/**
 * HTTP 基础方法 增
 *
 * @param path 接口路径
 * @param body 请求体
 * @param log 日志
*/
export function httpAdd<B>(path: string, body: B, log: string): Promise<null> {
  return httpAddOrUpdateOrDelete<B>(path, body, log);
}

/**
 * HTTP 基础方法 删
 *
 * @param path 接口路径
 * @param body 请求体
 * @param log 日志
 */
export function httpDelete<B>(path: string, body: B, log: string): Promise<null> {
  return httpAddOrUpdateOrDelete<B>(path, body, log);
}

/**
 * HTTP 基础方法 改
 *
 * @param path 接口路径
 * @param body 请求体
 * @param log 日志
 */
export function httpUpdate<B>(path: string, body: B, log: string): Promise<null> {
  return httpAddOrUpdateOrDelete<B>(path, body, log);
}

/**
 * HTTP 基础方法 查列表
 *
 * @param path 接口路径
 * @param body 请求体
 * @param VClass 请求的 VO
 * @param log 日志
*/
export function httpGet<B, D, V>(path: string, body: B, VClass: { new(...args:any[]): any }, log: string): Promise<HttpGetResponseVO<V>> {
  return new Promise<HttpGetResponseVO<V>>((resolve, reject) => {
    
    const resolveData = (data: AxiosResponse<HttpResponseDTO<any>, any> | HttpResponse) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      const vs = [] as V[];
      for (let i = 0, len = data.data.data.length; i < len; i++) {
        vs.push(new VClass(data.data.data[i]));
      }
      resolve({ total: data.data.total, vos: vs });
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpGetResponseDTO<D[]>>(path, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .post<B>(path, body, log, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    
  });
}

/**
 * HTTP 基础方法 查VO
 *
 * @param path 接口路径
 * @param body 请求体
 * @param VClass 请求的 VO
 * @param log 日志
 */
export function httpGetVO<B, D, V>(path: string, body: B, VClass: { new(...args:any[]): any }, log: string): Promise<V> {
  return new Promise<V>((resolve, reject) => {
    const resolveData = (data: HTTPResponseType2<D>) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      resolve(new VClass(data.data.data as D));
    };
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<D>>(path, body, undefined)
        .then(data => {
          resolveData(data as unknown as HTTPResponseType2<D>);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .post(path, body, log, true)
        .then(data => {
          resolveData(data as unknown as HTTPResponseType2<D>);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
  });
}

/**
 * HTTP 基础方法 上传
 *
 * @param path 接口路径
 * @param fd FormData
 * @param log 日志
 */
export function httpUpload<D>(path: string, fd: FormData, log: string): Promise<D> {
  return new Promise<D>((resolve, reject) => {
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      resolve(data.data.data);
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<D>>(path, fd, { headers: { 'Content-Type': 'multipart/form-data' }})
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .postFormData(path, fd, log)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    
  });
}

/**
 * HTTP 基础方法 下载
 *
 * @param path 地址
 * @param body 请求体
 * @param log 日志
 * @param filename 文件名，如 abc.xlsx。可选，不填则通过响应头中的 content-disposition 获取。
 */
export function httpDownload<B>(path: string, body: B, log: string, filename?: string): Promise<null> {
  // https://developer.mozilla.org/zh-CN/docs/Web/API/Blob
  return new Promise<null>((resolve, reject) => {
    instance
      .post<Blob>(path, body, { responseType: 'blob' })
      .then(data => {
        
        if (!data || !isBlob(data.data)) {
          return reject('无返回数据');
        }
        
        if (data.data.type === 'application/json') {
          data.data.text().then(jsonText => {
            const res = JSON.parse(jsonText) as HttpResponseDTO<null>;
            reject(res.msg || '下载数据为空');
          });
          return;
        }
        
        let name = '';
        if (filename) {
          name = filename;
        }
        else {
          if (data.headers && data.headers['content-disposition']) {
            const texts = data.headers['content-disposition'].split('filename*=UTF-8\'\'');
            if (texts && texts.length > 1) {
              name = decodeURI(texts[1]);
            }
          }
        }
        
        const url = window.URL.createObjectURL(data.data);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', name);
        document.body.appendChild(link);
        link.click();
        window.URL.revokeObjectURL(url);
        link.remove();
        
        resolve(null);
      })
      .catch(err => httpNoResponseCatcher(err, log, reject));
  });
}

function httpAddOrUpdateOrDelete<B>(path: string, body: B, log: string): Promise<null> {
  return new Promise<null>((resolve, reject) => {
    
    const resolveData = (data: HTTPResponseType) => {
      if (isHttpResponseError(data)) {
        return httpResponseCatcher(data, reject);
      }
      resolve(null);
    };
    
    if (isWebHttpUsing()) {
      instance
        .post<HttpResponseDTO<null>>(path, body, undefined)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    else {
      AppHttpClient
        .post<B>(path, body, log, true)
        .then(data => {
          resolveData(data);
        })
        .catch(err => httpNoResponseCatcher(err, log, reject));
    }
    
  });
}
