import type {AxiosResponse} from 'axios';
import type {HttpResponseDTO} from '@/lib/http/dto/http.dto';
import type {HttpResponse} from '@capacitor/core/types/core-plugins';

export type HTTPResponseType = AxiosResponse<HttpResponseDTO<any>, any> | HttpResponse;
export type HTTPResponseType2<T> = AxiosResponse<HttpResponseDTO<T>, any> | HttpResponse;
