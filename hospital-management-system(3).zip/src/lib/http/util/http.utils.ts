import { AxiosResponse } from 'axios';
import { isOnline, isOnlineServer } from '@/lib/env/utils/env.domain.util';
import { HTTP_CODE, HttpResponseDTO } from '@/lib/http/dto/http.dto';
import { doWorkAfterLogout } from '@/utils/global.tool';
import { useAppStore } from '@/lib/app/store/app.store';
import { printGroup, printSingle } from '@/lib/log/util/log.util';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { isDevelopment, isProduction, isServerDevelopment } from '@/lib/env/utils/env.util.root';
import {getRequestUrl} from '@/lib/request/util/request.util';
import {HTTPS_PROTOCOL} from '@/lib/http/config/http.protocol';
import {HTTP_DEFAULT_PORT, HTTPS_DEFAULT_PORT} from '@/lib/http/config/http.port';
import type {HttpResponse} from '@capacitor/core/types/core-plugins';
import type {HTTPResponseType} from '@/lib/http/types/http.type';


/**
 * PC端获取地址
 */
export function getBaseURI(): string {
  // 生产环境手动构建url;
  // 开发环境为空字符串代表请求本地，由本地的 nodejs 提供中转服务（查看 vue.config.js: getDevProxy）
  return isProduction() ? getRequestUrl() : '';
  // 20251031 已废弃
  // return isProduction() ? (isOnline() ? getProdCloudUrl() : getProdNotCloudUrl()) : '';
}

// 部署到内网的 URL，如 'http://192.168.1.247:8080'

export function getProdNotCloudUrl() {
  return location.protocol + '//' + location.hostname + ':' + getLocationPort();
}

// 部署到云的 URL，如 'https://server.aaruy.com'，使用默认端口(443)
export function getProdCloudUrl() {
  return location.protocol + '//' + location.hostname;
}

// 返回地址栏的 HTTP 端口
// 注意: 地址栏未写明HTTP端口时，location.port 会返回空字符串，此时手动返回默认端口号。
// 参考 https://developer.mozilla.org/en-US/docs/Web/API/Location/port
export function getLocationPort(): number {
  const data = location.port;
  return data ? (+data) : (location.protocol === HTTPS_PROTOCOL ? HTTPS_DEFAULT_PORT : HTTP_DEFAULT_PORT);
}

/**
 * HTTP 响应是否是错误响应
 *
 * @param data  承载 HTTP 响应的对象
 * @return {boolean} true表示有错误, false表示没错误
 */
export function isHttpResponseError(data: HTTPResponseType): boolean {
  return !data || !data.data || data.data.code !== HTTP_CODE.SUCCESS;
}

/**
 * HTTP 有正常响应，但是响应是报错，此函数用于处理此种错误。
 *
 * @param data  承载 HTTP 响应的对象
 * @param reject 拒绝函数
 */
export function httpResponseCatcher(data: AxiosResponse<HttpResponseDTO<any>, any> | HttpResponse, reject: (reason?: any) => void): void {
  let message = '';
  
  if (!data || !data.data) {
    message = 'No Data';
  }
  if (data && data.data && data.data.code !== HTTP_CODE.SUCCESS) {
    // 未登录时返回登录页
    if (data.data.code === HTTP_CODE.NOT_LOGIN) {
      doWorkAfterLogout();
    }
    message = data.data.msg;
  }
  
  reject(message);
}

/**
 * HTTP 无正常响应时，axios 会抛出错误，此函数用于处理此种错误。
 *
 * @param err 错误对象
 * @param log 日志标题 (DEV)
 * @param reject Promise 提供的 reject 函数
 */
export function httpNoResponseCatcher(err: any, log: string, reject: (reason?: any) => void): void {
  let message = '';
  
  printGroup('ERROR[httpNoResponseCatcher]', err, LOG_COLOR.NORMAL);
  
  if (err && err.response && err.response.status) {
    message = err.response.status + ' ' + err.response.statusText;
  }
  else if (err && err.message) {
    message = err.message;
  }
  else if (err && err.code) {
    message = 'code ' +  err.code;
  }
  else {
    message = 'unknown error';
  }
  
  reject(message);
  // sendErrorToServer('HTTP UNCAUGHT ERROR', message, log, 'http.utils.ts');
}

export function getHttpCatcherType(log: string, path: string): string {
  return `[ERROR][HTTP] ${log}: ${path}`;
}

export function logUrl(isPC: boolean): void {
  if (isPC) {
    let url = getBaseURI();
    if (isDevelopment()) {
      // 开发环境的配置。含义见 ~src/lib/env/utils/env.util.root.ts;
      // 开发环境 HTTP URL（查看 vue.config.js: getDevProxy）
      url = process.env.VUE_APP_DEV_PROTOCOL + '://' + process.env.VUE_APP_DEV_HOST_NAME + ':' + process.env.VUE_APP_DEV_PORT;
    }
    printSingle(`[HTTP]URL: ${url}`, LOG_COLOR.NORMAL, useScreenStore().isMobile);
  }
  else {
    printSingle(`[HTTP]URL: ${useAppStore().domain}`, LOG_COLOR.NORMAL, true);
  }
}

export function throwFieldLackError(field: string, path: string, isWS?: boolean): void {
  path = isWS ? `WS事件: ${path}` : path;
  throw new Error(`[字段缺失] ${path} 返回值缺少字段【${field}】;`);
}

/**
 * 是否使用正式服接口
 * pc && mobile;
 */
export function isServerPathUsing(): boolean {
  return (isDevelopment() && isServerDevelopment()) || (isProduction() && isOnlineServer());
}
