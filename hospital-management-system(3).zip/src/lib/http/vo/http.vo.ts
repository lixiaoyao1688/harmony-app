export interface HttpGetResponseVO<V> {
	total: number;
	vos: V[];
}