<script setup lang="ts">
/**
 * 箭头 图标
 *
 * 风格
 * 填充
 *
 * 使用范围
 * pc && mobile;
 */
interface Prop {
  type: 'up' | 'down';
}

defineProps<Prop>();
</script>

<template>
  <svg v-if="type === 'down'" xmlns="http://www.w3.org/2000/svg" width="21" height="16" viewBox="0 0 21 16">
    <rect width="16" height="16" transform="translate(5)" fill="none"/>
    <path d="M9.293.707a1,1,0,0,1,1.414,0l7.586,7.586A1,1,0,0,1,17.586,10H2.414a1,1,0,0,1-.707-1.707Z" transform="translate(20 14.5) rotate(180)" fill="#adb3ba"/>
  </svg>
  <svg v-else xmlns="http://www.w3.org/2000/svg" width="21" height="16" viewBox="0 0 21 16">
    <g id="icon-下拉三角" transform="translate(21 18) rotate(180)">
      <rect id="矩形_2682" data-name="矩形 2682" width="16" height="16" transform="translate(5)" fill="none"/>
      <path id="多边形_4" data-name="多边形 4" d="M9.293.707a1,1,0,0,1,1.414,0l7.586,7.586A1,1,0,0,1,17.586,10H2.414a1,1,0,0,1-.707-1.707Z" transform="translate(20 14.5) rotate(180)" fill="#adb3ba"/>
    </g>
  </svg>
</template>
