<script setup lang="ts">
import { ONE } from '@/lib/math/config/math.config';

interface IProp {
  width: number   // 原始 svg 宽度
  height: number  // 原始 svg 高度
  scale?: number  // svg 缩放比例, 如: {2:放大1倍}, {0.5:缩小1倍}
  style?: string  // svg 元素样式
}

const prop = defineProps<IProp>();
const width = prop.width * (prop.scale || ONE);
const height = prop.height * (prop.scale || ONE);
</script>


<template>
  <slot name="svg" :width="width" :height="height" :style="style"></slot>
</template>


