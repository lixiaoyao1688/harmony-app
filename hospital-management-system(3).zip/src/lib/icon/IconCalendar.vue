<template>
  <svg id="iconCalendar" data-name="组 8274" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <rect id="iconCalendarRect" data-name="矩形 1615" width="24" height="24" fill="none"/>
    <g id="iconCalendarG" data-name="组 6644" transform="translate(-2 -1)">
      <path id="iconCalendarGPath1" data-name="路径 1855" d="M5,19H23v9.947a.947.947,0,0,1-.947.947H5.947A.947.947,0,0,1,5,28.947Z" transform="translate(0 -7.895)" fill="none" stroke="#FFF" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath2" data-name="路径 1856" d="M5,7.947A.947.947,0,0,1,5.947,7H22.053A.947.947,0,0,1,23,7.947v4.737H5Z" transform="translate(0 -1.579)" fill="none" stroke="#FFF" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath3" data-name="路径 1857" d="M16,4V7.789" transform="translate(-5.789)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath4" data-name="路径 1858" d="M32,4V7.789" transform="translate(-14.211)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath5" data-name="路径 1859" d="M28,34h2.842" transform="translate(-12.105 -15.789)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath6" data-name="路径 1860" d="M14,34h2.842" transform="translate(-4.737 -15.789)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath7" data-name="路径 1861" d="M28,26h2.842" transform="translate(-12.105 -11.579)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
      <path id="iconCalendarGPath8" data-name="路径 1862" d="M14,26h2.842" transform="translate(-4.737 -11.579)" fill="none" stroke="#FFF" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
    </g>
  </svg>
</template>