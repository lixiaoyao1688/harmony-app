<script setup lang="ts">
import { CloudFilled } from '@ant-design/icons-vue';
</script>

<template>
  <CloudFilled :style="{ fontSize: '24px', color: 'rgb(91, 103, 116)' }" />
</template>