<template>
  <svg id="iconDownArrow" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <rect id="iconDownArrowRect" data-name="矩形 2682" width="16" height="16" fill="none"/>
    <path id="iconDownArrowPath" data-name="多边形 4" d="M5.293.707a1,1,0,0,1,1.414,0l3.586,3.586A1,1,0,0,1,9.586,6H2.414a1,1,0,0,1-.707-1.707Z" transform="translate(14 11.5) rotate(180)" fill="#adb3ba"/>
  </svg>
</template>
