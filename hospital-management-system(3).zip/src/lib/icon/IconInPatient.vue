<template>
  <svg id="iconInPatient" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <rect id="iconInPatientRect" data-name="矩形 3466" width="20" height="20" fill="rgba(255,255,255,0)"/>
    <path id="iconInPatientPath1" data-name="联合 177" d="M3.5,13a.5.5,0,0,1-.5-.5V6H.652a.5.5,0,0,1-.277-.916L7.723.185a.5.5,0,0,1,.554,0l7.349,4.9A.5.5,0,0,1,15.349,6H13v6.5a.5.5,0,0,1-.5.5Z" transform="translate(2 3)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="iconInPatientPath2" data-name="路径 2846" d="M2537.1-319.335h4" transform="translate(-2529.104 330.335)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconInPatientPath3" data-name="路径 2847" d="M2537.1-319.335h4" transform="translate(-309.335 -2528.104) rotate(90)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
  </svg>
</template>