<script setup lang="ts">
import { LoadingOutlined } from '@ant-design/icons-vue';


/**
 * 加载中 图标
 *
 * 备注
 * 具备动画效果;
 *
 * 使用范围
 * 仅 pc;
 */
interface Prop {
  color?: string;
  margin?: string;
  use4KStyle?: boolean;
}

defineProps<Prop>();
</script>

<template>
  <LoadingOutlined :style="{ color: color, margin: margin, fontSize: use4KStyle ? '32px' : '14px' }" />
</template>
