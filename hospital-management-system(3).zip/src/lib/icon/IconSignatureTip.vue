<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="53" height="320" viewBox="0 0 53 320">
    <text id="iconSignatureTip" transform="translate(10) rotate(90)" fill="rgba(255,255,255,0.16)" font-size="40" font-family="MicrosoftJhengHeiUIRegular, Microsoft JhengHei UI"><tspan x="0" y="0">请</tspan><tspan y="0" font-family="YuGothicUI-Regular, Yu Gothic UI">在此区域内</tspan><tspan y="0">签</tspan><tspan y="0" font-family="YuGothicUI-Regular, Yu Gothic UI">字</tspan></text>
  </svg>
</template>