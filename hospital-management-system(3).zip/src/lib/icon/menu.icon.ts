export const IN_PATIENT_ICON = `<svg id="iconInPatient" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconInPatientRect" data-name="矩形 3466" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <path id="iconInPatientPath1" data-name="联合 177" d="M3.5,13a.5.5,0,0,1-.5-.5V6H.652a.5.5,0,0,1-.277-.916L7.723.185a.5.5,0,0,1,.554,0l7.349,4.9A.5.5,0,0,1,15.349,6H13v6.5a.5.5,0,0,1-.5.5Z" transform="translate(2 3)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
  <path id="iconInPatientPath2" data-name="路径 2846" d="M2537.1-319.335h4" transform="translate(-2529.104 330.335)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
  <path id="iconInPatientPath3" data-name="路径 2847" d="M2537.1-319.335h4" transform="translate(-309.335 -2528.104) rotate(90)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
</svg>
`;

export const HISTORY_ICON = `<svg id="iconHistory" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconHistoryRect" data-name="矩形 3457" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <g id="iconHistoryG" data-name="组 8150" transform="translate(-829.905 -1273.455)">
    <circle id="iconHistoryGCircle1" data-name="椭圆 94" cx="4" cy="4" r="4" transform="translate(835.405 1275.955)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <circle id="iconHistoryGCircle2" data-name="椭圆 97" cx="3" cy="3" r="3" transform="translate(841.405 1283.955)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconHistoryGPath1" data-name="路径 2829" d="M832.405,1290.955a7,7,0,0,1,7-7" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconHistoryGPath2" data-name="路径 2826" d="M2114.115-872v1.5h1.5" transform="translate(-1269.91 2157.755)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.8"/>
  </g>
</svg>
`;

export const ANALYSIS_ICON = `<svg id="iconAnalyze" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconAnalyzeRect1" data-name="矩形 3456" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <path id="iconAnalyzePath" data-name="路径 2842" d="M2,16.6H18" transform="translate(0 0.403)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
  <rect id="iconAnalyzeRect2" data-name="矩形 3463" width="3" height="6" rx="0.5" transform="translate(3 8)" fill="none" stroke="#fff" stroke-width="1"/>
  <rect id="iconAnalyzeRect3" data-name="矩形 3464" width="3" height="8" rx="0.5" transform="translate(8.5 6)" fill="none" stroke="#fff" stroke-width="1"/>
  <rect id="iconAnalyzeRect4" data-name="矩形 3465" width="3" height="11" rx="0.5" transform="translate(14 3)" fill="none" stroke="#fff" stroke-width="1"/>
</svg>
`;

export const SYSTEM_ICON = `<svg id="iconSystem" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconSystemRect" data-name="矩形 3458" width="20" height="20" fill="rgba(255,255,255,0)"/>
	<path id="iconSystemPath1" data-name="路径 2844" d="M2562-380.542h15" transform="translate(-2561.501 385.042)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
	<path id="iconSystemPath2" data-name="路径 2845" d="M2562-380.542h15" transform="translate(-2561.501 391.042)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
	<path id="iconSystemPath3" data-name="路径 2846" d="M2562-380.542h15" transform="translate(-2561.501 396.542)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
	<path id="iconSystemPath4" data-name="联合 174" d="M4,1.5H4a1.5,1.5,0,1,1,3,0H7a1.5,1.5,0,0,1-3,0Z" transform="translate(2.5 3)" fill="#001529" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
  <path id="iconSystemPath5" data-name="联合 175" d="M4,1.5H4a1.5,1.5,0,1,1,3,0H7a1.5,1.5,0,0,1-3,0Z" transform="translate(2.5 14)" fill="#001529" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
  <path id="iconSystemPath6" data-name="联合 176" d="M8,1.5H8a1.5,1.5,0,1,1,3,0h0a1.5,1.5,0,0,1-3,0Z" transform="translate(2.5 8.5)" fill="#001529" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
</svg>
`;


export const SYSTEM_STAFF_ICON = `<svg id="iconStaff" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconStaffRect" data-name="矩形 3459" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <g id="iconStaffG" data-name="组 8151" transform="translate(-2 -3.2)">
    <path id="iconStaffGPath1" data-name="路径 2828" d="M14.8,11.6A2.8,2.8,0,1,0,12,8.8,2.8,2.8,0,0,0,14.8,11.6Z" transform="translate(-4.8 0)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="iconStaffGPath2" data-name="路径 2829" d="M32.608,7a2.8,2.8,0,0,1,0,4.8" transform="translate(-17.165 -0.6)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="iconStaffGPath3" data-name="路径 2831" d="M41.379,34.123v-.48c0-1.792,0-2.688-.349-3.373a3.2,3.2,0,0,0-1.4-1.4" transform="translate(-21.379 -13.772)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="iconStaffGPath4" data-name="矩形 3471" d="M3,0H9a3,3,0,0,1,3,3V5a.5.5,0,0,1-.5.5H.5A.5.5,0,0,1,0,5V3A3,3,0,0,1,3,0Z" transform="translate(4 14.9)" fill="none" stroke="#fff" stroke-width="1"/>
  </g>
</svg>
`;

export const SYSTEM_ROLE_ICON = `<svg id="iconRole" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconRoleRect" data-name="矩形 3460" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <g id="iconRoleG" data-name="组 8157" transform="translate(0 0.5)">
    <rect id="iconRoleGRect" data-name="矩形 3473" width="15" height="11" rx="1" transform="translate(3 4)" fill="none" stroke="#fff" stroke-width="1"/>
    <path id="iconRoleGPath1" data-name="路径 2854" d="M12.21,7.145h2.5" transform="translate(0.79 -1.145)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconRoleGPath2" data-name="路径 2855" d="M12.21,7.145h2.5" transform="translate(0.79 0.855)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconRoleGPath3" data-name="路径 2856" d="M12.21,7.145h2.5" transform="translate(0.79 2.855)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <circle id="iconRoleGCircle" data-name="椭圆 98" cx="2" cy="2" r="2" transform="translate(6.5 5.75)" fill="none" stroke="#fff" stroke-width="1"/>
    <path id="iconRoleGPath4" data-name="椭圆 99" d="M837.1,1286.183a3.5,3.5,0,0,1,7,0" transform="translate(-832.104 -1272.933)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
  </g>
</svg>
`;

export const SYSTEM_LOG_LOGIN_ICON = `<svg id="iconLogLogin" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconLogLoginRect" data-name="矩形 3461" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <g id="iconLogLoginG" data-name="组 8158">
    <rect id="iconLogLoginGRect" data-name="矩形 3474" width="15" height="12" rx="1" transform="translate(2.5 5)" fill="none" stroke="#fff" stroke-width="1"/>
    <path id="iconLogLoginGPath1" data-name="路径 2857" d="M6.43,5.42V2.92" transform="translate(-0.43 0.08)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath2" data-name="路径 2858" d="M6.43,5.42V2.92" transform="translate(7.57 0.08)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath3" data-name="路径 2859" d="M3,7.987H18" transform="translate(-0.5 0.013)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath4" data-name="路径 2860" d="M3,7.987H5" transform="translate(2 2.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath5" data-name="路径 2863" d="M3,7.987H5" transform="translate(2 4.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath6" data-name="路径 2866" d="M3,7.987H5" transform="translate(2 6.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath7" data-name="路径 2861" d="M3,7.987H5" transform="translate(6 2.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath8" data-name="路径 2864" d="M3,7.987H5" transform="translate(6 4.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath9" data-name="路径 2867" d="M3,7.987H5" transform="translate(6 6.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath10" data-name="路径 2862" d="M3,7.987H5" transform="translate(10 2.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath11" data-name="路径 2865" d="M3,7.987H5" transform="translate(10 4.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogLoginGPath12" data-name="路径 2868" d="M3,7.987H5" transform="translate(10 6.513)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
  </g>
</svg>
`;

export const SYSTEM_LOG_OP_ICON = `<svg id="iconLogOp" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
  <rect id="iconLogOpRect" data-name="矩形 3462" width="20" height="20" fill="rgba(255,255,255,0)"/>
  <g id="iconLogOpG" data-name="组 8159" transform="translate(0.5 0.5)">
    <path id="iconLogOpGPath1" data-name="减去 36" d="M-2550.5,399.5h-8.071a.934.934,0,0,1-.929-.938V385.438a.934.934,0,0,1,.929-.938h11.143a.934.934,0,0,1,.929.938V395.5l-4,4Z" transform="translate(2562.5 -382.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
    <path id="iconLogOpGPath2" data-name="路径 2837" d="M2776.4-878.279h8" transform="translate(-2770.902 883.779)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogOpGPath3" data-name="路径 2838" d="M2776.4-878.279h6" transform="translate(-2770.902 886.779)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogOpGPath4" data-name="路径 2839" d="M2776.4-878.279h4" transform="translate(-2770.902 889.779)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1"/>
    <path id="iconLogOpGPath5" data-name="路径 2870" d="M1,0H4L0,4V1A1,1,0,0,1,1,0Z" transform="translate(12 13)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
  </g>
</svg>
`;

export const SYSTEM_CONFIG_ICON = `<svg xmlns="http://www.w3.org/2000/svg" width="19.423" height="18.4" viewBox="0 0 19.423 18.4">
  <path data-name="路径 4082" d="M85.535,96.347c-.13-.687-.57-1.128-1.12-1.119h-.077a2.066,2.066,0,0,1-2.063-2.063,2.369,2.369,0,0,1,.181-.783,1.41,1.41,0,0,0-.475-1.7l-.023-.016-.029-.018-2.3-1.276-.027-.014-.025-.011a1.43,1.43,0,0,0-.574-.116,1.538,1.538,0,0,0-1.092.448,3.113,3.113,0,0,1-1.645.942,3.12,3.12,0,0,1-1.655-.96,1.538,1.538,0,0,0-1.1-.457,1.427,1.427,0,0,0-.563.112l-.025.01-.029.014-2.378,1.306-.029.018-.023.016a1.408,1.408,0,0,0-.478,1.7,2.351,2.351,0,0,1,.181.784A2.066,2.066,0,0,1,68.1,95.228h-.1a1.2,1.2,0,0,0-1.1,1.119,8.849,8.849,0,0,0,0,3.722,1.2,1.2,0,0,0,1.1,1.119H68.1a2.066,2.066,0,0,1,2.063,2.063,2.373,2.373,0,0,1-.181.783,1.412,1.412,0,0,0,.475,1.7l.022.016.027.017,2.253,1.26.028.014.024.011a1.416,1.416,0,0,0,.573.117,1.515,1.515,0,0,0,1.1-.469,3.169,3.169,0,0,1,1.681-1,3.143,3.143,0,0,1,1.692,1.021,1.515,1.515,0,0,0,1.11.477h0a1.411,1.411,0,0,0,.563-.114l.024-.01.029-.014,2.336-1.291.029-.018.023-.016a1.41,1.41,0,0,0,.477-1.7,2.374,2.374,0,0,1-.181-.784,2.066,2.066,0,0,1,2.063-2.063h.093a1.2,1.2,0,0,0,1.1-1.118,12.036,12.036,0,0,0,.2-1.862,11.748,11.748,0,0,0-.2-1.861Zm-.639,3.6c-.067.352-.253.589-.464.589h-.093a2.717,2.717,0,0,0-2.714,2.714,3.022,3.022,0,0,0,.235,1.045v0a.76.76,0,0,1-.254.907l-.009.006-2.307,1.275-.01,0a.767.767,0,0,1-.305.06.855.855,0,0,1-.629-.264,5.246,5.246,0,0,0-.852-.731,2.43,2.43,0,0,0-1.321-.5,3.715,3.715,0,0,0-2.16,1.212.866.866,0,0,1-.623.258.77.77,0,0,1-.311-.062l-.01,0-2.226-1.245-.009-.006a.762.762,0,0,1-.252-.908,3.031,3.031,0,0,0,.236-1.045,2.717,2.717,0,0,0-2.714-2.714H68.01c-.21,0-.4-.237-.463-.589a8.207,8.207,0,0,1,0-3.481c.067-.352.253-.589.462-.589h.1a2.717,2.717,0,0,0,2.714-2.714,2.992,2.992,0,0,0-.236-1.047h0a.759.759,0,0,1,.254-.906l.009-.007,2.349-1.29.01,0a.782.782,0,0,1,.308-.06.889.889,0,0,1,.63.255,5.149,5.149,0,0,0,.838.688,1.992,1.992,0,0,0,2.567.009,5.125,5.125,0,0,0,.834-.676.888.888,0,0,1,.624-.249.782.782,0,0,1,.313.062l.01,0L81.6,91.2l.01.007a.76.76,0,0,1,.253.907,3.011,3.011,0,0,0-.236,1.046,2.717,2.717,0,0,0,2.714,2.714h.094c.21,0,.4.237.463.589a8.2,8.2,0,0,1,0,3.48Zm-8.715-5.259A3.506,3.506,0,1,0,79.688,98.2a3.51,3.51,0,0,0-3.507-3.506Zm0,6.362A2.856,2.856,0,1,1,79.037,98.2a2.859,2.859,0,0,1-2.856,2.856Zm0,0" transform="translate(-66.51 -89.001)" fill="#fff" stroke="#fff" stroke-width="0.4"/>
</svg>
`;

export const ABOUT_ICON = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
  <g id="iconAbout" data-name="组 9849" transform="translate(-53.312 -53.312)">
    <path id="iconAboutP1" data-name="路径 4083" d="M448.515,302.665h-.207a.628.628,0,1,1,0-1.256h.029a4.308,4.308,0,0,1,.515.02.985.985,0,0,1,.9.9,4.043,4.043,0,0,1,.02.515v4.214a.628.628,0,0,1-1.256,0v-4.394Zm.421-3.977a.838.838,0,0,0,0,1.674h.006a.838.838,0,0,0,0-1.674h-.008Z" transform="translate(-386.63 -240.561)" fill="#fff"/>
    <path id="iconAboutP2" data-name="路径 4084" d="M53.312,62.312a9,9,0,1,0,9-9A9,9,0,0,0,53.312,62.312Zm9,7.744a7.744,7.744,0,1,1,7.744-7.744A7.744,7.744,0,0,1,62.312,70.056Z" fill="#fff"/>
  </g>
</svg>`;
