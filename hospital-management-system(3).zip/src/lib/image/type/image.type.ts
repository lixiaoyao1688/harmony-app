/**
 * 图片尺寸
 */
export interface ImageDimensionsType {
  width: number;  // 宽度 px
  height: number;  // 高度 px
}

/**
 * 图片类型
 */
export type ImageExtensionType = 'jpeg' | 'png' | 'gif';
