import html2canvas from 'html2canvas';


/**
 * 将指定DOM元素转换为图片并下载到本地
 * @param elementId - 要截图的DOM元素ID
 * @param filename - 下载的文件名，如 'screenshot.png'
 * @param bgColor - 背景颜色，默认纯白
 */
export async function captureAndDownloadElement(elementId: string, filename: string, bgColor?: string): Promise<void> {
  const el = document.getElementById(elementId);
  if (!el) {
    throw new Error('界面未渲染完成，请稍候重试');
  }
  const o = {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: bgColor || 'rgb(255,255,255)',
    allowTaint: false,
  };
  // 使用html2canvas捕获元素
  const canvas = await html2canvas(el, o);
  // 将canvas转换为data URL
  const imageData = canvas.toDataURL('image/png');
  // 创建下载链接并触发下载
  const link = document.createElement('a');
  link.href = imageData;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
