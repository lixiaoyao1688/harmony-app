import type {ImageDimensionsType} from '@/lib/image/type/image.type';


/**
 * 获取图片尺寸
 *
 * @param arrayBuffer 图片数据;
 * @param mimeType 类型，如 image/jpeg;
 *
 * resolve 图片原始宽高。
 */
export async function getImageDimensionsFromArrayBuffer(arrayBuffer: ArrayBuffer, mimeType: string): Promise<ImageDimensionsType> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([arrayBuffer], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    
    img.onload = (): void => {
      URL.revokeObjectURL(url);
      resolve({
        width: img.naturalWidth,
        height: img.naturalHeight
      });
    };
    img.onerror = (): void => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image'));
    };
    img.src = url;
  });
}

/**
 * 返回固定高度下，保持宽高比的图片宽度 px
 *
 * @param originalWidth 图片的原始宽度 px
 * @param originalHeight 图片的原始高度 px
 * @param fixedHeight 图片当前需要显示的的高度 px
 */
export function calculateScaledWidth(originalWidth: number, originalHeight: number, fixedHeight: number): number {
  return (originalWidth / originalHeight) * fixedHeight;
}


/**
 * 将图片以正确的方向绘制，然后返回新的图片数据;
 *
 * 适用场景
 * 通过网络地址得到的 arrayBuffer 产生的图片方向不对。
 *
 * @param arrayBuffer 图片的数据
 */
export async function correctImageOrientation(arrayBuffer: ArrayBuffer) {
  return new Promise<ArrayBuffer>((resolve) => {
    const blob = new Blob([arrayBuffer]);
    const img = new Image();
    const url = URL.createObjectURL(blob);
    
    img.onload = function() {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      // 设置 canvas 尺寸为图片原始尺寸
      canvas.width = img.width;
      canvas.height = img.height;
      
      if (ctx) {
        // 绘制图片（这会自动校正方向）
        ctx.drawImage(img, 0, 0);
      }
      
      canvas.toBlob((blob) => {
        if (blob) {
          blob.arrayBuffer().then(resolve);
          URL.revokeObjectURL(url);
        }
      });
    };
    
    img.src = url;
  });
}
