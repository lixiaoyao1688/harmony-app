export enum LOG_ADD_KIND {
	INSULIN = 0,  // 查看 PROJECT_NAME
}

export interface LogAddDTO {
	kind_id: LOG_ADD_KIND;  // 0-医院血糖管理平台
	content: string;  // 日志内容 不限长
	lifecycle?: string;  // VUE组件生命周期
	filename?: string;  // 报错的文件名 (包含路径)
}

export enum LOG_COLOR {
	ERROR = 'rgb(248,14,9)',
	NORMAL = 'rgb(16,192,112)',
	WARN = 'rgb(227,187,23)',
	WARN_2 = 'rgb(238,212,105)',
	PRIMARY = 'rgb(23,125,220)',
	PRIMARY_2 = 'rgb(86,173,253)',
	WARN_HARD = 'rgb(249,13,1)',
	
	NORMAL_2 = 'rgb(236,130,250)',
	NORMAL_3 = 'rgb(173,31,255)',
}
