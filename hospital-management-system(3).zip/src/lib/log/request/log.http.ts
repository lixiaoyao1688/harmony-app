import { instance } from '@/lib/http/request/http';
import { httpNoResponseCatcher, httpResponseCatcher, isHttpResponseError } from '@/lib/http/util/http.utils';
import type { LogAddDTO } from '@/lib/log/dto/log.dto';
import type { HttpResponseDTO } from '@/lib/http/dto/http.dto';


const PATH = {
  ADD: '/back/log/add'
};

enum LOG {
	ADD = '错误日志 新增'
}


export function httpLogAdd(body: LogAddDTO) {
  return new Promise<null>((resolve, reject) => {
    instance
      .post<HttpResponseDTO<null>>(PATH.ADD, body, undefined)
      .then(data => {
        if (isHttpResponseError(data)) {
          return httpResponseCatcher(data, reject);
        }
        resolve(null);
      })
      .catch(err => httpNoResponseCatcher(err, LOG.ADD, reject));
  });
}
