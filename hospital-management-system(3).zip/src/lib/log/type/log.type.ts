export interface LogError {
	message: string;
}
