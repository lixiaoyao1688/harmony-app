import {fill2Zero, fill3Zero, fill4Zero, fill5Zero, fillZero,} from '@/lib/time/util/time.util';
import {randomInEnum, randomInList, randomInRange, randomInSet} from '@/lib/math/util/math.util';


/**
 * 随机产生一个姓名
 * 注意: 用 * 保护隐私。
 */
export function MOCK_getName(): string {
  const firstNames = '赵钱孙李周吴郑王彭张丁曾胡田祁高'.split('');
  const lastNames = '忠孝仁义礼智信富强立达文武伟淮优良'.split('');
  
  return randomInList(firstNames) + '*' + randomInList(lastNames);
}

/**
 * 随机产生一个手机号
 * @param isProtected 是否保护隐私
 */
export function MOCK_getPhone(isProtected?: boolean): string {
  const r = randomInRange;
  const rs = randomInSet;
  const f3z = fill3Zero;
  return '1' + rs(new Set([3,7,8])) + r(1,9) + (isProtected ? '****' : f3z(r(0,9999))) + f3z(r(0,9999));
}

/**
 * 随机产生一个身份证号
 */
export function MOCK_getIdCard(): string {
  const r = randomInRange;
  const rs = randomInSet;
  const f3z = fill3Zero;
  const fz = fillZero;
  return '4405' + rs(new Set([24,82])) + '199' + r(1,9) + fz(r(1,12)) + fz(r(1,28)) + f3z(r(0,9999));
}

/**
 * 随机产生一个日期
 * 格式: YYYY-MM-DD;
 *
 * @param year 指定年份
 */
export function MOCK_getDateText(year?: number): string {
  const r = randomInRange;
  const fz = fillZero;
  
  const y = year || r(1950,2025);
  const m = fz(r(1,12));
  const d = fz(r(1,28));
  
  return `${y}-${m}-${d}`;
}

/**
 * 随机产生一个床号
 * 格式: 前缀+序号，如："XH-001";
 *
 * @param i 序号
 * @param pre 前缀
 */
export function MOCK_getBedText(i: number, pre?: string): string {
  return (pre || 'XH') + '-' + fill2Zero(i+1);
}

/**
 * 随机产生一个登记号
 */
export function MOCK_getCode(): string {
  const f = fill3Zero;
  const r = randomInRange;
  return f(r(0,9999)) + f(r(0,9999));
}

/**
 * 随机产生一个序列号
 * 格式: 1位字母+5位数字，如 "Q10123";
 */
export function MOCK_getSn(isCGM?: boolean, isEnum?: boolean): string {
  const re = randomInEnum;
  const r = randomInRange;
  const f4z = fill4Zero;
  const f5z = fill5Zero;
  
  if (isEnum) {
    return re('Q10123','Q10132','Q10156');
  }
  if (isCGM) {
    // 长度18: 6+1+6+5
    return f5z(r(0,999999)) + re('D','O','C','Y') + f5z(r(0,999999)) + f4z(r(0,99999));
  }
  return re('Q','X') + f4z(r(0,99999));
}

/**
 * 随机产生一个产品型号
 */
export function MOCK_getProductCode(): string {
  return randomInList(['AR-B200A', 'AR-B200B', 'AR-B200C', 'AR-B200D']);
}

/**
 * 随机产生一个科室名
 */
export function MOCK_getPartName(): string {
  return randomInEnum('内分泌科','消化内科','儿科','妇产科');
}

/**
 * 随机产生一个病区名
 */
export function MOCK_getAreaName(): string {
  return randomInEnum('内分泌一区','消化一区','儿科二区','妇产科二区');
}

/**
 * 随机产生一个床号
 * 格式: 数字序号，如："001"、"002";
 */
export function MOCK_getBedName(): string {
  return fill2Zero(randomInRange(1,100));
}
