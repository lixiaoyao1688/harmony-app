import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


export enum OPEN_OR_CLOSE {
  CLOSED = 0,
  OPENED = 1
}

export const OPEN_OR_CLOSE_ITEM_CLOSE = new SelectItemVO<unknown>({ id: OPEN_OR_CLOSE.CLOSED, text: '关' });
export const OPEN_OR_CLOSE_ITEM_OPENED = new SelectItemVO<unknown>({ id: OPEN_OR_CLOSE.OPENED, text: '开' });
export const OPEN_OR_CLOSE_ITEMS = [
  OPEN_OR_CLOSE_ITEM_CLOSE,
  OPEN_OR_CLOSE_ITEM_OPENED,
];
export const OPEN_OR_CLOSE_MAP = SelectItemVO.getMap(OPEN_OR_CLOSE_ITEMS);
