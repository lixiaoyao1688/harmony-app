import {OPEN_OR_CLOSE} from '@/lib/openOrClose/config/openOrClose.config';


export function isGlobalOpened(data: OPEN_OR_CLOSE): boolean {
  return data !== OPEN_OR_CLOSE.CLOSED;
}

export function isGlobalClosed(data: OPEN_OR_CLOSE): boolean {
  return data === OPEN_OR_CLOSE.CLOSED;
}
