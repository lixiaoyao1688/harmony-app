export enum ORDER {
  DESCENDING = 0,  // 倒序（降序）
  ASCENDING = 1,  // 正序（升序）
}
