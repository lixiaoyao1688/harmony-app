<template>
  <svg id="Show_Hide" data-name="Show/Hide" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <rect id="矩形_1489" data-name="矩形 1489" width="20" height="20" fill="rgba(6,6,6,0)"/>
    <g id="Icon_feather-eye-off" data-name="Icon feather-eye-off" transform="translate(1.983 1.983)">
      <path id="路径_805" data-name="路径 805" d="M11.96,11.96A6.713,6.713,0,0,1,8,13.333C3.333,13.333.667,8,.667,8A12.3,12.3,0,0,1,4.04,4.04M6.6,2.827A6.08,6.08,0,0,1,8,2.667C12.667,2.667,15.333,8,15.333,8a12.333,12.333,0,0,1-1.44,2.127m-4.48-.713A2,2,0,1,1,6.587,6.587" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.333"/>
      <path id="路径_806" data-name="路径 806" d="M.667.667,15.333,15.333" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.333"/>
    </g>
  </svg>
</template>