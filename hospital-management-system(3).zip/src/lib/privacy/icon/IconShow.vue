<template>
  <svg id="Show_Hide" data-name="Show/Hide" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
    <rect id="矩形_1489" data-name="矩形 1489" width="20" height="20" fill="rgba(255,255,255,0)"/>
    <g id="Icon_feather-eye" data-name="Icon feather-eye" transform="translate(1.983 1.983)">
      <path id="路径_803" data-name="路径 803" d="M.667,8S3.333,2.667,8,2.667,15.333,8,15.333,8,12.667,13.333,8,13.333.667,8,.667,8Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.333"/>
      <path id="路径_804" data-name="路径 804" d="M10,8A2,2,0,1,1,8,6,2,2,0,0,1,10,8Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.333"/>
    </g>
  </svg>
</template>