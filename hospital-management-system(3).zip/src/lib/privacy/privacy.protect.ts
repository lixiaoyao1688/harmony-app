/**
 * 返回保护隐私后的手机号
 */
export function getProtectedPhone(phone: string): string {
  const tail = phone.slice(-4);
  const head = phone.slice(0,-8);
  return `${head}****${tail}`;
}

/**
 * 返回保护隐私后的身份证号
 * @param data 完整身份证号，不可为空。
 */
export function getProtectedIdCard(data: string): string {
  const tail = data.slice(-4);
  const head = data.slice(0,4);
  return `${head}**********${tail}`;
}

/**
 * 返回保护隐私后的姓名
 */
export function getProtectedName(name: string): string {
  if (!name) {
    return '';
  }
  if (name.length === 1) {
    return name;
  }
  if (name.length === 2) {
    return name[0] + '*';
  }
  if (name.length === 3) {
    return name[0] + '*' + name[2];
  }
  return name.slice(0,2) + '**';
}

/**
 * 返回保护隐私后的姓名
 * by 姚伊婷 2026-05-21 16:22:06
 */
export function getProtectedNameNew(name: string): string {
  if (!name) {
    return '';
  }
  if (name.length === 1) {
    return name;
  }
  if (name.length === 2) {
    return '*' + name[1];
  }
  if (name.length === 3) {
    return name[0] + '*' + name[2];
  }
  return '**' + name.slice(-2);
}
