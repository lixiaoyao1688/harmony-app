import {isDevelopment} from '@/lib/env/utils/env.util.root';


/**
 * 获取PC端的"WS/HTTP"服务地址
 *
 * 注意:
 * 1. 从浏览器地址栏获取"通信协议"和"域名"。
 * 2. 使用默认端口.
 * 3. 和APP端的服务地址 @src\lib\app\store\app.store.ts: domain 同步修改.
 *
 * 示例
 * 1. 内网: https://192.168.1.247
 * 2. 公网: https://server.aaruy.com
 */
export function getRequestUrl(): string {
  if (isDevelopment()) {
    return process.env.VUE_APP_DEV_PROTOCOL + '://' + process.env.VUE_APP_DEV_HOST_NAME;
  }
  return location.protocol + '//' + location.hostname;
}
