import { ListNode } from '@/lib/scheduler/ListNode';


/**
 * 双向链表
 */
export class DoubleLinkedList<T> {
	
	private _head: ListNode<T> | null;
	private _tail: ListNode<T> | null;
	
	public total: number;

	constructor() {
	  this._head = null;
	  this._tail = null;
	  this.total = 0;
	}
	
	// 插入结点到链表头
	public insertAtHead(node: ListNode<T>): void {
	  if (this._head === null) {
	    this._head = node;
	    this._tail = node;
	  }
	  else {
	    let temp = this._head;
	    this._head = node;
	    temp.pre = node;
	    node.next = temp;
		  (temp as ListNode<T> | null) = null;
	  }
	  this.total++;
	}
	
	// 插入结点到链表尾
	public insertAtTail(node: ListNode<T>): void {
	  if (this._tail === null) {
	    this._head = node;
	    this._tail = node;
	  }
	  else {
		  let temp = this._tail;
	    this._tail = node;
	    temp.next = node;
	    node.pre = temp;
		  (temp as ListNode<T> | null) = null;
	  }
	  this.total++;
	}
	
	// 弹出链表尾结点
	public pop(): ListNode<T> | null {
	  if (this._tail === null) {
	    return null;
	  }
		
	  this.total--;
	  if (this._tail.pre === null) {
	    const temp = this._tail;
	    this._tail = null;
	    this._head = null;
	    return temp;
	  }
	  else {
		  const temp = this._tail;
	    this._tail = this._tail.pre;
	    this._tail.next = null;
	    temp.pre = null;
	    return temp;
	  }
		
	}
	
	// 从末尾开始弹出 count 个结点，组成一个数组返回。
	public popList(count: number): Array<ListNode<T>> {
	  if (count <= 0) {
	    return [];
	  }
		
	  const list: Array<ListNode<T>> = [];
		
	  while (count > 0) {
	    const node = this.pop();
			
	    if (node) {
	      list.push(node);
	    }
	    count--;
	  }
		
	  return list;
	}
	
	// 是否为空
	public get isEmpty(): boolean {
	  return this._head === null;
	}
	
}