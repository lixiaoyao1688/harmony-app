/**
 * 双向链表 结点
 */
export class ListNode<T> {
	
	public data: T;
	public pre: ListNode<T> | null;
	public next: ListNode<T> | null;
	
	constructor(data: T) {
	  this.data = data;
	  this.pre = null;
	  this.next = null;
	}
	
}