export class Task {
	
	private readonly _cb: Function;
	private readonly _cbFinished: Promise<void>;
	
	constructor(cb?: Function, cbf?: Promise<void>) {
	  if (cb) {
	    this._cb = cb;
	  }
	  if (cbf) {
	    this._cbFinished = cbf;
	  }
	}
	
	public run(): Promise<void> {
	  return new Promise((resolve, reject) => {
	    if (!this._cbFinished) {
	      return reject('Callback Finish Not Found');
	    }
		  if (!this._cb) {
			  return reject('Callback Not Found');
		  }
			
	    try {
	      this._cb.call(null);
		    this._cbFinished
			    .then(() => resolve())
			    .catch(reason => reject(reason));
	    }
	    catch(err) {
	      reject(err);
	    }

	  });
	}
	
}
