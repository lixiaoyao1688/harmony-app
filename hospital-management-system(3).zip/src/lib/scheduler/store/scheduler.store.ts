import { defineStore, Store } from 'pinia';
import { Task } from '@/lib/scheduler/Task';
import { ListNode } from '@/lib/scheduler/ListNode';
import { printError, printSingle } from '@/lib/log/util/log.util';
import { DoubleLinkedList } from '@/lib/scheduler/DoubleLinkedList';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';


interface State {
	queue: DoubleLinkedList<Task>;  // 任务队列
}

interface Action {
	add: (task: Task) => void; // 添加任务
  processOrder: () => Promise<void>; // 顺序执行
	processBatch: (count: number) => Promise<void>;  // 批量执行 (count: 并发任务数)
}

type Getter = {
}

export type SchedulerStoreType = Store<string, State, Getter, Action>;

// 性能优化 四、时间切片
// 将耗时的操作分成多个任务，一个任务运行完后让出主线程，给浏览器渲染视图，下一个任务留到下一帧执行。
export const useSchedulerStore = defineStore<string, State, Getter, Action>('scheduler-store', {
	
  state: () => ({
    queue: new DoubleLinkedList<Task>(),
  }),
	
  actions: {
    add(task) {
      if (document.hidden) {
        // https://developer.mozilla.org/zh-CN/docs/Web/API/Document/visibilitychange_event#%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E
        return;
      }
      this.queue.insertAtHead(new ListNode(task));
    },
    processOrder() {
      return new Promise(resolve => {
        printSingle('[顺序执行] 开始', LOG_COLOR.NORMAL_2);
        const total = this.queue.total;  // 只关注开始执行的的这一批任务，后续加入的不受理。
        let count = 0;
        
        const doWork = () => {
          printSingle(`[顺序执行] 已执行: ${count}, 总数: ${total}`, LOG_COLOR.NORMAL_2);
          if (this.queue.isEmpty || count >= total) {
            printSingle('[顺序执行] 结束', LOG_COLOR.NORMAL_2);
            resolve();
            return;
          }
          (this.queue.pop() as ListNode<Task>).data
            .run()
            .catch(reason => { printError('[ERROR PROCESS ORDER]', reason); })
            .finally(() => {
              count = count + 1;
              // 无论成功失败，都要继续下一个任务
              requestAnimationFrame(() => {
                doWork();
              });
            });
        };
        doWork();
        
      });
    },
    processBatch(taskCount) {
      return new Promise((resolve) => {
        printSingle('[批处理] 开始', LOG_COLOR.NORMAL_3);
        const total = this.queue.total;  // 只关注开始执行的的这一批任务，后续加入的不受理。
        let count = 0;
        
        const doWork = (queue: DoubleLinkedList<Task>, c: number) => {
          printSingle(`[批处理] 每批: ${taskCount}, 已处理: ${count}, 总数: ${total}`, LOG_COLOR.NORMAL_3);
          if (this.queue.isEmpty || count >= total) {
            printSingle('[批处理] 结束', LOG_COLOR.NORMAL_3);
            resolve();
            return;
          }
          const batch = queue.popList(c);
          if (batch.length > 0) {
            Promise.allSettled(batch.map(b => b.data.run()))
              .then(() => {
                count = count + c;
                requestAnimationFrame(() => {
                  doWork(queue, c);
                });
              });
          }
        };
        doWork(this.queue as DoubleLinkedList<Task>, taskCount);
      });
      

    },
  },
	
  getters: {

  }
	
});

