import { defineStore, Store } from 'pinia';
import {isScreen4KOrAbove, showScreenInfo} from '@/lib/screen/util/screen.util';
import { MIN_SCREEN_WIDTH } from '@/lib/env/config/env.screen.config';
import { isDeviceMobile } from '@/lib/env/utils/env.device.util.root';
import type { ScreenUIEventTarget } from '@/lib/screen/type/screen.type';


interface State {
	listener: ((e: UIEvent) => void) | null;
	widthPixel: number;  // 屏幕的水平像素数(px)。如: 显示器分辨率设置为 1680x1050，则 widthPixel 为 1680。
  is4KOrAbove: boolean;  // 是否4K及以上分辨率 (3840*2160)
}

interface Action {
	listen: () => void;
	stopListening: () => void;
	showInfo: () => void;
}

type Getter = {
	isMobile: () => boolean;  // 移动端 (平板/手机)
	isPC: () => boolean;  // PC端
	
	// 对应新平板
	isNewPhone: () => boolean;  // 手机
	isNewSmallPhone: () => boolean;  // 窄屏手机
	isNewLargePhone: () => boolean;  // 宽屏手机
	isPad: () => boolean;  // 新平板
	
	isPhone: () => boolean;  // 手机
	isSmallPhone: () => boolean;  // 窄屏手机
	isLargePhone: () => boolean;  // 宽屏手机
	isTablet: () => boolean;  // 平板
	
	isLaptop: () => boolean;  // 笔记本
	isSmallDesktop: () => boolean;  // 小型台式机
	isLargeDesktop: () => boolean;  // 大型台式机
	isLarge: () => boolean;  // 大屏
	
	isSmallPC: () => boolean;  // 小台式
	isLargePC: () => boolean;  // 大台式
}


export type ScreenStoreType = Store<string, State, Getter, Action>;

export const useScreenStore = defineStore<string, State, Getter, Action>('screen-store', {
	
  state: () => ({
    listener: null,
    widthPixel: window.innerWidth,
    is4KOrAbove: isScreen4KOrAbove(window.innerWidth)
  }),
	
  actions: {
	  listen() {
      this.listener = (e: UIEvent) => {
        if (!e || !e.target) {
          return;
        }
        const data = (e.target as ScreenUIEventTarget).innerWidth;
        this.widthPixel = data;
        this.is4KOrAbove = isScreen4KOrAbove(data);
      };
      window.addEventListener('resize', this.listener);
    },
	  stopListening() {
      this.widthPixel = window.innerWidth;
      if (this.listener) {
        window.removeEventListener('resize', this.listener);
      }
    },
    showInfo() {
      showScreenInfo();
    }
  },
	
  getters: {
	  isMobile() {
		  return isDeviceMobile();
	  },
    isPC() {
      return !this.isMobile;
    },
		
		
    isNewPhone() {
      return this.isMobile && (this.widthPixel >= MIN_SCREEN_WIDTH.MOBILE) && (this.widthPixel < MIN_SCREEN_WIDTH.NEW_PAD);
    },
    isNewSmallPhone() {
      return this.isNewPhone && (this.widthPixel < MIN_SCREEN_WIDTH.LARGE_PHONE);
    },
    isNewLargePhone() {
      return this.isNewPhone && (this.widthPixel >= MIN_SCREEN_WIDTH.LARGE_PHONE);
    },
    isPad() {
      return this.isMobile && (this.widthPixel >= MIN_SCREEN_WIDTH.NEW_PAD);
    },
		
		
    isPhone() {
      return this.isMobile && (this.widthPixel >= MIN_SCREEN_WIDTH.MOBILE) && (this.widthPixel < MIN_SCREEN_WIDTH.PAD);
    },
    isSmallPhone() {
      return this.isPhone && (this.widthPixel < MIN_SCREEN_WIDTH.LARGE_PHONE);
    },
    isLargePhone() {
      return this.isPhone && !this.isSmallPhone;
    },
    isTablet() {
      return this.isMobile && !this.isPhone;
    },

	  
	  isLaptop() {
		  return this.isPC && this.widthPixel < MIN_SCREEN_WIDTH.DESKTOP;
	  },
	  isSmallDesktop() {
		  return this.isPC && (this.widthPixel >= MIN_SCREEN_WIDTH.DESKTOP) && (this.widthPixel < MIN_SCREEN_WIDTH.MID_DESKTOP);
	  },
	  isLargeDesktop() {
		  return this.isPC && (this.widthPixel >= MIN_SCREEN_WIDTH.MID_DESKTOP) && (this.widthPixel < MIN_SCREEN_WIDTH.LARGE);
	  },
	  isLarge() {
		  return this.isPC && (this.widthPixel >= MIN_SCREEN_WIDTH.LARGE);
	  },
	  
	  isSmallPC() {
      return this.isPC && (this.widthPixel < MIN_SCREEN_WIDTH.MID_DESKTOP);
	  },
	  isLargePC() {
      return this.isPC && (this.widthPixel >= MIN_SCREEN_WIDTH.MID_DESKTOP);
	  }
	  
  }
	
});
