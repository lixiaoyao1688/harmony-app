export type ScreenUIEventTarget = EventTarget & { innerWidth: number };
