import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { printGroup } from '@/lib/log/util/log.util';
import {MIN_SCREEN_WIDTH} from '@/lib/env/config/env.screen.config';

export function showScreenInfo() {
  printGroup('[SCREEN]', {
    width: window.innerWidth,
    height: window.innerHeight,
    devicePixelRatio: window.devicePixelRatio
  }, LOG_COLOR.NORMAL);
}

export function isScreen4KOrAbove(data: number): boolean {
  return data >= MIN_SCREEN_WIDTH.LARGE_4K;
}
