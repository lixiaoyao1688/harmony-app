import {SelectItemVO} from '@/lib/aaruy-design/selector/vo/SelectItem.vo';


/**
 * 开始或结束 配置
 */
export enum START_OR_END {
  START = 0,
  END = 1,
}

const START_OR_END_0 = new SelectItemVO({ id: START_OR_END.START, text: '开始' });
const START_OR_END_1 = new SelectItemVO({ id: START_OR_END.END, text: '结束' });

export const START_OR_ENDS = [
  START_OR_END_0,
  START_OR_END_1
];
export const START_OR_END_MAP = SelectItemVO.getMap(START_OR_ENDS);
