export const TOKEN_KEY = 'token_hospital';
export const COOKIE_KEY = 'cookie_hospital';