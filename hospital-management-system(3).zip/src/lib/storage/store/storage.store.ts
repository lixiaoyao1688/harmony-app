import { defineStore } from 'pinia';
import {COOKIE_KEY, TOKEN_KEY} from '@/lib/storage/config/storage.config';
import { PRIVACY_POLICY_KEY } from '@/modules/about/config/privacy.policy.config';
import { USER_DOMAIN_KEY } from '@/modules/user/configs/user.domain';
import { Preferences } from '@capacitor/preferences';
import {printGroup} from '@/lib/log/util/log.util';
import {LOG_COLOR} from '@/lib/log/dto/log.dto';


interface State {
}

interface Action {
  getMobileCookie: () => Promise<string>;  // 仅mobile;
  setMobileCookie: (k: string) => Promise<void>;  // 仅mobile;
  
  getMobileToken: () =>  Promise<string>;  // 仅mobile;
  setMobileToken: (data: string) => Promise<void>;  // 仅mobile;
  hasMobileToken: () => Promise<boolean>;  // 仅mobile;
  
  getMobileDomain: () => Promise<string>;  // 获取手机存储的域名
  setMobileDomain: (data: string) => Promise<void>;  // 设置手机存储的域名
  hasMobileDomain: () => Promise<boolean>;  // 检查手机是否存储了域名
  
	setToken: (t: string) => void;  // 仅pc;
	getToken: () => string;  // 仅pc;
  hasToken: () => boolean;  // 仅pc;
  
	clear: () => void;  // 仅pc;
	clearMobile: () => Promise<null>;  // 仅mobile;
}

type Getter = {
}

export const useStorageStore = defineStore<string, State, Getter, Action>('storage', {
	
  state: () => ({
  }),
	
  actions: {
    
    async getMobileCookie() {
      const { value } = await Preferences.get({ key: COOKIE_KEY });
      return value || '';
    },
    setMobileCookie(data) {
      return Preferences.set({ key: COOKIE_KEY, value: data });
    },
    
    
    async getMobileToken() {
      const { value } = await Preferences.get({ key: TOKEN_KEY });
      // printGroup('[Token][GET]', value, LOG_COLOR.NORMAL);
      return value || '';
    },
    setMobileToken(t) {
      // printGroup('[Token][SET]', t, LOG_COLOR.NORMAL);
      return Preferences.set({ key: TOKEN_KEY, value: t });
    },
    async hasMobileToken() {
      const { value } = await Preferences.get({ key: TOKEN_KEY });
      return value !== null && value !== '';
    },
    
    
    async getMobileDomain() {
      const { value } = await Preferences.get({ key: USER_DOMAIN_KEY });
      printGroup('[USER_DOMAIN_KEY][GET]', value, LOG_COLOR.NORMAL);
      return value || '';
    },
    setMobileDomain(t) {
      printGroup('[USER_DOMAIN_KEY][SET]', t, LOG_COLOR.NORMAL);
      return Preferences.set({ key: USER_DOMAIN_KEY, value: t });
    },
    async hasMobileDomain() {
      const { value } = await Preferences.get({ key: USER_DOMAIN_KEY });
      printGroup('[USER_DOMAIN_KEY][GET]', value, LOG_COLOR.NORMAL);
      return value !== null && value !== '';
    },
    
    
    setToken(token) {
      localStorage.setItem(TOKEN_KEY, token);
    },
    getToken() {
      return localStorage.getItem(TOKEN_KEY) || '';
    },
    hasToken() {
      const key = localStorage.getItem(TOKEN_KEY);
      return key !== null && key !== '';
    },
    
    clear() {
      localStorage.setItem(TOKEN_KEY, '');
    },
    
    async clearMobile() {
      try {
        // 获取所有的 keys
        const { keys } = await Preferences.keys();
        // 遍历所有 keys 并删除那些不等于 "privacyPolicyAccepted" 的 keys
        for (const key of keys) {
          if (key !== PRIVACY_POLICY_KEY) {
            // 隐私政策这个键保存一次就再不改变，所以不清除
            await Preferences.remove({ key: key });
          }
        }
        return null;
      }
      catch (e) {
        throw Error('Preferences Clear Error: \n\n' + e);
      }
      // return Preferences.clear();
    },
  },
	
  getters: {
  }
	
});
