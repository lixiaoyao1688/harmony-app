export const FONT_WEIGHT_NORMAL = 400;
export const FONT_WEIGHT_BOLD = 700;
