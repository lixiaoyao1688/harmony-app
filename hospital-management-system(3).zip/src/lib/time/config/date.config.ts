import dayjs from 'dayjs';

// 日期格式
export const SERVER_DATE_FORMAT = 'YYYY-MM-DD';
// 缺省日期
export const SERVER_DATE_EMPTY = '1970-01-01';


export const INFINITE_DAY = dayjs().year(2100);
export const TODAY_DAY = dayjs();
export const TOMORROW_DAY = dayjs().hour(0).minute(0).second(0).millisecond(0).add(1, 'day');
