import dayjs from 'dayjs';

// 最小的日期
export const MIN_DAY = dayjs().year(1970).month(0).date(1).hour(0).minute(0).second(0).millisecond(0);
