export const HALF_MS_PER_SECOND = 500;
export const MS_PER_SECOND = 1000;
export const MS_PER_MINUTE = 60000;
export const MS_PER_HOUR = 3600000;
export const MS_PER_DAY = 86400000;

export const SECONDS_PER_MINUTE = 60;
export const MINUTES_PER_HOUR = 60;
export const HOURS_PER_DAY = 24;
export const DAYS_PER_MONTH = 30;
export const DAYS_PER_YEAR = 365;
export const ONE_MINUTE = 1;
export const FIVE_MINUTES = 5;


// 一小时的秒数
export const SECONDS_PER_HOUR = 3600;
// 一天的秒数
export const SECONDS_PER_DAY = 86400;
// 一周的秒数
export const SECONDS_PER_WEEK = 604800;
// 一个月的秒数
export const SECONDS_PER_MONTH = 2592000;
// 一年的秒数
export const SECONDS_PER_YEAR = 31104000;


// 每 4 小时 1 个刻度
export const INDEX_INTERVAL_HOURS = 4;


/**
 * === 每3分钟1个索引  === start
 */
export const MINUTES_PER_INDEX = 3;
export const MINUTES_PER_INDEX_3 = 3;
// 1个索引
export const ONE_INDEX_FOR_THREE_MINUTES = 1;
// 一天的索引数
export const THREE_MINUTE_INDEXES_PER_DAY = 480;
// 3分钟/索引，1天的索引数组
export const INDEXES_3 = Array(THREE_MINUTE_INDEXES_PER_DAY + ONE_INDEX_FOR_THREE_MINUTES).fill(0).map((_, i) => i);
// 每3分钟1个索引，一天的索引数，最后一个索引
export const THREE_MINUTE_LAST_INDEX = THREE_MINUTE_INDEXES_PER_DAY - 1;
// 1小时的索引数
export const INDEXES_PER_HOUR = 20;

// 每一段索引的秒数
export const SECONDS_PER_INDEX = 180;
/**
 * === 每3分钟1个索引  === end
 */


/**
 * === 每 15 分钟1个索引  === start
 */
// 1个索引的分钟数
export const INDEX_FIFTEEN_MINUTES = 15;
// 一天的索引数  24*60/15
export const FIFTEEN_MINUTE_INDEXES_PER_DAY = 96;
// 每 15 分钟1个索引，一天的索引数，最后一个索引
export const FIFTEEN_MINUTE_LAST_INDEX = FIFTEEN_MINUTE_INDEXES_PER_DAY - 1;
// 1小时的索引数
// export const INDEXES_PER_HOUR = 20;
// 每 4 小时 1 个刻度
// export const INDEX_INTERVAL_HOURS = 4;
// 1个索引
// export const ONE_INDEX_FOR_THREE_MINUTES = 1;
// 每一段索引的秒数
export const FIFTEEN_MINUTE_SECONDS_PER_INDEX = 900;
/**
 * === 每 15 分钟1个索引  === end
 */


/**
 * === 每 5 分钟 1 个索引  === start
 */
// 1个索引的分钟数
export const INDEX_FIVE_MINUTES = 5;
export const MINUTES_PER_INDEX_5 = 5;
// 一天的索引数, 24*60/5。（手机）屏幕水平像素数至少要有这么多，才可正常使用。（目前系统需要手机水平像素数 >= 350px）
export const FIVE_MINUTE_INDEXES_PER_DAY = 288;
// 5分钟/索引，1天的索引数组
export const INDEXES_5 = Array(FIVE_MINUTE_INDEXES_PER_DAY).fill(0).map((_, i) => i);
// 每 5 分钟 1 个索引，一天的索引数，最后一个索引
export const FIVE_MINUTE_LAST_INDEX = FIVE_MINUTE_INDEXES_PER_DAY - 1;
// 每一段索引的秒数  5*60
export const FIVE_MINUTE_SECONDS_PER_INDEX = 300;
/**
 * === 每 5 分钟 1 个索引  === end
 */



// 一天的分钟数
export const MINUTES_PER_DAY = 1440;
// 一天的分钟数组，如 [0分钟, 1分钟, 2分钟, 3分钟, ..., 59分钟, ..., 119分钟, ..., 1159分钟, ...]
export const MINUTES_ARRAY_PER_DAY = Array(MINUTES_PER_HOUR * HOURS_PER_DAY + 1).fill(0).map((_, i) => i);
// 一天的毫秒数
export const ONE_DAY_TIME_STAMP = 86400000;

// 星期 映射表
export const WEEK_MAP = new Map([
  [0, '星期天'],
  [1, '星期一'],
  [2, '星期二'],
  [3, '星期三'],
  [4, '星期四'],
  [5, '星期五'],
  [6, '星期六'],
]);

export const INVALID_TIME = 0;
