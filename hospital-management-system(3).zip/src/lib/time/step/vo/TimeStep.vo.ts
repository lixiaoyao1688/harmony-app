import dayjs, {Dayjs} from 'dayjs';
import {MINUTES_PER_HOUR} from '@/lib/time/config/time.config';
import {getNDayAfterDayjs} from '@/lib/time/util/dayjs.util';


/**
 * 时间步长 VO
 *
 * 适用场景
 * 输注设置-目标血糖、胰岛素敏感系数等
 */
export class TimeStepVO {
  
  public static MIN_INDEX = 0;
  public static MAX_INDEX = 1440;
  
  
  /**
   * 根据日期获取分钟索引
   * @param d 日期
   * @param isTomorrow 是否第二天
   * @return 分钟索引 范围: [MIN_INDEX, MAX_INDEX]
   */
  public static dayjsToMinuteIndex(d: Dayjs, isTomorrow?: boolean): number {
    if (isTomorrow) {
      return TimeStepVO.MAX_INDEX;
    }
    const h = d.hour();
    const m = d.minute();
    return Math.floor(h * MINUTES_PER_HOUR + m);
  }
  
  /**
   * 根据分钟索引获取日期
   * @param i 分钟索引
   * @return 日期 范围 [今天00:00:00,明天00:00:00]
   */
  public static minuteIndexToDayjs(i: number): Dayjs {
    if (i >= TimeStepVO.MAX_INDEX) {
      return getNDayAfterDayjs(1);
    }
    const h = Math.floor(i / MINUTES_PER_HOUR);
    const m = Math.floor(i % MINUTES_PER_HOUR);
    return dayjs().hour(h).minute(m).second(0).millisecond(0);
  }
  
}
