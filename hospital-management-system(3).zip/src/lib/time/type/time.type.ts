// 时间图表的 X 轴信息
export interface InfoX {
	// x轴的数据是一个分钟数组，有2种:
	// 1. 不跨天，如 [0,1,2,...,1439]，代表 00:00~23:59，共 1440 个点
	// 2. 跨天，如 [1078,1079,...,2517] 代表 -17:58~+17:57，共 1440 个点 (1078=17*60+58)
	// 注意: y和x在索引上一一对应
	// 如 xData:['Mon','Tue','Web']，yData:[1,2,3]
	data: Array<number>;
	
	// 分钟数组的起始时刻，如 new Date(YYYY-MM-(TODAY-1) 17:50:00)
	start: Date;
	
	// 最后一个整点对应的分钟值，如 17h 返回 2460。【(2460-1440)/60=17h】
	dataOfLastHour: number;
}


export interface DateTimeType {
	year: number;
	monthIndex: number;  // 0~11
	day: number;
	hour: number;
	minute: number;
	second: number;
}
