import dayjs, {Dayjs} from 'dayjs';
import {fillZero, timeZeroing} from '@/lib/time/util/time.util';
import {DAYS_PER_MONTH, DAYS_PER_YEAR, MINUTES_PER_HOUR} from '@/lib/time/config/time.config';
import type {NewDateRange} from '@/lib/aaruy-design/date-range-picker/types/date.range.picker.type';


export function getNowDayjs(): Dayjs {
  return dayjs();
}

export function getNDayAfterNowDayjs(n: number): Dayjs {
  return getNowDayjs().add(n, 'd');
}

export function getTodayDayjs(): Dayjs {
  return dayjs().hour(0).minute(0).second(0).millisecond(0);
}

export function getNDayAgoDayjs(n: number): Dayjs {
  return getTodayDayjs().subtract(n, 'd');
}

export function getNDayAfterDayjs(n: number): Dayjs {
  return getTodayDayjs().add(n, 'd');
}

// 解析日期
// formatText: YYYY-MM-DD;
export function getDayFromText(formatText: string): Dayjs {
  return dayjs(formatText).hour(0).minute(0).second(0).millisecond(0);
}

// 解析时间
// text: YYYY-MM-DD HH:mm:ss;
export function getDayFromServerDateTimeText(text: string, isOnlyDate?: boolean): Dayjs {
  if (isOnlyDate) {
    text = text + ' 00:00:00';
  }
  const [ymd, hms] = text.split(' ');
  const [y,mo,d] = ymd.split('-');
  const [h,mi,s] = hms.split(':');
  return dayjs().year(+y).month((+mo)-1).date(+d).hour(+h).minute(+mi).second(+s).millisecond(0);
}

// text: YYYY-MM-DD HH:mm:ss;
export function getServerTimeFromServerDateTimeText(text: string): number {
  return getDayFromServerDateTimeText(text).unix();
}

// time: 时间戳，秒;
export function getDayFromServerTime(time: number): Dayjs {
  return dayjs.unix(time);
}

// 获取分钟索引，数值区间: [0,1440]
export function getMinuteIndexFromDayjs(d: Dayjs): number {
  const h = d.hour();
  const m = d.minute();
  return Math.floor(h * MINUTES_PER_HOUR + m);
}

// （新）获取分钟索引，数值区间: [0,1440]
export function getMinuteIndexFromDayjs2(d: Dayjs): number {
  if (d.diff(getTodayDayjs(), 'd') === 1) {
    return 1440;
  }
  return Math.floor(d.hour() * MINUTES_PER_HOUR + d.minute());
}

// 获取日期
export function getDayjsFromMinuteIndex(i: number): Dayjs {
  if (i === 0) {
    return getTodayDayjs();
  }
  if (i === 1440) {
    return getNDayAfterDayjs(1);
  }
  const h = Math.floor(i / MINUTES_PER_HOUR);
  const m = Math.floor(i % MINUTES_PER_HOUR);
  return getTodayDayjs().hour(h).minute(m).second(0).millisecond(0);
}

// 获取时间范围文本
export function getRangeTextFromRange(s: Dayjs, e: Dayjs): string {
  const template = 'HH:mm';
  const startText = s.format(template);
  let endText = e.format(template);
  
  if (e.unix() === getNDayAfterDayjs(1).unix()) {
    endText = '24:00';
  }
  return `${startText}-${endText}`;
}

// bornDate: 出生日期，格式: YYYY-MM-DD;
export function getAgeTextFromBornDate(bornDate: string): string {
  const bornDay = dayjs(bornDate).hour(0).minute(0).second(0).millisecond(0);
  const today = getTodayDayjs();
  const day = today.diff(bornDay, 'day');
  
  if (day < DAYS_PER_MONTH) {
    return `${day}天`;
  }
  if (day < DAYS_PER_YEAR) {
    const m = Math.floor(day / DAYS_PER_MONTH);
    const d = Math.floor(day % DAYS_PER_MONTH);
    return `${m}个月${d}天`;
  }
  return Math.floor(day / DAYS_PER_YEAR) + '岁';
}

/**
 * 今天以前的时间不可选择，供给 a-date-picker 使用。
 * @param cur 当前时间
 */
export function getDisabledDayBeforeToday(cur: Dayjs): boolean {
  return cur && cur.unix() < getTodayDayjs().unix();
}

/**
 * 今天以后的日期不可选择，供给 a-date-picker 使用。
 * @param cur 当前日期
 */
export function getDisabledDayAfterToday(cur: Dayjs): boolean {
  return cur && timeZeroing(cur).unix() > getTodayDayjs().unix();
}

// 接收一个剩余时间的秒数，返回剩余时间的文本，格式 HH:mm:ss;
export function formatSecondsToHHMMSS(seconds: number): string {
  if (seconds < 0) {
    return '--:--:--';
  }
  if (seconds > 86400) {
    return '超过一天';
  }
  const fz = fillZero;
  const h = Math.floor(seconds / 3600);
  const remainingSecondsAfterHours = seconds % 3600;
  const m = Math.floor(remainingSecondsAfterHours / 60);
  const s = remainingSecondsAfterHours % 60;
  return `${fz(h)}:${fz(m)}:${fz(s)}`;
}


export function getDisabledDay(range: NewDateRange, maxRange: number, disabledFn?: (c: Dayjs) => boolean): (c: Dayjs) => boolean {
  return function (c: Dayjs) {
    // 返回 true 表示禁用
    // c 表示当前正在判断的日期
    
    // 不得选择今天以后的日期
    if (disabledFn && disabledFn.call(null, c)) {
      return true;
    }
    
    // base case
    if (!range || range.length < 2) {
      return false;
    }
    
    // 选中一个日期后，只能选择范围内的日期
    const [start, end] = range;
    const tooLate = (start && c.diff(start, 'days') >= maxRange);
    const tooEarly = (end && end.diff(c, 'days') >= maxRange);
    return tooEarly || tooLate;
  };
}

/**
 * 返回格式化的时间文本
 * @param time 时间戳，秒
 * @param template 格式，如 'HH:mm'等
 */
export function getTextFromTime(time: number, template: string): string {
  return dayjs.unix(time).format(template);
}
