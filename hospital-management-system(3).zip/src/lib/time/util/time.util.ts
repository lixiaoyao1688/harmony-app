import dayjs, { Dayjs } from 'dayjs';
import { isZero } from '@/lib/math/util/math.util';
import { ZERO } from '@/lib/math/config/math.config';
import { isGlobalIdCardValid } from '@/utils/global.check';
import { DateTimeType, InfoX } from '@/lib/time/type/time.type';
import {
  FIVE_MINUTES,
  MINUTES_PER_DAY,
  MINUTES_PER_HOUR,
  MS_PER_MINUTE,
  MS_PER_SECOND,
  ONE_DAY_TIME_STAMP,
  ONE_MINUTE,
  SECONDS_PER_DAY,
  SECONDS_PER_HOUR,
  SECONDS_PER_MINUTE,
  SECONDS_PER_MONTH,
  SECONDS_PER_YEAR,
  WEEK_MAP
} from '@/lib/time/config/time.config';


// 2024-03-27: 为了显示最后的刻度，x轴的data数组 比 y轴多一分钟
const MINUTES_FOR_X_DATA = MINUTES_PER_DAY + ONE_MINUTE;


/**
 * 从身份证号获取日期
 */
export function getDayjsFromIdCard(idCard: string): Dayjs {
  if (!isGlobalIdCardValid(idCard)) {
    return dayjs();
  }
  const data = idCard.substring(6, 14);  // 440524199108204514  => 19910820
  const y = +data.substring(0, 4);
  const m = +data.substring(4, 6);
  const d = +data.substring(6, 8);
  return dayjs(new Date(y, m-1, d));
}


/**
 * 根据服务端返回的格式化文本得到 Dayjs 对象。
 * @param formatText 时间文本, 格式为: "YYYY-MM-DD HH:mm:ss"
 */
export function getDayjsFromServerTimeText(formatText: string): Dayjs {
  if (!formatText) {
    return dayjs();
  }
  const [ymd, hms] = formatText.split(' ');
  const [y,m0,d] = ymd.split('-');
  const [h,m1,s] = hms.split(':');
  return dayjs().year(+y).month(Math.floor((+m0)-1)).date(+d).hour(+h).minute(+m1).second(+s).millisecond(0);
}

/**
 * 根据服务端返回的格式化文本得到 Dayjs 对象。
 * @param timeText 时间文本，格式为 "YYYY-MM-DD HH:mm:ss"
 */
export function getDayjsFromTimeText(timeText: string): Dayjs {
  const [ymd, hms] = timeText.split(' ');
  const [y,m,d] = ymd.split('-');
  const [hh,mm,ss] = hms.split(':');
  return dayjs().year(+y).month((+m)-1).date(+d).hour(+hh).minute(+mm).second(+ss).millisecond(0);
}

/**
 * 分钟转成 HH:mm 显示
 * @param min 分钟数
 */
export function minutesToHHMM(min: number): string {
  const h = Math.floor(min / MINUTES_PER_HOUR);
  const m = (min % MINUTES_PER_HOUR);
  return fillZero(h) + ':' + fillZero(m);
}

/**
 * 往数字前补0，直到满足 digit 位。
 * @param data 数字
 * @param digit 位数
 *
 * 如输入 9,3，返回 '009'。
 */
export function fillPreZero(data: number, digit: number): string {
  let dataText = data.toString();
  while (dataText.length < digit) {
    dataText = '0' + dataText;
  }
  return dataText;
}


/**
 * 数字补充前置零
 * @param num 目标数字
 */
export function fillZero(num: number): string {
  return num < 10 ? `0${num}` : num.toString();
}

/**
 * 数字补充前置两个零
 * @param num 目标数字
 */
export function fill2Zero(num: number): string {
  return num < 10 ? `00${num}` : (num < 100 ? `0${num}` : num.toString());
}

/**
 * 数字补充前置三个零
 * @param n 目标数字
 */
export function fill3Zero(n: number): string {
  return n < 10 ? `000${n}` : (n < 100 ? `00${n}` : (n < 1000 ? `0${n}` : n.toString()));
}

/**
 * 数字补充前置四个零
 * @param n 目标数字
 */
export function fill4Zero(n: number): string {
  if (n >= 10000) {
    return n.toString();
  }
  return '0' + fill3Zero(n);
}


/**
 * 数字补充前置5个零
 * @param n 目标数字
 */
export function fill5Zero(n: number): string {
  if (n >= 100000) {
    return n.toString();
  }
  return '0' + fill4Zero(n);
}


// 返回跨天的 InfoX, 以当前时刻 17:57 举例
export function getInfoXByNow(): InfoX {
  const d = new Date();
  const h = d.getHours();
  const m = d.getMinutes()+1;
  const start = MINUTES_PER_HOUR*h+m;   // 对齐服务返回的 [-17:58~17:57]
  const ms = Array(MINUTES_FOR_X_DATA).fill(start).map((_,i) => start+i);
  const end = getEnd(ms);
	
  // 图形改成整点?
  // const start = MINUTES_PER_HOUR*h;  // -17:00(start)  -17:57(pass)  +17:57(end)
	
  return {
    data: ms,
    dataOfLastHour: end,
    start: new Date(d.getTime() - ONE_DAY_TIME_STAMP),
  };
}

// 返回 "d的00:00 ~ d下一天00:00" 的 InfoX
export function getInfoXByDate(d: Date): InfoX {
  // d 恢复到 00:00:00:000 时刻
  d.setHours(ZERO);
  d.setMinutes(ZERO);
  d.setSeconds(ZERO);
  d.setMilliseconds(ZERO);
	
  return {
    data: Array(MINUTES_FOR_X_DATA).fill(ZERO).map((_, i) => i),
    dataOfLastHour: 1380,  // 23h (23 * 60  === 1380)
    start: d,
  };
}

// 最后一个整点对应的分钟值
function getEnd(ms: number[]) {
  let end = 0;
	
  for (let i = ms.length - 1; i >= 0; i--) {
    if (ms[i] % MINUTES_PER_HOUR === 0) {
      end = ms[i];
      break;
    }
  }
	
  return end;
}


/**
 * 【本地时间标准】
 * 接收一个时间字符串 YYYY-MM-DD HH:MM:SS:MIS，返回 server时刻 (单位秒)
 * 时间戳是指本地时间标准下的 1970-01-01 00:00:00 到达该时刻所经过的秒数
 *
 * 坑:
 * iphone11 上用不了 new Date(string) 和 Date.parse(string)，还是要一个一个去解析!!!!
 *
 * @param {string} text 时间字符串，如 "2023-03-27 14:37:00"
 * @return {number} server时刻，单位秒
 */
export function getServerTimeFromText(text: string): number {
  const [datePart, timePart] = text.split(' ');
  const [year, month, date] = datePart.split('-');
  const [hour, minute, second, millisecond] = timePart.split(':');
  const d = new Date();
  // 采用 本地时间 标准统一时刻
  d.setFullYear(+year); // 年份，如1970
  d.setMonth(+month - 1); // 月份索引，范围0~11, 如1月是0
  d.setDate(+date); // 日期，范围1~31, 如1日是1
  d.setHours(+hour); // 时，范围0~23, 如凌晨0时是0
  d.setMinutes(+minute); // 分，范围0~59，如25分是25
  d.setSeconds(second ? +second : 0); // 秒，范围0~59，如40秒是40
  d.setMilliseconds(millisecond ? +millisecond : 0); // 毫秒，范围0～999，如200毫秒是200

  return webTimeToServerTime(d.getTime());
}


/**
 * 返回今天 HH:mm:ss:ms 时刻的时间戳 (毫秒)
*/
export function getTodayTimestamp(h: number, m: number, s: number, ms: number): number {
  const date = new Date();
  
  date.setHours(h);
  date.setMinutes(m);
  date.setSeconds(s);
  date.setMilliseconds(ms);
  
  return date.getTime();
  
  // const y = date.getFullYear();
  // const m = fillZero(date.getMonth() + 1);
  // const d = fillZero(date.getDate());
  // 注意:
  // 当用 Date 构造函数（和 Date.parse，它们是等价的）解析日期字符串时，一定要确保输入符合 ISO 8601 格式 YYYY-MM-DDTHH:mm:ss.ssZ，否则无法在所有浏览器上运行，比如 Safari。
  // 参考 https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Date/Date#datestring
  // return new Date(`${y}-${m}-${d}T${hms}.00Z`).getTime();
}

/**
 * 返回 UTC 时区下，明天 HH:mm:ss 时刻的时间戳 (毫秒)
 */
export function getTomorrowTimestamp(h: number, m: number, s: number, ms: number) {
  return getTodayTimestamp(h,m,s,ms) + ONE_DAY_TIME_STAMP;
}

// 根据本地时间戳返回服务端使用的时间戳
export function getServerTimeFromLocalTime(ms: number): number {
  return Math.floor(ms / MS_PER_SECOND);
}



export function getDateFromServerTime(serverTime: number): Date {
  return new Date(serverTime * MS_PER_SECOND);
}


// 根据服务器的时间戳(秒)，返回 YYYY-MM-DD 格式
export function getYYYYMMDDFromTime(ms: number) {
  const date = new Date(ms);
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
	
  return `${y}-${fillZero(m)}-${fillZero(d)}`;
}

// 根据本地时间戳(毫秒)，返回 MM-DD HH:mm 格式
export function getMMDDHHmmFromTime(ms: number): string {
  return getMMDDHHmmFromServerTime(webTimeToServerTime(ms));
}

// 根据服务器的时间戳(秒)，返回 MM-DD HH:mm 格式
export function getMMDDHHmmFromServerTime(time: number) {
  const f = fillZero;
  const date = new Date(time * MS_PER_SECOND);
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const hh = date.getHours();
  const mm = date.getMinutes();
  
  return `${f(m)}-${f(d)} ${f(hh)}:${f(mm)}`;
}


// 根据服务器的时间戳(秒)，返回 YYYY-MM-DD 格式
export function getYYYYMMDDFromServerTime(time: number) {
  const date = new Date(time * MS_PER_SECOND);
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
	
  return `${y}-${fillZero(m)}-${fillZero(d)}`;
}

// 根据服务器的时间戳(秒)，返回 HH:mm:ss 格式
export function getHHmmSSFromServerTime(time: number) {
  const date = new Date(time * MS_PER_SECOND);
  const hh = date.getHours();
  const mm = date.getMinutes();
  const ss = date.getSeconds();
  return `${fillZero(hh)}:${fillZero(mm)}:${fillZero(ss)}`;
}

// 根据服务器的时间戳(秒)，返回 HH:mm 格式
export function getHHmmFromServerTime(time: number) {
  const date = new Date(serverTimeToWebTime(time));
  const hh = date.getHours();
  const mm = date.getMinutes();
  return `${fillZero(hh)}:${fillZero(mm)}`;
}

export function getChineseFromServerTime(sec: number): string {
  // 0 ~ 60s
  if (sec < SECONDS_PER_MINUTE) {
    return `${Math.floor(sec)}秒`;
  }
  // 1m0s ~ 59m59s
  if (sec < SECONDS_PER_HOUR) {
    const m = Math.floor(sec / SECONDS_PER_MINUTE);
    const s = sec % SECONDS_PER_MINUTE;
    return isZero(s) ? `${m}分钟` : `${m}分钟${s}秒`;
  }
  // 1h0m ~ 23h59m
  if (sec < SECONDS_PER_DAY) {
    const h = Math.floor(sec / SECONDS_PER_HOUR);
    const m = Math.floor((sec - (h * SECONDS_PER_HOUR)) / SECONDS_PER_MINUTE);
    return isZero(m) ? `${h}小时` : `${h}小时${m}分钟`;
  }
  // 1d0h ~ xdxh
  if (sec < SECONDS_PER_MONTH) {
    const d = Math.floor(sec / SECONDS_PER_DAY);
    const h = Math.floor((sec - (d * SECONDS_PER_DAY)) / SECONDS_PER_HOUR);
    return isZero(h) ? `${d}天` : `${d}天${h}小时`;
  }
  if (sec < SECONDS_PER_YEAR) {
    const m = Math.floor(sec / SECONDS_PER_MONTH);
    const d = Math.floor((sec - (m * SECONDS_PER_MONTH)) / SECONDS_PER_DAY);
    return isZero(d) ? `${m}个月` : `${m}个月${d}天`;
  }
  
  const y = Math.floor(sec / SECONDS_PER_YEAR);
  const m = Math.floor((sec - (y * SECONDS_PER_YEAR)) / SECONDS_PER_MONTH);
  const d = Math.floor((sec - (y * SECONDS_PER_YEAR) - (m * SECONDS_PER_MONTH)) / SECONDS_PER_DAY);
  return isZero(d) ? (isZero(m) ? `${y}年` : `${y}年${m}个月`) : `${y}年${m}个月${d}天`;
}

export function getChineseTimeTextFromMinutes(minute: number): string {
  // 0m ~ 60m
  if (minute < MINUTES_PER_HOUR) {
    return `${minute}分钟`;
  }
  // 1h0m ~ 23h59m
  if (minute < MINUTES_PER_DAY) {
    const h = Math.floor(minute / MINUTES_PER_HOUR);
    const m = minute % MINUTES_PER_HOUR;
    return isZero(m) ? `${h}小时` : `${h}小时${m}分钟`;
  }
  return `${Math.floor(minute / MINUTES_PER_DAY)}天`;
}

// 根据服务器的时间戳(秒)，返回 YYYY-MM-DD HH:mm:ss 格式
export function getYYYYMMDDHHmmSSFromServerTime(time: number) {
  return getYYYYMMDDHHmmSSFromDate(new Date(serverTimeToWebTime(time)));
}

// 返回今天的 YYYY-MM-DD HH:mm:ss 格式文本
export function getYYYYMMDDHHmmSSFromToday(): string {
  return getYYYYMMDDHHmmSSFromDate(new Date());
}

// 返回今天的 HH:mm:ss
export function getHHmmSSFromToday() {
  return getHHmmSSFromDate(new Date());
}


// 返回今天的 YYYY-MM-DD
export function getYYYYMMDDFromToday(): string {
  return getYYYYMMDDFromDate(new Date());
}

// 返回今天的 YYYY年MM月DD日
export function getYYYYMMDDFromTodayCN(): string {
  return getYYYYMMDDFromDateCN(new Date());
}

// 返回今天的 星期X
export function getWeekFromTodayCN() {
  return getWeekFromDateCN(new Date());
}




// 返回某一天的 YYYY-MM-DD HH:mm:ss 格式
export function getYYYYMMDDHHmmSSFromDate(date: Date) {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const hh = date.getHours();
  const mm = date.getMinutes();
  const ss = date.getSeconds();
  return `${y}-${fillZero(m)}-${fillZero(d)} ${fillZero(hh)}:${fillZero(mm)}:${fillZero(ss)}`;
}

// 返回某一天的 HH:mm:ss
export function getHHmmSSFromDate(date: Date) {
  const hh = date.getHours();
  const mm = date.getMinutes();
  const ss = date.getSeconds();
  return `${fillZero(hh)}:${fillZero(mm)}:${fillZero(ss)}`;
}

// 返回某一天的 YYYY年MM月DD日
export function getYYYYMMDDFromDateCN(date: Date) {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  return `${y}年${fillZero(m)}月${fillZero(d)}日`;
}
// 返回某一天的 YYYY-MM-DD
export function getYYYYMMDDFromDate(date: Date): string {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  return `${y}-${fillZero(m)}-${fillZero(d)}`;
}


export function serverTimeToWebTime(serverTimeSeconds: number): number {
  return serverTimeSeconds * MS_PER_SECOND;
}

export function webTimeToServerTime(ms: number): number {
  return Math.floor(ms / MS_PER_SECOND);
}


export function msToMinutes(ms: number): number {
  return Math.floor(ms / MS_PER_MINUTE);
}



// 返回某一天的 星期X
export function getWeekFromDateCN(date: Date) {
  const w = date.getDay();
  return WEEK_MAP.get(w) || '';
}



// 返回 "mm.dd"
export function getMMDotDDFromDate(d: Date): string {
  return `${fillZero(d.getMonth() + 1)}.${fillZero(d.getDate())}`;
}

// 返回中文格式的日期，如 "x月x日"
export function getMMDDFromDate(d: Date) {
  return `${fillZero(d.getMonth() + 1)}月${fillZero(d.getDate())}日`;
}




// 根据分隔符返回，如 "05-01", "05/01"
export function getMMDDFromServerTime(serverTime: number, sign?: string): string {
  const d = getDateFromServerTime(serverTime);
  const f = fillZero;
  
  sign = sign || '-';
  
  return `${f(d.getMonth() + 1)}${sign}${f(d.getDate())}`;
}

/**
 * @param date {Date} 日期
 * @return {string}  返回 "2023/11/01" 格式的日期字符串
*/
export function getDividerYMD(date: Date): string {
  return `${date.getFullYear()}/${fillZero(date.getMonth() + 1)}/${fillZero(date.getDate())}`;
}

export function getDividerYMDAndHMS(date: Date): string {
  const ymd = getDividerYMD(date);
  const h = date.getHours();
  const m = date.getMinutes();
  const s = date.getSeconds();
  const f = fillZero;
  
  return `${ymd} ${f(h)}:${f(m)}:${f(s)}`;
}

export function getTextByMinutes(m: number): string {
  if (m < ONE_MINUTE) {
    return '刚刚';
  }
  if (m < MINUTES_PER_HOUR) {
    return m + '分前';
  }
  if (m < MINUTES_PER_DAY) {
    const h = Math.floor(m / MINUTES_PER_HOUR);
    return`${h}小时前`;
  }
  return `${Math.floor(m / MINUTES_PER_DAY)}天前`;
}

// [[单位,值],[单位,值]]
export function baseFormatTime(sec: number, sUnit?: string, mUnit?: string, hUnit?: string, dUnit?: string): [[string, number], [string, number]] {
  sUnit = sUnit || 's';
  mUnit = mUnit || 'm';
  hUnit = hUnit || 'h';
  dUnit = dUnit || 'd';
  
  
  // 0 ~ 60s
  if (sec < SECONDS_PER_MINUTE) {
    return [[sUnit,sec], ['', 0]];
  }
  // 1m0s ~ 59m59s
  if (sec < SECONDS_PER_HOUR) {
    const m = Math.floor(sec / SECONDS_PER_MINUTE);
    const s = sec % SECONDS_PER_MINUTE;
    return [[mUnit,m], [sUnit,s]];
  }
  // 1h0m ~ 23h59m
  if (sec < SECONDS_PER_DAY) {
    const h = Math.floor(sec / SECONDS_PER_HOUR);
    const m = Math.floor((sec - (h * SECONDS_PER_HOUR)) / SECONDS_PER_MINUTE);
    return [[hUnit,h], [mUnit,m]];
  }
  // 1d0h ~ xdxh
  const d = Math.floor(sec / SECONDS_PER_DAY);
  const h = Math.floor((sec - (d * SECONDS_PER_DAY)) / SECONDS_PER_HOUR);
  return [[dUnit,d], [hUnit,h]];
}


// todo: 几个相似的逻辑统一成一个函数
export function formatTime(sec: number): string {
  if (sec === 0) {
    return '0s';
  }
  // 1s ~ 60s
  if (sec < SECONDS_PER_MINUTE) {
    const s = Math.ceil(sec);
    return `${s}s`;
  }
  // 1m0s ~ 59m59s
  if (sec < SECONDS_PER_HOUR) {
    const m = Math.floor(sec / SECONDS_PER_MINUTE);
    const s = sec % SECONDS_PER_MINUTE;
    return s === 0 ? `${m}m` : `${m}m${s}s`;
  }
  // 1h0m ~ 23h59m
  if (sec < SECONDS_PER_DAY) {
    const h = Math.floor(sec / SECONDS_PER_HOUR);
    const m = Math.floor((sec - (h * SECONDS_PER_HOUR)) / SECONDS_PER_MINUTE);
    return m === 0 ? `${h}h` : `${h}h${m}m`;
  }
  // 1d0h ~ xdxh
  if (sec < SECONDS_PER_MONTH) {
    const d = Math.floor(sec / SECONDS_PER_DAY);
    const h = Math.floor((sec - (d * SECONDS_PER_DAY)) / SECONDS_PER_HOUR);
    return h === 0 ? `${d}d` : `${d}d${h}h`;
  }
  // 1Month ~ xMonth
  if (sec < SECONDS_PER_YEAR) {
    return Math.floor(sec / SECONDS_PER_MONTH) + ' Mon';
  }
  // 1Year ~ xYear
  return Math.floor(sec / SECONDS_PER_YEAR) + ' Year';
}

export function getSecondFromHour(h: number) {
  return SECONDS_PER_HOUR * h;
}

// 从 YYYY-MM-DD HH:mm:ss 格式中取出各个位置的数字
export function getDateTimeFromText(text: string): DateTimeType | null {
  const pattern = /(\d{4})-(\d{2})-(\d{2})\s(\d{2}):(\d{2}):(\d{2})/;
  const match = pattern.exec(text);
  
  if (!match || match.length < 7) {
    return null;
  }
  
  return {
    year: +match[1],
    monthIndex: +match[2] - 1,
    day: +match[3],
    hour: +match[4],
    minute: +match[5],
    second: +match[6],
  };
}

// 获取当前时间戳 单位秒
export function getCurrentTime(): number {
  return webTimeToServerTime(new Date().getTime());
}


/**
 * 使指定日期的时刻归零
 * @param d 指定日期
 */
export function timeZeroing(d: Dayjs): Dayjs {
  return d.hour(0).minute(0).second(0).millisecond(0);
}


/**
 * 小时转分钟，保留整数
 * @param data 小时数
 */
export function hourToMinute(data: number): number {
  return Math.floor(data * MINUTES_PER_HOUR);
}
