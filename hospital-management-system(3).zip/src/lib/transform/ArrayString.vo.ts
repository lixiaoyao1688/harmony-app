/**
 * 列表序列化、反序列化转换器 VO
 */
export class ArrayStringVO<T> {
  
  private readonly _text: string;
  private readonly _list: Array<T>;
  
  constructor(s?: string, a?: Array<T>) {
    this._text = s || '';
    this._list = a || [];
  }
  
  
  // field: _list 的元素中为列表的 key;
  public getText(listField?: keyof T): string {
    if (!listField) {
      return this.text;
    }
    if (!this._list || this._list.length === 0) {
      return '';
    }
    if (typeof this._list[0] === 'object') {
      for (let i = 0, len = this._list.length; i < len; i++) {
        const it = this._list[i];
        // @ts-ignore
        if (!it[listField].join) {
          // @ts-ignore
          it[listField] = '[]';
        }
        else {
          // @ts-ignore
          it[listField] = '[' + it[listField].join(',') + ']';
        }
      }
      return '[' + this._list.map(it => JSON.stringify(it)).join(',') + ']';
    }
    return '[' + this._list.join(',') + ']';
  }
  
  
  public get text(): string {
    if (!this._list || this._list.length === 0) {
      return '';
    }
    if (typeof this._list[0] === 'object') {
      return '[' + this._list.map(it => JSON.stringify(it)).join(',') + ']';
    }
    return '[' + this._list.join(',') + ']';
  }
  
  public get list(): Array<T> {
    if (!this._text || this._text === '[]') {
      return [];
    }
    try {
      return JSON.parse(this._text);
    }
    catch (e) {
      console.error(e);
      return [];
    }
  }
  
}
