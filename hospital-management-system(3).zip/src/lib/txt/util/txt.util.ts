/**
 * 下载文本文件
 * @param {string} content - 文件内容
 * @param {string} filename - 文件名，如: download.txt
 */
export function downloadTextFile(content: string, filename: string) {
  // 创建Blob对象
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  
  // 创建下载链接
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.href = url;
  link.download = filename;
  
  // 触发下载
  document.body.appendChild(link);
  link.click();
  
  // 清理
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
