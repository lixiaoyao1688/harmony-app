<script setup lang="ts">
import dayjs, { Dayjs } from 'dayjs';
import { getDayjsTypeDate, turnToDate } from '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile';
import '@/lib/aaruy-design/date-picker/mobile/date.picker.mobile.style.css';


interface Prop {
  date: Dayjs;
  title: string;
  showPicker: boolean;
  timeColumnsType: string[];
  minDate: Dayjs;
  maxDate: Dayjs;
  tabs: string[];  // eg:['选择日期','选择时间']
}

interface Emit {
  (e: 'ok', date: Dayjs): void;
  (e: 'close'): void;
}

const getCurrTime = (date: Dayjs) => {
  let types: string[] = prop.timeColumnsType;
  let h: number, m: number, s: number;
  let arr: number[] = [];
  for (let item of types) {
    if (item === 'hour') {
      h = date.hour();
      arr.push(h);
    } else if (item === 'minute') {
      m = date.minute();
      arr.push(m);
    } else if (item === 'second') {
      s = date.second();
      arr.push(s);
    }
  }
  return arr.map(it => {
    return it.toString();
  });
};

const prop = defineProps<Prop>();
const emit = defineEmits<Emit>();
let currentDate = prop.date ? getDayjsTypeDate(prop.date) : new Date();
let currentTime = prop.date ? getCurrTime(prop.date) : new Date();
let minDate: Date = prop.minDate ? turnToDate(prop.minDate) : new Date(1950, 1, 1);
let maxDate: Date = prop.maxDate ? turnToDate(prop.maxDate) : new Date(2100, 12, 31);

function confirm(e): void {
  let d: string = e[0].selectedValues.join('-');
  let t: string = e[1].selectedValues.join(':');
  let dateTime: Dayjs = dayjs(d + t);
  emit('ok', dateTime);
}

function onClose(): void {
  emit('close');
}
</script>

<template>
  <!--
     变更 next-step-text="确认" by 姚伊婷 2026-06-02 10:55:46 fix: http://192.168.1.236:81/redmine/issues/8813
     参考 https://vant-ui.github.io/vant/#/zh-CN/picker-group#xia-yi-bu-an-niu
  -->
  <van-popup :show="showPicker" @click-overlay="onClose" position="bottom" class="time-picker-mobile">
    <van-picker-group
        :title="title"
        :tabs="tabs"
        next-step-text="确认"
        confirm-button-text="确认"
        @confirm="confirm"
        @cancel="onClose"
    >
      <van-date-picker
          v-model="currentDate"
          :min-date="minDate"
          :max-date="maxDate"
      />
      <van-time-picker v-model="currentTime" :columns-type="timeColumnsType"/>
    </van-picker-group>
  </van-popup>
</template>
