import { defineStore } from 'pinia';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { TSocket, WS_EVENT } from '@/lib/ws/dto/ws.event.dto';
import { doWorkAfterLogout } from '@/utils/global.tool';
import { doWorkAfterWsConnected, getSocketInstance, wsGetURI, wsLogger, wsSubscribeFirst } from '@/lib/ws/util/ws.utils';
import { WS_STATUS } from '@/lib/ws/config/ws.config';
import { WS_CODE } from '@/lib/ws/dto/ws.enum.dto';
import { notifyError } from '@/lib/aaruy-design/notify/notify';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useStorageStore } from '@/lib/storage/store/storage.store';
import { printError, printSingle, sendErrorToServer } from '@/lib/log/util/log.util';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import type { WsResponseDTO } from '@/lib/ws/dto/ws.dto';


const WS_RECONNECT_DELAY = 1000;

// gpt: WS 连接需要全局只保留一条，避免 Android 熄屏恢复后旧连接和新连接同时重连。
let wsConnectId = 0;
let wsConnectPromise: Promise<void> | null = null;
let wsReconnectTimer: ReturnType<typeof setTimeout> | null = null;

// gpt: PC/APP 当前都可能走不同 token 存储位置，统一封装后重连逻辑不用分叉两套。
function getWsToken(): Promise<string> {
  const storageStore = useStorageStore();
  if (isWebHttpUsing()) {
    return Promise.resolve(storageStore.getToken());
  }
  return storageStore.getMobileToken();
}

// gpt: 判断是否需要重连时也必须按当前运行端读取 token，避免误判为主动退出。
function hasWsToken(): Promise<boolean> {
  const storageStore = useStorageStore();
  if (isWebHttpUsing()) {
    return Promise.resolve(storageStore.hasToken());
  }
  return storageStore.hasMobileToken();
}

// gpt: 手动重连只允许存在一个 timer，防止连续 connect_error 堆出多条重连链路。
function clearReconnectTimer(): void {
  if (wsReconnectTimer) {
    clearTimeout(wsReconnectTimer);
    wsReconnectTimer = null;
  }
}

// gpt: Android 熄屏恢复时常见 timeout/websocket error，都按超时状态展示并进入同一条重连流程。
function isTimeoutError(e: any): boolean {
  const message = e && e.message ? e.message : e;
  return typeof message === 'string' && (message.includes('timeout') || message.includes('websocket error'));
}

// gpt: 创建新 socket 前必须彻底关闭旧 socket，否则旧 socket 仍会继续打印 CONNECT_ERROR。
function closeSocketInstance(s: unknown): void {
  const socket = s as TSocket | null;
  if (!socket) {
    return;
  }
  try {
    socket.removeAllListeners();
    socket.disconnect();
  }
  catch (e) {
    printError('[ERROR][WS][CLOSE]', e, useScreenStore().isMobile);
  }
}

interface State {
	socket: TSocket | null;
  isConnecting: boolean;  // 是否首次连接中
  isConnected: boolean;  // 是否连接完成
  isReconnecting: boolean;  // 是否重连中
  isTimeout: boolean;  // 连接是否超时
}

interface Action {
  init: () => Promise<void>;
	connect: (isReconnect?: boolean) => Promise<void>;
	disconnect: () => void;
  listenError: (s: TSocket) => void;
  resolveError: (s?: TSocket) => void;
	off: (event?: WS_EVENT) => void;  // 移除全部监听器
	on: (event: WS_EVENT, listener: (data: any) => void) => void;
	send: (event: WS_EVENT, payload: unknown, isMobile?: boolean) => void;
}

type Getter = {}

export const useWsStore = defineStore<string, State, Getter, Action>('ws-store', {
	
  state: () => ({
    socket: null,
    isConnecting: false,
    isConnected: false,
    isReconnecting: false,
    isTimeout: false,
  }),
	
  actions: {
    init() {
      return new Promise<void>(resolve => {
        this
          .connect()
          .then(() => {
            doWorkAfterWsConnected();
            resolve();
          })
          .catch(reason => {
            printError('[ERROR][WS]', reason);
          });
      });
    },
    
    listenError(s: TSocket) {
      const screenStore = useScreenStore();
      // 连接建立后断开
      s.on(WS_EVENT.DISCONNECT, (reason: string) => {
        // gpt: 忽略旧 socket 的迟到事件，避免已重连成功后又被旧连接拉回重连状态。
        if (s !== this.socket) {
          return;
        }
        // https://socket.io/zh-CN/docs/v4/client-api/#event-disconnect
        if (reason && reason.includes && reason.includes('timeout')) {
          this.isTimeout = true;
        }
        wsLogger(WS_STATUS.DISCONNECT, '', reason, screenStore.isMobile);
        this.resolveError(s);
      });
      // 连接建立过程中出错
      s.on(WS_EVENT.CONNECT_ERROR, (e) => {
        // gpt: 只处理当前 socket 的错误，旧 socket 的错误日志不再触发新的重连。
        if (s !== this.socket) {
          return;
        }
        if (isTimeoutError(e)) {
          // 检测到断网立即显示超时。见《GBT25000.51-2016符合性声明》 5.3.2 产品质量-性能效率-注。
          this.isTimeout = true;
        }
        wsLogger(WS_STATUS.CONNECT_ERROR, '', e, screenStore.isMobile);
        this.resolveError(s);
      });
    },
    
    resolveError(s?: TSocket) {
      if (s && s !== this.socket) {
        return;
      }
      this.isConnected = false;
      this.isConnecting = false;
      
      // 重连
      const reconnect = () => {
        // gpt: 手动重连和 socket.io 内置重连不能并行，这里保证项目侧也只调度一次。
        if (this.isReconnecting || wsReconnectTimer) {
          printSingle('System is reconnecting. Do not reconnect again.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
          return;  // 如果正在重连，不要重复连接。
        }
        this.isReconnecting = true;
        wsReconnectTimer = setTimeout(() => {
          wsReconnectTimer = null;
          printSingle('[WS] Reconnect Trying...', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
          this.connect(true)
            .then(() => {
              printSingle('[WS] Reconnected.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
              doWorkAfterWsConnected();
              console.log('subscribe after reconnected.');
              wsSubscribeFirst();
            })
            .catch(reason => printError('[ERROR][WS]', reason))
            .finally(() => {
              const connected = !!(this.socket && this.socket.connected && this.isConnected);
              if (connected) {
                printSingle('[WS] Reconnect Finished.', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
                this.isReconnecting = false;
              }
              else {
                printSingle('[WS] Reconnect Waiting...', LOG_COLOR.NORMAL_2, useScreenStore().isMobile);
                this.isReconnecting = false;
                // gpt: 当前这次没连上就重新进入同一个重连入口，而不是开第二套重连逻辑。
                this.resolveError(this.socket as TSocket || undefined);
              }
            });
        }, WS_RECONNECT_DELAY);
      };
      
      // 如果本地有 token_hospital, 则认为不是用户主动退出, 重连;
      // 如果本地没有 token_hospital, 说明是正常断开，关闭 socket 实例, 不再接收消息。
      hasWsToken()
        .then(hasToken => {
          if (!hasToken) {
            this.disconnect();
            return;
          }
          reconnect();
        })
        .catch(reason => {
          printError('[ERROR][WS][TOKEN]', reason, useScreenStore().isMobile);
          this.disconnect();
        });
    },
    
	  connect(isReconnect) {
      // gpt: 已经连接成功时直接复用，避免患者页面重复 init 时生成新 socket。
      if (this.socket && this.socket.connected && this.isConnected) {
        return Promise.resolve();
      }
      // gpt: 首次连接或重连正在进行时复用同一个 Promise，避免并发 connect。
      if (wsConnectPromise) {
        return wsConnectPromise;
      }
      
      const task = new Promise<void>((resolve, reject) => {
        const screenStore = useScreenStore();
        const currentConnectId = ++wsConnectId;
        
        if (!isReconnect) {
          this.isConnecting = true;
        }
        this.isTimeout = false;
        this.isConnected = false;
        
        getWsToken()
          .then(WS_TOKEN => {
            if (!WS_TOKEN) {
              sendErrorToServer('TOKEN ERROR', WS_TOKEN, '', 'ws.store.ts');
              this.disconnect();
              doWorkAfterLogout();
              reject(new Error('WS TOKEN ERROR'));
              return;
            }
            
            // 连接 WS
            const WS_URI = wsGetURI();
            printSingle(`[WS]URL: ${WS_URI}`, LOG_COLOR.NORMAL, screenStore.isMobile);
            printSingle(`[WS]TOKEN: ${WS_TOKEN}`, LOG_COLOR.NORMAL, screenStore.isMobile);
            
            // gpt: 新 socket 接管前先清掉旧 socket 的监听和连接，避免旧连接继续报错。
            closeSocketInstance(this.socket);
            const socket = getSocketInstance(WS_URI, WS_TOKEN);
            if (!socket) {
              reject(new Error('Socket Not Found'));
              return;
            }
            this.socket = socket;
            
            // gpt: connectId 用来识别当前连接批次，旧批次事件即使迟到也不再改状态。
            const isCurrentSocket = () => this.socket === socket && currentConnectId === wsConnectId;
            let onConnect = () => {};
            let onConnectError = (_e: any) => {};
            const clearConnectListeners = () => {
              socket.off(WS_EVENT.CONNECT as any, onConnect as any);
              socket.off(WS_EVENT.CONNECT_ERROR as any, onConnectError as any);
            };
            onConnect = () => {
              if (!isCurrentSocket()) {
                return;
              }
              clearConnectListeners();
              this.isConnecting = false;
              this.isTimeout = false;
              this.isConnected = true;
              resolve();
            };
            onConnectError = (e: any) => {
              if (!isCurrentSocket()) {
                return;
              }
              clearConnectListeners();
              if (isTimeoutError(e)) {
                this.isTimeout = true;
              }
              this.isConnecting = false;
              this.isConnected = false;
              reject(e);
            };
            
            socket.once(WS_EVENT.CONNECT as any, onConnect as any);
            socket.once(WS_EVENT.CONNECT_ERROR as any, onConnectError as any);
            
            // 离线通知
            socket.on(WS_EVENT.REPORT_OFFLINE, (data: WsResponseDTO) => {
              // gpt: 离线通知也必须限定当前 socket，防止旧连接误触发退出登录。
              if (!isCurrentSocket()) {
                return;
              }
              wsLogger(WS_STATUS.RECEIVED, WS_EVENT.REPORT_OFFLINE, data, screenStore.isMobile);
              
              const handler = (data: WsResponseDTO, message: string) => {
                notifyError(message, '请重新登录');
                doWorkAfterLogout();
              };
              
              if (data.code === WS_CODE.TOKEN_LACK) {
                handler(data, '身份验证失败');
              }
              else if (data.code === WS_CODE.OTHER_LOGIN) {
                handler(data, '用户在其他地方登录');
              }
              else if (data.code === WS_CODE.TOKEN_INVALID) {
                // 2025-08-05: 弹窗后直接退出，不调用任何接口。
                handler(data, '登录已过期');
                // requestLogout()
                //   .then(() => {
                //     doWorkAfterLogout();
                //   });
              }
            });
            // 2024-01-15: 移除WS登录操作，不需要监听登录结果了
            // socket.on(WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, (data: WsResponseDTO) => {
            // 	wsLogger(WS_STATUS.RECEIVED, WS_EVENT.SUBSCRIBE_AND_REPORT_LOGIN, data);
            // 	if (data.code !== WS_CODE.SUCCESS) {
            // 		doWorkAfterLogout();
            // 		return;
            // 	}
            // })
            
            // 处理报错
            this.listenError(socket as TSocket);
          })
          .catch(reason => {
            this.isConnecting = false;
            this.isConnected = false;
            reject(reason);
          });
      });
      
      wsConnectPromise = task;
      return task.finally(() => {
        if (wsConnectPromise === task) {
          wsConnectPromise = null;
        }
      });
	   
    },
    
	  send(event, payload, isMobile) {
		  if (!this.socket) {
			  printError('[ERROR][WS]', 'Socket Not Found');
			  return;
		  }
      const storageStore = useStorageStore();
      if (isWebHttpUsing()) {
        // WEB
        const token = storageStore.getToken();
        const realPayload = !!payload && typeof payload === 'object' ? { ...payload, token: token } : { token: token };
        wsLogger(WS_STATUS.SEND, event, realPayload, isMobile);
        this.socket.emit(event as any, realPayload);
      }
      else {
        // APP
        storageStore.getMobileToken().then(token => {
          const realPayload = !!payload && typeof payload === 'object' ? { ...payload, token: token } : { token: token };
          wsLogger(WS_STATUS.SEND, event, realPayload, isMobile);
          this.socket ? this.socket.emit(event as any, realPayload) : null;
        });
      }
	  },
   
	  on(event, listener) {
      if (!this.socket) {
        return;
      }
      this.socket.on(event as any, listener);
	  },
   
	  off(event) {
      if (!this.socket) {
        return;
      }
      this.socket.off(event as any);
	  },
   
	  disconnect() {
      // gpt: 主动退出/页面卸载时清理所有重连状态，保证不会在登出后被 timer 拉起。
      clearReconnectTimer();
      wsConnectId++;
      wsConnectPromise = null;
      closeSocketInstance(this.socket);
      this.socket = null;
      this.isConnecting = false;
      this.isReconnecting = false;
      this.isTimeout = false;
      this.isConnected = false;
	  }
   
  }
	
});
