import { io } from 'socket.io-client';
import { LOG_COLOR } from '@/lib/log/dto/log.dto';
import { WS_CODE } from '@/lib/ws/dto/ws.enum.dto';
import { WS_STATUS } from '@/lib/ws/config/ws.config';
import { isProduction } from '@/lib/env/utils/env.util.root';
import { isWebHttpUsing } from '@/lib/env/utils/env.domain.util';
import { printGroup, printSingle } from '@/lib/log/util/log.util';
import { notifyErrorNormal, notifySuccess } from '@/lib/aaruy-design/notify/notify';
import { useScreenStore } from '@/lib/screen/store/screen.store';
import { useWsStore } from '@/lib/ws/store/ws.store';
import { useAppStore } from '@/lib/app/store/app.store';
import { wsReportWarnOne, wsReportWarns } from '@/modules/warn/request/warn.ws';
import { wsReportHospitalBoard } from '@/modules/board/requests/board.ws';
import { useCardStore } from '@/modules/admission/store/card.store';
import { TEST_HOSPITAL_PATH } from '@/lib/http/config/http.path.config';
import { wsReportAdmissionConfig, wsReportAdmissionUpdateAll, wsReportAdmissionUpdateOne } from '@/modules/admission/requests/admission.ws';
import { HTTPS_PROTOCOL_PREFIX } from '@/lib/http/config/http.protocol';
import {IS_APP} from '@/lib/app/config/app.config';
import {isValidIP} from '@/lib/env/utils/env.ip.util';
import {getRequestUrl} from '@/lib/request/util/request.util';
import type { WsResponseDTO } from '@/lib/ws/dto/ws.dto';
import type { TSocket } from '@/lib/ws/dto/ws.event.dto';


/**
 * 获取 Socket 实例
 *
 * on 20251028
 */
export function getSocketInstance(url: string, token: string): TSocket | null {
  // 已废弃，统一用 "/sio-hospital/"。2025/10/21
  // https: '/sio-hospital/';  http: '/socket.io/';
  // const PATH = isOnline(useAppStore()) ? '/sio-hospital/' : '/socket.io/';
  // 2025/06/24
  const opt = {
    transports: ['websocket'],  // ['websocket','polling']
    path: '/sio-hospital/',
    namespace: '/hospital',
    // gpt: 重连由 ws.store.ts 统一管理，避免 socket.io 内置重连和项目手动重连互相叠加。
    reconnection: false,
    reconnectionDelay: 1000,
    // timeout: 1,  // 连接超时时间，ms，仅用于测试
  };
  // 2025/05/19
  // const opt = {
  //   transports: ['polling'],
  //   path: PATH,
  //   rememberUpgrade: true,
  //   withCredentials: true,
  //   extraHeaders: {
  //     'token': token,
  //   }
  // };
  printGroup('[WS][OPTION]',{ ...opt }, LOG_COLOR.NORMAL, useScreenStore().isMobile);
  
  return io(url, opt);
  
  // // 旧方案
  // // 4.1.2
  // return io(url, {
  //   transports: ['polling'],
  //   extraHeaders: {
  //     'token': token,
  //   }
  // });
  
  // // 2.5.0
  // // return io(WS_URI, {
  // // 	transportOptions: {
  // // 		polling: {
  // // 			extraHeaders: {
  // // 				"token": WS_TOKEN
  // // 			}
  // // 		}
  // // 	}
  // // });
}
/**
 * 获取 Socket 实例 （已废弃 20251028）
 */
// export function getSocketInstance(url: string, token: string): TSocket | null {
//   // https: '/sio-hospital/';  http: '/socket.io/'
//   const PATH = isOnline(useAppStore()) ? '/sio-hospital/' : '/socket.io/';
//   // 2025/05/19
//   let opt: any = {
//     transports: ['polling'],
//     path: PATH,
//     rememberUpgrade: true,
//     withCredentials: true,
//     extraHeaders: {
//       'token': token,
//     }
//   };
//   if (USE_NEW_WS) {
//     // 2025/06/24
//     // const transports = ['websocket','polling'];
//     const transports = ['websocket'];
//     const OPTION = {
//       transports: transports,
//       path: PATH,
//       namespace: '/hospital',
//       reconnection: true,
//       reconnectionDelay: 1000,
//       // timeout: 1,  // 连接超时时间，ms，仅用于测试
//     };
//     opt = {
//       ...OPTION
//     };
//     printGroup('[WS][OPTION]', OPTION, LOG_COLOR.NORMAL, useScreenStore().isMobile);
//   }
//   return io(url, opt);
//
//   // // 旧方案
//   // // 4.1.2
//   // return io(url, {
//   //   transports: ['polling'],
//   //   extraHeaders: {
//   //     'token': token,
//   //   }
//   // });
//
//   // // 2.5.0
//   // // return io(WS_URI, {
//   // // 	transportOptions: {
//   // // 		polling: {
//   // // 			extraHeaders: {
//   // // 				"token": WS_TOKEN
//   // // 			}
//   // // 		}
//   // // 	}
//   // // });
// }


/**
 * 返回 WS 地址
 *
 * on 20251028
 *
 * 注意: (周益民 2025-10-22 10:07:39 至 周益民 2025-10-22 10:09:33)
 * PC端
 * 1. 公网/内网统一，协议用 https，端口用默认端口(443)
 * APP端
 * 1. 公网协议用 https，端口用默认端口(443)
 * 2. 内网协议用 https，端口用默认端口(443)
 * 2(已废弃 20251127). 内网协议用 http，端口用默认端口(80)
 *
 * 已废弃:
 * 1. 开发环境: .env 文件定义
 * 2. 生产环境: WEB从地址栏获取，APP分网络类型获取;
 */
export function wsGetURI(): string {
  // const suffix = isServerPathUsing() ? `/${SERVER_HOSPITAL_PATH}` : `/${TEST_HOSPITAL_PATH}`;
  const suffix = `/${TEST_HOSPITAL_PATH}`;
  if (isProduction()) {
    // 生产模式
    if (isWebHttpUsing()) {
      // PC端:
      // 2025-10-31: 公网/内网统一，协议从地址栏获取，端口用该协议的默认端口 (https:443, http:80)
      return getRequestUrl() + suffix;
      // （已废弃）公网/内网统一，协议用 https，端口用默认端口(443)
      // return HTTPS_PROTOCOL_PREFIX + location.hostname + suffix;
    }
    else {
      // APP端:
      // 1. 公网协议用 https，端口用默认端口(443)
      // 2. 内网协议用 http，端口用默认端口(80)
      return useAppStore().domain + suffix;
    }
    // // 已废弃 2025/10/21
    // // PC端
    // if (isWebHttpUsing()) {
    //   if (isOnline()) {
    //     // 线上用默认端口 (443)
    //     return 'https://' + location.hostname + suffix;
    //   }
    //   // 方案一: 本地用"地址栏的HTTP端口"
    //   // return 'http://' + location.hostname + ':' + getLocationPort() + suffix;
    //   // 方案二: 本地用"地址栏的HTTP端口+2"
    //   return 'http://' + location.hostname + ':' + Math.floor(getLocationPort() + 2) + suffix;
    // }
    // // APP端
    // const appStore = useAppStore();
    // const domain = appStore.domain;
    // if (appStore.kindItem.id === APP_KIND.IN) {
    //   // 内网端口固定(82)
    //   return domain + ':82' + suffix;
    // }
    // // 公网使用默认端口(443)
    // return domain + suffix;
  }
  else {
    // 开发模式 (和生产模式一致)
    if (IS_APP) {
      // APP端:
      if (isValidIP(process.env.VUE_APP_DEV_HOST_NAME as string)) {
        // 内网: 协议用 http，端口用默认端口(80)
        return process.env.VUE_APP_DEV_PROTOCOL_FOR_APP + '://' + process.env.VUE_APP_DEV_HOST_NAME + ':' + process.env.VUE_APP_DEV_WS_PORT_FOR_APP + suffix;
      } else {
        // 公网: 协议用 https，端口用默认端口(443)
        return process.env.VUE_APP_DEV_PROTOCOL + '://' + process.env.VUE_APP_DEV_HOST_NAME + ':' + process.env.VUE_APP_DEV_WS_PORT + suffix;
      }
    }
    else {
      // PC端
      // 2025-10-31: 公网/内网统一，协议从 .env.development 获取，端口用该协议的默认端口 (https:443, http:80)
      return getRequestUrl() + suffix;
      // （已废弃）公网/内网统一，协议用 https，端口用默认端口(443)
      // return process.env.VUE_APP_DEV_PROTOCOL + '://' + process.env.VUE_APP_DEV_HOST_NAME + suffix;
    }
    // // 已废弃 统一用默认端口 2025/10/21
    // // 含义见 ~src/lib/env/utils/env.util.root.ts;
    // const protocol = process.env.VUE_APP_DEV_PROTOCOL;
    // const hostname = process.env.VUE_APP_DEV_HOST_NAME;
    // const wsPort = process.env.VUE_APP_DEV_WS_PORT;
    // if (protocol === 'https') {
    //   // 开发模式 https 不加端口，和线上保持一致。
    //   return protocol + '://' + hostname + suffix;
    // }
    // return protocol + '://' + hostname + ':' + wsPort + suffix;
  }
}
/**
 * 返回 WS 地址 （已废弃 20251028）
 * 注意:
 * 1. 开发环境: .env 文件定义
 * 2. 生产环境: WEB从地址栏获取，APP分网络类型获取;
 */
// export function wsGetURI(): string {
//
//   // const suffix = isServerPathUsing() ? `/${SERVER_HOSPITAL_PATH}` : `/${TEST_HOSPITAL_PATH}`;
//   const suffix = `/${TEST_HOSPITAL_PATH}`;
//
//   if (isProduction()) {
//     if (isWebHttpUsing()) {
//       if (isOnline()) {
//         // 线上用默认端口 (443)
//         return 'https://' + location.hostname + suffix;
//       }
//       // 方案一: 本地用"地址栏的HTTP端口"
//       // return 'http://' + location.hostname + ':' + getLocationPort() + suffix;
//       // 方案二: 本地用"地址栏的HTTP端口+2"
//       return 'http://' + location.hostname + ':' + Math.floor(getLocationPort() + 2) + suffix;
//     }
//
//     // APP
//     const appStore = useAppStore();
//     const domain = appStore.domain;
//     if (appStore.kindItem.id === APP_KIND.IN) {
//       // 内网端口固定(82)
//       return domain + ':82' + suffix;
//     }
//     // 公网使用默认端口(443)
//     return domain + suffix;
//   }
//
//   // 含义见 ~src/lib/env/utils/env.util.root.ts;
//   const protocol = process.env.VUE_APP_DEV_PROTOCOL;
//   const hostname = process.env.VUE_APP_DEV_HOST_NAME;
//   const wsPort = process.env.VUE_APP_DEV_WS_PORT;
//   if (protocol === 'https') {
//     // 开发模式 https 不加端口，和线上保持一致。
//     return protocol + '://' + hostname + suffix;
//   }
//   return protocol + '://' + hostname + ':' + wsPort + suffix;
//
// }

// WS 日志
export function wsLogger(type: WS_STATUS, event?: string, data?: unknown, isMobile?: boolean): void {
  switch (type) {
  case WS_STATUS.OPENED: {
    printSingle('[WS][OPENED]', LOG_COLOR.NORMAL, isMobile);
    break;
  }
  case WS_STATUS.CLOSED: {
    printGroup('[WS][CLOSED]', data, LOG_COLOR.ERROR, isMobile);
    break;
  }
  case WS_STATUS.DISCONNECT: {
    printGroup('[WS][DISCONNECT]', data, LOG_COLOR.ERROR, isMobile);
    break;
  }
  case WS_STATUS.ERROR: {
    printGroup('[WS][ERROR]', { event, data }, LOG_COLOR.ERROR, isMobile);
    break;
  }
  case WS_STATUS.CONNECT_ERROR: {
    printGroup('[WS][CONNECT_ERROR]', data, LOG_COLOR.ERROR, isMobile);
    break;
  }
  case WS_STATUS.SEND: {
    printGroup(`[WS][${event}](SEND)`, data, LOG_COLOR.WARN, isMobile);
    break;
  }
  case WS_STATUS.RECEIVED:
  case WS_STATUS.RECEIVED_MOCK: {
    const text = (type === WS_STATUS.RECEIVED) ? 'RECEIVE' : 'RECEIVED_MOCK';
    const color = (type === WS_STATUS.RECEIVED) ? LOG_COLOR.PRIMARY : LOG_COLOR.WARN_HARD;
    let logData = data;
    if (typeof data === 'string' && data.includes('code')) {
      logData = JSON.parse(data);
    }
    printGroup(`[WS][${event}](${text})`, logData, color, isMobile);
    break;
  }
  default: {
    return;
  }
  }
}

// WS 响应处理器
export function wsResponseHandler(dto: WsResponseDTO, hideSuccess?: boolean): void {
  if (dto && dto.code === WS_CODE.SUCCESS) {
    if (hideSuccess) {
      return;
    }
    notifySuccess(dto.msg || '成功');
  } else {
    notifyErrorNormal(dto ? dto.msg : '');
  }
}

// gpt: doWorkAfterWsConnected 会在重连成功后再次执行，卸载监听只能注册一次。
let isBeforeUnloadListening = false;

// gpt: 抽成稳定函数引用，方便 beforeunload 只绑定同一个处理器。
function disconnectWsBeforeUnload(): void {
  console.log('disconnect ws when widow unloaded.');
  useWsStore().disconnect();  // 关闭窗口时断开 WS 连接
}

export function doWorkAfterWsConnected(): void {
  wsLogger(WS_STATUS.OPENED, '', '', useScreenStore().isMobile);
  wsListenAll();
  // gpt: 防止多次重连成功后重复 addEventListener，导致一次卸载触发多次 disconnect。
  if (!isBeforeUnloadListening) {
    window.addEventListener('beforeunload', disconnectWsBeforeUnload);
    isBeforeUnloadListening = true;
  }
}

function wsListenAll(): void {
  wsReportAdmissionUpdateAll();
  wsReportAdmissionUpdateOne();
  wsReportWarns();
  wsReportWarnOne();
  wsReportAdmissionConfig();
  wsReportHospitalBoard();
}

export function wsSubscribeFirst(): void {
  useCardStore().find();
}
